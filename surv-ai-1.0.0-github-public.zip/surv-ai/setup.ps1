# Explicit optional setup. Never enables cameras, monitoring or startup tasks.
param([switch]$LocalDetection,[switch]$Reports)
$ErrorActionPreference='Stop'
Push-Location $PSScriptRoot
try {
  $setupNode=Get-Command node -ErrorAction SilentlyContinue
  if (-not $setupNode) { throw 'Install Node.js 24.7+ from nodejs.org, then reopen PowerShell.' }
  $setupVersion=[version]((& $setupNode.Source --version) -replace '^v','')
  if ($setupVersion -lt [version]'24.7.0') { throw 'Node.js 24.7+ is required for native SQLite and Argon2id.' }
  # Scheduler can retain an older PATH. Pin this explicitly verified executable locally.
  $setupRuntime=Join-Path $PSScriptRoot '.local-runtime'
  New-Item -ItemType Directory -Path $setupRuntime -Force | Out-Null
  [IO.File]::WriteAllText((Join-Path $setupRuntime 'node-path.txt'),$setupNode.Source,[Text.UTF8Encoding]::new($false))
  if (-not (Test-Path -LiteralPath '.env')) { Copy-Item -LiteralPath '.env.example' -Destination '.env' }
  if ($LocalDetection) { & (Join-Path $PSScriptRoot 'setup-local.ps1') }
  if ($Reports) {
    $setupPython=Get-Command python -ErrorAction Stop
    & $setupPython.Source -m pip install --target .local-python --upgrade -r requirements-report.txt
    if ($LASTEXITCODE -ne 0) { throw 'PDF dependency installation failed.' }
  }
  Write-Output 'Setup ready. Start with npm start, then open http://localhost:4173/. Supply your own optional API key during onboarding.'
  Write-Output 'Camera, monitoring and Windows automatic startup remain opt-in.'
} finally { Pop-Location }
