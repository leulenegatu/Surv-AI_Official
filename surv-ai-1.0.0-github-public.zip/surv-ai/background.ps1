param([ValidateSet('Run','Start','Stop','Restart','Status')][string]$Action = 'Status')
$ErrorActionPreference = 'Stop'
$launcherRoot = [IO.Path]::GetFullPath($PSScriptRoot)
$launcherRuntime = Join-Path $launcherRoot '.local-launcher'
$launcherStatePath = Join-Path $launcherRuntime 'state.json'
$launcherShell = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'

try {
  Add-Type -Path (Join-Path $launcherRoot 'windows-launcher.cs') -ReferencedAssemblies System.Windows.Forms,System.Web.Extensions,System.Core
  if ($Action -eq 'Run') {
    exit [SurvAI.WindowsLauncher]::Run($launcherRoot,$launcherShell)
  }
  if ($Action -eq 'Stop' -or $Action -eq 'Restart') {
    [SurvAI.WindowsLauncher]::Stop($launcherRoot,30000)
    if ($Action -eq 'Stop') { Write-Output 'Surv-AI background server stopped (or was already stopped).'; exit 0 }
  }
  if ($Action -eq 'Start' -or $Action -eq 'Restart') {
    if ([SurvAI.WindowsLauncher]::IsRunning($launcherRoot)) { Write-Output 'Surv-AI is already running under the background launcher.'; exit 0 }
    $launcherStart = New-Object Diagnostics.ProcessStartInfo
    $launcherStart.FileName = Join-Path $env:SystemRoot 'System32\wscript.exe'
    $launcherStart.Arguments = '//B //NoLogo "' + (Join-Path $launcherRoot 'start-hidden.vbs') + '" -NoProfile -NonInteractive -ExecutionPolicy Bypass -WindowStyle Hidden -File "' + (Join-Path $launcherRoot 'background.ps1') + '" -Action Run'
    $launcherStart.WorkingDirectory = $launcherRoot
    $launcherStart.UseShellExecute = $true
    $launcherStart.WindowStyle = [Diagnostics.ProcessWindowStyle]::Hidden
    $launcherProcess = [Diagnostics.Process]::Start($launcherStart)
    $launcherDeadline = [DateTime]::UtcNow.AddSeconds(40)
    while ([DateTime]::UtcNow -lt $launcherDeadline) {
      if ([SurvAI.WindowsLauncher]::IsReady($launcherRoot)) { Write-Output 'Surv-AI background server is ready. Logs: .local-launcher\logs'; exit 0 }
      if ($launcherProcess.HasExited -and $launcherProcess.ExitCode -ne 0) { throw ('Background startup exited with code ' + $launcherProcess.ExitCode + '. Check .local-launcher\logs.') }
      Start-Sleep -Milliseconds 200
    }
    throw 'Startup is still pending. Check background.ps1 -Action Status and .local-launcher\logs; no second server was started.'
  }
  [SurvAI.WindowsLauncher]::Status($launcherRoot) | ConvertTo-Json
} catch {
  $launcherError = $_.Exception.Message
  try {
    if (-not (Test-Path -LiteralPath $launcherRuntime)) { New-Item -ItemType Directory -Path $launcherRuntime | Out-Null }
    Add-Content -LiteralPath (Join-Path $launcherRuntime 'launcher-errors.log') -Value ((Get-Date -Format o) + ' ' + $launcherError) -Encoding UTF8
  } catch {}
  [Console]::Error.WriteLine($launcherError)
  exit 1
}
