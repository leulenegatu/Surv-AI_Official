[CmdletBinding(SupportsShouldProcess=$true)]
param([ValidateSet('Show','Install')][string]$Action='Show',[string]$TaskName='Surv-AI Auto Start')
$ErrorActionPreference='Stop'
$startupShell=Join-Path $env:SystemRoot 'System32\wscript.exe'
$startupArguments='//B //NoLogo "'+(Join-Path $PSScriptRoot 'start-hidden.vbs')+'" -NoProfile -NonInteractive -ExecutionPolicy Bypass -WindowStyle Hidden -File "'+(Join-Path $PSScriptRoot 'background.ps1')+'" -Action Run'
if ($Action -eq 'Show') {
  [pscustomobject]@{TaskName=$TaskName;Program=$startupShell;Arguments=$startupArguments;WorkingDirectory=$PSScriptRoot;Trigger='At logon for this Windows user';LogonMode='Run only when user is logged on';ExecutionPolicy='Bypass for the launched process only'} | Format-List
  exit 0
}
foreach ($startupFile in @('start.ps1','start-hidden.vbs','background.ps1','windows-launcher.cs','windows-launcher-preload.cjs')) {
  if (-not (Test-Path -LiteralPath (Join-Path $PSScriptRoot $startupFile))) { throw ('Missing launcher source: '+$startupFile) }
}
$startupTask=Get-ScheduledTask -TaskName $TaskName -TaskPath '\' -ErrorAction SilentlyContinue
if ($startupTask -and $startupTask.Principal.LogonType.ToString() -ne 'Interactive') { throw 'This launcher needs an interactive logon task for Windows shutdown notifications and Desktop Context. Existing noninteractive task was not changed.' }
$startupAction=New-ScheduledTaskAction -Execute $startupShell -Argument $startupArguments -WorkingDirectory $PSScriptRoot
if ($PSCmdlet.ShouldProcess($TaskName,'Install the hidden Surv-AI logon launcher and preserve an existing task backup')) {
  $startupBackupDirectory=Join-Path $PSScriptRoot '.local-launcher\task-backups'
  New-Item -ItemType Directory -Path $startupBackupDirectory -Force | Out-Null
  if ($startupTask) {
    $startupBackup=Join-Path $startupBackupDirectory ((Get-Date -Format 'yyyyMMdd-HHmmss-fff')+'.xml')
    [IO.File]::WriteAllText($startupBackup,(Export-ScheduledTask -TaskName $TaskName -TaskPath '\'))
    $startupSettings=$startupTask.Settings
    $startupSettings.MultipleInstances=2 # IgnoreNew
    $startupSettings.ExecutionTimeLimit='PT0S'
    $startupSettings.AllowHardTerminate=$false
    $startupSettings.StopIfGoingOnBatteries=$false
    $startupSettings.DisallowStartIfOnBatteries=$false
    $startupSettings.StartWhenAvailable=$true
    $startupSettings.RestartCount=3
    $startupSettings.RestartInterval='PT1M'
    Set-ScheduledTask -TaskName $TaskName -TaskPath '\' -Action $startupAction -Settings $startupSettings | Out-Null
  } else {
    $startupUser=[Security.Principal.WindowsIdentity]::GetCurrent().Name
    $startupPrincipal=New-ScheduledTaskPrincipal -UserId $startupUser -LogonType Interactive -RunLevel Limited
    $startupTrigger=New-ScheduledTaskTrigger -AtLogOn -User $startupUser
    $startupSettings=New-ScheduledTaskSettingsSet -MultipleInstances IgnoreNew -ExecutionTimeLimit ([TimeSpan]::Zero) -DisallowHardTerminate -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable -RestartCount 3 -RestartInterval (New-TimeSpan -Minutes 1)
    Register-ScheduledTask -TaskName $TaskName -TaskPath '\' -Action $startupAction -Trigger $startupTrigger -Principal $startupPrincipal -Settings $startupSettings -Description 'Surv-AI hidden local server with graceful shutdown and local logs.' | Out-Null
  }
  Write-Output ('Installed '+$TaskName+'. Existing running processes were not stopped. Task XML backups: .local-launcher\task-backups')
}
