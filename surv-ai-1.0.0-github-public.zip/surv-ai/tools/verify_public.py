"""Fail closed on private paths, secret-shaped values and broken local Markdown links."""
from pathlib import Path
import argparse,hashlib,json,re
from urllib.parse import unquote,urlsplit
ROOT=Path(__file__).resolve().parents[1]
FORBIDDEN={'.git','.local-data','.local-launcher','.local-models','.local-python','.venv','node_modules','__pycache__','.test-output','output','.openai'}
PATTERNS={
 'provider-key':rb'\bsk-(?:proj-|svcacct-)?[A-Za-z0-9_-]{24,}',
 'github-token':rb'\b(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,})',
 'private-key':rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----',
 'machine-home':rb'(?i)C:[\\/]Users[\\/](?!YOUR_USERNAME|example|Public)[A-Za-z0-9_.-]+',
 'personal-email':rb'(?i)\b[A-Za-z0-9._%+-]+@(?:gmail|outlook|hotmail|yahoo)\.[a-z]+',
}
def source_paths():
 names=json.loads((ROOT/'public-files.json').read_text(encoding='utf-8'))['files']
 if len(names)!=len(set(names)):raise ValueError('Duplicate allowlist paths.')
 result=[]
 for name in names:
  relative=Path(name)
  if relative.is_absolute() or '..' in relative.parts or '\\' in name:raise ValueError('Unsafe allowlist path.')
  p=ROOT/relative
  if not p.is_file() or p.is_symlink() or not p.resolve().is_relative_to(ROOT):raise ValueError('Missing or unsafe public source: '+name)
  if any((ROOT/Path(*relative.parts[:i])).is_symlink() for i in range(1,len(relative.parts))):raise ValueError('Linked parent directory.')
  if any(part in FORBIDDEN or part.startswith('.local-') for part in relative.parts):raise ValueError('Private runtime path in allowlist.')
  if p.name.startswith('.env') and p.name!='.env.example':raise ValueError('Private environment in allowlist.')
  if p.suffix.lower() in {'.sqlite','.db','.log','.tmp','.bak','.zip','.pdf','.pem','.pfx','.key'}:raise ValueError('Unsupported public artifact: '+name)
  if p.suffix.lower() in {'.png','.webp','.svg'} and relative.parts[:2]!=('docs','screenshots'):raise ValueError('Unreviewed media location.')
  result.append(p)
 return result
def verify(clean_tree=False):
 paths=source_paths();issues=[]
 if clean_tree:
  allowed=set(paths)
  for candidate in ROOT.rglob('*'):
   if candidate.is_file() and candidate not in allowed:issues.append({'file':candidate.relative_to(ROOT).as_posix(),'category':'unreviewed-file-in-public-folder'})
 for name in ['README.md','.gitignore','.env.example','server.mjs','package.json','start.ps1','setup.ps1','src/storage.mjs','dist/index.html','dist/home.html','docs/INSTALLATION.md','docs/SECURITY-AUDIT.md']:
  if ROOT/name not in paths:issues.append({'file':name,'category':'required-source-missing'})
 for p in paths:
  relative=p.relative_to(ROOT).as_posix();data=p.read_bytes()
  if p.suffix.lower() not in {'.png','.webp'}:
   for category,pattern in PATTERNS.items():
    if re.search(pattern,data):issues.append({'file':relative,'category':category})
  if p.suffix=='.html':
   for asset in re.findall(r'<(?:script|link|img)\b[^>]*?\b(?:src|href)=["\']([^"\']+)',data.decode('utf-8-sig'),re.I):
    parsed=urlsplit(asset)
    if parsed.scheme or asset.startswith('#'):continue
    target=(ROOT/'dist'/parsed.path.lstrip('/')) if parsed.path.startswith('/') else p.parent/parsed.path
    if target.resolve() not in {v.resolve() for v in paths}:issues.append({'file':relative,'category':'missing-packaged-asset','target':asset})
  if p.suffix=='.md':
   text=data.decode('utf-8-sig')
   for target in re.findall(r'!?\[[^\]]*\]\(([^)]+)\)',text):
    target=target.split(' "',1)[0].strip('<>')
    if not target or target.startswith('#'):continue
    parsed=urlsplit(target)
    if parsed.scheme:continue
    local=(p.parent/unquote(parsed.path)).resolve()
    if not local.is_relative_to(ROOT) or not local.exists():issues.append({'file':relative,'category':'broken-local-link','target':target})
   headings=[re.sub(r'[^\w\- ]','',h.lower()).replace(' ','-') for h in re.findall(r'^#{1,6}\s+(.+)$',text,re.M)]
   for anchor in re.findall(r'\]\(#([^)]+)\)',text):
    if anchor not in headings:issues.append({'file':relative,'category':'broken-anchor','target':anchor})
 env=(ROOT/'.env.example').read_text(encoding='utf-8-sig')
 if not re.search(r'^OPENAI_API_KEY=\s*$',env,re.M):issues.append({'file':'.env.example','category':'nonempty-api-key-example'})
 if issues:raise ValueError(json.dumps(issues,indent=2))
 return {'passed':True,'files':len(paths),'bytes':sum(p.stat().st_size for p in paths),'sha256':{p.relative_to(ROOT).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}}
if __name__=='__main__':
 parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--clean-tree',action='store_true',help='Also reject unlisted files, including ignored runtime data; use before first upload.')
 result=verify(clean_tree=parser.parse_args().clean_tree);print(json.dumps({k:v for k,v in result.items() if k!='sha256'}))
