// Actual UI, isolated SQLite, synthetic records/canvas, zero provider requests.
const {chromium}=require(process.argv[2]||'playwright');
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),{pathToFileURL}=require('node:url'),{randomUUID}=require('node:crypto');
(async()=>{
 const root=path.resolve(__dirname,'..'),out=path.join(root,'.test-output/docs');fs.mkdirSync(out,{recursive:true});
 const {desktopFixture,client,ok}=await import(pathToFileURL(path.join(root,'tests/desktop-fixture.mjs')));
 const clock=Date.parse('2026-10-20T16:00:00Z');let providerCalls=0,detectorCalls=0;
 const f=await desktopFixture({apiKey:'',now:()=>clock,fetchImpl(){providerCalls++;throw Error('Documentation must not call AI');},detector:{async start(){},async inspect(){detectorCalls++;return {frameValid:true,personPresent:true,personScore:.92};},close(){}}});f.now=clock;
 const browser=await chromium.launch({channel:'msedge',headless:true,args:['--disable-gpu']}),context=await browser.newContext({viewport:{width:1600,height:1000},timezoneId:'UTC',reducedMotion:'reduce'}),page=await context.newPage(),errors=[],shots=[];
 await context.route('**/*',route=>new URL(route.request().url()).origin===f.origin?route.continue():route.abort());
 page.on('pageerror',error=>errors.push(error.message));
 await context.addInitScript(now=>{
  const OriginalDate=Date;globalThis.Date=class extends OriginalDate{constructor(...a){super(...(a.length?a:[now]));}static now(){return now;}};
  globalThis.docCameraOpens=0;
  if(!navigator.mediaDevices)return;
  Object.defineProperty(navigator.permissions,'query',{value:async()=>({state:'prompt'})});
  Object.defineProperty(navigator.mediaDevices,'enumerateDevices',{value:async()=>[{kind:'videoinput',deviceId:'synthetic-desk',groupId:'synthetic',label:'Synthetic desk camera'}]});
  Object.defineProperty(navigator.mediaDevices,'getUserMedia',{value:async()=>{
   docCameraOpens++;const canvas=document.createElement('canvas');canvas.width=960;canvas.height=540;const x=canvas.getContext('2d');
   const draw=()=>{x.fillStyle='#172a32';x.fillRect(0,0,960,540);x.fillStyle='#24434a';x.fillRect(0,0,960,350);x.fillStyle='#29443e';x.fillRect(0,350,960,190);x.fillStyle='#8d7864';x.fillRect(130,330,690,24);x.fillStyle='#b9a17b';x.fillRect(170,354,15,130);x.fillRect(760,354,15,130);x.fillStyle='#0d1920';x.fillRect(300,120,380,200);x.fillStyle='#82c6bc';x.fillRect(318,138,344,160);x.fillStyle='#2b5a59';x.fillRect(335,156,210,12);x.fillRect(335,180,280,8);x.fillRect(335,202,190,8);x.fillRect(335,226,240,8);x.fillStyle='#19272e';x.fillRect(478,320,22,30);x.fillRect(430,345,120,8);x.fillStyle='#ceb88e';x.fillRect(190,285,75,44);x.fillStyle='#254c44';x.beginPath();x.ellipse(780,240,44,70,.2,0,Math.PI*2);x.fill();x.fillStyle='#a5dec9';x.font='20px sans-serif';x.fillText('SYNTHETIC DOCUMENTATION SCENE',32,48);};draw();const timer=setInterval(draw,120);const stream=canvas.captureStream(8);const track=stream.getVideoTracks()[0];Object.defineProperty(track,'getSettings',{value:()=>({deviceId:'synthetic-desk',width:960,height:540})});track.addEventListener('ended',()=>clearInterval(timer));return stream;
  }});
 },clock);
 const capture=async(name)=>{
  await page.evaluate(()=>{let b=document.getElementById('doc-fixture-label');if(!b){b=document.createElement('div');b.id='doc-fixture-label';b.textContent='SYNTHETIC DOCUMENTATION FIXTURE · NO REAL CAMERA OR AI CALLS';Object.assign(b.style,{position:'fixed',bottom:'14px',right:'18px',zIndex:2147483647,background:'#0b171eee',color:'#9be8cc',font:'600 10px system-ui',letterSpacing:'1px',padding:'10px 14px',border:'1px solid #507568',borderRadius:'5px',pointerEvents:'none'});document.body.append(b);}});
  await page.screenshot({path:path.join(out,name+'.png'),animations:'disabled'});shots.push(name);
 };
 const go=async route=>{await page.goto(f.origin+'/workspace#'+route);try{await page.waitForFunction(()=>authState.ready,{timeout:10000});}catch(error){console.error('Synthetic fixture page state:',await page.evaluate(()=>({loading:authState.loading,authenticated:!!authState.user,error:authState.error,body:document.body.innerText.slice(0,600)})));throw error;}await page.locator('#app h1').first().waitFor();};
 try{
  await page.goto(f.origin);await page.locator('.home-hero').waitFor();await capture('01-homepage');assert.equal(await page.evaluate(()=>docCameraOpens),0);assert.equal(f.collector.samples,0);
  await page.goto(f.origin+'/workspace#onboarding');await page.locator('#app').waitFor();await page.waitForFunction(()=>document.body.innerText.includes('Welcome'));await capture('02-setup');
  await page.goto('about:blank');
  const a=await client(f,{owner:true,email:'demo@example.test'});
  await context.clearCookies();
  const browserMe=await (await context.request.get(f.origin+'/api/auth/me')).json();
  const browserLogin=await context.request.post(f.origin+'/api/auth/login',{headers:{'X-Surv-CSRF':browserMe.csrfToken},data:{email:'demo@example.test',password:'desktop synthetic fixture passphrase 2026'}});
  assert.equal(browserLogin.status(),200);assert.equal((await browserLogin.json()).user.id,a.state.user.id);
  const s=f.store.forUser(a.state.user.id);s.renameCamera('local-webcam','Desk view');const wide=s.addCamera({name:'Wide view',deviceId:'synthetic-wide'});
  const area=await ok(a.post('/api/camera-areas',{name:'Study space'}));s.updateCamera('local-webcam',{areaId:area.areas[0].id});s.updateCamera(wide.id,{areaId:area.areas[0].id,rotation:90});
  const activities=[['Reading','Study','A synthetic person appears to read a book.',['book','desk']],['Using computer','Study','A synthetic person is seated at a workstation.',['monitor','keyboard']],['Preparing tea','Kitchen','A synthetic person stands near a cup.',['cup','kettle']],['Writing notes','Study','A synthetic person appears to write in a notebook.',['notebook','pen']]];
  const records=[];
  for(let day=14;day<=20;day++)for(let i=0;i<6;i++){const activity=activities[(day+i)%activities.length],timestamp=`2026-10-${day}T${String(9+i).padStart(2,'0')}:12:00.000Z`;records.push(s.saveObservation({id:randomUUID(),timestamp,activity:activity[0],location:activity[1],description:activity[2]+' Fictional documentation data.',objects:activity[3],confidence:.88,source:'manual_ai'}));}
  for(let day=3;day<=27;day+=4)s.saveObservation({id:randomUUID(),timestamp:`2026-09-${String(day).padStart(2,'0')}T10:15:00.000Z`,activity:'Reading',location:'Study',description:'Fictional documentation observation for a completed-month report.',objects:['book'],confidence:.9,source:'manual_ai'});
  await ok(a.post('/api/privacy/settings',{timeZone:'UTC'}));
  await go('cameras');await capture('03-cameras');assert.equal(await page.evaluate(()=>docCameraOpens),0);
  await go('live');await page.getByRole('button',{name:'Enable Camera',exact:true}).first().click();await page.waitForFunction(()=>cameraReady());await capture('04-live');
  await go('overview');await capture('05-overview');
  await go('timeline');await page.evaluate(()=>{selectedDate='2026-10-20';writeHistoryDate();render();});await capture('06-history');
  await page.evaluate(id=>showSession(id),records.find(r=>r.timestamp.startsWith('2026-10-20')).id);await page.locator('#detail').waitFor({state:'visible'});await capture('07-observation');await page.keyboard.press('Escape');
  await go('analytics');await page.waitForFunction(()=>localData.analytics?.days&&!localData.analyticsError);await capture('08-analytics');
  await go('ask');await page.evaluate(async()=>{await askQuestion('What did I do this week?');document.querySelector('.query-assist').open=false;});await page.locator('.message.assistant').waitFor();await capture('09-ask');
  await go('settings');await page.waitForFunction(()=>desktopPreferences.loaded&&privacySettings.loaded&&browserPreferences.data);await page.evaluate(()=>document.querySelector('.desktop-settings').scrollIntoView({block:'start'}));await capture('10-desktop');await page.evaluate(()=>document.querySelector('.browser-settings').scrollIntoView({block:'start'}));await capture('11-browser');
  const archive=await a.post('/api/reports/monthly',{month:'2026-09',timeZone:'UTC'});assert.equal(archive.status,200,JSON.stringify(archive.data));
  await go('timeline');await page.evaluate(()=>void openMonthlyReports());await page.locator('#report-detail').waitFor({state:'visible'});await capture('12-reports');await page.keyboard.press('Escape');
  await go('usage');await page.waitForFunction(()=>document.body.innerText.includes('Usage & Cost'));await capture('13-usage');
  await go('settings');await page.waitForFunction(()=>privacySettings.loaded);await page.evaluate(()=>document.querySelector('.retention-settings').scrollIntoView({block:'start'}));await capture('14-settings');
  assert.equal(providerCalls,0);assert.equal(f.collector.samples,0);assert.deepEqual(errors,[]);
  fs.writeFileSync(path.join(out,'capture-result.json'),JSON.stringify({passed:true,shots,dimensions:[1600,1000],providerCalls,realCameraCalls:0,realDesktopCalls:0,detectorCalls,synthetic:true},null,2));
  console.log(JSON.stringify({passed:true,screenshots:shots.length,providerCalls,realCameraCalls:0}));
 } finally {await browser.close();await f.close();}
})().catch(error=>{console.error(error);process.exitCode=1;});
