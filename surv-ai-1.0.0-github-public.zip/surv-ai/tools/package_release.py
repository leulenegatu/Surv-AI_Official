"""Public-tree extension of Surv-AI's deterministic source-only release packager."""
from pathlib import Path
import argparse,hashlib,json,stat,zipfile,sys
sys.dont_write_bytecode=True
from verify_public import ROOT,verify,source_paths
def build(output_dir=None):
 checked=verify();version=json.loads((ROOT/'package.json').read_text(encoding='utf-8'))['version']
 destination=Path(output_dir).absolute() if output_dir else ROOT/'output/releases'
 for p in (destination,*destination.parents):
  if p.is_symlink():raise ValueError('Output directories must not be links.')
 destination.mkdir(parents=True,exist_ok=True)
 archive=destination/f'surv-ai-{version}-github-public.zip';checksum=archive.with_suffix('.sha256')
 if archive.is_symlink() or checksum.is_symlink():raise ValueError('Release outputs must not be links.')
 entries={p.relative_to(ROOT).as_posix():p.read_bytes() for p in source_paths()}
 manifest={'application':'Surv-AI','version':version,'kind':'clean-public-source','files':{name:{'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()} for name,data in entries.items()}}
 entries['release-manifest.json']=(json.dumps(manifest,sort_keys=True,indent=2)+'\n').encode()
 with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as output:
  for name,data in sorted(entries.items()):
   info=zipfile.ZipInfo('surv-ai/'+name,(2026,10,20,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=(stat.S_IFREG|0o644)<<16
   output.writestr(info,data,compresslevel=9)
 with zipfile.ZipFile(archive) as output:
  if output.testzip() is not None:raise ValueError('ZIP integrity failed.')
  if set(output.namelist())!={'surv-ai/'+name for name in entries}:raise ValueError('Unexpected archive contents.')
  for name,data in entries.items():
   if output.read('surv-ai/'+name)!=data:raise ValueError('Archive bytes differ from reviewed source.')
 digest=hashlib.sha256(archive.read_bytes()).hexdigest();checksum.write_text(digest+'  '+archive.name+'\n',encoding='utf-8')
 print(json.dumps({'archive':str(archive),'sourceFiles':checked['files'],'bytes':archive.stat().st_size,'sha256':digest}))
if __name__=='__main__':
 parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--output-dir',help='Optional release output directory; defaults to output/releases')
 build(parser.parse_args().output_dir)
