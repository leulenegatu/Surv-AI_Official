"""Convert real synthetic-fixture screenshots and compose the README walkthrough."""
from pathlib import Path
import json,os
from PIL import Image,ImageDraw,ImageFont
ROOT=Path(__file__).resolve().parents[1]
SOURCE=ROOT/'.test-output/docs';DEST=ROOT/'docs/screenshots'
def font(size,bold=False):
    name='segoeuib.ttf' if bold else 'segoeui.ttf'
    try:return ImageFont.truetype(str(Path(os.environ.get('SystemRoot','C:/Windows'))/'Fonts'/name),size)
    except OSError:return ImageFont.load_default()
def main():
    result=json.loads((SOURCE/'capture-result.json').read_text(encoding='utf-8'))
    assert result['passed'] and result['providerCalls']==0 and result['realCameraCalls']==0
    DEST.mkdir(parents=True,exist_ok=True)
    for name in result['shots']:
        with Image.open(SOURCE/(name+'.png')) as image:
            assert image.size==(1600,1000)
            image.convert('RGB').save(DEST/(name+'.webp'),'WEBP',quality=87,method=6,exif=b'')
    canvas=Image.new('RGB',(1800,1420),'#0b151b');draw=ImageDraw.Draw(canvas)
    draw.text((54,36),'SURV-AI',font=font(38,True),fill='#98e9ca')
    draw.text((54,91),'Your everyday, worth remembering.',font=font(26),fill='#f0f5f2')
    draw.text((54,135),'THE PRODUCT JOURNEY  /  ACTUAL APPLICATION  /  SYNTHETIC DOCUMENTATION DATA',font=font(14),fill='#91a8aa')
    sequence=[('01-homepage','01  ARRIVE','Explore the public interactive demo'),('02-setup','02  SET UP','Create a local account and preferences'),('03-cameras','03  CONFIGURE','Map cameras, orientation and Areas'),('04-live','04  OBSERVE','Explicit camera and monitoring controls'),('07-observation','05  REVIEW','Saved point-in-time evidence'),('06-history','06  RECALL','Filter retained observations by date'),('08-analytics','07  EXPLORE','Recorded activity distributions'),('12-reports','08  REFLECT','Local calendar-month PDF archives'),('13-usage','09  UNDERSTAND','Measured usage and hypothetical costs')]
    for index,(name,label,description) in enumerate(sequence):
        col=index%3;row=index//3;x=54+col*578;y=203+row*391
        draw.rounded_rectangle((x-1,y-1,x+536,y+365),radius=9,fill='#15262d',outline='#304b50')
        draw.text((x+16,y+13),label,font=font(17,True),fill='#ade7d3')
        with Image.open(DEST/(name+'.webp')) as shot:canvas.paste(shot.resize((536,335-34),Image.Resampling.LANCZOS),(x,y+45))
        draw.text((x+16,y+348),description,font=font(12),fill='#aabdc0')
    draw.text((54,1374),'Local-first records. Optional external AI. All imagery uses fictional fixtures; no real camera footage or paid requests.',font=font(17),fill='#b2c7c6')
    canvas.save(DEST/'00-walkthrough.webp','WEBP',quality=89,method=6,exif=b'')
    print(json.dumps({'screenshots':len(result['shots']),'dimensions':[1600,1000],'walkthrough':[1800,1420],'totalImageBytes':sum(p.stat().st_size for p in DEST.glob('*.webp'))}))
if __name__=='__main__':main()
