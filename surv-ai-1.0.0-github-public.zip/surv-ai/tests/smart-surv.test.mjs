import {test} from 'node:test';
import assert from 'node:assert/strict';
import {mkdtemp,rm,readFile} from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import {MonitoringPolicy} from '../src/monitoring.mjs';
import {LocalStorage} from '../src/storage.mjs';
import {SnapshotStore} from '../src/snapshot-store.mjs';
import {createServer} from '../server.mjs';

const image='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+j1ioAAAAASUVORK5CYII=';
const password='smart surv disposable fixture passphrase 2026';
const signup=email=>({displayName:'Smart Surv fixture',email,password,confirmPassword:password});
for(const smartSurv of [true,false])for(const personPresent of [true,false])test(`Smart Surv ${smartSurv?'ON':'OFF'}, person ${personPresent}: truthful detection and eligible ticket`,()=>{
  const p=new MonitoringPolicy(),s=p.start(),gate=p.checked(s,{frameValid:true,personPresent},{image},false,smartSurv);
  assert.equal(gate.personPresent,personPresent);assert.equal(p.status().personPresent,personPresent);assert.equal(gate.smartSurv,smartSurv);
  assert.equal(!!gate.ticket,!smartSurv||personPresent);assert.equal(s.telemetry.noPerson,smartSurv&&!personPresent?1:0,'only actual person-gate skips count as skips');
  if(gate.ticket){p.consume(s.id,gate.ticket,false,smartSurv);assert.throws(()=>p.consume(s.id,gate.ticket,false,smartSurv),/fresh/);}
});
for(const intervalMs of [15000,30000,60000])test(`Smart Surv OFF keeps ${intervalMs/1000}s interval, validity, shared lock and no catch-up`,()=>{
  let now=Date.now();const p=new MonitoringPolicy({now:()=>now}),s=p.start({intervalMs}),frame={frameValid:true,personPresent:false},check=busy=>p.checked(s,frame,{image},busy,false);
  assert.equal(p.checked(s,{frameValid:false,personPresent:false},{image},false,false).ticket,null);
  const first=check(false);p.consume(s.id,first.ticket,false,false);now+=intervalMs-1;assert.equal(check(false).ticket,null);now++;assert(check(false).ticket);assert.equal(check(true).ticket,null);
  now+=300000;const latest=check(false);p.consume(s.id,latest.ticket,false,false);assert.equal(check(false).ticket,null);now+=intervalMs;const locked=check(false);assert.throws(()=>p.consume(s.id,locked.ticket,true,false),/progress/);
  p.stop(s.id);assert.throws(()=>check(false),/OFF/);assert.throws(()=>p.consume(s.id,'any',false,false),/OFF/);
});
test('turning Smart Surv ON rejects an unconsumed OFF no-person ticket without falsifying its result',()=>{
  const p=new MonitoringPolicy(),s=p.start(),gate=p.checked(s,{frameValid:true,personPresent:false},{image},false,false);
  assert.throws(()=>p.consume(s.id,gate.ticket,false,true),/person/);assert.equal(p.lastRequest(s),-Infinity);assert.equal(p.status().personPresent,false);
});
test('old settings read as Smart Surv ON without a schema/row rewrite; explicit saves persist transactionally',async()=>{
  const dir=await mkdtemp(path.join(os.tmpdir(),'surv-smart-store-')),file=path.join(dir,'history.sqlite');let store=new LocalStorage(file);
  try{
    const before=store.db.prepare('SELECT * FROM app_settings').all(),schema=store.db.prepare("SELECT sql FROM sqlite_master WHERE name='app_settings'").get().sql;
    assert.equal(store.settings().smartSurv,true);assert.deepEqual(store.db.prepare('SELECT * FROM app_settings').all(),before);assert.equal(store.db.prepare("SELECT sql FROM sqlite_master WHERE name='app_settings'").get().sql,schema);
    assert.throws(()=>store.transaction(()=>{store.setSmartSurv(false);throw Error('fixture rollback');}),/rollback/);assert.deepEqual(store.db.prepare('SELECT * FROM app_settings').all(),before);assert.equal(store.settings().smartSurv,true);
    store.setInterval(30000);store.setSaveSnapshots(false);store.transaction(()=>store.setSmartSurv(false));assert.equal(store.settings().smartSurv,false);store.close();store=new LocalStorage(file);
    assert.deepEqual(store.settings(),{intervalMs:30000,saveSnapshots:false,smartSurv:false,detectionOnlyRotation:false});assert.equal(store.db.prepare('PRAGMA user_version').get().user_version,5);assert.deepEqual(store.db.prepare('PRAGMA foreign_key_check').all(),[]);
  }finally{store.close();await rm(dir,{recursive:true,force:true});}
});

async function fixture(){
  const dir=await mkdtemp(path.join(os.tmpdir(),'surv-smart-http-')),storage=new LocalStorage(path.join(dir,'db.sqlite')),snapshots=new SnapshotStore(path.join(dir,'snapshots'));
  const f={dir,storage,snapshots,now:Date.now(),person:false,valid:true,checks:0,calls:0,inFlight:0,maxInFlight:0,hold:null,release:null};
  f.server=createServer({storage,snapshots,now:()=>f.now,apiKey:'mock-only',detector:{async start(){},async inspect(){f.checks++;return {frameValid:f.valid,personPresent:f.person};},close(){}},fetchImpl:async()=>{
    f.calls++;f.maxInFlight=Math.max(f.maxInFlight,++f.inFlight);if(f.hold)await new Promise(r=>f.release=r);f.inFlight--;
    return new Response(JSON.stringify({status:'completed',output:[{type:'message',content:[{type:'output_text',text:JSON.stringify({activity:'Reading',location:'Office',description:'A person appears to be reading.',confidence:.9,objects:['person','book']})}]}]}));
  }});
  await new Promise(r=>f.server.listen(0,'127.0.0.1',r));f.origin='http://127.0.0.1:'+f.server.address().port;assert.notEqual(new URL(f.origin).port,'4173');
  f.close=async()=>{f.release?.();await new Promise(r=>f.server.close(r));await rm(dir,{recursive:true,force:true});};return f;
}
async function client(f){
  const state={cookie:'',csrf:''},request=async(route,body)=>{const res=await fetch(f.origin+route,{method:body?'POST':'GET',headers:{...(body?{'Content-Type':'application/json'}:{}),...(state.cookie?{Cookie:state.cookie}:{}),...(state.csrf?{'X-Surv-CSRF':state.csrf}:{})},...(body?{body:JSON.stringify(body)}:{})});if(res.headers.get('set-cookie'))state.cookie=res.headers.get('set-cookie').split(';')[0];const data=await res.json();if(data.csrfToken)state.csrf=data.csrfToken;return {status:res.status,data};};
  await request('/api/auth/me');return {state,request,get:r=>request(r),post:(r,b)=>request(r,b)};
}
const ok=async promise=>{const r=await promise;assert.equal(r.status,200,JSON.stringify(r.data));return r.data;};
test('real HTTP local gate runs with OFF, saves owned snapshots, preserves counters/interval/lock, and rejects OFF/disabled capture',async()=>{
  const f=await fixture();try{
    const a=await client(f);await ok(a.post('/api/auth/owner',signup('owner@example.test')));assert.equal((await ok(a.get('/api/settings'))).smartSurv,true);
    for(const value of [null,0,1,'false',{}])assert.equal((await a.post('/api/settings',{smartSurv:value})).status,400);assert(!f.storage.db.prepare('PRAGMA table_info(app_settings)').all().some(c=>c.name==='smart_surv'));
    const {sessionId}=await ok(a.post('/api/monitoring/start',{cameraActive:true})),check=()=>ok(a.post('/api/monitoring/check',{sessionId,cameraActive:true,image,timestamp:new Date(f.now).toISOString()})),analyze=ticket=>a.post('/api/automatic-analyze',{sessionId,ticket});
    assert.equal((await check()).ticket,null);assert.equal(f.calls,0);f.person=true;const detected=await check();await ok(analyze(detected.ticket));assert.equal(f.calls,1);
    await ok(a.post('/api/settings',{smartSurv:false,intervalMs:30000}));assert.equal(f.calls,1,'saving a preference never creates a request');f.person=false;f.now+=15000;assert.equal((await check()).ticket,null,'30-second minimum remains authoritative');
    f.now+=15000;const allowed=await check();assert.equal(allowed.personPresent,false);assert.equal(allowed.smartSurv,false);assert(allowed.ticket);assert.match(allowed.decision,/Smart Surv off/);assert.equal((await ok(a.get('/api/monitoring/status'))).personPresent,false);
    await ok(a.post('/api/settings',{smartSurv:true}));assert.equal((await analyze(allowed.ticket)).status,409);assert.equal(f.calls,1);
    await ok(a.post('/api/settings',{smartSurv:false}));const beforeChecks=f.checks,saved=await ok(analyze((await check()).ticket));assert.equal(f.checks,beforeChecks+1);assert.equal(f.calls,2);assert.equal(saved.observation.source,'automatic_ai');assert.equal(saved.observation.monitoringSessionId,sessionId);assert(saved.observation.snapshotRef);assert.deepEqual((await f.snapshots.get(saved.observation.snapshotRef)).data,Buffer.from(image.split(',')[1],'base64'));
    assert.equal((await analyze(allowed.ticket)).status,409);f.person=true;f.now+=30000;const offPerson=await check();assert.equal(offPerson.smartSurv,false);assert.equal(offPerson.personPresent,true);await ok(analyze(offPerson.ticket));assert.equal(f.calls,3);f.person=false;
    f.valid=false;f.now+=30000;assert.equal((await check()).ticket,null);assert.equal(f.calls,3);f.valid=true;
    f.hold=true;const held=analyze((await check()).ticket);while(!f.release)await new Promise(r=>setTimeout(r,5));f.now+=300000;assert.equal((await check()).ticket,null);assert.equal(f.calls,4);assert.equal(f.maxInFlight,1);f.hold=null;f.release();await ok(held);
    // The long blocked interval is not a queue: only the next current eligible
    // frame is sent, and the immediately following check waits for its interval.
    await ok(analyze((await check()).ticket));assert.equal(f.calls,5);assert.equal((await check()).ticket,null);
    const sessions=(await ok(a.get('/api/monitoring/sessions'))).sessions;assert.equal(sessions.length,1);assert.equal(sessions[0].api_requests,5);assert.equal(sessions[0].successful_analyses,5);assert.equal(sessions[0].no_person_skipped,1);assert.equal(sessions[0].invalid_frame_skipped,1);
    await ok(a.post('/api/monitoring/stop',{sessionId}));f.now+=30000;assert.equal((await a.post('/api/monitoring/check',{sessionId,cameraActive:true,image,timestamp:new Date(f.now).toISOString()})).status,409);assert.equal((await analyze('anything')).status,409);assert.equal(f.calls,5);
    const next=await ok(a.post('/api/monitoring/start',{cameraActive:true}));await ok(a.post('/api/cameras/local-webcam',{enabled:false}));assert.equal((await a.post('/api/automatic-analyze',{sessionId:next.sessionId,ticket:'anything'})).status,409);assert.equal((await a.post('/api/monitoring/start',{cameraActive:true})).status,400);assert.equal(f.calls,5);
  }finally{await f.close();}
});
test('two authenticated users keep independent Smart Surv settings and gates, including newly created users',async()=>{
  const f=await fixture();try{
    const a=await client(f);const owner=await ok(a.post('/api/auth/owner',signup('owner@example.test')));await ok(a.post('/api/settings',{smartSurv:false}));
    const b=await client(f);const other=await ok(b.post('/api/auth/register',signup('other@example.test')));assert.notEqual(owner.user.id,other.user.id);assert.equal((await ok(b.get('/api/settings'))).smartSurv,true);assert.equal((await ok(a.get('/api/settings'))).smartSurv,false);
    const camera=await ok(b.post('/api/cameras',{name:'Other camera',deviceId:'other-fixture'}));const one=await ok(a.post('/api/monitoring/start',{cameraActive:true})),two=await ok(b.post('/api/monitoring/start',{cameraActive:true,cameraId:camera.camera.id}));
    const frame=id=>({sessionId:id,cameraActive:true,image,timestamp:new Date(f.now).toISOString()});assert((await ok(a.post('/api/monitoring/check',frame(one.sessionId)))).ticket);assert.equal((await ok(b.post('/api/monitoring/check',frame(two.sessionId)))).ticket,null);
    assert.equal((await b.post('/api/settings',{smartSurv:false,userId:owner.user.id})).status,400);assert.equal((await b.post('/api/monitoring/check',frame(one.sessionId))).status,404);
    await ok(b.post('/api/settings',{smartSurv:false}));await ok(a.post('/api/settings',{smartSurv:true}));assert.equal((await ok(a.get('/api/settings'))).smartSurv,true);assert.equal((await ok(b.get('/api/settings'))).smartSurv,false);assert.equal(f.calls,0);
  }finally{await f.close();}
});
