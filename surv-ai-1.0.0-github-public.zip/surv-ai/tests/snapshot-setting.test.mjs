import {test} from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {randomUUID} from 'node:crypto';
import {mkdtemp,rm,readdir,readFile,writeFile} from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import {createTestServer as createServer,testFetch as fetch,stripTestOwnership} from './auth-fixture.mjs';
import {LocalStorage} from '../src/storage.mjs';
import {SnapshotStore} from '../src/snapshot-store.mjs';
const image='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+j1ioAAAAASUVORK5CYII=';
const fixture={activity:'Using computer',location:'Office',description:'Person at a computer.',confidence:.91,objects:['monitor','keyboard']};

test('v3 settings migration creates a consistent backup and preserves every existing row, setting and snapshot reference',async()=>{
  const directory=await mkdtemp(path.join(os.tmpdir(),'surv-snapshot-migration-')),filename=path.join(directory,'history.sqlite');let storage;
  try{
    storage=new LocalStorage(filename);const observation=storage.saveObservation({...fixture,id:randomUUID(),source:'manual_ai',timestamp:'2026-10-01T12:00:00.000Z',snapshotRef:randomUUID()+'.png'});storage.setInterval(60000);stripTestOwnership(storage);storage.db.exec('ALTER TABLE app_settings DROP COLUMN save_snapshots; PRAGMA user_version=3');storage.close();
    storage=new LocalStorage(filename);assert.deepEqual(storage.getObservation(observation.id),observation);assert.deepEqual(storage.settings(),{intervalMs:60000,saveSnapshots:true,smartSurv:true,detectionOnlyRotation:false});
    const backup=new DatabaseSync(storage.migrationBackup,{readOnly:true});assert.equal(backup.prepare('PRAGMA user_version').get().user_version,3);assert.equal(backup.prepare('SELECT interval_ms FROM app_settings').get().interval_ms,60000);assert.equal(backup.prepare('SELECT snapshot_ref FROM observations').get().snapshot_ref,observation.snapshotRef);backup.close();
    storage.setSaveSnapshots(false);storage.close();storage=new LocalStorage(filename);assert.equal(storage.settings().saveSnapshots,false);assert.equal(storage.migrationBackup,undefined);assert((await readdir(path.join(directory,'backups'))).filter(f=>f.endsWith('.sqlite')).length>=2);
  }finally{storage?.close();await rm(directory,{recursive:true,force:true});}
});
test('backup failure prevents a settings migration and leaves the original database readable',async()=>{
  const directory=await mkdtemp(path.join(os.tmpdir(),'surv-backup-failure-')),filename=path.join(directory,'history.sqlite');
  try{
    const storage=new LocalStorage(filename);storage.setInterval(30000);stripTestOwnership(storage);storage.db.exec('ALTER TABLE app_settings DROP COLUMN save_snapshots; PRAGMA user_version=3');storage.close();await writeFile(path.join(directory,'backups'),'Blocked directory');
    assert.throws(()=>new LocalStorage(filename),/back up/);const db=new DatabaseSync(filename,{readOnly:true});assert.equal(db.prepare('PRAGMA user_version').get().user_version,3);assert.deepEqual({...db.prepare('SELECT * FROM app_settings').get()},{id:1,interval_ms:30000});db.close();
  }finally{await rm(directory,{recursive:true,force:true});}
});
test('ON/OFF persists and affects new manual and gated automatic snapshots; existing images and metadata survive',async()=>{
  const directory=await mkdtemp(path.join(os.tmpdir(),'surv-snapshot-setting-'));let now=Date.parse('2026-10-03T14:00:00.000Z'),calls=0,server;
  const options={databasePath:path.join(directory,'history.sqlite'),snapshots:new SnapshotStore(path.join(directory,'snapshots')),now:()=>now,apiKey:'mock-only',detector:{async start(){},async inspect(){return {frameValid:true,personPresent:true};},close(){}},fetchImpl:async()=>{calls++;return new Response(JSON.stringify({status:'completed',output:[{type:'message',content:[{type:'output_text',text:JSON.stringify(fixture)}]}]}));}};
  const start=async()=>{server=createServer(options);await new Promise(r=>server.listen(0,'127.0.0.1',r));return `http://127.0.0.1:${server.address().port}`;};let origin;
  const get=async url=>(await fetch(origin+url)).json();const post=async(url,body,status=200)=>{const response=await fetch(origin+url,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});const data=await response.json();assert.equal(response.status,status,JSON.stringify(data));return data;};
  const manual=()=>({...fixture,id:randomUUID(),timestamp:new Date(now).toISOString(),source:'manual_ai',context:'Retained context'});
  try{
    origin=await start();assert.equal((await get('/api/settings')).saveSnapshots,true);
    const a=(await post('/api/observations',{observation:manual(),image})).observation;assert(a.snapshotRef);const original=await readFile(path.join(directory,'snapshots',a.snapshotRef));
    const run=await post('/api/monitoring/start',{cameraActive:true}),gate=()=>post('/api/monitoring/check',{sessionId:run.sessionId,cameraActive:true,image,timestamp:new Date(now).toISOString()});
    const automatic=async()=>{const {ticket}=await gate();return (await post('/api/automatic-analyze',{sessionId:run.sessionId,ticket})).observation;};
    const b=await automatic();assert(b.snapshotRef);const onFileCount=(await readdir(path.join(directory,'snapshots'))).length;
    await post('/api/settings',{saveSnapshots:'false'},400);await post('/api/settings',{saveSnapshots:false});assert.equal((await get('/api/settings')).intervalMs,15000);
    assert.equal((await get('/api/monitoring/status')).sessionId,run.sessionId,'changing snapshot storage does not replace or finalize a running session');
    const draft=manual(),c=(await post('/api/observations',{observation:draft,image})).observation;assert.equal(c.snapshotRef,null);assert.equal(c.description,fixture.description);assert.equal(c.context,'Retained context');assert.deepEqual(c.objects,fixture.objects);
    await post('/api/observations',{observation:draft,image});assert.equal((await get('/api/observations')).observations.length,3,'retry of a snapshotless record is idempotent');
    now+=15000;const d=await automatic();assert.equal(d.snapshotRef,null);assert.equal(d.monitoringSessionId,run.sessionId);assert.equal(d.cameraName,'Office');assert.equal(d.source,'automatic_ai');assert.equal((await readdir(path.join(directory,'snapshots'))).length,onFileCount);
    assert.deepEqual(await readFile(path.join(directory,'snapshots',a.snapshotRef)),original);assert.equal((await fetch(origin+'/api/snapshots/'+a.snapshotRef)).status,200);
    assert.equal((await post('/api/snapshots',{image,timestamp:new Date(now).toISOString()})).snapshotRef,null);
    await post('/api/monitoring/stop',{sessionId:run.sessionId});const status=await get('/api/monitoring/status');assert.equal(status.monitoring,'off');
    const preview=await get('/api/reports/preview?startDate=2026-09-27&length=7&timeZone=UTC');assert.equal(preview.total,4);assert.equal(preview.observedDays,1);const beforeCalls=calls;
    const pdf=await fetch(origin+'/api/reports/pdf',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({startDate:'2026-09-27',length:7,timeZone:'UTC'})});assert.equal(pdf.status,200);assert.equal(pdf.headers.get('content-type'),'application/pdf');assert(Buffer.from(await pdf.arrayBuffer()).subarray(0,5).equals(Buffer.from('%PDF-')));assert.equal(calls,beforeCalls);
    await new Promise(r=>server.close(r));origin=await start();assert.equal((await get('/api/settings')).saveSnapshots,false);assert.equal((await get('/api/observations')).observations.length,4);assert.equal((await fetch(origin+'/api/snapshots/'+b.snapshotRef)).status,200);
    await post('/api/settings',{saveSnapshots:true});const e=(await post('/api/observations',{observation:manual(),image})).observation;assert(e.snapshotRef);assert.equal((await readdir(path.join(directory,'snapshots'))).length,onFileCount+1);assert.equal(calls,2);
  }finally{if(server?.listening)await new Promise(r=>server.close(r));await rm(directory,{recursive:true,force:true});}
});
