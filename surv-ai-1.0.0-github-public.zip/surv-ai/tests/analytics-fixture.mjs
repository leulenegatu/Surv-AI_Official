// Synthetic evidence only; callers use disposable owned stores.
import {randomUUID} from 'node:crypto';
import {sessionContext} from '../src/usage-cost.mjs';
export const analyticsClock=Date.parse('2026-10-06T16:00:00Z');
export function seedAnalytics(store){
  store.setInterval(30000);
  const camera=store.addCamera({name:'Office',deviceId:'analytics-second'}),historical=store.addCamera({name:'Office',deviceId:'analytics-historical'});
  const create=(start,end,{id='local-webcam',name='Office',status='completed',tracked=false}={})=>{
    const s={id:randomUUID(),cameraId:id,cameraName:name,intervalMs:30000,telemetry:{requests:14,successes:12,failures:1,noPerson:70,invalid:3,lastRequest:start}};store.createSession(s,start);if(tracked)sessionContext(store,s,start);store.saveSession(s,end);if(status==='completed')store.finishSession(s.id,end);else if(status==='interrupted')store.db.prepare("UPDATE monitoring_sessions SET status='interrupted',end_reason='server_restart' WHERE id=? AND user_id=?").run(s.id,store.userId);return s;
  };
  const cross=create('2026-10-06T03:00:00Z','2026-10-06T05:00:00Z'),completed=create('2026-10-06T13:00:00Z','2026-10-06T15:00:00Z',{tracked:true}),active=create('2026-10-06T14:00:00Z','2026-10-06T15:45:00Z',{status:'active',id:camera.id}),interrupted=create('2026-10-06T14:30:00Z','2026-10-06T15:00:00Z',{status:'interrupted',id:historical.id});
  const labels=['using computer','working on computer','using computer with dual monitors','using computer at standing desk','Reading','Preparing tea','Standing at desk','Organizing documents','Writing in a notebook','Looking at a screen','Walking through the room','Stretching near the desk','Reviewing a printed page with a laptop and a notebook on the desk','<img src=x onerror=alert(1)>'];
  const save=(timestamp,activity,extra={})=>store.saveObservation({id:randomUUID(),timestamp,activity,location:'Office',description:'Synthetic visible evidence.',objects:['monitor','monitor','Monitor','notebook','object '+activity.slice(0,60)],confidence:.9,source:'manual_ai',...extra});
  for(let i=0;i<42;i++)save(new Date(Date.parse('2026-10-06T13:00:00Z')+i*120000).toISOString(),labels[i%labels.length],i%3===0?{}:{source:'automatic_ai',monitoringSessionId:completed.id,cameraId:i%2?camera.id:'local-webcam',cameraName:'Office'});
  save('2026-10-06T04:30:00Z','Reading',{source:'automatic_ai',monitoringSessionId:cross.id,cameraId:'local-webcam',cameraName:'Office'});
  save('2026-10-06T03:30:00Z','Reading',{source:'automatic_ai',monitoringSessionId:cross.id,cameraId:'local-webcam',cameraName:'Office'});
  save('2026-10-04T16:00:00Z','Preparing tea');save('2026-09-10T16:00:00Z','Archived reading');
  save('2026-10-06T14:40:00Z','Organizing documents',{source:'automatic_ai',monitoringSessionId:interrupted.id,cameraId:historical.id,cameraName:'Office'});
  const legacy=save('2026-10-06T15:00:00Z','Legacy unassigned evidence');store.db.prepare("UPDATE observations SET source='automatic_ai',legacy_imported=1 WHERE id=? AND user_id=?").run(legacy.id,store.userId);
  store.removeCamera(historical.id);return {camera,historical,cross,completed,active,interrupted,labels};
}
