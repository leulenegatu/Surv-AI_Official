import {test} from 'node:test';
import assert from 'node:assert/strict';
import {createHash,randomUUID} from 'node:crypto';
import {mkdtemp,rm,readFile,readdir} from 'node:fs/promises';
import {existsSync} from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import {fileURLToPath} from 'node:url';
import {LocalStorage} from '../src/storage.mjs';
import {AuthService} from '../src/auth.mjs';
import {SnapshotStore} from '../src/snapshot-store.mjs';
import {LocalDetector} from '../src/local-detector.mjs';
import {createServer} from '../server.mjs';
import {buildReport} from '../src/report.mjs';
import {renderReportPDF} from '../src/report-pdf.mjs';

// Release acceptance never opens the real installation. In particular, these
// fixtures pass an absent databasePath to the normal lazy server startup path.
const password='release fixture private passphrase 2026';
const now=Date.parse('2026-11-04T12:00:00.000Z');
const image='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+j1ioAAAAASUVORK5CYII=';
const digest=value=>createHash('sha256').update(value).digest('hex');
const signup=email=>({displayName:'Release Fixture',email,password,confirmPassword:password});
const sample=extra=>({id:randomUUID(),timestamp:'2019-01-15T12:00:00.000Z',activity:'Reading',description:'A person reads a book.',location:'Fixture office',confidence:.9,objects:['book'],source:'manual_ai',...extra});
const coreTables=['users','auth_identities','installation','auth_sessions','auth_throttle','observations','monitoring_sessions','cameras','app_settings'];
const hashes=store=>Object.fromEntries(coreTables.map(table=>[table,digest(JSON.stringify(store.db.prepare(`SELECT * FROM ${table} ORDER BY 1`).all()))]));
const coreSchema=store=>digest(JSON.stringify(store.db.prepare("SELECT type,name,tbl_name,sql FROM sqlite_master WHERE name NOT LIKE 'sqlite_%' ORDER BY type,name").all().filter(row=>coreTables.includes(row.tbl_name))));
const files=directory=>readdir(directory).catch(error=>{if(error.code==='ENOENT')return [];throw error;});
const defaults={historyRetention:'indefinite',snapshotRetention:'with-history',monthlyReports:false,timeZone:'UTC',saveSnapshots:true,lastMaintenance:null,maintenanceError:''};

async function installation(){
  const dir=await mkdtemp(path.join(os.tmpdir(),'surv-v10-release-'));
  const f={dir,databasePath:path.join(dir,'installation','.local-data','surv-ai.sqlite'),snapshots:new SnapshotStore(path.join(dir,'installation','.local-data','snapshots')),reportsDirectory:path.join(dir,'installation','.local-data','reports'),calls:0,renders:0,detectorStarts:0};
  f.start=async()=>{
    f.server=createServer({databasePath:f.databasePath,snapshots:f.snapshots,reportsDirectory:f.reportsDirectory,apiKey:'',publicOrigin:'',now:()=>now,
      fetchImpl(){f.calls++;throw Error('Release acceptance must not request the AI provider');},
      reportRender(){f.renders++;throw Error('Default privacy must not silently generate reports');},
      detector:{async start(){f.detectorStarts++;},async inspect(){return {frameValid:true,personPresent:false};},close(){}}});
    await new Promise((resolve,reject)=>{f.server.once('error',reject);f.server.listen(0,'127.0.0.1',resolve);});
    await f.server.privacyReady;
    f.origin=`http://127.0.0.1:${f.server.address().port}`;
    assert.notEqual(new URL(f.origin).port,'4173','Never use the real installation');
    f.store=f.server.privacy.storage;
  };
  f.restart=async()=>{await new Promise(resolve=>f.server.close(resolve));await f.start();};
  f.close=async()=>{if(f.server?.listening)await new Promise(resolve=>f.server.close(resolve));await rm(dir,{recursive:true,force:true});};
  return f;
}
async function client(f){
  const state={cookie:'',csrf:'',user:null};
  const request=async(route,body)=>{
    const res=await fetch(f.origin+route,{method:body?'POST':'GET',headers:{...(state.cookie?{Cookie:state.cookie}:{}),...(body?{'Content-Type':'application/json','X-Surv-CSRF':state.csrf}:{})},...(body?{body:JSON.stringify(body)}:{})});
    if(res.headers.get('set-cookie'))state.cookie=res.headers.get('set-cookie').split(';')[0];
    const data=res.headers.get('content-type')?.includes('json')?await res.json():Buffer.from(await res.arrayBuffer());
    if(data.csrfToken)state.csrf=data.csrfToken;if(data.user)state.user=data.user;
    return {res,status:res.status,data};
  };
  const c={state,get:route=>request(route),post:(route,body)=>request(route,body)};
  await c.get('/api/auth/me');return c;
}
const ok=async promise=>{const response=await promise;assert.equal(response.status,200,JSON.stringify(response.data));return response.data;};
function integrity(f){assert.equal(f.store.db.prepare('PRAGMA user_version').get().user_version,5);assert.equal(f.store.db.prepare('PRAGMA integrity_check').get().integrity_check,'ok');assert.deepEqual(f.store.db.prepare('PRAGMA foreign_key_check').all(),[]);}
async function emptyWorkspace(f,c){
  assert.deepEqual(await ok(c.get('/api/observations')),{observations:[]});
  assert.deepEqual(await ok(c.get('/api/monitoring/sessions')),{sessions:[]});
  assert.deepEqual(await ok(c.get('/api/reports/monthly')),{reports:[],availableMonths:[],monthlyReports:false,maintenanceError:''});
  assert.equal((await ok(c.get('/api/monitoring/status'))).monitoring,'off');
  assert.deepEqual(await files(f.snapshots.directory),[]);assert.deepEqual(await files(f.reportsDirectory),[]);
  assert.equal(f.calls,0);assert.equal(f.renders,0);assert.equal(f.detectorStarts,0);
}

test('V1 fresh lazy installation starts empty, completes owner setup, persists settings and survives logout/login/restart without analysis',async()=>{
  const f=await installation();
  try{
    for(const filename of [f.databasePath,f.snapshots.directory,f.reportsDirectory])assert.equal(existsSync(filename),false,'Fresh fixture must begin with no runtime data');
    await f.start();integrity(f);
    assert.equal(f.store.db.prepare('SELECT COUNT(*) n FROM users').get().n,0);
    const homepage=await fetch(f.origin+'/');assert.equal(homepage.status,200);assert((await homepage.text()).includes('Surv-AI'));
    const status=await fetch(f.origin+'/api/public/status');assert.equal(status.headers.get('set-cookie'),null);assert.deepEqual(await status.json(),{setupRequired:true});
    const c=await client(f);assert.equal((await ok(c.get('/api/auth/me'))).ownerSetup,true);
    const created=await ok(c.post('/api/auth/owner',signup('release-owner@example.test'))),ownerId=created.user.id;
    assert.equal(created.user.installationOwner,true);assert.equal(created.user.role,'ADMIN');
    for(const step of [4,5,6])await ok(c.post('/api/onboarding/progress',{step}));
    const completed=await ok(c.post('/api/onboarding/complete',{}));assert.equal(completed.pending,false);assert.equal(completed.ai.configured,false);
    assert.equal((await c.get('/workspace')).status,200);
    assert.deepEqual(await ok(c.get('/api/privacy/settings')),defaults);
    const cameras=await ok(c.get('/api/cameras'));assert.equal(cameras.cameras.length,1);assert.equal(cameras.cameras[0].source,'local-webcam');
    await emptyWorkspace(f,c);
    await ok(c.post('/api/settings',{intervalMs:30000,saveSnapshots:false}));
    await ok(c.post('/api/privacy/settings',{timeZone:'America/New_York'}));
    const saved=await ok(c.get('/api/privacy/settings'));assert.deepEqual(saved,{...defaults,snapshotRetention:'never',saveSnapshots:false,timeZone:'America/New_York'});
    const credentials=digest(f.store.db.prepare('SELECT password_hash FROM users WHERE id=?').get(ownerId).password_hash);
    await ok(c.post('/api/auth/logout',{}));assert.equal((await c.get('/api/observations')).status,401);
    const signedIn=await client(f);assert.equal((await ok(signedIn.post('/api/auth/login',{email:'release-owner@example.test',password}))).user.id,ownerId);
    assert.deepEqual(await ok(signedIn.get('/api/settings')),{intervalMs:30000,saveSnapshots:false,smartSurv:true,detectionOnlyRotation:false});
    await f.restart();integrity(f);
    const after=await ok(signedIn.get('/api/auth/me'));assert.equal(after.user.id,ownerId);assert.equal(after.user.installationOwner,true);assert.equal(after.onboarding.pending,false);
    assert.deepEqual(await ok(signedIn.get('/api/privacy/settings')),saved);assert.deepEqual(await ok(signedIn.get('/api/settings')),{intervalMs:30000,saveSnapshots:false,smartSurv:true,detectionOnlyRotation:false});
    assert.equal(digest(f.store.db.prepare('SELECT password_hash FROM users WHERE id=?').get(ownerId).password_hash),credentials);
    assert.equal(f.store.db.prepare('SELECT COUNT(*) n FROM users').get().n,1);
    assert.equal(f.store.db.prepare('SELECT owner_user_id FROM installation').get().owner_user_id,ownerId);
    assert.deepEqual(await files(path.join(path.dirname(f.databasePath),'backups')),[]);
    await emptyWorkspace(f,signedIn);
    await ok(signedIn.post('/api/auth/logout',{}));
    const afterRestart=await client(f);assert.equal((await ok(afterRestart.post('/api/auth/login',{email:'release-owner@example.test',password}))).user.id,ownerId);
    assert.equal(f.calls,0);
  }finally{await f.close();}
});

test('V1 upgrade adds privacy auxiliaries to genuine core-v5 data without rewriting credentials, ownership, history, cameras, settings or source bytes',async()=>{
  const f=await installation();let fixtureStore;
  try{
    fixtureStore=new LocalStorage(f.databasePath);
    const auth=new AuthService(fixtureStore,{now:()=>now});
    const accounts=[await auth.signup(signup('upgrade-owner@example.test'),{owner:true}),await auth.signup(signup('upgrade-user@example.test'))];
    for(const [index,account] of accounts.entries()){
      const owned=fixtureStore.forUser(account.id);owned.setSaveSnapshots(index===1);owned.setInterval(index===0?30000:60000);
      const camera=index===0?owned.updateCamera('local-webcam',{name:'Upgrade owner camera',deviceId:'upgrade-owner-device'}):owned.addCamera({name:'Upgrade user camera',deviceId:'upgrade-user-device'});
      const session={id:randomUUID(),intervalMs:index===0?30000:60000,cameraId:camera.id,cameraName:camera.name,telemetry:{requests:7,successes:5,failures:2,noPerson:11,invalid:3,lastRequest:'2019-01-15T12:00:00.000Z'}};
      owned.createSession(session,'2019-01-15T11:00:00.000Z');owned.saveSession(session,'2019-01-15T12:00:00.000Z');owned.finishSession(session.id,'2019-01-15T13:00:00.000Z','auto_off');
      for(const source of ['manual_ai','automatic_ai'])owned.saveObservation(sample({source,activity:`Reading ${index}`,snapshotRef:await f.snapshots.put(image),cameraId:camera.id,cameraName:camera.name,...(source==='automatic_ai'?{monitoringSessionId:session.id}:{})}));
    }
    for(const table of ['privacy_settings','monthly_reports','expired_snapshot_records','privacy_cleanup_commits','installation_onboarding'])assert.equal(fixtureStore.db.prepare('SELECT name FROM sqlite_master WHERE type=\'table\' AND name=?').get(table),undefined,'Upgrade must begin before additive privacy/onboarding schema');
    const before=hashes(fixtureStore),schema=coreSchema(fixtureStore),snapshotHashes={};
    for(const ref of await files(f.snapshots.directory))snapshotHashes[ref]=digest(await readFile(f.snapshots.validate(ref)));
    assert.equal(Object.keys(snapshotHashes).length,4);
    fixtureStore.close();fixtureStore=null;
    await f.start();integrity(f);
    // Compare before any login: last_login_at is intentionally updated by login.
    assert.deepEqual(hashes(f.store),before);assert.equal(coreSchema(f.store),schema);
    for(const [ref,hash] of Object.entries(snapshotHashes))assert.equal(digest(await readFile(f.snapshots.validate(ref))),hash);
    assert.deepEqual((await files(f.snapshots.directory)).sort(),Object.keys(snapshotHashes).sort());
    assert.deepEqual(await files(f.reportsDirectory),[]);
    assert.equal(f.store.db.prepare('SELECT COUNT(*) n FROM privacy_settings').get().n,0);
    assert.equal(f.store.db.prepare('SELECT COUNT(*) n FROM monthly_reports').get().n,0);
    for(const [index,account] of accounts.entries()){
      const c=await client(f),login=await ok(c.post('/api/auth/login',{email:account.email,password}));
      assert.equal(login.user.id,account.id);assert.equal(login.user.role,index===0?'ADMIN':'USER');assert.equal(login.user.installationOwner,index===0);assert.equal(login.user.status,'ACTIVE');
      assert.deepEqual(await ok(c.get('/api/privacy/settings')),{...defaults,snapshotRetention:index===0?'never':'with-history',saveSnapshots:index===1});
      assert.deepEqual(await ok(c.get('/api/settings')),{intervalMs:index===0?30000:60000,saveSnapshots:index===1,smartSurv:true,detectionOnlyRotation:false});
      const observations=await ok(c.get('/api/observations'));assert.equal(observations.observations.length,2);assert(observations.observations.every(record=>record.activity===`Reading ${index}`));
      const sessions=await ok(c.get('/api/monitoring/sessions'));assert.equal(sessions.sessions.length,1);assert.equal(sessions.sessions[0].status,'completed');assert.equal(sessions.sessions[0].api_requests,7);assert.equal(sessions.sessions[0].successful_analyses,5);
      assert.equal((await ok(c.get('/api/monitoring/status'))).monitoring,'off');
      const archived=await ok(c.get('/api/reports/monthly'));assert.deepEqual(archived.reports,[]);assert.equal(archived.monthlyReports,false);assert.equal(archived.availableMonths[0].observationCount,2);
      for(const record of observations.observations){const source=await c.get('/api/snapshots/'+record.snapshotRef);assert.equal(source.status,200);assert.equal(digest(source.data),snapshotHashes[record.snapshotRef]);}
      assert.equal(digest(f.store.db.prepare('SELECT password_hash FROM users WHERE id=?').get(account.id).password_hash),digest(account.password_hash));
    }
    const afterLogin=hashes(f.store);await f.restart();integrity(f);assert.deepEqual(hashes(f.store),afterLogin);assert.equal(coreSchema(f.store),schema);
    assert.equal(f.calls,0);assert.equal(f.renders,0);assert.equal(f.detectorStarts,0);
  }finally{fixtureStore?.close();await f.close();}
});

test('V1 missing SURV_PYTHON fails with actionable OpenCV setup guidance without leaking local paths', {concurrency:false},async()=>{
  const dir=await mkdtemp(path.join(os.tmpdir(),'surv-v10-no-detector-')),previous=process.env.SURV_PYTHON;
  const missing=path.join(dir,'absent-private-runtime','python.exe'),detector=new LocalDetector(fileURLToPath(new URL('..',import.meta.url)));
  try{
    assert.equal(existsSync(missing),false);process.env.SURV_PYTHON=missing;
    await assert.rejects(detector.start(),error=>{assert.match(error.message,/Local OpenCV detector unavailable/);assert.match(error.message,/setup-local\.ps1/);assert.match(error.message,/SURV_PYTHON/);assert(!error.message.includes(dir));return true;});
  }finally{detector.close();if(previous===undefined)delete process.env.SURV_PYTHON;else process.env.SURV_PYTHON=previous;await rm(dir,{recursive:true,force:true});}
});

test('V1 missing report Python fails with actionable local dependency guidance and keeps saved evidence', {concurrency:false},async()=>{
  const dir=await mkdtemp(path.join(os.tmpdir(),'surv-v10-no-report-')),previous=process.env.SURV_REPORT_PYTHON,store=new LocalStorage(':memory:');
  const missing=path.join(dir,'absent-private-runtime','python.exe');
  try{
    store.saveObservation(sample({timestamp:'2026-10-01T12:00:00.000Z'}));const before=hashes(store);
    const report=buildReport(store,{startDate:'2026-10-01',length:7,timeZone:'UTC',now});
    assert.equal(existsSync(missing),false);process.env.SURV_REPORT_PYTHON=missing;
    await assert.rejects(renderReportPDF(report),error=>{assert.match(error.message,/local PDF renderer is unavailable/);assert.match(error.message,/requirements-report\.txt/);assert(!error.message.includes(dir));return true;});
    assert.deepEqual(hashes(store),before);assert.deepEqual(await files(dir),[]);
  }finally{store.close();if(previous===undefined)delete process.env.SURV_REPORT_PYTHON;else process.env.SURV_REPORT_PYTHON=previous;await rm(dir,{recursive:true,force:true});}
});
