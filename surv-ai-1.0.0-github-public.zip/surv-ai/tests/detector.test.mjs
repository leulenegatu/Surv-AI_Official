import {test} from 'node:test';
import assert from 'node:assert/strict';
import {existsSync} from 'node:fs';
import {readFile} from 'node:fs/promises';
import path from 'node:path';
import {LocalDetector} from '../src/local-detector.mjs';
test('actual local OpenCV worker rejects tiny/corrupt images and detects a sample person',{skip:!existsSync('.local-models/mobilenet_iter_73000.caffemodel')},async()=>{
  const detector=new LocalDetector(process.cwd());
  try{
    await detector.start();assert(detector.ready);
    assert.equal((await detector.inspect('data:image/jpeg;base64,aGVsbG8=')).frameValid,false);
    if(existsSync('.test-output/person.png')){
      const input='data:image/png;base64,'+(await readFile('.test-output/person.png')).toString('base64');
      const [invalid,frame]=await Promise.all([detector.inspect('data:image/jpeg;base64,aGVsbG8='),detector.inspect(input)]);assert.equal(invalid.frameValid,false);assert(frame.frameValid);assert(frame.personPresent);
    }
  }finally{detector.close();}
});
