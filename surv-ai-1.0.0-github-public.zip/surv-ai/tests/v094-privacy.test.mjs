import {test} from 'node:test';
import assert from 'node:assert/strict';
import {randomUUID,createHash} from 'node:crypto';
import {mkdtemp,rm,readFile,readdir} from 'node:fs/promises';
import * as disk from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {LocalStorage} from '../src/storage.mjs';
import {SnapshotStore} from '../src/snapshot-store.mjs';
import {createServer} from '../server.mjs';

// Every fixture is temporary, every account disposable, and provider access
// forbidden. These tests exercise actual authentication and ownership checks.
const password='privacy fixture private passphrase 2026';
const image='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+j1ioAAAAASUVORK5CYII=';
const digest=bytes=>createHash('sha256').update(bytes).digest('hex');
const signup=email=>({displayName:'Privacy Fixture',email,password,confirmPassword:password});
async function fixture(extra={}){
  const dir=await mkdtemp(path.join(os.tmpdir(),'surv-v094-privacy-'));
  const f={dir,origin:null,store:null,server:null,snapshots:new SnapshotStore(path.join(dir,'snapshots')),calls:0,now:Date.parse('2026-11-04T12:00:00.000Z')};
  f.start=async()=>{
    f.store=new LocalStorage(path.join(dir,'history.sqlite'));
    f.server=createServer({storage:f.store,snapshots:f.snapshots,now:()=>f.now,apiKey:'fixture-only',fetchImpl(){f.calls++;throw Error('Privacy maintenance must not request AI');},detector:{async start(){},async inspect(){return {frameValid:true,personPresent:false};},close(){}},...extra});
    await new Promise(resolve=>f.server.listen(0,'127.0.0.1',resolve));
    await f.server.privacyReady;
    f.origin=`http://127.0.0.1:${f.server.address().port}`;
    assert.notEqual(new URL(f.origin).port,'4173','Never mutate the actual installation');
  };
  f.restart=async()=>{await new Promise(resolve=>f.server.close(resolve));await f.start();};
  f.close=async()=>{if(f.server?.listening)await new Promise(resolve=>f.server.close(resolve));await rm(dir,{recursive:true,force:true});};
  await f.start();return f;
}
async function client(f){
  const state={cookie:'',csrf:'',user:null};
  const request=async(route,{body,method=body?'POST':'GET',headers={}}={})=>{
    const res=await fetch(f.origin+route,{method,headers:{...(body?{'Content-Type':'application/json'}:{}),...(state.cookie?{Cookie:state.cookie}:{}),...(state.csrf?{'X-Surv-CSRF':state.csrf}:{}),...headers},...(body?{body:JSON.stringify(body)}:{})});
    if(res.headers.get('set-cookie'))state.cookie=res.headers.get('set-cookie').split(';')[0];
    const data=res.headers.get('content-type')?.includes('json')?await res.json():Buffer.from(await res.arrayBuffer());
    if(data.csrfToken)state.csrf=data.csrfToken;if(data.user)state.user=data.user;
    return {res,status:res.status,data};
  };
  const c={state,request,get:route=>request(route),post:(route,body)=>request(route,{body})};await c.get('/api/auth/me');return c;
}
const ok=async promise=>{const result=await promise;assert.equal(result.status,200,JSON.stringify(result.data));return result.data;};
async function owner(f){const c=await client(f);await ok(c.post('/api/auth/owner',signup('privacy-owner@example.test')));return c;}
async function user(f,email='privacy-user@example.test'){const c=await client(f);await ok(c.post('/api/auth/register',signup(email)));return c;}
async function seed(f,c,{timestamp='2026-10-01T12:00:00.000Z',activity='PRIVATE_SAVED_READING',snapshot=true,...values}={}){
  const ref=snapshot?await f.snapshots.put(image):null;
  const record=f.store.forUser(c.state.user.id).saveObservation({id:randomUUID(),timestamp,activity,description:'A person is reading a book.',source:'manual_ai',location:'Office',confidence:.9,objects:['book'],snapshotRef:ref,...values});
  return {record,ref,...(ref?{hash:digest(await readFile(f.snapshots.validate(ref)))}:{})};
}
const rows=(f,table,where='')=>JSON.stringify(f.store.db.prepare(`SELECT * FROM ${table}${where} ORDER BY 1`).all());
const protectedRows=f=>Object.fromEntries(['users','auth_identities','installation','cameras','app_settings'].map(table=>[table,rows(f,table)]));
const historyRows=f=>Object.fromEntries(['observations','monitoring_sessions'].map(table=>[table,rows(f,table)]));
async function run(f,c){
  let cameraId;if(!c.state.user.installationOwner)cameraId=(await ok(c.post('/api/cameras',{name:'Private test camera',deviceId:'fixture-'+randomUUID()}))).camera.id;
  return (await ok(c.post('/api/monitoring/start',{cameraActive:true,...(cameraId?{cameraId}:{})}))).sessionId;
}
function assertPrivateError(result,f,...secrets){
  const serialized=JSON.stringify(result.data);assert(!serialized.includes(f.dir),'Error leaked the fixture filesystem path');
  for(const secret of secrets.filter(Boolean))assert(!serialized.includes(secret),'Error disclosed a private value');
}

const reset={currentPassword:password,confirmation:'DELETE MY HISTORY',deleteReports:false};
const privacy=c=>ok(c.get('/api/privacy/settings'));
const configure=(c,settings)=>ok(c.post('/api/privacy/settings',settings));
const sweep=c=>ok(c.post('/api/privacy/maintenance',{}));
const reportList=async c=>(await ok(c.get('/api/reports/monthly'))).reports;
function finals(f){f.store.db.exec("CREATE TABLE privacy_finals(id TEXT); CREATE TRIGGER privacy_final_count AFTER UPDATE OF status ON monitoring_sessions WHEN OLD.status='active' AND NEW.status='completed' BEGIN INSERT INTO privacy_finals VALUES(NEW.id); END");}

test('owner and USER can reset personal history without changing identity, credentials, ownership, cameras, settings or an active runtime',async()=>{
  const f=await fixture();try{
    const a=await owner(f),b=await user(f),aOld=await seed(f,a,{activity:'OWNER_OLD_HISTORY'}),bOld=await seed(f,b,{activity:'USER_OLD_HISTORY'});finals(f);
    const aRun=await run(f,a),bRun=await run(f,b);
    const active=await seed(f,a,{source:'automatic_ai',monitoringSessionId:aRun,timestamp:'2026-11-04T11:59:00.000Z',activity:'ACTIVE_RUNTIME_EVIDENCE'});
    const finished=randomUUID(),owned=f.store.forUser(a.state.user.id);owned.createSession({id:finished,intervalMs:15000,telemetry:{requests:0,successes:0,failures:0,noPerson:0,invalid:0,lastRequest:null}},'2026-09-01T12:00:00.000Z');owned.finishSession(finished,'2026-09-01T13:00:00.000Z');
    const shared=await seed(f,a,{snapshot:false,activity:'SHARED_A_HISTORY',snapshotRef:bOld.ref});
    const preserved=protectedRows(f),foreign=rows(f,'observations',` WHERE user_id='${b.state.user.id}'`),cookie=a.state.cookie;
    await ok(a.post('/api/account/history/delete',reset));
    assert.deepEqual(protectedRows(f),preserved);assert.equal(a.state.cookie,cookie);assert.equal((await a.get('/api/auth/me')).status,200);
    assert.equal(f.store.getObservation(aOld.record.id),null);assert.equal(f.store.getObservation(shared.record.id),null);assert(!disk.existsSync(f.snapshots.validate(aOld.ref)));assert.equal(f.store.getObservation(active.record.id).snapshotRef,active.ref);
    assert.equal(f.store.session(aRun).status,'active');assert.equal(f.store.session(bRun).status,'active');assert.equal(f.store.session(finished),null);assert.equal(rows(f,'observations',` WHERE user_id='${b.state.user.id}'`),foreign);assert.equal(digest(await readFile(f.snapshots.validate(bOld.ref))),bOld.hash);
    assert.equal((await ok(a.get('/api/monitoring/status'))).sessionId,aRun);assert.equal(f.store.db.prepare('SELECT COUNT(*) n FROM privacy_finals WHERE id=?').get(aRun).n,0);
    await ok(a.post('/api/monitoring/check',{sessionId:aRun,cameraActive:true,image,timestamp:new Date(f.now).toISOString()}));assert.equal(f.store.session(aRun).no_person_skipped,1);
    const ownerAfter=rows(f,'observations',` WHERE user_id='${a.state.user.id}'`);await ok(b.post('/api/account/history/delete',reset));assert.deepEqual(protectedRows(f),preserved);assert.equal(rows(f,'observations',` WHERE user_id='${a.state.user.id}'`),ownerAfter);assert.equal(f.store.session(bRun).status,'active');assert(!disk.existsSync(f.snapshots.validate(bOld.ref)));assert.equal(f.calls,0);assert.deepEqual(f.store.db.prepare('PRAGMA foreign_key_check').all(),[]);
  }finally{await f.close();}
});

test('history reset requires password, typed confirmation, CSRF and same-origin; identity injection and unauthenticated requests fail safely',async()=>{
  const f=await fixture();try{
    const a=await owner(f),b=await user(f);await seed(f,a);await seed(f,b);const before=historyRows(f),protectedBefore=protectedRows(f);
    assert.equal((await fetch(f.origin+'/api/account/history/delete',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(reset)})).status,401);
    for(const body of [{confirmation:'DELETE MY HISTORY',deleteReports:false},{...reset,currentPassword:'wrong private passphrase'},{...reset,confirmation:'DELETE'},{...reset,userId:a.state.user.id},{...reset,user_id:a.state.user.id},{...reset,deleteReports:'false'}]){
      const result=await b.post('/api/account/history/delete',body);assert.equal(result.status,400,JSON.stringify(result.data));assertPrivateError(result,f,password,a.state.user.id);
    }
    for(const headers of [{'X-Surv-CSRF':''},{Origin:'https://attacker.example'},{'Sec-Fetch-Site':'cross-site'}])assert.equal((await b.request('/api/account/history/delete',{body:reset,headers})).status,403);
    assert.deepEqual(historyRows(f),before);assert.deepEqual(protectedRows(f),protectedBefore);assert.equal((await b.get('/api/settings')).status,200);assert.equal(f.calls,0);
  }finally{await f.close();}
});

test('history SQL failure rolls back records and staged snapshot bytes while active monitoring stays valid',async()=>{
  const f=await fixture();try{
    const a=await owner(f),saved=await seed(f,a),active=await run(f,a),before=historyRows(f),preserved=protectedRows(f);
    f.store.db.exec("CREATE TRIGGER fail_privacy_history BEFORE DELETE ON observations BEGIN SELECT RAISE(ABORT,'isolated private SQL failure'); END");
    const result=await a.post('/api/account/history/delete',reset);assert.equal(result.status,507);assertPrivateError(result,f,password);assert.deepEqual(historyRows(f),before);assert.deepEqual(protectedRows(f),preserved);assert.equal(digest(await readFile(f.snapshots.validate(saved.ref))),saved.hash);assert.equal(f.store.session(active).status,'active');assert.equal((await a.get('/api/observations')).status,200);assert.equal(f.calls,0);
  }finally{await f.close();}
});

test('snapshot staging failure restores all history images and preserves another account',async()=>{
  let moves=0;const f=await fixture({privacyFiles:{renameSync(from,to){if(to.includes('privacy-cleanups')&&++moves===2)throw Error('isolated staging failure');return disk.renameSync(from,to);}}});try{
    const a=await owner(f),b=await user(f),one=await seed(f,a),two=await seed(f,a),foreign=await seed(f,b),before=historyRows(f);
    const result=await a.post('/api/account/history/delete',reset);assert.equal(result.status,507);assertPrivateError(result,f);assert.deepEqual(historyRows(f),before);
    for(const saved of [one,two,foreign])assert.equal(digest(await readFile(f.snapshots.validate(saved.ref))),saved.hash);assert.equal((await a.get('/api/observations')).status,200);assert.equal(f.calls,0);
  }finally{await f.close();}
});

test('post-commit file cleanup failure is explicit and recovery completes privately after restart',async()=>{
  let fail=true;const f=await fixture({privacyFiles:{unlinkSync(file){if(fail&&file.endsWith('.png'))throw Error('isolated physical cleanup failure');return disk.unlinkSync(file);}}});try{
    const a=await owner(f),saved=await seed(f,a),before=protectedRows(f),result=await a.post('/api/account/history/delete',reset);
    assert.equal(result.status,202);assert.equal(result.data.cleanupPending,true);assertPrivateError(result,f,password);assert.equal(f.store.getObservation(saved.record.id),null);assert.deepEqual(protectedRows(f),before);assert(!disk.existsSync(f.snapshots.validate(saved.ref)));assert.equal((await a.get('/api/settings')).status,200);
    assert.equal(f.server.privacy.jobs().length,1,'Committed cleanup has a private recovery journal');
    fail=false;await f.restart();assert.equal(f.store.getObservation(saved.record.id),null);assert.deepEqual(protectedRows(f),before);assert.equal((await a.get('/api/auth/me')).status,200);assert.equal(f.server.privacy.jobs().length,0);assert.equal(f.calls,0);
  }finally{await f.close();}
});

test('startup restores files staged before an interrupted uncommitted history transaction',async()=>{
  const f=await fixture();try{
    const a=await owner(f),b=await user(f),saved=await seed(f,a),foreign=await seed(f,b),before=historyRows(f),preserved=protectedRows(f),id=randomUUID(),job=f.server.privacy.jobPath(id);
    disk.mkdirSync(job,{recursive:true});disk.writeFileSync(path.join(job,'manifest.json'),JSON.stringify({version:1,id,userId:a.state.user.id,entries:[{type:'snapshot',ref:saved.ref}]}));disk.renameSync(f.snapshots.validate(saved.ref),path.join(job,'snapshot-'+saved.ref));
    await f.restart();assert.deepEqual(historyRows(f),before);assert.deepEqual(protectedRows(f),preserved);assert.equal(digest(await readFile(f.snapshots.validate(saved.ref))),saved.hash);assert.equal(digest(await readFile(f.snapshots.validate(foreign.ref))),foreign.hash);assert.equal((await a.get('/api/observations')).status,200);assert.equal(f.server.privacy.jobs().length,0);assert.equal(f.calls,0);
  }finally{await f.close();}
});

test('failed rollback file restoration is visible, isolates only the affected account and supports safe recovery retry',async()=>{
  let fail=true;const f=await fixture({privacyFiles:{renameSync(from,to){if(fail&&from.includes('privacy-cleanups'))throw Error('isolated rollback restoration failure');return disk.renameSync(from,to);}}});try{
    const a=await owner(f),b=await user(f),saved=await seed(f,a),foreign=await seed(f,b),before=historyRows(f);
    f.store.db.exec("CREATE TRIGGER fail_privacy_restore BEFORE DELETE ON observations BEGIN SELECT RAISE(ABORT,'isolated private SQL failure'); END");
    const result=await a.post('/api/account/history/delete',reset);assert.equal(result.status,507);assert(result.data.error.includes('recovery is pending'));assertPrivateError(result,f,password);assert.deepEqual(historyRows(f),before);assert.equal((await a.get('/api/snapshots/'+saved.ref)).status,503);assert.equal((await a.get('/api/observations')).status,200);assert.equal((await b.get('/api/observations')).status,200);assert.equal((await b.get('/api/snapshots/'+foreign.ref)).status,200);assert.equal(digest(await readFile(f.snapshots.validate(foreign.ref))),foreign.hash);
    fail=false;assert.equal(f.server.privacy.recover().pendingPrivacyCleanupCount,0);assert.equal((await a.get('/api/observations')).status,200);assert.equal(digest(await readFile(f.snapshots.validate(saved.ref))),saved.hash);assert.equal(f.calls,0);
  }finally{await f.close();}
});

test('defaults keep all history and snapshots indefinitely and archive nothing; repeat maintenance is harmless',async()=>{
  const f=await fixture();try{
    const a=await owner(f),saved=await seed(f,a,{timestamp:'2022-01-01T12:00:00.000Z'}),before=historyRows(f),settings=await privacy(a);
    assert.equal(settings.historyRetention,'indefinite');assert.equal(settings.snapshotRetention,'with-history');assert.equal(settings.monthlyReports,false);assert.equal(settings.saveSnapshots,true);
    await sweep(a);await sweep(a);assert.deepEqual(historyRows(f),before);assert.equal(digest(await readFile(f.snapshots.validate(saved.ref))),saved.hash);assert.deepEqual(await reportList(a),[]);assert.equal(f.calls,0);
  }finally{await f.close();}
});

for(const [policy,now,timeZone,cutoff] of [
  ['30-days','2026-11-04T12:00:00.000Z','America/New_York','2026-10-05T04:00:00.000Z'],
  ['90-days','2026-11-04T12:00:00.000Z','America/New_York','2026-08-06T04:00:00.000Z'],
  ['6-months','2026-10-31T12:00:00.000Z','America/New_York','2026-04-30T04:00:00.000Z'],
  ['1-year','2024-02-29T12:00:00.000Z','UTC','2023-02-28T00:00:00.000Z'],
])test(`${policy} retention uses local calendar cutoff ${cutoff}, preserves equality/recent/other accounts and is idempotent`,async()=>{
  const f=await fixture();try{
    f.now=Date.parse(now);const a=await owner(f),b=await user(f);await configure(a,{historyRetention:policy,timeZone});
    const expired=await seed(f,a,{timestamp:new Date(Date.parse(cutoff)-1).toISOString()}),boundary=await seed(f,a,{timestamp:cutoff}),recent=await seed(f,a,{timestamp:new Date(f.now).toISOString()}),foreign=await seed(f,b,{timestamp:'2020-01-01T12:00:00.000Z'}),foreignBefore=rows(f,'observations',` WHERE user_id='${b.state.user.id}'`),preserved=protectedRows(f);
    await sweep(a);assert.equal(f.store.getObservation(expired.record.id),null);assert(!disk.existsSync(f.snapshots.validate(expired.ref)));assert(f.store.getObservation(boundary.record.id));assert(f.store.getObservation(recent.record.id));assert.equal(rows(f,'observations',` WHERE user_id='${b.state.user.id}'`),foreignBefore);assert.equal(digest(await readFile(f.snapshots.validate(foreign.ref))),foreign.hash);assert.deepEqual(protectedRows(f),preserved);
    const after=historyRows(f);await sweep(a);assert.deepEqual(historyRows(f),after);assert.equal(f.calls,0);
  }finally{await f.close();}
});

test('snapshot expiry preserves textual observation details, respects live references and never removes unrelated files',async()=>{
  const f=await fixture();try{
    const a=await owner(f),b=await user(f);await configure(a,{snapshotRetention:'30-days',timeZone:'UTC'});
    const old=await seed(f,a,{timestamp:'2026-09-01T12:00:00.000Z'}),recent=await seed(f,a,{timestamp:'2026-11-04T11:00:00.000Z'}),shared=await seed(f,a,{timestamp:'2026-09-02T12:00:00.000Z'});
    const foreign=await seed(f,b,{snapshot:false,snapshotRef:shared.ref,timestamp:'2026-09-02T12:00:00.000Z',activity:'B_OWNS_SHARED_IMAGE'}),unrelated=await f.snapshots.put(image),protectedBefore=protectedRows(f);
    await sweep(a);const retained=f.store.getObservation(old.record.id);assert.equal(retained.snapshotRef,null);assert.equal(retained.snapshotExpired,true);
    for(const key of ['timestamp','activity','description','location','confidence','objects','source'])assert.deepEqual(retained[key],old.record[key]);assert(!disk.existsSync(f.snapshots.validate(old.ref)));assert.equal(f.store.getObservation(recent.record.id).snapshotRef,recent.ref);
    assert.equal(f.store.getObservation(shared.record.id).snapshotRef,null);assert.equal(f.store.getObservation(foreign.record.id).snapshotRef,shared.ref);assert.equal(digest(await readFile(f.snapshots.validate(shared.ref))),shared.hash);assert(disk.existsSync(f.snapshots.validate(unrelated)));assert.deepEqual(protectedRows(f),protectedBefore);assert.equal((await a.get('/api/snapshots/'+old.ref)).status,404);assert.equal((await b.get('/api/snapshots/'+shared.ref)).status,200);assert.equal(f.calls,0);
  }finally{await f.close();}
});

test('90-day source retention expires only images strictly before its local calendar boundary',async()=>{
  const f=await fixture();try{
    const a=await owner(f);await configure(a,{snapshotRetention:'90-days',timeZone:'America/New_York'});
    const expired=await seed(f,a,{timestamp:'2026-08-06T03:59:59.999Z'}),boundary=await seed(f,a,{timestamp:'2026-08-06T04:00:00.000Z'});await sweep(a);assert.equal(f.store.getObservation(expired.record.id).snapshotRef,null);assert.equal(f.store.getObservation(expired.record.id).snapshotExpired,true);assert.equal(f.store.getObservation(boundary.record.id).snapshotRef,boundary.ref);assert.equal(digest(await readFile(f.snapshots.validate(boundary.ref))),boundary.hash);assert.equal(f.store.forUser(a.state.user.id).observations().length,2);assert.equal(f.calls,0);
  }finally{await f.close();}
});

test('source policy never coheres with Save snapshots OFF and manual saves without deleting existing sources',async()=>{
  const f=await fixture();try{
    const a=await owner(f),old=await seed(f,a);await configure(a,{snapshotRetention:'never'});assert.equal((await privacy(a)).saveSnapshots,false);assert.equal((await ok(a.get('/api/settings'))).saveSnapshots,false);
    const draft={id:randomUUID(),timestamp:new Date(f.now).toISOString(),activity:'Reading a book',source:'manual_ai',description:'A book is visible.',location:'Office',confidence:.9,objects:['book']};
    const saved=(await ok(a.post('/api/observations',{observation:draft,image}))).observation;assert.equal(saved.snapshotRef,null);assert.equal(digest(await readFile(f.snapshots.validate(old.ref))),old.hash);
    await ok(a.post('/api/settings',{saveSnapshots:true}));assert.equal((await privacy(a)).snapshotRetention,'with-history');assert.equal((await privacy(a)).saveSnapshots,true);
    await configure(a,{snapshotRetention:'90-days'});await ok(a.post('/api/settings',{saveSnapshots:false}));assert.equal((await privacy(a)).saveSnapshots,false);assert.equal((await privacy(a)).snapshotRetention,'never');assert.equal(f.calls,0);
  }finally{await f.close();}
});

test('retention preserves active sessions and their observations while deleting completed expired history exactly once',async()=>{
  const f=await fixture();try{
    const a=await owner(f),b=await user(f);await configure(a,{historyRetention:'30-days',timeZone:'UTC'});finals(f);const active=await run(f,a),foreignRun=await run(f,b);
    const kept=await seed(f,a,{timestamp:'2026-08-01T12:00:00.000Z',source:'automatic_ai',monitoringSessionId:active}),gone=await seed(f,a,{timestamp:'2026-08-01T12:00:00.000Z'});
    await sweep(a);await sweep(a);assert(f.store.getObservation(kept.record.id));assert.equal(f.store.getObservation(gone.record.id),null);assert.equal(f.store.session(active).status,'active');assert.equal(f.store.session(foreignRun).status,'active');assert.equal((await ok(a.get('/api/monitoring/status'))).sessionId,active);assert.equal(f.store.db.prepare('SELECT COUNT(*) n FROM privacy_finals').get().n,0);
    await ok(a.post('/api/monitoring/check',{sessionId:active,cameraActive:true,image,timestamp:new Date(f.now).toISOString()}));assert.equal(f.store.session(active).no_person_skipped,1);await ok(a.post('/api/monitoring/stop',{sessionId:active}));assert.equal(f.store.db.prepare('SELECT COUNT(*) n FROM privacy_finals WHERE id=?').get(active).n,1);assert.equal(f.calls,0);
  }finally{await f.close();}
});

test('settings are private, validate periods/timezone/identity and preserve CSRF protections',async()=>{
  const f=await fixture();try{
    const a=await owner(f),b=await user(f),before=await privacy(b);await configure(a,{historyRetention:'90-days',snapshotRetention:'30-days',monthlyReports:true,timeZone:'America/New_York'});
    assert.equal((await privacy(b)).historyRetention,before.historyRetention);assert.equal((await privacy(b)).monthlyReports,false);
    for(const fields of [{historyRetention:'forever-ish'},{snapshotRetention:'1-hour'},{monthlyReports:'true'},{timeZone:'../private'},{userId:b.state.user.id},{saveSnapshots:true}])assert.equal((await a.post('/api/privacy/settings',fields)).status,400,JSON.stringify(fields));
    assert.equal((await a.get('/api/privacy/settings?user_id='+b.state.user.id)).status,400);for(const route of ['/api/privacy/settings','/api/privacy/maintenance','/api/reports/monthly'])assert.equal((await fetch(f.origin+route)).status,401);
    assert.equal((await a.request('/api/privacy/settings',{body:{monthlyReports:false},headers:{'X-Surv-CSRF':''}})).status,403);assert.equal((await a.request('/api/privacy/maintenance',{body:{},headers:{Origin:'https://attacker.example'}})).status,403);assert.equal(f.calls,0);
  }finally{await f.close();}
});

test('failed required monthly report blocks retention, retries preserve the completed month then allow deletion, and restart catch-up remains idempotent',async()=>{
  let fail=true;const rendered=[];const f=await fixture({reportRender:async report=>{rendered.push(report);if(fail)throw Error('isolated private PDF failure');return Buffer.from('%PDF-1.7\nlocal fixture archived report\n%%EOF');}});try{
    const a=await owner(f),b=await user(f),completed=randomUUID(),owned=f.store.forUser(a.state.user.id);owned.createSession({id:completed,intervalMs:15000,telemetry:{requests:1,successes:1,failures:0,noPerson:2,invalid:0,lastRequest:'2026-10-01T12:00:00.000Z'}},'2026-10-01T11:00:00.000Z');owned.finishSession(completed,'2026-10-01T13:00:00.000Z');
    const old=await seed(f,a,{timestamp:'2026-10-01T12:00:00.000Z',activity:'OWNER_REPORT_EVIDENCE',source:'automatic_ai',monitoringSessionId:completed}),later=await seed(f,a,{timestamp:'2026-10-31T12:00:00.000Z'}),current=await seed(f,a,{timestamp:'2026-11-02T12:00:00.000Z'});await seed(f,b,{timestamp:'2026-10-01T12:00:00.000Z',activity:'FOREIGN_REPORT_SECRET'});
    await configure(a,{historyRetention:'30-days',monthlyReports:true,timeZone:'UTC'});assert(f.store.getObservation(old.record.id),'Failed report must protect its required expired observations');assert.equal(f.store.session(completed).status,'completed','Required report failure preserves its historical monitoring counters');assert.deepEqual(await reportList(a),[]);assert((await privacy(a)).maintenanceError);assert(!JSON.stringify(await privacy(a)).includes('isolated private'));
    fail=false;await sweep(a);let reports=await reportList(a);assert.equal(reports.length,1);assert.equal(reports[0].month,'2026-10');assert.equal(reports[0].observationCount,2);assert.equal(f.store.getObservation(old.record.id),null);assert.equal(f.store.session(completed),null);assert(f.store.getObservation(later.record.id));assert(f.store.getObservation(current.record.id));assert(!JSON.stringify(rendered).includes('FOREIGN_REPORT_SECRET'));assert.equal((await privacy(a)).maintenanceError,'');
    await sweep(a);assert.equal((await reportList(a)).length,1);const bytes=(await a.get('/api/reports/monthly/'+reports[0].id+'/pdf')).data;assert(bytes.subarray(0,5).equals(Buffer.from('%PDF-')));
    await seed(f,a,{timestamp:'2026-09-01T12:00:00.000Z'});await f.restart();reports=await reportList(a);assert(reports.some(r=>r.month==='2026-09'),'Startup catches up a completed month while offline');assert.equal(reports.filter(r=>r.month==='2026-10').length,1);assert(!reports.some(r=>r.month==='2026-11'));assert.equal(f.calls,0);
  }finally{await f.close();}
});

test('monthly archive endpoints enforce ownership and safe IDs, support PDF download/delete, and reset report choice is explicit',async()=>{
  const f=await fixture({reportRender:async()=>Buffer.from('%PDF-1.7\nprivate test report\n%%EOF')});try{
    const a=await owner(f),b=await user(f);await seed(f,a,{timestamp:'2026-10-01T12:00:00.000Z'});await seed(f,b,{timestamp:'2026-10-01T12:00:00.000Z'});
    const ar=(await ok(a.post('/api/reports/monthly',{month:'2026-10',timeZone:'UTC'}))).report,br=(await ok(b.post('/api/reports/monthly',{month:'2026-10',timeZone:'UTC'}))).report;
    assert.equal((await reportList(a)).length,1);assert.equal((await reportList(b)).length,1);assert.equal((await a.get('/api/reports/monthly/'+br.id+'/pdf')).status,404);assert.equal((await b.get('/api/reports/monthly/'+ar.id+'/pdf')).status,404);assert.equal((await a.post('/api/reports/monthly/'+br.id+'/delete',{confirmation:'DELETE REPORT'})).status,404);
    const pdf=await a.get('/api/reports/monthly/'+ar.id+'/pdf?download=1');assert.equal(pdf.status,200);assert.equal(pdf.res.headers.get('content-type'),'application/pdf');assert.match(pdf.res.headers.get('content-disposition'),/^attachment;/);assert(pdf.data.subarray(0,5).equals(Buffer.from('%PDF-')));
    for(const id of ['not-a-report','..%2F..%2F.env',randomUUID()+'.pdf']){const result=await a.get('/api/reports/monthly/'+id+'/pdf');assert([400,404].includes(result.status));assertPrivateError(result,f,password);}
    assert.equal((await a.post('/api/reports/monthly',{month:'2026-11',timeZone:'UTC'})).status,400);assert.equal((await a.post('/api/reports/monthly',{month:'2026-10',userId:b.state.user.id})).status,400);assert.equal((await a.get('/api/reports/monthly?user_id='+b.state.user.id)).status,400);
    const duplicate=await ok(a.post('/api/reports/monthly',{month:'2026-10',timeZone:'UTC'}));assert.equal(duplicate.report.id,ar.id);assert.equal((await reportList(a)).length,1);
    await ok(a.post('/api/account/history/delete',reset));assert.equal((await reportList(a))[0].id,ar.id);assert.equal((await reportList(b))[0].id,br.id);
    assert.equal((await a.post('/api/reports/monthly/'+ar.id+'/delete',{confirmation:''})).status,400);assert.equal((await a.request('/api/reports/monthly/'+ar.id+'/delete',{body:{confirmation:'DELETE REPORT'},headers:{'X-Surv-CSRF':''}})).status,403);await ok(a.post('/api/reports/monthly/'+ar.id+'/delete',{confirmation:'DELETE REPORT'}));assert.deepEqual(await reportList(a),[]);assert.equal((await a.get('/api/reports/monthly/'+ar.id+'/pdf')).status,404);
    const protectedBefore=protectedRows(f);await ok(b.post('/api/account/history/delete',{...reset,deleteReports:true}));assert.deepEqual(await reportList(b),[]);assert.deepEqual(protectedRows(f),protectedBefore);assert.equal(f.calls,0);
  }finally{await f.close();}
});

test('overlapping maintenance shares one report operation and rejects a conflicting destructive reset without duplicate work',async()=>{
  let release,entered,renders=0;const rendering=new Promise(resolve=>entered=resolve),blocked=new Promise(resolve=>release=resolve);
  const f=await fixture({reportRender:async()=>{renders++;entered();await blocked;return Buffer.from('%PDF-1.7\nsingle maintenance fixture\n%%EOF');}});try{
    const a=await owner(f);await configure(a,{historyRetention:'30-days',monthlyReports:true,timeZone:'UTC'});const old=await seed(f,a,{timestamp:'2026-10-01T12:00:00.000Z'});
    const first=sweep(a);await rendering;const second=sweep(a),resetResult=await a.post('/api/account/history/delete',reset);assert.equal(resetResult.status,409);assert(f.store.getObservation(old.record.id));assert.equal(renders,1);
    release();await first;await second;assert.equal(renders,1);assert.equal((await reportList(a)).length,1);assert.equal(f.store.getObservation(old.record.id),null);assert.equal(f.calls,0);
  }finally{release?.();await f.close();}
});

test('explicit archived-report deletion remains available for a missing or corrupted own PDF',async()=>{
  const f=await fixture({reportRender:async()=>Buffer.from('%PDF-1.7\nprivate test report\n%%EOF')});try{
    const a=await owner(f),b=await user(f);
    for(const [month,damage] of [['2026-09','missing'],['2026-10','corrupt']]){
      const saved=await seed(f,a,{timestamp:month+'-01T12:00:00.000Z'}),report=(await ok(a.post('/api/reports/monthly',{month,timeZone:'UTC'}))).report,row=f.store.db.prepare('SELECT file_ref FROM monthly_reports WHERE id=? AND user_id=?').get(report.id,a.state.user.id),file=f.server.monthlyReports.validate(row.file_ref);
      if(damage==='missing')disk.unlinkSync(file);else disk.writeFileSync(file,'damaged private fixture artifact');
      const read=await a.get('/api/reports/monthly/'+report.id+'/pdf');assert.equal(read.status,503);assertPrivateError(read,f,password);assert.equal((await b.post('/api/reports/monthly/'+report.id+'/delete',{confirmation:'DELETE REPORT'})).status,404);
      await ok(a.post('/api/reports/monthly/'+report.id+'/delete',{confirmation:'DELETE REPORT'}));assert.equal((await a.get('/api/reports/monthly/'+report.id+'/pdf')).status,404);assert(f.store.getObservation(saved.record.id),'Deleting an archive does not delete its retained history');assert(!disk.existsSync(file));
    }
    assert.deepEqual(await reportList(a),[]);assert.equal(f.calls,0);
  }finally{await f.close();}
});

test('old pre-account browser imports cannot restore reset or expired history and cannot reattach an expired source',async()=>{
  const f=await fixture();try{
    const a=await owner(f),old=await seed(f,a,{timestamp:'2026-09-01T12:00:00.000Z'});await configure(a,{snapshotRetention:'30-days'});assert.equal(f.store.getObservation(old.record.id).snapshotRef,null);
    const retry=await ok(a.post('/api/observations/import',{observations:[old.record]}));assert.equal(retry.imported,1);assert.equal(f.store.getObservation(old.record.id).snapshotRef,null);assert.equal(f.store.getObservation(old.record.id).snapshotExpired,true);
    await configure(a,{historyRetention:'30-days'});assert.equal(f.store.getObservation(old.record.id),null);const expired=await ok(a.post('/api/observations/import',{observations:[old.record]}));assert.equal(expired.imported,0);assert.equal(expired.skipped,1);
    const current=await seed(f,a,{timestamp:new Date(f.now).toISOString()});await ok(a.post('/api/account/history/delete',reset));const resetRetry=await ok(a.post('/api/observations/import',{observations:[old.record,current.record]}));assert.equal(resetRetry.imported,0);assert.equal(resetRetry.skipped,2);assert.deepEqual(f.store.forUser(a.state.user.id).observations(),[]);assert.equal(f.calls,0);
  }finally{await f.close();}
});

test('explicit archive deletion opts its month out of automatic recreation across maintenance/restart; manual generation restores consent',async()=>{
  let renders=0;const f=await fixture({reportRender:async()=>{renders++;return Buffer.from('%PDF-1.7\nconsented archive fixture\n%%EOF');}});try{
    const a=await owner(f);await configure(a,{monthlyReports:true,timeZone:'UTC'});const saved=await seed(f,a,{timestamp:'2026-10-01T12:00:00.000Z'});await sweep(a);let reports=await reportList(a);assert.equal(reports.length,1);assert.equal(renders,1);
    await ok(a.post('/api/reports/monthly/'+reports[0].id+'/delete',{confirmation:'DELETE REPORT'}));await sweep(a);assert.deepEqual(await reportList(a),[]);assert.equal(renders,1);assert(f.store.getObservation(saved.record.id));
    await f.restart();assert.deepEqual(await reportList(a),[]);assert.equal(renders,1);assert(f.store.getObservation(saved.record.id));
    const manual=await ok(a.post('/api/reports/monthly',{month:'2026-10',timeZone:'UTC'}));assert.equal(manual.report.month,'2026-10');assert.equal(renders,2);await sweep(a);assert.equal((await reportList(a)).length,1);assert.equal(renders,2);
    await ok(a.post('/api/reports/monthly/'+manual.report.id+'/delete',{confirmation:'DELETE REPORT'}));await configure(a,{historyRetention:'30-days'});assert.deepEqual(await reportList(a),[]);assert.equal(f.store.getObservation(saved.record.id),null,'Explicit finite retention still applies after the user opts out of recreating this archive');assert.equal(renders,2);assert.equal(f.calls,0);
  }finally{await f.close();}
});
