import {test} from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {mkdtemp,rm} from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import {randomUUID} from 'node:crypto';
import {LocalStorage} from '../src/storage.mjs';
import {MonitoringPolicy} from '../src/monitoring.mjs';
import {createTestServer as createServer,testFetch as fetch} from './auth-fixture.mjs';
import {SnapshotStore} from '../src/snapshot-store.mjs';
import {dayBounds,analytics,insights,askLocal} from '../src/intelligence.mjs';

const image='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+j1ioAAAAASUVORK5CYII=';
const fixture={activity:'Using computer',location:'Study',description:'A person appears to be using a computer.',confidence:.9,objects:['monitor','keyboard','Monitor','water bottle'],timestamp:'2026-10-02T22:45:00.000Z'};
const scoped={date:'2026-10-02',timeZone:'America/New_York',cameras:[{id:'local-webcam',name:'Office'}]};
const record=(values={})=>({...fixture,id:randomUUID(),source:'manual_ai',cameraId:null,cameraName:null,snapshotRef:null,...values});

test('local day boundaries include DST, offset zones and calendar validation',()=>{
  assert.deepEqual(dayBounds('2026-10-02','America/New_York'),{from:'2026-10-02T04:00:00.000Z',to:'2026-10-03T04:00:00.000Z'});
  const spring=dayBounds('2026-03-08','America/New_York'),fall=dayBounds('2026-11-01','America/New_York');assert.equal(Date.parse(spring.to)-Date.parse(spring.from),23*3600000);assert.equal(Date.parse(fall.to)-Date.parse(fall.from),25*3600000);
  assert.equal(dayBounds('2026-10-02','Asia/Kathmandu').from,'2026-10-01T18:15:00.000Z');assert.throws(()=>dayBounds('2026-02-30','UTC'));assert.throws(()=>dayBounds('2026-10-02','Bad/Zone'));
});

test('version 1 migration preserves observations, objects, counters and references; never assigns old cameras',async()=>{
  const directory=await mkdtemp(path.join(os.tmpdir(),'surv-migration-')),filename=path.join(directory,'old.sqlite');let db,store;
  try{
    db=new DatabaseSync(filename);db.exec(`
      CREATE TABLE monitoring_sessions(id TEXT PRIMARY KEY,started_at TEXT NOT NULL,ended_at TEXT,camera_source TEXT NOT NULL,interval_ms INTEGER NOT NULL CHECK(interval_ms=15000),status TEXT NOT NULL,end_reason TEXT,api_requests INTEGER NOT NULL,successful_analyses INTEGER NOT NULL,failed_analyses INTEGER NOT NULL,no_person_skipped INTEGER NOT NULL,invalid_frame_skipped INTEGER NOT NULL,last_request_at TEXT,updated_at TEXT NOT NULL) STRICT;
      CREATE TABLE observations(id TEXT PRIMARY KEY,timestamp TEXT NOT NULL,activity TEXT NOT NULL,location TEXT NOT NULL,description TEXT NOT NULL,confidence REAL NOT NULL,objects_json TEXT NOT NULL,source TEXT NOT NULL,monitoring_session_id TEXT REFERENCES monitoring_sessions(id),snapshot_ref TEXT,user_context TEXT NOT NULL,legacy_imported INTEGER NOT NULL) STRICT;
      PRAGMA user_version=1;
    `);
    const session=randomUUID(),id=randomUUID(),ref=randomUUID()+'.jpg';db.prepare('INSERT INTO monitoring_sessions VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)').run(session,fixture.timestamp,fixture.timestamp,'original-device',15000,'completed','auto_off',3,2,1,5,4,fixture.timestamp,fixture.timestamp);
    db.prepare('INSERT INTO observations VALUES (?,?,?,?,?,?,?,?,?,?,?,?)').run(id,fixture.timestamp,fixture.activity,fixture.location,fixture.description,fixture.confidence,JSON.stringify(fixture.objects),'automatic_ai',session,ref,'Old context',0);
    const beforeSession=db.prepare('SELECT * FROM monitoring_sessions').get();db.close();db=null;
    store=new LocalStorage(filename);const saved=store.getObservation(id),run=store.session(session);assert.equal(saved.cameraId,null);assert.equal(saved.cameraName,null);assert.equal(saved.monitoringSessionId,session);assert.equal(saved.snapshotRef,ref);assert.equal(saved.context,'Old context');assert.deepEqual(saved.objects,fixture.objects);
    for(const [key,value] of Object.entries(beforeSession))assert.equal(run[key],value);assert.equal(run.camera_id,null);assert.equal(store.db.prepare('PRAGMA user_version').get().user_version,5);assert.equal(store.db.prepare('PRAGMA foreign_keys').get().foreign_keys,1);assert.deepEqual(store.db.prepare('PRAGMA foreign_key_check').all(),[]);
    assert.equal(store.camera().name,'Office');store.renameCamera('local-webcam','Study camera');store.setInterval(30000);store.close();store=new LocalStorage(filename);assert.equal(store.camera().name,'Study camera');assert.equal(store.settings().intervalMs,30000);assert.deepEqual(store.getObservation(id),saved);
  }finally{db?.close();store?.close();await rm(directory,{recursive:true,force:true});}
});

test('selected interval controls eligibility, has a server minimum and never queues missed submissions',()=>{
  let now=100000;const policy=new MonitoringPolicy({now:()=>now});assert.throws(()=>policy.start({intervalMs:10000}));
  for(const intervalMs of [30000,60000]){const session=policy.start({intervalMs}),frame={frameValid:true,personPresent:true};now+=60000;const first=policy.checked(session,frame,{},false);policy.consume(session.id,first.ticket,false);now+=intervalMs-1;assert.equal(policy.checked(session,frame,{},false).ticket,null);now++;const next=policy.checked(session,frame,{},false);assert(next.ticket);policy.consume(session.id,next.ticket,false);now+=600000;const afterGap=policy.checked(session,frame,{},false);policy.consume(session.id,afterGap.ticket,false);assert.equal(policy.checked(session,frame,{},false).ticket,null);assert.equal(policy.checked(session,frame,{},true).ticket,null);}
});

test('analytics counts real records and deduplicates each normalized object per observation',()=>{
  const values=[record({cameraId:'local-webcam',cameraName:'Old name',source:'automatic_ai'}),record({activity:'Reading',confidence:.7,objects:['book','book','water bottle']}),record({source:'automatic_ai',objects:[]})];
  const sessions=[{api_requests:4,successful_analyses:2,failed_analyses:1,no_person_skipped:8,invalid_frame_skipped:3}];
  const data=analytics(values,sessions,{...scoped,from:scoped.date,to:scoped.date});assert.equal(data.totals.observations,3);assert.equal(data.totals.automatic,2);assert.equal(data.totals.manual,1);assert.equal(data.totals.monitoringSessions,1);assert.equal(data.totals.apiRequests,4);assert.equal(data.totals.successfulAnalyses,2);assert.equal(data.byHour[18].count,3);assert.equal(data.byDay[0].count,3);assert.equal(data.byCamera.find(c=>c.id==='local-webcam').label,'Office');assert.equal(data.objects.find(o=>o.label==='monitor').count,1);assert.equal(data.objects.find(o=>o.label==='book').count,1);assert.equal(data.objects.find(o=>o.label==='water bottle').count,2);assert(!JSON.stringify(data).includes('duration'));
  const empty=analytics([],[],{...scoped,from:scoped.date,to:scoped.date});assert.equal(empty.totals.averageConfidence,null);assert.equal(empty.totals.observations,0);assert.deepEqual(empty.objects,[]);
});

test('insights are deterministic counts with conservative evidence wording',()=>{
  const values=[record(),record({timestamp:'2026-10-02T22:50:00.000Z'})],options={...scoped,previousRecords:[record()]};
  const result=insights(values,[],options);assert.deepEqual(insights(values,[],options),result);assert(result.cards.some(c=>c.text.includes('Visibility does not establish')));assert(result.cards.some(c=>c.text.includes('Frequency does not establish')));assert(result.cards.some(c=>c.title==='Compared with previous day'));assert(!JSON.stringify(result).includes('spent most'));assert.equal(insights([],[],scoped).empty,true);
});

test('Ask supports selected-day times, activities, objects, cameras, counts and unknown gaps',()=>{
  const values=[record({cameraId:'local-webcam',cameraName:'Office',source:'automatic_ai'}),record({activity:'Watching video content',objects:['phone','screen'],timestamp:'2026-10-02T22:50:00.000Z'}),record({activity:'Reading',objects:['book'],timestamp:'2026-10-02T12:00:00.000Z'})];
  const query=q=>askLocal(q,values,[],scoped);
  assert.equal(query('What was I doing around 6:45 PM?').evidence.length,2);assert(query('What was I doing at 3 PM?').text.includes('unknown'));assert.equal(query('What was I doing at 6:45?').kind,'clarification');assert.equal(query('When was I using my PC?').evidence.some(r=>r.id===values[0].id),true);assert.equal(query('When was I watching videos?').evidence[0].id,values[1].id);assert.equal(query('Was my water bottle seen today?').evidence[0].id,values[0].id);assert.equal(query('Did you see a phone today?').evidence[0].id,values[1].id);assert.equal(query('When was my phone visible?').evidence[0].id,values[1].id);
  assert(query('What was observed in the Office?').evidence.some(r=>r.id===values[0].id));assert(query('How many observations were made today?').text.startsWith('3'));assert(query('How many automatic observations?').text.startsWith('1'));assert(query('How many manual observations?').text.startsWith('2'));assert.equal(query('What was the most common object?').kind,'objects');assert.equal(query('What was the most common activity?').kind,'activities');assert.equal(query('What cameras observed me today?').kind,'cameras');assert.equal(query('What objects were seen today?').kind,'objects');assert.equal(query('What did I do today?').evidence.length,3);assert.equal(query('How long was I working?').kind,'unsupported');assert.equal(query('Was a guitar seen?').evidence.length,0);assert(askLocal('What did I do today?',[],[],scoped).text.includes('unknown'));
});

test('object-only, negated and user-context evidence never become drinking/eating/typing/reading/phone actions',()=>{
  const objectOnly=record({activity:'Using computer',description:'A bottle and phone are on the desk. The person is not drinking.',objects:['water bottle','food','keyboard','book','phone'],context:'I drank, ate, typed, read and used my phone.'});
  for(const question of ['Did I drink today?','Did I eat today?','Did I type today?','Did I read today?','Did I use my phone today?']){const result=askLocal(question,[objectOnly],[],scoped);assert.equal(result.count,0,question);assert(result.context.observations.every(r=>r.evidenceType==='object-context'));}
  const behavior=record({activity:'Working at computer and drinking',description:'The person appears to be drinking from a bottle.'});const result=askLocal('Did I drink today?',[objectOnly,behavior],[],scoped);assert.equal(result.evidence.find(r=>r.id===behavior.id).evidenceType,'behavior');assert.equal(result.context.observations.find(r=>r.id===objectOnly.id).evidenceType,'object-context');assert(!result.text.includes('drank water 2 times'));
  for(const description of ['A bottle of drinking water is on the desk.','The person is beside a bottle containing drinking water.','A drinking water bottle is visible.']){
    const result=askLocal('Did I drink today?',[record({description})],[],scoped);assert.equal(result.count,0,description);assert(result.context.observations.every(r=>r.evidenceType==='object-context'));
  }
  const noun=record({activity:'Using computer',description:'The person is near a working computer and reading glasses.',objects:['computer','book']});assert(askLocal('Did I work today?',[noun],[],scoped).count===0);assert(askLocal('Did I read today?',[noun],[],scoped).count===0);
});

test('HTTP local endpoints never call AI, filter before querying and persist camera/interval/session association across restart',async()=>{
  const directory=await mkdtemp(path.join(os.tmpdir(),'surv-local-api-'));let now=Date.parse(fixture.timestamp),calls=0,server,origin;
  const options={databasePath:path.join(directory,'history.sqlite'),snapshots:new SnapshotStore(path.join(directory,'snapshots')),now:()=>now,apiKey:'test-only',detector:{async start(){},async inspect(){return {frameValid:true,personPresent:true};},close(){}},fetchImpl:async()=>{calls++;return new Response(JSON.stringify({status:'completed',output:[{type:'message',content:[{type:'output_text',text:JSON.stringify(fixture)}]}]}));}};
  const start=async()=>{server=createServer(options);await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));origin=`http://127.0.0.1:${server.address().port}`;};
  const get=async route=>{const res=await fetch(origin+route);assert.equal(res.status,200);return res.json();};
  const post=async(route,body,status=200)=>{const res=await fetch(origin+route,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});assert.equal(res.status,status);return res.json();};
  try{
    await start();assert.equal((await get('/api/cameras')).cameras[0].name,'Office');await post('/api/cameras/local-webcam',{name:'Study camera'});await post('/api/cameras/local-webcam',{name:'  '},400);await post('/api/settings',{intervalMs:10000},400);await post('/api/settings',{intervalMs:30000});
    for(const timestamp of ['2026-10-02T03:59:59.000Z','2026-10-02T04:00:00.000Z','2026-10-03T04:00:00.000Z'])await post('/api/observations',{observation:record({timestamp}),image});
    const params='date=2026-10-02&timeZone=America%2FNew_York';assert.equal((await get('/api/observations?'+params)).observations.length,1);
    const data=await get('/api/analytics?from=2026-10-02&to=2026-10-02&timeZone=America%2FNew_York');assert.equal(data.totals.observations,1);await get('/api/insights?'+params);
    const answer=await post('/api/ask-local',{question:'What did I do today?',date:scoped.date,timeZone:scoped.timeZone});assert.equal(answer.evidence.length,1);assert.equal(answer.evidence[0].timestamp,'2026-10-02T04:00:00.000Z');assert.equal(calls,0);
    await post('/api/ask-local',{question:'What did I do today?',date:'2026-02-30',timeZone:'UTC'},400);
    const first=await post('/api/monitoring/start',{cameraActive:true});assert.equal(first.intervalMs,30000);assert.equal(first.cameraName,'Study camera');await post('/api/settings',{intervalMs:60000});await post('/api/cameras/local-webcam',{name:'Renamed during run'});
    const check=()=>post('/api/monitoring/check',{sessionId:first.sessionId,cameraActive:true,image,timestamp:new Date(now).toISOString()});
    const gate=await check(),automatic=await post('/api/automatic-analyze',{sessionId:first.sessionId,ticket:gate.ticket});assert.equal(automatic.observation.cameraId,'local-webcam');assert.equal(automatic.observation.cameraName,'Renamed during run');assert.deepEqual(automatic.observation.objects,fixture.objects);assert.equal(calls,1);
    now+=30000;assert.equal((await check()).ticket,null);now+=30000;assert((await check()).ticket);await post('/api/monitoring/stop',{sessionId:first.sessionId});const before=(await get('/api/monitoring/sessions')).sessions[0];assert.equal(before.interval_ms,60000);await post('/api/monitoring/stop',{sessionId:first.sessionId});assert.deepEqual((await get('/api/monitoring/sessions')).sessions[0],before);
    await new Promise(resolve=>server.close(resolve));await start();assert.equal((await get('/api/cameras')).cameras[0].name,'Renamed during run');assert.equal((await get('/api/settings')).intervalMs,60000);assert.deepEqual((await get('/api/monitoring/sessions')).sessions[0],before);const second=await post('/api/monitoring/start',{cameraActive:true});assert.equal(second.intervalMs,60000);assert.notEqual(second.sessionId,first.sessionId);assert.equal(second.telemetry.requests,0);await post('/api/monitoring/stop',{sessionId:second.sessionId});
    assert.equal((await get('/api/observations')).observations.filter(r=>r.cameraId).length,1);assert.equal(calls,1);
  }finally{if(server?.listening)await new Promise(resolve=>server.close(resolve));await rm(directory,{recursive:true,force:true});}
});
