import {test} from 'node:test';
import assert from 'node:assert/strict';
import {mkdtemp,rm,readFile} from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import {randomUUID} from 'node:crypto';
import vm from 'node:vm';
import {LocalStorage} from '../src/storage.mjs';
import {historyWeek,mondayOf,dailyHighlight} from '../src/week-summary.mjs';
import {dayBounds} from '../src/local-calendar.mjs';
import {createTestServer as createServer,testFetch as fetch} from './auth-fixture.mjs';
const observation=(timestamp,extra={})=>({id:randomUUID(),timestamp,source:'manual_ai',activity:'Using computer',description:'A person is using the computer.',location:'Office',objects:['water bottle','food container'],confidence:.9,...extra});
test('Monday–Sunday weeks cross month/year boundaries and validate calendar dates',()=>{
  for(const [date,monday] of [['2026-10-04','2026-09-28'],['2026-10-05','2026-10-05'],['2027-01-01','2026-12-28'],['2026-03-08','2026-03-02']])assert.equal(mondayOf(date),monday);
  for(const date of ['2026-02-30','bad',''])assert.throws(()=>mondayOf(date));
});
test('compact SQL week aggregates preserve rows and count exact local spans on 23/25-hour and offset days',async()=>{
  const dir=await mkdtemp(path.join(os.tmpdir(),'surv-week-')),storage=new LocalStorage(path.join(dir,'history.sqlite'));
  try{
    for(const [date,zone] of [['2026-03-08','America/New_York'],['2026-11-01','America/New_York'],['2026-10-02','Asia/Kathmandu'],['2026-10-02','Pacific/Honolulu']]){
      const b=dayBounds(date,zone),before=new Date(Date.parse(b.from)-1).toISOString(),last=new Date(Date.parse(b.to)-1).toISOString();
      const records=[before,b.from,last,b.to].map(t=>observation(t));records.forEach(r=>storage.saveObservation(r));
      const rows=JSON.stringify(storage.observations()),schema=storage.db.prepare('PRAGMA user_version').get().user_version;
      // Never use the full-history/snapshot adapter to produce a week.
      const original=storage.observations;storage.observations=()=>{throw Error('Unscoped records loaded');};
      const week=historyWeek(storage,{date,timeZone:zone});storage.observations=original;
      assert.equal(week.days.length,7);assert.equal(new Date(week.from+'T00:00:00Z').getUTCDay(),1);assert.equal(new Date(week.to+'T00:00:00Z').getUTCDay(),0);
      const day=week.days.find(d=>d.date===date);assert.equal(day.count,2);assert.equal(day.first,b.from);assert.equal(day.last,last);assert.equal(day.actions.drink,0);assert.equal(day.actions.eat,0);
      assert(!JSON.stringify(week).includes('snapshot'));assert(JSON.stringify(week).length<6000);assert.equal(JSON.stringify(storage.observations()),rows);assert.equal(storage.db.prepare('PRAGMA user_version').get().user_version,schema);
      records.forEach(r=>storage.db.prepare('DELETE FROM observations WHERE id=?').run(r.id));
    }
    const empty=historyWeek(storage,{date:'2026-10-02',timeZone:'UTC'});assert(empty.days.every(d=>d.count===0&&d.first===null&&d.last===null&&d.highlight==='No observations'));
  }finally{storage.close();await rm(dir,{recursive:true,force:true});}
});
test('daily signals require explicit action evidence, ignore objects/context and remain deterministic',async()=>{
  const dir=await mkdtemp(path.join(os.tmpdir(),'surv-signals-')),storage=new LocalStorage(path.join(dir,'history.sqlite'));
  try{
    const save=(activity,description,extra={})=>storage.saveObservation(observation('2026-10-02T18:00:00Z',{activity,description,...extra}));
    save('Working computer visible','A drinking water bottle and food container are visible.',{context:'I was drinking and eating'});
    save('Unknown activity','The person is not drinking or eating. A bottle is visible.');
    save('Unknown activity','A bottle contains drinking water.');
    let day=historyWeek(storage,{date:'2026-10-02'}).days[4];assert.deepEqual(day.actions,{drink:0,eat:0,game:0});assert(!/drinking|eating|gaming/i.test(day.highlight));
    save('Drinking','A person is sipping from a cup.');day=historyWeek(storage,{date:'2026-10-02'}).days[4];assert.equal(day.actions.drink,1);assert.equal(day.highlight,'Drinking evidence recorded');
    assert.deepEqual(historyWeek(storage,{date:'2026-10-02'}),historyWeek(storage,{date:'2026-10-02'}));
    const base={count:4,actions:{drink:0,eat:0,game:0},evening:0,lateNight:0,cameraCount:1,categories:[],locations:[]};
    assert.equal(dailyHighlight({...base,evening:3}),'Evening-heavy observations');assert.equal(dailyHighlight({...base,cameraCount:2}),'Multiple cameras recorded');
    assert.equal(dailyHighlight({...base,categories:[{label:'Computer use',count:3}]}),'Computer activity frequently observed');
    assert.equal(dailyHighlight({...base,locations:[{label:'Office',count:3}]}),'Mostly Office observations');assert.equal(dailyHighlight({...base,lateNight:1}),'Late-night observation');
  }finally{storage.close();await rm(dir,{recursive:true,force:true});}
});
test('week HTTP API is read-only, validates dates/zones and makes zero AI calls',async()=>{
  const dir=await mkdtemp(path.join(os.tmpdir(),'surv-week-api-'));let calls=0;
  const server=createServer({databasePath:path.join(dir,'history.sqlite'),apiKey:'test-only',fetchImpl:()=>{calls++;throw Error('AI must not run');},detector:{close(){}}});
  await new Promise(r=>server.listen(0,'127.0.0.1',r));const origin=`http://127.0.0.1:${server.address().port}`;
  try{
    const get=async route=>{const r=await fetch(origin+route);return {status:r.status,data:await r.json()};};
    const before=await get('/api/observations'),sessions=await get('/api/monitoring/sessions'),settings=await get('/api/settings');
    for(const date of ['2026-10-02','2027-01-01','2026-11-01']){const r=await get('/api/history/week?'+new URLSearchParams({date,timeZone:'America/New_York'}));assert.equal(r.status,200);assert.equal(r.data.days.length,7);assert(r.data.days.every(d=>d.count===0));}
    for(const query of ['date=2026-02-30','date=2026-10-02&timeZone=not-a-zone',''])assert.equal((await get('/api/history/week?'+query)).status,400);
    assert.deepEqual(await get('/api/observations'),before);assert.deepEqual(await get('/api/monitoring/sessions'),sessions);assert.deepEqual(await get('/api/settings'),settings);assert.equal(calls,0);
  }finally{await new Promise(r=>server.close(r));await rm(dir,{recursive:true,force:true});}
});
async function navigationContext(url='http://localhost/?historyDate=2026-10-02#timeline'){
  const listeners={},location={href:url,hash:new URL(url).hash},context={Date,URL,URLSearchParams,Intl,location,history:{replaceState(_,__,url){location.href=String(url);},pushState(_,__,url){location.href=String(url);}},window:{addEventListener(type,fn){listeners[type]=fn;}},localDate:()=> '2026-10-04',localData:{insightsError:''},render(){},console};
  vm.createContext(context);vm.runInContext(await readFile(new URL('../dist/history-navigation.js',import.meta.url),'utf8'),context);vm.runInContext('let selectedDate=initialHistoryDate(),historyMode="real";',context);
  return {context,listeners,run:code=>vm.runInContext(code,context)};
}
test('one bookmarkable history date survives route changes, refresh, distant jumps and browser history',async()=>{
  let {context,listeners,run}=await navigationContext();assert.equal(run('selectedDate'),'2026-10-02');
  run("selectHistoryDate('2026-10-04');location.hash='#insights';");assert.equal(run('selectedDate'),'2026-10-04');assert(context.location.href.includes('historyDate=2026-10-04'));
  run("selectHistoryDate('2027-01-01');location.hash='#timeline';");assert.equal(run('historyMonday()'),'2026-12-28');
  run('shiftHistoryWeek(-1)');assert.equal(run('selectedDate'),'2026-12-25');run('shiftHistoryWeek(1)');assert.equal(run('selectedDate'),'2027-01-01');
  run("adoptHistoryDate('2026-10-05')");assert.equal(run('selectedDate'),'2027-01-01');
  assert.equal((await navigationContext(context.location.href)).run('selectedDate'),'2027-01-01');
  context.location.href='http://localhost/?historyDate=2026-10-03#insights';listeners.popstate();assert.equal(run('selectedDate'),'2026-10-03');
  assert.equal((await navigationContext('http://localhost/?historyDate=2026-02-30#timeline')).run('selectedDate'),'2026-10-04');
});
test('weekly fetches share a single flight and discard stale results after a distant date selection',async()=>{
  const {context,run}=await navigationContext();let resolve;const requests=[];
  context.userTimeZone=()=> 'UTC';context.localQuery=params=>new URLSearchParams(params).toString();context.historyApi=route=>new Promise(r=>{requests.push(route);resolve=r;});
  const a=run('refreshHistoryWeek()'),b=run('refreshHistoryWeek()');assert.equal(requests.length,1);
  run("selectedDate='2027-01-01'");resolve({from:'2026-09-28',days:Array(7).fill({count:0})});await a;await Promise.resolve();assert.equal(requests.length,2);
  resolve({from:'2026-12-28',days:Array(7).fill({count:0})});await b;await Promise.resolve();assert.equal(run('weekState.key'),'2026-12-28|UTC');assert.equal(run('weekState.data.from'),'2026-12-28');assert.equal(run('weekState.pending'),null);
});
