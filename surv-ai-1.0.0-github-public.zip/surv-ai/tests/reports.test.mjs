import {test} from 'node:test';
import assert from 'node:assert/strict';
import {randomUUID} from 'node:crypto';
import {mkdtemp,rm,readFile,writeFile,mkdir} from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import {LocalStorage} from '../src/storage.mjs';
import {activityCategory,objectCategory,buildReport,reportPeriod} from '../src/report.mjs';
import {renderReportPDF} from '../src/report-pdf.mjs';

const record=(value={})=>({id:randomUUID(),source:'manual_ai',timestamp:'2026-10-01T14:00:00.000Z',activity:'Using computer',location:'Office',description:'A person uses a computer. A mug is visible.',confidence:.9,objects:['coffee mug','mug','monitor','computer monitor','water bottle'],snapshotRef:null,...value});
const now=Date.parse('2026-11-15T17:00:00.000Z');

test('7/30-day periods count the start as Day 1 and use local calendar boundaries including DST',()=>{
  const week=reportPeriod('2026-10-01',7,'America/New_York');assert.equal(week.endDate,'2026-10-07');assert.equal(week.bounds.to,'2026-10-08T04:00:00.000Z');
  assert.equal(reportPeriod('2026-09-01',30).endDate,'2026-09-30');assert.equal(reportPeriod('2026-01-25',7).endDate,'2026-01-31');
  const dst=reportPeriod('2026-10-30',7,'America/New_York');assert.equal(Date.parse(dst.bounds.to)-Date.parse(dst.bounds.from),169*3600000);
  assert.throws(()=>reportPeriod('2026-02-30',7));assert.throws(()=>reportPeriod('2026-10-01',14));assert.throws(()=>reportPeriod('2026-10-01',7,'unknown-zone'));
});
test('normalization uses explicit labels, one exclusive category per observation, and conservative exact object aliases',()=>{
  for(const value of ['Using computer','Using computer with dual monitors','Using desktop computer','Using computer screens'])assert.equal(activityCategory(value),'Computer use');
  assert.equal(activityCategory('Using computer for coding or programming'),'Coding / programming');
  assert.equal(activityCategory('Eating and using computer'),'Eating / food');assert.equal(activityCategory('Possibly using computer'),'Other observed activity');
  assert.equal(activityCategory('Not drinking, a water bottle is visible'),'Other observed activity');assert.equal(activityCategory('Seated beside a water bottle'),'Other observed activity');
  assert.equal(objectCategory('coffee mug'),'mug');assert.equal(objectCategory('computer monitors'),'monitor');assert.equal(objectCategory('dual monitors'),'monitor');assert.equal(objectCategory('Monitor'),'monitor');assert.equal(objectCategory('bottle'),'bottle');assert.equal(objectCategory('water bottle'),'water bottle');assert.equal(objectCategory('coffee machine'),'coffee machine');
});
test('report is period-scoped, excludes future and demo records, represents zero days and deduplicates aliases within observations',()=>{
  const storage=new LocalStorage(':memory:');
  try{
    storage.saveObservation(record({timestamp:'2026-10-01T03:59:59.000Z',activity:'OUTSIDE BEFORE'}));
    storage.saveObservation(record({timestamp:'2026-10-01T04:00:00.000Z'}));storage.saveObservation(record({timestamp:'2026-10-07T23:00:00.000Z',activity:'Using computer with dual monitors'}));
    storage.saveObservation(record({timestamp:'2026-10-08T04:00:00.000Z',activity:'OUTSIDE AFTER'}));
    assert.throws(()=>storage.saveObservation(record({source:'demo'})));
    const report=buildReport(storage,{startDate:'2026-10-01',length:7,timeZone:'America/New_York',now});
    assert.equal(report.summary.total,2);assert.equal(report.summary.observedDays,2);assert.equal(report.days.length,7);assert.equal(report.days[1].count,0);assert.equal(report.days[1].first,null);
    assert.equal(report.activities[0].count,2);assert.equal(report.activities.reduce((s,a)=>s+a.count,0),2);assert.equal(report.objects.find(o=>o.label==='mug').count,2);assert.equal(report.objects.find(o=>o.label==='monitor').count,2);
    assert(!JSON.stringify(report).includes('OUTSIDE'));assert(!JSON.stringify(report).includes('spent'));assert(!('duration' in report.summary));assert(report.patterns.some(p=>p.includes('missing coverage')));
    assert.throws(()=>buildReport(storage,{startDate:'2026-11-14',length:7,now}),/future/);assert.throws(()=>buildReport(storage,{startDate:'2025-01-01',length:7,now}),/overlap/);
    storage.saveObservation(record({timestamp:'2026-11-10T14:00:00.000Z'}));storage.saveObservation(record({timestamp:'2026-11-15T23:00:00.000Z',activity:'UNRECORDED FUTURE'}));const today=buildReport(storage,{startDate:'2026-11-09',length:7,now});assert.equal(today.summary.total,1);assert(!JSON.stringify(today).includes('UNRECORDED FUTURE'));
  }finally{storage.close();}
});
test('session lifetime counters that cross a report boundary are not claimed as period counters',()=>{
  const storage=new LocalStorage(':memory:');
  try{
    const make=(started,end)=>{const id=randomUUID(),session={id,intervalMs:30000,telemetry:{requests:5,successes:3,failures:2,noPerson:8,invalid:0,lastRequest:end}};storage.createSession(session,started);storage.saveSession(session,end);storage.finishSession(id,end);return id;};
    const partial=make('2026-09-30T23:50:00.000Z','2026-10-01T02:00:00.000Z');make('2026-10-02T01:00:00.000Z','2026-10-02T02:00:00.000Z');make('2026-10-07T23:00:00.000Z','2026-10-08T01:00:00.000Z');
    storage.saveObservation(record({source:'automatic_ai',monitoringSessionId:partial}));
    const r=buildReport(storage,{startDate:'2026-10-01',length:7,now});assert.equal(r.monitoring.sessions,3);assert.equal(r.monitoring.excludedSessions,2);assert.equal(r.monitoring.successful,3);assert.equal(r.monitoring.failed,2);assert.equal(r.monitoring.noPerson,8);assert.equal(r.summary.automatic,1);
  }finally{storage.close();}
});
test('camera counts use saved identities; variable location wording and manual/legacy records cannot create cameras',()=>{
  const storage=new LocalStorage(':memory:');
  try{
    for(const location of ['Office','Indoor room with computer','Office'])storage.saveObservation(record({cameraId:'local-webcam',cameraName:'Study',location}));
    storage.saveObservation(record({cameraId:null,cameraName:null,location:'Somewhere else'}));
    const report=buildReport(storage,{startDate:'2026-09-25',length:7,now});assert.equal(report.summary.cameras,1);assert.equal(report.cameras.find(c=>c.label==='Study').count,3);assert.equal(report.cameras.find(c=>c.label==='Manual upload').count,1);assert.equal(report.locations.find(c=>c.label==='Office').count,2);
    const second=storage.addCamera({name:'Study',deviceId:'test-second-camera'});storage.saveObservation(record({cameraId:second.id,cameraName:'Study'}));const distinct=buildReport(storage,{startDate:'2026-09-25',length:7,now});assert.equal(distinct.summary.cameras,2);assert.equal(distinct.cameras.filter(c=>c.label.startsWith('Study (camera ')).length,2);assert(!JSON.stringify(distinct).includes(second.id));
  }finally{storage.close();}
});
test('local PDF generation handles sparse and larger 30-day history without external requests',async()=>{
  const storage=new LocalStorage(':memory:');const originalFetch=globalThis.fetch;globalThis.fetch=()=>{throw Error('Reporting cannot use network requests');};
  try{
    storage.saveObservation(record());const sparse=buildReport(storage,{startDate:'2026-09-25',length:7,now});
    const sparsePDF=await renderReportPDF(sparse);assert(sparsePDF.subarray(0,5).equals(Buffer.from('%PDF-')));
    for(let day=1;day<=30;day++)for(let i=0;i<20;i++)storage.saveObservation(record({timestamp:`2026-10-${String(day).padStart(2,'0')}T${String(12+i%10).padStart(2,'0')}:00:00.000Z`,activity:i%4===0?'Eating food':i%3===0?'Using computer for coding or programming':'Using computer screens',cameraId:i%2?'local-webcam':null,cameraName:i%2?'Study camera':null,location:'Office',objects:['coffee mug','mug','monitors','computer monitor','water bottle','keyboard']}));
    const large=buildReport(storage,{startDate:'2026-10-01',length:30,now});assert.equal(large.summary.total,601);assert.equal(large.days.length,30);assert.equal(large.activities.reduce((s,a)=>s+a.count,0),601);
    const pdf=await renderReportPDF(large);assert(pdf.length>10000);await mkdir('.test-output',{recursive:true});await writeFile('.test-output/report-sparse.pdf',sparsePDF);await writeFile('.test-output/report-30-day.pdf',pdf);
    await writeFile('.test-output/report-30-day.json',JSON.stringify(large));
  }finally{globalThis.fetch=originalFetch;storage.close();}
});
