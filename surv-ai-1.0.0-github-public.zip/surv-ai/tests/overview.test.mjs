import {test} from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import {randomUUID,webcrypto} from 'node:crypto';
import {createTestServer as createServer,testFetch as fetch} from './auth-fixture.mjs';

function frontend(){
  const elements=new Map();const element=id=>elements.get(id)||elements.set(id,{innerHTML:'',textContent:'',style:{},dataset:{},addEventListener(){},scrollIntoView(){},showModal(){},close(){}}).get(id);
  const context={Date,document:{addEventListener(){},getElementById:element,querySelector:element,querySelectorAll:()=>[],body:{classList:{remove(){}}}},window:{addEventListener(){},scrollTo(){}},location:{hash:'#overview'},localStorage:{getItem(){return null},setItem(){throw Error('Durable data must not be written to browser storage');}},navigator:{},setTimeout(){},clearTimeout(){},setInterval(){},clearInterval(){},Blob,URL,URLSearchParams,crypto:webcrypto,console};
  context.authState={user:{role:'ADMIN',installationOwner:true}};context.authenticatedUI=()=>true;context.updateAccountChrome=()=>{};context.accountPage=()=>'';context.adminPage=()=>'';context.bootstrapAuth=()=>vm.runInContext('historyState.ready=initializeHistory()',context);vm.createContext(context);for(const file of ['time-format.js','observation.js','snapshot-storage.js','test-lab.js','live-camera.js','overview.js','local-intelligence.js','cameras.js','ask-scope.js','ask-results.js','reports.js','history-navigation.js','usage-model.js','usage-dashboard.js','analytics-explorer.js','app.js'])vm.runInContext(fs.readFileSync('dist/'+file,'utf8'),context);
  return {context,element,run:code=>vm.runInContext(code,context)};
}
const record=(timestamp,activity='Reading',source='automatic_ai')=>({id:randomUUID(),timestamp:timestamp.toISOString(),activity,location:'Study',description:'A person appears to be reading.',confidence:.9,objects:['book'],source});

test('Overview uses real latest observation and honest ON/OFF/no-person/stale/empty states',()=>{
  const {context,element,run}=frontend();context.now=Date.now();context.records=[record(new Date(context.now-12000),'Latest reading'),record(new Date(context.now-60000),'Older reading','manual_ai')];
  run("historyState.loading=false;manualRecords=records.map(r=>makeObservationRecord(r,r.id));overviewState.monitoring={monitoring:'on',personPresent:true};overviewState.statusLoadedAt=now;render()");
  assert(element('app').innerHTML.includes('LATEST OBSERVED ACTIVITY'));assert(element('app').innerHTML.includes('Latest reading'));assert(element('app').innerHTML.includes('90%'));assert(element('app').innerHTML.includes('Automatic AI'));assert(!element('app').innerHTML.includes('Working at desk'));assert(!element('app').innerHTML.includes('SIMULATED'));assert(!element('app').innerHTML.includes('4h 49m'));assert(!element('app').innerHTML.includes('54 minutes'));
  assert.equal(run('overviewActivity(now).latest.activity'),'Latest reading');
  run("overviewState.monitoring.personPresent=false;render()");assert(element('app').innerHTML.includes('NOT CURRENTLY OBSERVED'));assert(element('app').innerHTML.includes('No person currently detected.'));assert(element('app').innerHTML.includes('LAST OBSERVED'));assert(!run('current()').includes('Away'));
  run("overviewState.monitoring={monitoring:'off'};render()");assert(element('app').innerHTML.includes('OBSERVATION PAUSED'));assert(element('app').innerHTML.includes('Latest reading'));
  run('showSession(manualRecords[0].id)');assert(element('detail').innerHTML.includes('No duration measured'));
  run("overviewState.monitoring={monitoring:'on',personPresent:true};overviewState.statusLoadedAt=now;manualRecords.forEach(r=>r.timestamp=new Date(now-61000).toISOString())");assert.equal(run('overviewActivity(now).recent'),false);
  run("manualRecords[0].timestamp=new Date(now+1000).toISOString()");assert.equal(run('overviewActivity(now).recent'),false);assert.equal(run('observedTime(manualRecords[0],now)'),'Recorded timestamp is in the future');
  run("overviewState.statusLoadedAt=now-11000");assert.equal(run('overviewActivity(now).label'),'OBSERVATION STATE UNKNOWN');
  run("overviewState.statusLoadedAt=now;overviewState.monitoring={monitoring:'on',personPresent:true,checkedAt:new Date(now-6000).toISOString(),reportedAt:new Date(now).toISOString()}");assert.equal(run('overviewActivity(now).label'),'OBSERVATION PENDING');
  run("overviewState.monitoring.reportedAt=new Date(now-11000).toISOString()");assert.equal(run('overviewActivity(now).label'),'OBSERVATION STATE UNKNOWN');
  run("historyState.error='Offline'");assert.equal(run('overviewActivity(now).label'),'LAST LOADED OBSERVATION');
  run("historyState.error='';manualRecords=[];overviewState.sessions=[];overviewState.sessionsLoaded=true;overviewState.monitoring={monitoring:'off'};overviewState.statusLoadedAt=now;render()");assert(element('app').innerHTML.includes('No observations yet.'));assert(element('app').innerHTML.includes('No observations today.'));assert(element('app').innerHTML.includes('OBSERVATION SUMMARIES'));assert(!element('app').innerHTML.includes('DEMO'));
  context.location.hash='#cameras';run('render()');assert(element('app').innerHTML.includes('No configured cameras'));assert(!element('app').innerHTML.includes('Office camera'));assert(!element('app').innerHTML.includes('Living room'));assert(element('app').innerHTML.includes('Add camera'));assert.equal(run('liveState.cameraActive'),false);
});

test('local-day metrics use stored timestamps/session starts, deduplicate IDs and add no duration',()=>{
  const {context,run}=frontend();context.testDay=new Date(2026,9,2,12);
  const first=record(new Date(2026,9,2,0,0),'Midnight automatic');context.records=[first,first,record(new Date(2026,9,2,23,59),'Late manual','manual_ai'),record(new Date(2026,9,1,23,59),'Yesterday'),record(new Date(2026,9,3,0,0),'Tomorrow')];
  context.sessions=[{started_at:new Date(2026,9,2,0,0).toISOString(),successful_analyses:3},{started_at:new Date(2026,9,2,23,59).toISOString(),successful_analyses:2},{started_at:new Date(2026,9,1,23,59).toISOString(),successful_analyses:20},{started_at:new Date(2026,9,3,0,0).toISOString(),successful_analyses:30}];
  run('manualRecords=records.map(r=>makeObservationRecord(r,r.id));overviewState.sessions=sessions');
  const result=JSON.parse(run('JSON.stringify(overviewToday(testDay))'));assert.equal(result.observations,2);assert.equal(result.automatic,1);assert.equal(result.manual,1);assert.equal(result.monitoringSessions,2);assert.equal(result.successfulAnalyses,5);
  const markers=run('todayObservationMarkers(overviewToday(testDay).records,testDay)');assert(markers.includes(first.id));assert(markers.includes('left:0%'));assert(!markers.includes('Yesterday'));assert(!markers.includes('class="track"'));assert(!markers.includes('duration:'));assert(result.records.every(r=>r.duration===null));
  assert(markers.includes(new Date(2026,9,2,23,59).toISOString()));
});

test('nearby markers group for display only and preserve exact record details',()=>{
  const {context,element,run}=frontend();context.testDay=new Date(2026,9,2,12);context.records=[record(new Date(2026,9,2,12,0),'First observation'),record(new Date(2026,9,2,12,0,15),'Second observation','manual_ai'),record(new Date(2026,9,2,18,0),'Separate observation')];
  run('manualRecords=records.map(r=>makeObservationRecord(r,r.id))');const html=run('todayObservationMarkers(manualRecords,testDay)');
  assert.equal((html.match(/class="observation-point /g)||[]).length,2);assert(html.includes('mixed-point'));assert(html.includes('Unassigned camera and Manual AI'));assert(html.includes('left:50%'));assert(html.includes('left:75%'));for(const r of context.records)assert(html.includes(r.id));
  context.ids=context.records.slice(0,2).map(r=>r.id).join(',');run('showObservationGroup(ids)');assert(element('detail').innerHTML.includes('First observation'));assert(element('detail').innerHTML.includes('Second observation'));assert(element('detail').innerHTML.includes('Grouped for display only'));
  run('showSession(manualRecords[1].id)');assert(element('detail').innerHTML.includes('Second observation'));assert(element('detail').innerHTML.includes('No duration measured'));
});

test('monitoring status reads cannot grant tickets, count requests, renew stale checks or alter history',async()=>{
  let now=Date.now(),calls=0,person=false;const server=createServer({databasePath:':memory:',now:()=>now,apiKey:'test-only',detector:{async start(){},async inspect(){return {frameValid:true,personPresent:person};},close(){}},fetchImpl:async()=>{calls++;throw Error('Overview must not invoke AI');}});
  await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));const origin=`http://127.0.0.1:${server.address().port}`;
  const get=async route=>(await fetch(origin+route)).json();const post=async(route,body)=>(await fetch(origin+route,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)})).json();
  const image='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+j1ioAAAAASUVORK5CYII=';
  try{
    assert.equal((await get('/api/monitoring/status')).monitoring,'off');
    const {sessionId}=await post('/api/monitoring/start',{cameraActive:true});assert.equal((await get('/api/monitoring/status')).personPresent,null);
    const check=()=>post('/api/monitoring/check',{sessionId,cameraActive:true,image,timestamp:new Date(now).toISOString()});
    await check();assert.equal((await get('/api/monitoring/status')).personPresent,false);person=true;await check();const before=await get('/api/monitoring/sessions');
    for(let i=0;i<3;i++){const status=await get('/api/monitoring/status');assert.equal(status.personPresent,true);assert.equal(status.monitoring,'on');assert.equal(status.ticket,undefined);await get('/api/observations');}
    assert.deepEqual(await get('/api/monitoring/sessions'),before);assert.equal(calls,0);
    await post('/api/monitoring/telemetry',{sessionId,clientInvalid:1});assert.equal((await get('/api/monitoring/status')).personPresent,null);
    now+=11000;assert.equal((await get('/api/monitoring/status')).monitoring,'unknown');assert.equal((await get('/api/monitoring/status')).monitoring,'unknown','reading does not renew camera freshness');
    await post('/api/monitoring/stop',{sessionId});assert.equal((await get('/api/monitoring/status')).monitoring,'off');assert.equal(calls,0);
  }finally{await new Promise(resolve=>server.close(resolve));}
});
