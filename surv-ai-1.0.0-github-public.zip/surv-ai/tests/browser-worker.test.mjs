import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import {readFile} from 'node:fs/promises';
import {tabMetadata} from '../browser-companion/metadata.js';
const turn=()=>new Promise(r=>setImmediate(r));
async function worker(){
  const f={queries:[],events:{},storage:{token:'scoped-synthetic-token',port:9876,installation:'Synthetic local'},window:{id:1,focused:true,incognito:false},tab:{id:8,windowId:1,active:true,title:'Synthetic tab',url:'https://youtube.com/watch?v=private'},frames:[],sockets:[],alarms:0};
  const event=name=>({addListener:fn=>{f.events[name]=fn;}});
  class Socket{static OPEN=1;constructor(url){assert.equal(url,'ws://127.0.0.1:9876/browser-companion/channel');this.readyState=1;f.sockets.push(this);setImmediate(()=>this.onopen?.());}send(data){f.frames.push(JSON.parse(data));}close(){this.readyState=3;this.onclose?.();}}
  const chrome={storage:{local:{get:async()=>({...f.storage}),set:async v=>Object.assign(f.storage,v),remove:async keys=>keys.forEach(k=>delete f.storage[k]),setAccessLevel:async v=>assert.equal(v.accessLevel,'TRUSTED_CONTEXTS')}},alarms:{get:async()=>false,create:async(_name,c)=>{assert.equal(c.periodInMinutes,.5);f.alarms++;},onAlarm:event('alarm')},windows:{getLastFocused:async opts=>{assert.equal(opts.populate,false);return {...f.window};},get:async()=>({...f.window}),onFocusChanged:event('focus'),onRemoved:event('windowRemoved')},tabs:{query:async opts=>{f.queries.push(JSON.parse(JSON.stringify(opts)));if(f.hold)await f.hold;return [{...f.tab}];},onActivated:event('activated'),onUpdated:event('updated'),onRemoved:event('removed')},runtime:{id:'synthetic-id',getURL:p=>'chrome-extension://synthetic-id/'+p,onStartup:event('startup'),onInstalled:event('installed'),onMessage:event('message')}};
  const source=(await readFile(new URL('../browser-companion/background.js',import.meta.url),'utf8')).replace("import {tabMetadata} from './metadata.js';",'');
  const context={chrome,WebSocket:Socket,tabMetadata,Date,AbortSignal,fetch:()=>{throw Error('No networking in mock worker');},globalThis:null};context.globalThis=context;
  vm.runInNewContext(source+'\nglobalThis.stateValue=()=>state;globalThis.sampleRequest=sample;',context);await turn();await turn();f.context=context;
  f.request=async(includeTitle=true)=>{const ws=f.sockets.at(-1);await context.sampleRequest({requestId:'fresh-request',includeTitle},ws);return f.frames.at(-1);};return f;
}
test('suspendable worker reads one active tab in one focused window; no full URLs or private/hidden metadata leave it',async()=>{
  const f=await worker();const sample=await f.request();assert.equal(sample.hostname,'youtube.com');assert.equal(sample.title,'Synthetic tab');assert(!JSON.stringify(sample).includes('private'));assert.deepEqual(f.queries[0],{active:true,windowId:1});assert.equal(f.alarms,1);assert.equal(f.sockets.length,1);
  await f.request(false);assert.equal(f.frames.at(-1).title,null);
  for(const change of [{focused:false},{incognito:true}]){f.window={id:1,focused:true,incognito:false,...change};const s=await f.request();assert.equal(s.hostname,null);assert.equal(s.title,null);assert.equal(s.focused,false);}
  f.window={id:1,focused:true,incognito:false};f.tab.url='chrome://settings';assert.equal((await f.request()).hostname,null);
});
test('multiple windows and rapid tab/focus changes invalidate in-flight samples; background tab updates are ignored',async()=>{
  const f=await worker();let release;f.hold=new Promise(r=>release=r);const request=f.request();await turn();f.events.activated({tabId:9,windowId:2});f.window={id:2,focused:true,incognito:false};f.tab={id:9,active:true,windowId:2,title:'Other tab',url:'https://grammarly.com/journal'};release();assert.equal((await request).focused,false);
  f.hold=null;const next=await f.request();assert.equal(next.hostname,'grammarly.com');assert.deepEqual(f.queries.at(-1),{active:true,windowId:2});
  const before=f.sockets.length;for(let i=0;i<100;i++)f.events.updated(42,{title:'background music'},{active:false,windowId:1});assert.equal(f.sockets.length,before);assert.equal(f.queries.length,2);
});
test('popup messages are private to this extension; pause/disconnect clears socket; restart uses saved scope',async()=>{
  const f=await worker(),sender={id:'synthetic-id',url:'chrome-extension://synthetic-id/popup.html'};
  assert.equal(f.events.message({type:'disconnect'},{id:'untrusted',url:'http://evil'},()=>{}),undefined);
  const send=message=>new Promise(r=>f.events.message(message,sender,r));await send({type:'pause'});assert.equal(f.storage.paused,true);assert.equal(f.sockets[0].readyState,3);const count=f.queries.length;await f.request();assert.equal(f.queries.length,count);
  await send({type:'resume'});await turn();assert.equal(f.sockets.length,2);await send({type:'disconnect'});assert.equal(f.storage.token,undefined);assert.equal(f.context.stateValue(),'not_paired');
});
