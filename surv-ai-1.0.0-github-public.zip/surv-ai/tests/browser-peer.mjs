import net from 'node:net';
import {randomBytes} from 'node:crypto';
import {EXTENSION_ORIGIN} from '../src/browser-companion-store.mjs';
export async function browserPeer(f,token,{origin=EXTENSION_ORIGIN,auto=true}={}){
  const socket=net.createConnection({host:'127.0.0.1',port:Number(new URL(f.origin).port)}),peer={socket,received:[],sequence:0,focused:true,hostname:'youtube.com',title:'Synthetic tab',closed:false,auto};let buffer=Buffer.alloc(0),upgraded=false;
  peer.send=value=>{const data=Buffer.from(JSON.stringify(value)),mask=randomBytes(4),header=data.length<126?Buffer.from([129,128|data.length]):Buffer.from([129,254,data.length>>8,data.length&255]);const payload=Buffer.from(data);for(let i=0;i<payload.length;i++)payload[i]^=mask[i%4];socket.write(Buffer.concat([header,mask,payload]));};
  peer.close=()=>socket.destroy();
  peer.ready=new Promise((resolve,reject)=>{
    socket.once('connect',()=>socket.write(`GET /browser-companion/channel HTTP/1.1\r\nHost: ${new URL(f.origin).host}\r\nOrigin: ${origin}\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Version: 13\r\nSec-WebSocket-Key: ${randomBytes(16).toString('base64')}\r\nSec-WebSocket-Extensions: permessage-deflate; client_max_window_bits\r\n\r\n`));
    socket.on('error',reject);socket.on('close',()=>{peer.closed=true;if(!upgraded)reject(Error('Upgrade rejected'));});
    socket.on('data',chunk=>{
      buffer=Buffer.concat([buffer,chunk]);if(!upgraded){const i=buffer.indexOf('\r\n\r\n');if(i<0)return;const text=buffer.subarray(0,i).toString();if(!text.startsWith('HTTP/1.1 101')){reject(Error('Upgrade rejected'));socket.destroy();return;}buffer=buffer.subarray(i+4);upgraded=true;peer.send({type:'authenticate',token});}
      while(buffer.length>=2){let length=buffer[1]&127,offset=2;if(length===126){if(buffer.length<4)return;length=buffer.readUInt16BE(2);offset=4;}if(buffer.length<offset+length)return;const message=JSON.parse(buffer.subarray(offset,offset+length).toString());buffer=buffer.subarray(offset+length);peer.received.push(message);if(message.type==='ready')resolve(peer);if(message.type==='sample'&&peer.auto)peer.respond(message);}
    });
  });
  peer.respond=(request,extra={})=>peer.send({type:'sample',requestId:request.requestId,sequence:++peer.sequence,timestamp:f.now,focused:peer.focused,hostname:peer.focused?peer.hostname:null,title:peer.focused&&peer.hostname&&request.includeTitle?peer.title:null,...extra});
  return peer.ready;
}
