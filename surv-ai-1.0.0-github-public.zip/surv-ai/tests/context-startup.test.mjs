import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import vm from 'node:vm';
const source=readFileSync(new URL('../dist/context-monitoring.js',import.meta.url),'utf8');
function fixture(saved={supported:true,enabled:true,independentEnabled:true}){
  const requests=[],timers=new Set();let authenticated=true,gate=null,next=0,status='active';
  const scope=vm.createContext({window:{addEventListener(){}},location:{hash:'#overview'},navigator:{},Blob,
    authenticatedUI:()=>authenticated,updateGlobalMonitoring(){},invalidateLocalSummaries(){},render(){},
    setInterval:()=>{const id=++next;timers.add(id);return id;},clearInterval:id=>timers.delete(id),
    historyApi:async(route,body)=>{requests.push({route,body});if(route==='/api/settings/desktop'){if(gate)await gate;return saved;}if(route==='/api/context/start'){status='active';return {session:{id:'same-session',status},runToken:'memory-token'};}if(route.endsWith('pause'))status='paused';if(route.endsWith('stop'))status='completed';return {session:{id:'same-session',status},status:status==='active'?'running':status==='paused'?'paused':'stopped'};}
  });vm.runInContext(source,scope);
  return {scope,requests,timers,run:code=>vm.runInContext(code,scope),hold:promise=>gate=promise,signIn:()=>authenticated=true,signOut:()=>{authenticated=false;vm.runInContext('clearContextRuntime()',scope);}};
}
test('saved context starts once after authentication; concurrent startup/status/routes do not duplicate starts or timers',async()=>{
  const f=fixture();await Promise.all([f.run('startSavedContext()'),f.run('startSavedContext()')]);await f.run('refreshContextStatus()');await f.run('startSavedContext()');
  assert.equal(f.requests.filter(r=>r.route==='/api/context/start').length,1);assert.equal(f.timers.size,1);assert.equal(f.run('contextState.sessionId'),'same-session');
});
test('saved OFF, Desktop Context OFF and unsupported platforms do not start',async()=>{
  for(const change of [{independentEnabled:false},{enabled:false},{supported:false}]){const f=fixture({supported:true,enabled:true,independentEnabled:true,...change});await f.run('startSavedContext()');assert.equal(f.requests.length,1);assert.equal(f.timers.size,0);}
});
test('manual Pause and Stop suppress startup throughout the visit; explicit Start still works',async()=>{
  const f=fixture();await f.run('startSavedContext()');await f.run("contextAction('pause')");await f.run('startSavedContext()');assert.equal(f.run('contextState.data.status'),'paused');
  await f.run("contextAction('stop')");await f.run('refreshContextStatus()');await f.run('startSavedContext()');assert.equal(f.timers.size,0);assert.equal(f.requests.filter(r=>r.route==='/api/context/start').length,1);
  await f.run("contextAction('start')");assert.equal(f.timers.size,1);assert.equal(f.requests.filter(r=>r.route==='/api/context/start').length,2);
});
test('Pause, Stop or disabling consent cancels a pending startup preference read',async()=>{
  for(const action of ["contextAction('pause')","contextAction('stop')",'cancelContextStartup()']){const f=fixture();let release;f.hold(new Promise(r=>release=r));const pending=f.run('startSavedContext()');await f.run(action);release();await pending;assert.equal(f.requests.filter(r=>r.route==='/api/context/start').length,0);}
});
test('account release drops pending startup and run credentials; the next authenticated visit gets one new attempt',async()=>{
  const f=fixture();let release;f.hold(new Promise(r=>release=r));const pending=f.run('startSavedContext()');f.signOut();release();await pending;assert.equal(f.requests.filter(r=>r.route==='/api/context/start').length,0);assert.equal(f.run('contextState.runToken'),null);
  f.signIn();await f.run('startSavedContext()');assert.equal(f.timers.size,1);assert.equal(f.requests.filter(r=>r.route==='/api/context/start').length,1);
});
test('a rejected startup is reported once, without polling retries or a heartbeat timer',async()=>{
  const f=fixture(),api=f.scope.historyApi;f.scope.historyApi=async(...args)=>{const data=await api(...args);if(args[0]==='/api/context/start')throw Error('Context is controlled by another signed-in browser.');return data;};
  await f.run('startSavedContext()');await f.run('refreshContextStatus()');await f.run('startSavedContext()');assert.match(f.run('contextState.error'),/another signed-in browser/);assert.equal(f.requests.filter(r=>r.route==='/api/context/start').length,1);assert.equal(f.timers.size,0);
});
