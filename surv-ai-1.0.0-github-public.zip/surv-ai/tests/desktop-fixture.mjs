import assert from 'node:assert/strict';
import {mkdtemp,rm} from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import {LocalStorage} from '../src/storage.mjs';
import {SnapshotStore} from '../src/snapshot-store.mjs';
import {createServer} from '../server.mjs';
export const password='desktop synthetic fixture passphrase 2026';
export const image='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+j1ioAAAAASUVORK5CYII=';
export const result={activity:'Using computer',location:'Office',description:'A person is seated at a workstation.',objects:['monitor'],confidence:.9};
export class SyntheticCollector{
  constructor(){this.raw={executable:'Code.exe',title:'Synthetic project — Visual Studio Code',state:'active',idleMs:100};this.samples=0;this.starts=0;this.live=false;this.closes=0;this.hold=null;}
  async sample({includeTitle}){if(!this.live){this.live=true;this.starts++;}this.samples++;const raw={...this.raw,title:includeTitle?this.raw.title:null};if(this.hold)await this.hold;return raw;}
  close(){if(this.live)this.closes++;this.live=false;}
}
export async function desktopFixture(extra={}){
  const dir=await mkdtemp(path.join(os.tmpdir(),'surv-desktop-'));
  const f={dir,now:Date.parse('2026-10-06T16:00:00Z'),person:true,valid:true,calls:0,requests:[],collector:new SyntheticCollector(),snapshots:new SnapshotStore(path.join(dir,'snapshots'))};
  f.start=async()=>{
    f.store=new LocalStorage(path.join(dir,'db.sqlite'));
    f.server=createServer({storage:f.store,snapshots:f.snapshots,now:()=>f.now,desktopPlatform:'win32',desktopCollector:f.collector,desktopAutoSchedule:false,apiKey:'mock-only',detector:{async start(){},async inspect(){return {frameValid:f.valid,personPresent:f.person};},close(){}},fetchImpl:async(_url,init)=>{f.calls++;f.requests.push(JSON.parse(init.body));if(f.providerHold)await f.providerHold;return new Response(JSON.stringify({status:'completed',output:[{type:'message',content:[{type:'output_text',text:JSON.stringify(result)}]}]}));},...extra});
    await new Promise(r=>f.server.listen(f.port||0,'127.0.0.1',r));f.origin=`http://127.0.0.1:${f.server.address().port}`;assert.notEqual(new URL(f.origin).port,'4173');await f.server.privacyReady;
  };
  f.settle=async()=>{while(f.server.desktop.busy)await new Promise(r=>setImmediate(r));};
  f.tick=async(c,sessionId,ms=2000)=>{f.now+=ms;await ok(c.post('/api/monitoring/telemetry',{sessionId}));await f.server.desktop.poll();await f.settle();};
  f.restart=async()=>{await new Promise(r=>f.server.close(r));await f.start();};
  f.close=async()=>{if(f.server.listening)await new Promise(r=>f.server.close(r));await rm(dir,{recursive:true,force:true});};
  await f.start();return f;
}
export async function client(f,{owner=false,email='desktop-owner@example.test',register=true}={}){
  const state={cookie:'',csrf:'',user:null};
  const request=async(route,body)=>{const res=await fetch(f.origin+route,{method:body?'POST':'GET',headers:{...(body?{'Content-Type':'application/json'}:{}),Cookie:state.cookie,'X-Surv-CSRF':state.csrf},...(body?{body:JSON.stringify(body)}:{})});if(res.headers.get('set-cookie'))state.cookie=res.headers.get('set-cookie').split(';')[0];const data=res.headers.get('content-type')?.includes('json')?await res.json():Buffer.from(await res.arrayBuffer());if(data.csrfToken)state.csrf=data.csrfToken;if(data.user)state.user=data.user;return {status:res.status,res,data};};
  const c={state,get:route=>request(route),post:(route,body)=>request(route,body)};await c.get('/api/auth/me');
  await ok(c.post(register?(owner?'/api/auth/owner':'/api/auth/register'):'/api/auth/login',register?{displayName:'Desktop Fixture',email,password,confirmPassword:password}:{email,password}));
  const me=await ok(c.get('/api/auth/me'));if(me.onboarding?.pending){for(const step of [4,5,6])await ok(c.post('/api/onboarding/progress',{step}));await ok(c.post('/api/onboarding/complete',{}));}return c;
}
export const ok=async promise=>{const r=await promise;assert.equal(r.status,200,JSON.stringify(r.data));return r.data;};
export const enable=(c,cameraId='local-webcam',includeTitle=false)=>ok(c.post('/api/settings/desktop',{enabled:true,includeTitle,cameraId}));
export async function start(f,c,cameraId='local-webcam'){const r=await ok(c.post('/api/monitoring/start',{cameraActive:true,cameraId}));await f.settle();return r.sessionId;}
export const check=(f,c,id,extra={})=>c.post('/api/monitoring/check',{sessionId:id,cameraActive:true,image,timestamp:new Date(f.now).toISOString(),...extra});
export async function automatic(f,c,id,extra={}){const gate=await ok(check(f,c,id));return ok(c.post('/api/automatic-analyze',{sessionId:id,ticket:gate.ticket,...extra}));}
