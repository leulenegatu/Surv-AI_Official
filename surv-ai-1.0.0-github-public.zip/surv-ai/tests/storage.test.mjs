import {test} from 'node:test';
import assert from 'node:assert/strict';
import {mkdtemp,rm,readdir} from 'node:fs/promises';
import {fork} from 'node:child_process';
import {once} from 'node:events';
import path from 'node:path';
import os from 'node:os';
import {randomUUID} from 'node:crypto';
import {LocalStorage} from '../src/storage.mjs';
import {createTestServer as createServer,testFetch as fetch,registerTestOrigin} from './auth-fixture.mjs';
import {SnapshotStore} from '../src/snapshot-store.mjs';

const image='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+j1ioAAAAASUVORK5CYII=';
const fixture={activity:'Reading',location:'Study',description:'Person appears to be reading.',confidence:.91,objects:['person','book'],timestamp:'2026-10-02T14:00:00.000Z'};
test('SQLite initializes, validates real records, round-trips context/refs, imports idempotently and recovers unfinished sessions',async()=>{
  const directory=await mkdtemp(path.join(os.tmpdir(),'surv-db-')),filename=path.join(directory,'history.sqlite');let store;
  try{
    store=new LocalStorage(filename);assert.deepEqual(store.observations(),[]);assert.deepEqual(store.sessions(),[]);
    const session={id:randomUUID(),telemetry:{requests:2,successes:1,failures:1,noPerson:3,invalid:4,lastRequest:fixture.timestamp},clientInvalid:5};
    store.createSession(session,fixture.timestamp);store.saveSession(session,fixture.timestamp);
    const automatic=store.saveObservation({...fixture,id:randomUUID(),source:'automatic_ai',monitoringSessionId:session.id,snapshotRef:randomUUID()+'.jpg',context:'Local webcam'});
    const manual=store.saveObservation({...fixture,id:randomUUID(),source:'manual_ai',snapshotRef:randomUUID()+'.png',context:'Office camera'});
    assert.equal(manual.monitoringSessionId,null);assert.equal(manual.duration,null);
    assert.throws(()=>store.saveObservation({...manual,id:randomUUID(),source:'demo'}));
    assert.throws(()=>store.saveObservation({...manual,id:randomUUID(),monitoringSessionId:session.id}));
    assert.throws(()=>store.saveObservation({...automatic,id:randomUUID(),monitoringSessionId:randomUUID()}));
    const legacy={...fixture,id:randomUUID(),source:'automatic_ai',snapshotRef:null};
    store.saveObservation(legacy,{legacy:true});store.saveObservation(legacy,{legacy:true});assert.equal(store.observations().length,3);
    store.close();store=new LocalStorage(filename);store.recoverUnfinished();
    assert.deepEqual(store.getObservation(automatic.id),automatic);assert.deepEqual(store.getObservation(manual.id),manual);
    const persisted=store.session(session.id);assert.equal(persisted.status,'interrupted');assert.equal(persisted.ended_at,null);assert.equal(persisted.invalid_frame_skipped,9);assert.equal(persisted.api_requests,2);assert.equal(persisted.no_person_skipped,3);
    assert.equal(store.observations().filter(r=>r.legacyImported).length,1);
    assert.throws(()=>store.transaction(()=>{store.saveObservation({...manual,id:randomUUID()});throw Error('rollback');}));assert.equal(store.observations().length,3);
  }finally{store?.close();await rm(directory,{recursive:true,force:true});}
});

test('HTTP manual/automatic observations, snapshot links and finalized counters survive actual server restart',async()=>{
  const directory=await mkdtemp(path.join(os.tmpdir(),'surv-restart-'));let now=Date.parse(fixture.timestamp),person=false,valid=true,fail=false,calls=0,server,origin;
  const options={databasePath:path.join(directory,'history.sqlite'),snapshots:new SnapshotStore(path.join(directory,'snapshots')),now:()=>now,apiKey:'test-only',detector:{async start(){},async inspect(){return {frameValid:valid,personPresent:person};},close(){}},fetchImpl:async()=>{calls++;if(fail)return new Response('',{status:429});return new Response(JSON.stringify({status:'completed',output:[{type:'message',content:[{type:'output_text',text:JSON.stringify(fixture)}]}]}));}};
  const start=async()=>{server=createServer(options);await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));origin=`http://127.0.0.1:${server.address().port}`;};
  const get=async route=>(await fetch(origin+route)).json();
  const post=async(route,body)=>{const response=await fetch(origin+route,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});return {status:response.status,data:await response.json()};};
  try{
    await start();assert.deepEqual((await get('/api/observations')).observations,[]);
    const draft={...fixture,id:randomUUID(),source:'manual_ai',context:'User context'};
    const manual=(await post('/api/observations',{observation:draft,image})).data.observation;assert(manual.snapshotRef);assert.equal(manual.monitoringSessionId,null);
    assert.equal((await post('/api/observations',{observation:draft,image})).data.observation.id,manual.id,'commit retry is idempotent');assert.equal((await get('/api/observations')).observations.length,1);
    assert.equal((await post('/api/observations',{observation:{...draft,source:'demo'},image})).status,400);
    assert.equal((await fetch(origin+'/api/snapshots/'+manual.snapshotRef,{method:'DELETE'})).status,409);
    const {sessionId}=(await post('/api/monitoring/start',{cameraActive:true,cameraSource:'test-webcam'})).data;
    const check=()=>post('/api/monitoring/check',{sessionId,cameraActive:true,image,timestamp:new Date(now).toISOString(),context:'Local webcam',clientInvalid:2});
    await check();valid=false;await check();assert.equal(calls,0);valid=true;person=true;
    const gate=(await check()).data;
    const automatic=(await post('/api/automatic-analyze',{sessionId,ticket:gate.ticket})).data.observation;
    assert.equal(automatic.monitoringSessionId,sessionId);assert.equal(automatic.duration,null);
    assert.equal((await get('/api/observations')).observations.length,2,'automatic saved without any browser commit');
    const stop=await post('/api/monitoring/stop',{sessionId,clientInvalid:3});assert.equal(stop.data.session.status,'completed');assert(stop.data.session.ended_at);
    assert.equal(stop.data.session.api_requests,1);assert.equal(stop.data.session.successful_analyses,1);assert.equal(stop.data.session.failed_analyses,0);assert.equal(stop.data.session.no_person_skipped,1);assert.equal(stop.data.session.invalid_frame_skipped,4);
    await new Promise(resolve=>server.close(resolve));await start();
    const records=(await get('/api/observations')).observations;assert.equal(records.length,2);assert(records.some(r=>r.id===manual.id&&r.context==='User context'));
    for(const r of records){const snapshot=await fetch(origin+'/api/snapshots/'+r.snapshotRef);assert.equal(snapshot.status,200);assert.deepEqual(Buffer.from(await snapshot.arrayBuffer()),Buffer.from(image.split(',')[1],'base64'));assert.equal(r.duration,null);}
    assert.deepEqual((await get('/api/monitoring/sessions')).sessions[0],stop.data.session);
    const next=(await post('/api/monitoring/start',{cameraActive:true})).data;assert.notEqual(next.sessionId,sessionId);assert.equal(next.telemetry.requests,0);assert.equal(next.telemetry.invalid,0);
    now+=15000;fail=true;const failedGate=(await post('/api/monitoring/check',{sessionId:next.sessionId,cameraActive:true,image,timestamp:new Date(now).toISOString()})).data;
    assert.equal((await post('/api/automatic-analyze',{sessionId:next.sessionId,ticket:failedGate.ticket})).status,502);
    const sessions=(await get('/api/monitoring/sessions')).sessions;assert.equal(sessions.length,2);assert.equal(sessions.find(s=>s.id===sessionId).api_requests,1);assert.equal(sessions.find(s=>s.id===next.sessionId).failed_analyses,1);assert.equal((await get('/api/observations')).observations.length,2);
    const legacy={...fixture,id:randomUUID(),source:'manual_ai',recordType:'observation'};await post('/api/observations/import',{observations:[legacy]});await post('/api/observations/import',{observations:[legacy]});assert.equal((await get('/api/observations')).observations.length,3);
  }finally{if(server?.listening)await new Promise(resolve=>server.close(resolve));await rm(directory,{recursive:true,force:true});}
});

test('forced process termination preserves WAL records and marks an unresolved request interrupted',async()=>{
  const directory=await mkdtemp(path.join(os.tmpdir(),'surv-crash-')),filename=path.join(directory,'history.sqlite'),snapshots=path.join(directory,'snapshots');let child,server;
  try{
    child=fork(new URL('./crash-server.mjs',import.meta.url),[filename,snapshots],{stdio:['ignore','ignore','inherit','ipc']});
    const [message]=await once(child,'message');let origin=`http://127.0.0.1:${message.port}`;registerTestOrigin(origin);
    const post=async(route,body)=>(await fetch(origin+route,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)})).json();
    const manual=(await post('/api/observations',{observation:{...fixture,id:randomUUID(),source:'manual_ai'},image})).observation;
    const {sessionId}=await post('/api/monitoring/start',{cameraActive:true});
    const gate=await post('/api/monitoring/check',{sessionId,cameraActive:true,image,timestamp:new Date().toISOString()});
    const pending=post('/api/automatic-analyze',{sessionId,ticket:gate.ticket}).catch(()=>{});
    let requests=0;for(let i=0;i<100&&requests===0;i++){const data=await (await fetch(origin+'/api/monitoring/sessions')).json();requests=data.sessions[0].api_requests;if(!requests)await new Promise(resolve=>setTimeout(resolve,10));}
    assert.equal(requests,1);const exited=once(child,'exit');child.kill('SIGKILL');await exited;await pending;
    server=createServer({databasePath:filename,snapshots:new SnapshotStore(snapshots)});await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));origin=`http://127.0.0.1:${server.address().port}`;
    const observations=await (await fetch(origin+'/api/observations')).json();assert.equal(observations.observations[0].id,manual.id);assert.equal((await fetch(origin+'/api/snapshots/'+manual.snapshotRef)).status,200);
    const {sessions}=await (await fetch(origin+'/api/monitoring/sessions')).json();assert.equal(sessions[0].id,sessionId);assert.equal(sessions[0].status,'interrupted');assert.equal(sessions[0].ended_at,null);assert.equal(sessions[0].api_requests,1);assert.equal(sessions[0].successful_analyses,0);assert.equal(sessions[0].failed_analyses,0);assert.equal(sessions[0].no_person_skipped,0);
  }finally{if(child&&child.exitCode===null&&child.signalCode===null){const exited=once(child,'exit');child.kill();await exited;}if(server?.listening)await new Promise(resolve=>server.close(resolve));await rm(directory,{recursive:true,force:true});}
});

test('failed automatic database commit stops monitoring and cleans up an unreferenced snapshot',async()=>{
  const directory=await mkdtemp(path.join(os.tmpdir(),'surv-write-failure-')),storage=new LocalStorage(path.join(directory,'history.sqlite'));
  const server=createServer({storage,apiKey:'test-only',snapshots:new SnapshotStore(path.join(directory,'snapshots')),detector:{async start(){},async inspect(){return {frameValid:true,personPresent:true};},close(){}},fetchImpl:async()=>new Response(JSON.stringify({status:'completed',output:[{type:'message',content:[{type:'output_text',text:JSON.stringify(fixture)}]}]}))});
  await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));const origin=`http://127.0.0.1:${server.address().port}`;
  const post=async(route,body)=>fetch(origin+route,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
  try{
    const {sessionId}=await (await post('/api/monitoring/start',{cameraActive:true})).json();
    const gate=await (await post('/api/monitoring/check',{sessionId,cameraActive:true,image,timestamp:new Date().toISOString()})).json();
    storage.transaction=()=>{throw Error('Simulated failed disk commit');};
    assert.equal((await post('/api/automatic-analyze',{sessionId,ticket:gate.ticket})).status,507);
    assert.equal(storage.session(sessionId).status,'completed');assert.equal(storage.session(sessionId).api_requests,1);assert.equal(storage.session(sessionId).failed_analyses,1);assert.equal(storage.session(sessionId).successful_analyses,0);assert.equal(storage.observations().length,0);
    assert.equal((await post('/api/monitoring/check',{sessionId,cameraActive:true,image,timestamp:new Date().toISOString()})).status,409);assert.deepEqual(await readdir(path.join(directory,'snapshots')),[]);
  }finally{await new Promise(resolve=>server.close(resolve));await rm(directory,{recursive:true,force:true});}
});
