import test from 'node:test';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {readFile} from 'node:fs/promises';
const {buildDemo,summary,project,samplePDF,dayShift,dateList,FIRST,TODAY}=createRequire(import.meta.url)('../dist/home.js');
test('one deterministic synthetic calendar links observations, sources, requests and sessions',()=>{
  const d=buildDemo();assert.equal(d.synthetic,true);assert.equal(dateList(FIRST,TODAY).length,42);assert.deepEqual(d,buildDemo());
  assert.equal(new Set(d.observations.map(r=>r.id)).size,d.observations.length);
  for(const r of d.observations){assert(d.cameras.some(c=>c.id===r.cameraId&&c.name===r.camera));assert(d.sessions.some(s=>s.date===r.date&&s.camera===r.camera&&r.minute>=s.start&&r.minute<=s.end));assert.equal(d.requests.filter(q=>q.observationId===r.id).length,1);if(r.context){assert(d.context.some(s=>s.id===r.context.id));assert(r.minute>=r.context.start&&r.minute<r.context.end);assert.equal(r.context.state,'active');}}
});
test('hero, source preview and timeline refer to the same actual demo moment',()=>{
  const r=buildDemo().observations.find(r=>r.id===`observation-${TODAY}-1`);assert.equal(r.minute,624);assert.equal(r.activity,'Using computer');assert.equal(r.camera,'Studio wide');assert.equal(r.confidence,.92);assert.equal(r.context.application,'Microsoft Edge');assert.equal(r.context.hostname,'developer.mozilla.org');assert.equal(r.context.title,'JavaScript reference — MDN');assert.equal(r.context.minutes,40);
});
test('context spans never overlap; idle and unavailable periods do not become foreground time',()=>{
  const d=buildDemo();for(const date of dateList(FIRST,TODAY)){const spans=d.context.filter(s=>s.date===date);spans.forEach((s,i)=>{assert.equal(s.minutes,s.end-s.start);if(i)assert(s.start>=spans[i-1].end);if(s.state!=='active')assert.equal(s.application,null);if(s.hostname)assert.equal(s.provenance,'Windows + Browser Companion');});}
  const s=summary(d,TODAY,TODAY);assert.equal(s.activeMinutes,400);assert.equal(s.idleMinutes,65);assert(s.observations.some(r=>!r.context));
});
test('all range aggregates partition consistently into days and respect selected boundaries',()=>{
  const d=buildDemo();for(const [from,to] of [[TODAY,TODAY],[dayShift(TODAY,-6),TODAY],[dayShift(TODAY,-29),TODAY],['2026-09-01','2026-09-03']]){const s=summary(d,from,to);assert.equal(s.observations.length,dateList(from,to).reduce((n,date)=>n+summary(d,date,date).observations.length,0));assert.equal(s.sessions.length,dateList(from,to).length*3);assert(s.observations.every(r=>r.date>=from&&r.date<=to));assert.equal(s.covered,s.observations.length);assert.equal(s.requests.length-s.covered,s.requests.filter(r=>r.status==='failed').length);assert(s.requests.filter(r=>r.status==='failed').every(r=>r.inputTokens===null));}
});
test('cost scenarios are hypothetical and never mutate recorded history or rates',()=>{
  const d=buildDemo(),before=JSON.stringify(d),off=project(d,{smart:false}),on=project(d,{smart:true,presence:45});assert.equal(on.maximum,off.maximum);assert.equal(on.requests,off.requests*.45);assert.equal(project(d,{smart:true,presence:0}).cost,0);assert.equal(project(d,{smart:true,presence:100}).cost,off.cost);assert.equal(project(d,{smart:false,interval:60}).requests,off.requests/2);assert.equal(project(d,{smart:false,hours:4}).cost,off.cost/2);assert.equal(JSON.stringify(d),before);assert.equal(d.rates.illustrative,true);
});
test('synthetic September PDF contains coherent totals and valid byte offsets',()=>{
  const d=buildDemo(),pdf=samplePDF(d);assert(pdf.startsWith('%PDF-1.4'));assert(pdf.includes('/Count 2'));assert(pdf.includes(`${summary(d,'2026-09-01','2026-09-30').observations.length} saved moments`));assert(pdf.includes('SYNTHETIC SAMPLE / NOT YOUR DATA'));assert(pdf.includes('no real snapshot'));assert(!/[^\x00-\x7f]/.test(pdf));const start=Number(pdf.match(/startxref\n(\d+)/)[1]);assert.equal(pdf.slice(start,start+4),'xref');const offsets=[...pdf.matchAll(/^(\d{10}) 00000 n /gm)].map(m=>Number(m[1]));offsets.forEach((n,i)=>assert(pdf.slice(n).startsWith(`${i+1} 0 obj`)));for(const m of pdf.matchAll(/\/Length (\d+) >>\nstream\n([\s\S]*?)endstream/g))assert.equal(m[2].length,Number(m[1]));
});
test('homepage public entry remains separate from private runtime and external dependencies',async()=>{
  const [html,js,css]=await Promise.all(['home.html','home.js','home.css'].map(name=>readFile(new URL('../dist/'+name,import.meta.url),'utf8')));assert(html.includes('Your everyday,'));assert(html.includes('Leule Negatu'));assert(html.includes('Independent software project'));assert(!html.includes('@gmail.com'));assert(!html.includes('/style.css'));for(const script of ['auth.js','app.js','live-camera.js','context-monitoring.js'])assert(!html.includes('src="/'+script+'"'));assert.deepEqual([...js.matchAll(/fetch\(['"]([^'"]+)/g)].map(m=>m[1]),['/api/public/status']);assert(js.includes("credentials:'omit'"));assert(!js.includes('getUserMedia'));assert(!js.includes('setInterval'));assert(!js.includes('localStorage'));assert(css.includes('prefers-reduced-motion:reduce'));
});
