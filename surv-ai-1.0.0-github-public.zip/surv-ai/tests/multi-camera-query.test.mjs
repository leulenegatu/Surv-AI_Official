import {test} from 'node:test';
import assert from 'node:assert/strict';
import {randomUUID} from 'node:crypto';
import {mkdtemp,rm} from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import {LocalStorage} from '../src/storage.mjs';
import {MonitoringPolicy} from '../src/monitoring.mjs';
import {executeSQLQuery,parseLocalQuery,activityGroup} from '../src/local-query.mjs';
import {createTestServer as createServer,testFetch as fetch} from './auth-fixture.mjs';
import {SnapshotStore} from '../src/snapshot-store.mjs';
const scope={date:'2026-10-02',timeZone:'America/New_York'};
const image='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+j1ioAAAAASUVORK5CYII=';
const record=(values={})=>({id:randomUUID(),timestamp:'2026-10-02T14:00:00.000Z',activity:'Using computer',description:'A person is using the computer.',location:'Office',confidence:.95,objects:['keyboard','water bottle'],source:'manual_ai',snapshotRef:randomUUID()+'.png',...values});

test('per-camera eligibility is independent, interval changes immediately recompute from the last submission and starts are idempotent',()=>{
  let now=100000;const p=new MonitoringPolicy({now:()=>now}),a=p.start({cameraId:'a',intervalMs:30000}),b=p.start({cameraId:'b',intervalMs:30000}),valid={frameValid:true,personPresent:true};
  const gate=p.checked(a,valid,{},false);p.consume(a.id,gate.ticket,false);assert.equal(p.eligibleIn(a),30000);assert.equal(p.eligibleIn(b),0);
  assert.equal(p.checked(b,{frameValid:true,personPresent:false},{},false).ticket,null);assert.equal(b.telemetry.requests,0);assert.equal(a.telemetry.noPerson,0);
  now+=10000;p.setInterval(60000);assert.equal(p.eligibleIn(a),50000);assert.equal(a.intervalMs,60000);assert.equal(p.checked(a,valid,{},false).ticket,null);
  p.setInterval(15000);assert.equal(p.eligibleIn(a),5000);now+=5000;const next=p.checked(a,valid,{},false);assert(next.ticket);assert.equal(p.start({cameraId:'a'}).id,a.id);assert.equal(p.sessions.size,2);
  p.consume(a.id,next.ticket,false);assert(p.checked(b,valid,{},false).ticket);assert.equal(p.checked(b,valid,{},true).ticket,null);
});

test('camera configuration, timestamps and removal persist without altering observations, sessions or snapshot references',async()=>{
  const dir=await mkdtemp(path.join(os.tmpdir(),'surv-camera-config-')),file=path.join(dir,'history.sqlite');let s;
  try{
    s=new LocalStorage(file);s.updateCamera('local-webcam',{deviceId:'device-office'});const camera=s.addCamera({name:'Living Room',deviceId:'device-living'});assert.throws(()=>s.addCamera({name:'Duplicate',deviceId:'device-living'}));
    const session={id:randomUUID(),cameraId:camera.id,cameraName:camera.name,intervalMs:30000,telemetry:{requests:1,successes:1,failures:0,noPerson:2,invalid:0,lastRequest:'2026-10-02T14:00:00.000Z'}};
    s.createSession(session,'2026-10-02T14:00:00.000Z');s.saveSession(session,'2026-10-02T14:00:00.000Z');s.finishSession(session.id,'2026-10-02T14:01:00.000Z');
    const historical=s.saveObservation(record({cameraId:camera.id,cameraName:camera.name,source:'automatic_ai',monitoringSessionId:session.id})),legacy=s.saveObservation(record({cameraId:null,cameraName:null}),{legacy:true}),run=s.session(session.id);
    s.renameCamera(camera.id,'Living Room renamed');s.updateCamera(camera.id,{enabled:false});assert.equal(s.camera(camera.id).enabled,0);s.removeCamera(camera.id);assert.equal(s.camera(camera.id),null);assert.equal(s.cameras().length,1);assert.deepEqual(s.getObservation(historical.id),historical);assert.deepEqual(s.getObservation(legacy.id),legacy);assert.deepEqual(s.session(session.id),run);assert.deepEqual(s.db.prepare('PRAGMA foreign_key_check').all(),[]);
    s.close();s=new LocalStorage(file);assert.equal(s.cameras().length,1);assert.equal(s.cameras({historical:true}).find(c=>c.id===camera.id).name,'Living Room renamed');assert.equal(s.getObservation(historical.id).snapshotRef,historical.snapshotRef);
    const answer=executeSQLQuery(s,'What was observed in Living Room?',scope);assert.equal(answer.count,1);assert.equal(answer.evidence[0].id,historical.id);
  }finally{s?.close();await rm(dir,{recursive:true,force:true});}
});

test('composable SQLite Ask supports chronological, behavioral, object, camera, source and clock filters; preserves raw labels',()=>{
  const s=new LocalStorage(':memory:');try{
    const office=s.camera(),living=s.addCamera({name:'Living Room',deviceId:'living'}),session={id:randomUUID(),cameraId:office.id,cameraName:office.name,intervalMs:15000};s.createSession(session,'2026-10-02T13:00:00.000Z');
    const save=value=>s.saveObservation(record({source:'automatic_ai',monitoringSessionId:session.id,cameraId:office.id,cameraName:office.name,...value}));
    const early=save({timestamp:'2026-10-02T13:00:00.000Z',activity:'Using computer with headset',objects:['Keyboard','keyboard','headset','coffee mug','water bottle']}),drink=save({timestamp:'2026-10-02T18:34:00.000Z',activity:'Working at computer and drinking',description:'A person is drinking from a mug while using a computer.',objects:['coffee mug','keyboard']}),eat=save({timestamp:'2026-10-03T01:10:00.000Z',activity:'Eating while using computer',description:'The person is eating while using a computer.',objects:['bowl','keyboard']}),other=save({timestamp:'2026-10-03T02:00:00.000Z',cameraId:living.id,cameraName:living.name,activity:'Watching video content',description:'The person is watching video content.',objects:['phone','monitor']});
    save({timestamp:'2026-10-01T14:00:00.000Z'});const original=s.getObservation(early.id);
    // Narrow Ask must not load all history through the persistence adapter.
    s.observations=()=>{throw Error('Unscoped history load');};s.sessions=()=>{throw Error('Unscoped run load');};
    const ask=q=>executeSQLQuery(s,q,scope);
    for(const q of ['When was I first seen today?','When was the earliest observation today?','When was I first at my desk?','What was the first Office observation?']){assert.equal(ask(q).first.id,early.id,q);assert.equal(ask(q).queryType,'timestamp');}
    assert.equal(ask('When was I last at my desk?').latest.id,eat.id);assert.equal(ask('What was my last observation?').latest.id,other.id);assert.equal(ask('What was the last thing seen by the Office camera?').latest.id,eat.id);
    assert.equal(ask('What was I doing around 9 PM?').count,1);assert.equal(ask('What did I do this morning?').count,1);assert.equal(ask('Show Office observations between 9 AM and 3 PM').count,2);assert.equal(ask('Show Office observations before 2 PM').count,1);assert.equal(ask('Show Office observations after 8 PM').count,1);
    assert.equal(ask('Was I drinking today?').count,1);assert.equal(ask('Was I eating while using the computer?').count,1);assert.equal(ask('When was a coffee mug seen?').count,2);assert.equal(ask('How many times was a water bottle visible?').count,1);assert.equal(ask('How many automatic observations came from Office?').count,3);assert.equal(ask('How many manual observations came from Office?').count,0);
    const objects=ask('What objects were seen in Office?');assert.equal(objects.objects.find(o=>o.label==='keyboard').count,3);assert(!objects.objects.some(o=>o.label==='phone'));assert.equal(objects.searched,4);
    assert.equal(ask('Show water bottle visibility observations while using computer in Office').count,1);
    const grouped=ask('What did I do today?');assert.equal(grouped.groups.find(g=>g.label==='Computer use').count,1);assert.equal(grouped.groups.find(g=>g.label==='Eating / drinking').count,2);assert.equal(grouped.groups.find(g=>g.label==='Video viewing').count,1);assert.deepEqual(s.getObservation(early.id),original);
    assert.equal(ask('When was I first swimming today?').queryType,'unsupported');assert.equal(ask('When was I not drinking?').queryType,'unsupported');assert.equal(ask('Show observations before lunch').queryType,'unsupported');assert.equal(ask('Why was I stressed today?').queryType,'unsupported');assert.equal(ask('Was a guitar seen today?').queryType,'empty');assert.equal(ask('How long did I use the computer?').understood,false);assert.equal(ask('When was I first seen at 9?').kind,'clarification');
    assert.equal(activityGroup({activity:'Playing video game while eating',description:''}),'Gaming');
  }finally{s.close();}
});

test('SQLite evidence pagination exposes every match and action evidence never comes from objects, context or negative descriptions',()=>{
  const s=new LocalStorage(':memory:');try{
    for(let i=0;i<67;i++)s.saveObservation(record({timestamp:new Date(Date.parse('2026-10-02T14:00:00Z')+i*1000).toISOString(),activity:'Using computer with headset',description:'A person sits near a bottle containing drinking water. The person is not drinking.',context:'I drank water.',objects:['water bottle','keyboard','Keyboard']}));
    const first=executeSQLQuery(s,'What objects were seen today?',scope);assert.equal(first.count,67);assert.equal(first.evidence.length,6);assert.equal(first.objects.find(o=>o.label==='keyboard').count,67);assert.equal(first.hasMore,true);
    const second=executeSQLQuery(s,'What objects were seen today?',scope,{offset:6,limit:50}),third=executeSQLQuery(s,'What objects were seen today?',scope,{offset:56,limit:50});const ids=[...first.evidence,...second.evidence,...third.evidence].map(r=>r.id);assert.equal(new Set(ids).size,67);assert.equal(third.hasMore,false);
    const drinking=executeSQLQuery(s,'Did I drink today?',scope);assert.equal(drinking.count,0);assert.equal(drinking.context.count,67);assert.equal(drinking.context.objects.find(o=>o.label==='water bottle').count,67);assert(!drinking.context.objects.some(o=>o.label==='keyboard'));assert.equal(drinking.evidence.length,0);assert(drinking.context.observations.every(r=>r.evidenceType==='object-context'));
  }finally{s.close();}
});

test('HTTP cameras gate independently, settings update active persisted intervals, same-camera start reuses session and removed camera history survives restart',async()=>{
  const directory=await mkdtemp(path.join(os.tmpdir(),'surv-multi-api-'));let now=Date.parse('2026-10-02T14:00:00Z'),calls=0,server,origin,person=true;
  const options={databasePath:path.join(directory,'history.sqlite'),snapshots:new SnapshotStore(path.join(directory,'snapshots')),now:()=>now,apiKey:'test-only',detector:{async start(){},async inspect(){return {frameValid:true,personPresent:person};},close(){}},fetchImpl:async()=>{calls++;return new Response(JSON.stringify({status:'completed',output:[{type:'message',content:[{type:'output_text',text:JSON.stringify({activity:'Using computer',description:'The person is using the computer.',location:'Office',confidence:.95,objects:['keyboard']})}]}]}));}};
  const start=async()=>{server=createServer(options);await new Promise(r=>server.listen(0,'127.0.0.1',r));origin=`http://127.0.0.1:${server.address().port}`;},get=async route=>(await fetch(origin+route)).json(),post=async(route,body)=>{const res=await fetch(origin+route,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});assert.equal(res.status,200,await res.clone().text());return res.json();};
  try{
    await start();const camera=(await post('/api/cameras',{name:'Living Room',deviceId:'living'})).camera;await post('/api/settings',{intervalMs:30000});const ownerId=randomUUID(),a=await post('/api/monitoring/start',{cameraActive:true,cameraId:'local-webcam',ownerId}),b=await post('/api/monitoring/start',{cameraActive:true,cameraId:camera.id});assert.notEqual(a.sessionId,b.sessionId);assert.equal((await post('/api/monitoring/start',{cameraActive:true,cameraId:'local-webcam',ownerId})).sessionId,a.sessionId);
    const conflict=await fetch(origin+'/api/monitoring/start',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({cameraActive:true,cameraId:'local-webcam',ownerId:randomUUID()})});assert.equal(conflict.status,409);
    const check=sessionId=>post('/api/monitoring/check',{sessionId,cameraActive:true,image,timestamp:new Date(now).toISOString()});person=false;assert.equal((await check(b.sessionId)).ticket,null);person=true;const gate=await check(a.sessionId);await post('/api/automatic-analyze',{sessionId:a.sessionId,ticket:gate.ticket});assert.equal(calls,1);
    now+=10000;const sixty=await post('/api/settings',{intervalMs:60000});assert.equal(sixty.monitoring.cameras.find(c=>c.cameraId==='local-webcam').nextEligibleMs,50000);assert.equal((await get('/api/monitoring/sessions')).sessions.find(s=>s.id===a.sessionId).interval_ms,60000);assert.equal((await check(a.sessionId)).ticket,null);
    await post('/api/settings',{intervalMs:15000});now+=5000;assert((await check(a.sessionId)).ticket);assert((await check(b.sessionId)).ticket);await post('/api/cameras/'+camera.id,{name:'Living Room renamed'});const second=await check(b.sessionId);const saved=(await post('/api/automatic-analyze',{sessionId:b.sessionId,ticket:second.ticket})).observation;assert.equal(saved.cameraName,'Living Room renamed');assert.equal(saved.cameraId,camera.id);assert.equal(calls,2);
    await post('/api/monitoring/stop',{sessionId:a.sessionId});await post('/api/monitoring/stop',{sessionId:b.sessionId});const before=await get('/api/monitoring/sessions');await post('/api/monitoring/stop',{sessionId:a.sessionId});assert.deepEqual(await get('/api/monitoring/sessions'),before);
    await post('/api/cameras/'+camera.id,{remove:true});assert.equal((await get('/api/cameras')).cameras.length,1);assert.equal((await get('/api/observations')).observations.length,2);assert.equal((await fetch(origin+'/api/snapshots/'+saved.snapshotRef)).status,200);assert.equal((await post('/api/ask-local',{question:'What happened in Living Room renamed today?',...scope})).count,1);assert.equal(calls,2);
    await new Promise(r=>server.close(r));await start();assert.equal((await get('/api/monitoring/status')).monitoring,'off');assert.deepEqual(await get('/api/monitoring/sessions'),before);assert.equal((await get('/api/cameras')).cameras.length,1);
  }finally{if(server?.listening)await new Promise(r=>server.close(r));await rm(directory,{recursive:true,force:true});}
});


test('camera entity names do not masquerade as activity, source or ordinal filters; clock filters include seconds',()=>{
  const s=new LocalStorage(':memory:');try{
    const lastRoom=s.addCamera({name:'Last Room',deviceId:'last-room'}),desk=s.addCamera({name:'Desk',deviceId:'desk-camera'}),run={id:randomUUID(),cameraId:lastRoom.id,cameraName:lastRoom.name,intervalMs:15000};s.createSession(run,'2026-10-02T14:00:00Z');
    s.saveObservation(record({timestamp:'2026-10-03T01:00:30.000Z',source:'automatic_ai',monitoringSessionId:run.id,cameraId:lastRoom.id,cameraName:lastRoom.name}));
    const p=parseLocalQuery('What happened in Last Room today?',{...scope,cameras:s.cameras()});assert.equal(p.type,'camera');assert.equal(p.order,'asc');
    const activity=parseLocalQuery('When was I first at my desk?',{...scope,cameras:s.cameras()});assert.equal(activity.cameraIds.length,0);assert(activity.activities.includes('computer / desk'));
    assert.equal(parseLocalQuery('What happened in Desk camera?',{...scope,cameras:s.cameras()}).cameraIds[0],desk.id);
    assert.equal(executeSQLQuery(s,'Show Last Room observations after 9 PM',scope).count,1);assert.equal(executeSQLQuery(s,'Show Last Room observations before 9 PM',scope).count,0);
  }finally{s.close();}
});
