import {test} from 'node:test';
import assert from 'node:assert/strict';
import {randomUUID,createHash} from 'node:crypto';
import {mkdtemp,rm,readFile} from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import http from 'node:http';
import {LocalStorage} from '../src/storage.mjs';
import {SnapshotStore} from '../src/snapshot-store.mjs';
import {createServer} from '../server.mjs';
import {verifyPassword} from '../src/auth.mjs';
import * as disk from 'node:fs';
import {inflateRawSync} from 'node:zlib';
import {AccountData} from '../src/account-data.mjs';

// All account mutations use the real authentication endpoints and isolated data.
const password='account fixture private passphrase 2026';
const newPassword='  new account fixture 世界 passphrase 2026  ';
const image='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+j1ioAAAAASUVORK5CYII=';
const digest=value=>createHash('sha256').update(value).digest('hex');
const signup=(email='owner@example.test')=>({displayName:'Fixture Owner',email,password,confirmPassword:password});
async function fixture(extra={}){
  const dir=await mkdtemp(path.join(os.tmpdir(),'surv-account-'));
  const f={dir,origin:null,store:null,server:null,snapshots:new SnapshotStore(path.join(dir,'snapshots')),calls:0};
  f.start=async()=>{
    f.store=new LocalStorage(path.join(dir,'db.sqlite'));
    f.server=createServer({storage:f.store,snapshots:f.snapshots,apiKey:'fixture-only',fetchImpl(){f.calls++;throw Error('Unexpected AI request');},detector:{async start(){},async inspect(){return {frameValid:true,personPresent:false};},close(){}},...extra});
    await new Promise(r=>f.server.listen(0,'127.0.0.1',r));f.origin=`http://127.0.0.1:${f.server.address().port}`;
    assert.notEqual(new URL(f.origin).port,'4173');
  };
  f.restart=async()=>{await new Promise(r=>f.server.close(r));await f.start();};
  f.close=async()=>{if(f.server.listening)await new Promise(r=>f.server.close(r));await rm(dir,{recursive:true,force:true});};
  await f.start();return f;
}
async function client(f){
  const state={cookie:'',csrf:'',user:null};
  const request=async(route,{body,method=body?'POST':'GET',headers={},...options}={})=>{
    const res=await fetch(f.origin+route,{...options,method,headers:{...(body?{'Content-Type':'application/json'}:{}),...(state.cookie?{Cookie:state.cookie}:{}),...(state.csrf?{'X-Surv-CSRF':state.csrf}:{}),...headers},...(body?{body:JSON.stringify(body)}:{})});
    if(res.headers.get('set-cookie'))state.cookie=res.headers.get('set-cookie').split(';')[0];
    const data=res.headers.get('content-type')?.includes('json')?await res.json():Buffer.from(await res.arrayBuffer());
    if(data.csrfToken)state.csrf=data.csrfToken;if(data.user)state.user=data.user;
    return {res,status:res.status,data};
  };
  const c={state,request,get:route=>request(route),post:(route,body)=>request(route,{body})};await c.get('/api/auth/me');return c;
}
const ok=async request=>{const result=await request;assert.equal(result.status,200,JSON.stringify(result.data));return result.data;};
async function owner(f){const c=await client(f);await ok(c.post('/api/auth/owner',signup()));return c;}
async function login(f,email='owner@example.test',pass=password){const c=await client(f);await ok(c.post('/api/auth/login',{email,password:pass}));return c;}
const currentHash=c=>digest(c.state.cookie.slice(c.state.cookie.indexOf('=')+1));
const privateRows=store=>Object.fromEntries(['observations','monitoring_sessions','cameras','app_settings'].map(table=>[table,JSON.stringify(store.db.prepare(`SELECT * FROM ${table} ORDER BY id`).all())]));
async function history(f,userId){
  const owned=f.store.forUser(userId),ref=await f.snapshots.put(image);
  const record=owned.saveObservation({id:randomUUID(),timestamp:'2026-10-04T14:00:00.000Z',activity:'ACCOUNT_PRIVATE_HISTORY',description:'A book is visible.',location:'Office',confidence:.9,objects:['book'],source:'manual_ai',snapshotRef:ref});
  owned.setInterval(30000);owned.setSaveSnapshots(false);return {record,ref,rows:privateRows(f.store),hash:digest(await readFile(path.join(f.snapshots.directory,ref)))};
}
function noSecrets(data,...values){
  const walk=value=>{if(!value||typeof value!=='object')return;for(const [key,item]of Object.entries(value)){assert(!['password','currentPassword','newPassword','confirmPassword','password_hash','passwordHash','token_hash','tokenHash','csrf_token','sessionHash','cookie'].includes(key),`Leaked ${key}`);walk(item);}};walk(data);
  const serialized=JSON.stringify(data);assert(!serialized.includes('$argon2id$'));for(const value of values.filter(Boolean))assert(!serialized.includes(value),'A credential or raw session token was disclosed');
}

async function user(f,email='user@example.test'){const c=await client(f);await ok(c.post('/api/auth/register',signup(email)));return c;}
const deletion={currentPassword:password,confirmation:'DELETE MY ACCOUNT'};
const reset={currentPassword:password,newPassword,confirmPassword:newPassword,confirmation:'RESET PASSWORD'};
const resetRoute=c=>'/api/admin/users/'+c.state.user.id+'/reset-password';
function finals(f){f.store.db.exec("CREATE TABLE completion_finals(id TEXT); CREATE TRIGGER deletion_final AFTER UPDATE OF status ON monitoring_sessions WHEN OLD.status='active' AND NEW.status='completed' BEGIN INSERT INTO completion_finals VALUES(NEW.id); END");}
async function run(c,owner=false){let cameraId;if(!owner)cameraId=(await ok(c.post('/api/cameras',{name:'User camera',deviceId:'fixture-'+randomUUID()}))).camera.id;return (await ok(c.post('/api/monitoring/start',{cameraActive:true,...(cameraId?{cameraId}:{})}))).sessionId;}
function unzip(bytes){const entries={};let offset=0;while(bytes.readUInt32LE(offset)===0x04034b50){const method=bytes.readUInt16LE(offset+8),size=bytes.readUInt32LE(offset+18),nameSize=bytes.readUInt16LE(offset+26),extra=bytes.readUInt16LE(offset+28),name=bytes.subarray(offset+30,offset+30+nameSize).toString(),start=offset+30+nameSize+extra;assert.equal(method,8);entries[name]=inflateRawSync(bytes.subarray(start,start+size));offset=start+size;}assert.equal(bytes.readUInt32LE(offset),0x02014b50);return entries;}

test('Google controls/messaging are removed while local recovery and external-AI privacy wording are honest',async()=>{
  const code=await readFile(new URL('../dist/auth.js',import.meta.url),'utf8');assert(!code.includes('Continue with Google'));assert(!code.includes('Google —'));assert(code.includes('Password recovery is managed by the administrator'));assert(code.includes('Images selected for AI analysis may be sent to the configured AI provider.'));
  const f=await fixture();try{const c=await owner(f),me=await ok(c.get('/api/auth/me'));assert.equal(me.google,undefined);assert.equal(me.emailDeliveryConfigured,false);assert(me.user.installationOwner);assert.equal(me.user.deletionAllowed,false);}finally{await f.close();}
});

test('ADMIN resets only a USER with Argon2id, revokes all target sessions and finalizes exactly once without changing private history or other runtimes',async()=>{
  const f=await fixture();try{const a=await owner(f),b=await user(f),b2=await login(f,'user@example.test'),saved=await history(f,b.state.user.id);finals(f);const aRun=await run(a,true),bRun=await run(b),before=f.store.forUser(b.state.user.id).observations();
    assert.equal((await b.post(resetRoute(a),reset)).status,403);assert.equal((await a.post(resetRoute(a),reset)).status,403);assert.equal((await a.post(resetRoute(b),{...reset,confirmation:''})).status,400);
    const oldHash=f.store.db.prepare('SELECT password_hash FROM users WHERE id=?').get(b.state.user.id).password_hash,result=await ok(a.post(resetRoute(b),reset)),newHash=f.store.db.prepare('SELECT password_hash FROM users WHERE id=?').get(b.state.user.id).password_hash;
    assert.match(newHash,/^\$argon2id\$/);assert.notEqual(newHash,oldHash);assert(await verifyPassword(newPassword,newHash));assert.equal(await verifyPassword(password,newHash),false);assert.equal((await b.get('/api/observations')).status,401);assert.equal((await b2.get('/api/settings')).status,401);assert.equal(f.store.session(aRun).status,'active');assert.equal(f.store.session(bRun).end_reason,'password_reset');assert.equal(f.store.db.prepare('SELECT COUNT(*) n FROM completion_finals WHERE id=?').get(bRun).n,1);assert.deepEqual(f.store.forUser(b.state.user.id).observations(),before);assert.equal((await a.get('/api/snapshots/'+saved.ref)).status,404);assert.equal((await a.get('/api/observations/'+saved.record.id)).status,404);
    const attempt=await client(f);assert.equal((await attempt.post('/api/auth/login',{email:'user@example.test',password})).status,401);const fresh=await login(f,'user@example.test',newPassword);assert.equal(fresh.state.user.id,b.state.user.id);await ok(fresh.post('/api/account/password',{currentPassword:newPassword,newPassword:password,confirmPassword:password}));noSecrets(result,password,newPassword,newHash);assert.equal(f.calls,0);
  }finally{await f.close();}
});

test('reset rejects invalid proof/confirmation/passwords and rolls back failed writes without revoking sessions or changing suspension status',async()=>{
  const f=await fixture();try{const a=await owner(f),b=await user(f),id=b.state.user.id,hash=f.store.db.prepare('SELECT password_hash FROM users WHERE id=?').get(id).password_hash;
    for(const input of [{...reset,currentPassword:'wrong administrator password'},{...reset,newPassword:'short',confirmPassword:'short'},{...reset,confirmPassword:'mismatch'}])assert.equal((await a.post(resetRoute(b),input)).status,400);
    f.store.db.exec("CREATE TRIGGER fail_reset BEFORE UPDATE OF password_hash ON users BEGIN SELECT RAISE(ABORT,'isolated reset failure'); END");assert.equal((await a.post(resetRoute(b),reset)).status,500);assert.equal((await b.get('/api/settings')).status,200);assert.equal(f.store.db.prepare('SELECT password_hash FROM users WHERE id=?').get(id).password_hash,hash);f.store.db.exec('DROP TRIGGER fail_reset');
    await ok(a.post('/api/admin/users/'+id,{status:'SUSPENDED'}));await ok(a.post(resetRoute(b),reset));assert.equal(f.store.db.prepare('SELECT status FROM users WHERE id=?').get(id).status,'SUSPENDED');const candidate=await client(f);assert.equal((await candidate.post('/api/auth/login',{email:'user@example.test',password:newPassword})).status,401);
  }finally{await f.close();}
});

test('deletion requires current password, typed confirmation, CSRF and protects owner/last ADMIN',async()=>{
  const f=await fixture();try{const a=await owner(f),b=await user(f);assert.equal((await a.post('/api/account/delete',deletion)).status,403);
    for(const input of [{confirmation:'DELETE MY ACCOUNT'},{...deletion,currentPassword:'wrong private passphrase'},{...deletion,confirmation:'DELETE'},{...deletion,user_id:a.state.user.id}])assert.equal((await b.post('/api/account/delete',input)).status,400);
    assert.equal((await b.request('/api/account/delete',{body:deletion,headers:{'X-Surv-CSRF':''}})).status,403);assert.equal((await b.get('/api/settings')).status,200);
    f.store.db.prepare("UPDATE users SET role='USER' WHERE id=?").run(a.state.user.id);f.store.db.prepare("UPDATE users SET role='ADMIN' WHERE id=?").run(b.state.user.id);assert.equal((await b.post('/api/account/delete',deletion)).status,403);assert.equal(f.store.db.prepare('SELECT COUNT(*) n FROM users').get().n,2);
  }finally{await f.close();}
});

test('account deletion removes own records/files and staged images, preserves shared/other-user snapshots and runtime, and signs out every target session',async()=>{
  const f=await fixture();try{const a=await owner(f),b=await user(f),b2=await login(f,'user@example.test'),aSaved=await history(f,a.state.user.id),bSaved=await history(f,b.state.user.id),id=b.state.user.id;finals(f);const aRun=await run(a,true),bRun=await run(b),staged=(await ok(b.post('/api/snapshots',{image,timestamp:new Date().toISOString()}))).snapshotRef;
    f.store.forUser(id).setSaveSnapshots(true);const staged2=(await ok(b.post('/api/snapshots',{image,timestamp:new Date().toISOString()}))).snapshotRef;
    const shared=randomUUID();f.store.forUser(id).saveObservation({id:shared,timestamp:new Date().toISOString(),activity:'Shared own reference',description:'Book visible.',location:'Office',confidence:.9,objects:[],source:'manual_ai',snapshotRef:aSaved.ref});
    const result=await ok(b.post('/api/account/delete',deletion));assert.equal(result.deleted,true);assert.equal(result.cleanupPending,false);assert.equal(f.store.db.prepare('SELECT id FROM users WHERE id=?').get(id),undefined);for(const table of ['observations','monitoring_sessions','cameras','app_settings','auth_identities','auth_sessions'])assert.equal(f.store.db.prepare(`SELECT COUNT(*) n FROM ${table} WHERE user_id=?`).get(id).n,0);
    assert.equal((await b.get('/api/observations')).status,401);assert.equal((await b2.get('/api/settings')).status,401);assert.equal(f.store.session(aRun).status,'active');assert.equal(f.store.db.prepare('SELECT COUNT(*) n FROM completion_finals WHERE id=?').get(bRun).n,1);assert.equal(f.store.getObservation(aSaved.record.id).snapshotRef,aSaved.ref);assert.equal(digest(await readFile(path.join(f.snapshots.directory,aSaved.ref))),aSaved.hash);assert(!disk.existsSync(path.join(f.snapshots.directory,bSaved.ref)));assert(!disk.existsSync(path.join(f.snapshots.directory,staged2)));assert.equal(staged,null);assert(!disk.existsSync(path.join(f.snapshots.directory,'.account-deletions')));assert.deepEqual(f.store.db.prepare('PRAGMA foreign_key_check').all(),[]);assert.equal(f.calls,0);
  }finally{await f.close();}
});

test('database deletion failure restores snapshot bytes and all records/sessions, preserving the active target runtime',async()=>{
  const f=await fixture();try{const a=await owner(f),b=await user(f),saved=await history(f,b.state.user.id),sessionId=await run(b),before=privateRows(f.store),cookie=b.state.cookie;
    f.store.db.exec("CREATE TRIGGER fail_delete BEFORE DELETE ON users BEGIN SELECT RAISE(ABORT,'isolated deletion failure'); END");const failed=await b.post('/api/account/delete',deletion);assert.equal(failed.status,507);assert.deepEqual(privateRows(f.store),before);assert.equal(b.state.cookie,cookie);assert.equal((await b.get('/api/settings')).status,200);assert.equal((await a.get('/api/settings')).status,200);assert.equal(f.store.session(sessionId).status,'active');assert.equal(digest(await readFile(path.join(f.snapshots.directory,saved.ref))),saved.hash);assert(!disk.existsSync(path.join(f.snapshots.directory,'.account-deletions')));
  }finally{await f.close();}
});

test('staging I/O failure rolls back without leaving missing images, orphan files or deleted credentials',async()=>{
  let moves=0;const f=await fixture({accountFiles:{renameSync(from,to){if(to.includes('.account-deletions')&&++moves===2)throw Error('isolated staging failure');return disk.renameSync(from,to);}}});try{await owner(f);const b=await user(f),one=await history(f,b.state.user.id),two=await history(f,b.state.user.id),before=privateRows(f.store);assert.equal((await b.post('/api/account/delete',deletion)).status,507);assert.deepEqual(privateRows(f.store),before);assert.equal(digest(await readFile(path.join(f.snapshots.directory,one.ref))),one.hash);assert.equal(digest(await readFile(path.join(f.snapshots.directory,two.ref))),two.hash);assert.equal((await b.get('/api/settings')).status,200);assert(!disk.existsSync(path.join(f.snapshots.directory,'.account-deletions')));
  }finally{await f.close();}
});

test('post-commit file failure is explicit and journalled, and ADMIN retry/startup recovery completes private cleanup',async()=>{
  let fail=true;const f=await fixture({accountFiles:{unlinkSync(file){if(fail&&file.endsWith('.png'))throw Error('isolated cleanup failure');return disk.unlinkSync(file);}}});try{const a=await owner(f),b=await user(f),saved=await history(f,b.state.user.id),result=await b.post('/api/account/delete',deletion);assert.equal(result.status,202);assert.equal(result.data.cleanupPending,true);assert(result.data.message.includes('pending'));assert.equal((await b.get('/api/settings')).status,401);assert(!disk.existsSync(path.join(f.snapshots.directory,saved.ref)));assert.equal((await ok(a.get('/api/admin/cleanup'))).pendingDeletionCount,1);assert.equal((await ok(a.post('/api/admin/cleanup',{}))).pendingDeletionCount,1);fail=false;await f.restart();assert.equal((await ok(a.get('/api/admin/cleanup'))).pendingDeletionCount,0);assert(!disk.existsSync(path.join(f.snapshots.directory,'.account-deletions')));assert.equal(f.store.db.prepare('SELECT COUNT(*) n FROM users').get().n,1);
  }finally{await f.close();}
});

test('startup recovers files from a pre-commit crash journal without removing any account/history',async()=>{
  const f=await fixture();try{await owner(f);const b=await user(f),saved=await history(f,b.state.user.id),before=privateRows(f.store),job=path.join(f.snapshots.directory,'.account-deletions',randomUUID());disk.mkdirSync(job,{recursive:true});disk.writeFileSync(path.join(job,'manifest.json'),JSON.stringify({version:1,userId:b.state.user.id,refs:[saved.ref]}));disk.renameSync(path.join(f.snapshots.directory,saved.ref),path.join(job,saved.ref));await f.restart();assert.deepEqual(privateRows(f.store),before);assert.equal(digest(await readFile(path.join(f.snapshots.directory,saved.ref))),saved.hash);assert.equal((await b.get('/api/settings')).status,200);assert(!disk.existsSync(path.join(f.snapshots.directory,'.account-deletions')));
  }finally{await f.close();}
});

test('personal ZIP contains only own metadata/history/configuration/referenced images, handles missing images and excludes every authentication secret',async()=>{
  const f=await fixture();try{const a=await owner(f),b=await user(f),aSaved=await history(f,a.state.user.id),bSaved=await history(f,b.state.user.id);await run(b);const missing=randomUUID()+'.png';f.store.forUser(b.state.user.id).saveObservation({id:randomUUID(),timestamp:new Date().toISOString(),activity:'Missing owned image',description:'No retained image.',location:'Office',confidence:.5,objects:[],source:'manual_ai',snapshotRef:missing});
    const result=await b.get('/api/account/export');assert.equal(result.status,200);assert.equal(result.res.headers.get('content-type'),'application/zip');const entries=unzip(result.data),data=JSON.parse(entries['data.json']);assert.equal(data.account.id,b.state.user.id);assert(data.observations.every(row=>row.id!==aSaved.record.id));assert(data.cameras.every(row=>row.id!=='local-webcam'));assert.equal(data.monitoringSessions.length,1);assert.deepEqual(data.settings,{intervalMs:30000,saveSnapshots:false,smartSurv:true,detectionOnlyRotation:false});assert.deepEqual(data.snapshots.missing,[missing]);assert.deepEqual(entries['snapshots/'+bSaved.ref],await readFile(path.join(f.snapshots.directory,bSaved.ref)));assert.equal(entries['snapshots/'+aSaved.ref],undefined);
    noSecrets(data,password,currentHash(a),currentHash(b),a.state.cookie.split('=')[1],b.state.cookie.split('=')[1],a.state.csrf,b.state.csrf,f.store.db.prepare('SELECT password_hash FROM users WHERE id=?').get(b.state.user.id).password_hash,'fixture-only');assert.equal((await b.get('/api/account/export?user_id='+a.state.user.id)).status,400);assert.equal((await b.get('/api/admin/cleanup')).status,403);assert.equal(f.calls,0);
  }finally{await f.close();}
});

test('deleted account cannot commit an in-flight mocked automatic result or leave a fresh orphan snapshot; unaffected user continues',async()=>{
  let release,entered;const enteredAI=new Promise(r=>entered=r),pendingAI=new Promise(r=>release=r);const f=await fixture({detector:{async start(){},async inspect(){return {frameValid:true,personPresent:true};},close(){}},fetchImpl:async()=>{entered();await pendingAI;return new Response(JSON.stringify({status:'completed',output:[{type:'message',content:[{type:'output_text',text:JSON.stringify({activity:'Reading',description:'A person reads a book.',location:'Office',confidence:.9,objects:['book']})}]}]}));}});
  try{const a=await owner(f),b=await user(f);finals(f);const aRun=await run(a,true),bRun=await run(b),gate=await ok(b.post('/api/monitoring/check',{sessionId:bRun,cameraActive:true,image,timestamp:new Date().toISOString()})),inFlight=b.post('/api/automatic-analyze',{sessionId:bRun,ticket:gate.ticket});await enteredAI;await ok(b.post('/api/account/delete',deletion));release();assert.equal((await inFlight).status,401);assert.equal(f.store.session(aRun).status,'active');assert.equal(f.store.db.prepare('SELECT COUNT(*) n FROM completion_finals WHERE id=?').get(bRun).n,1);assert.equal(f.store.db.prepare('SELECT COUNT(*) n FROM observations').get().n,0);assert.deepEqual(await disk.promises.readdir(f.snapshots.directory).catch(()=>[]),[]);
  }finally{release();await f.close();}
});

test('unauthenticated new endpoints are denied; a session revoked during image export never receives a ZIP',async()=>{
  const f=await fixture();let release,entered;try{
    for(const route of ['/api/account/export','/api/admin/cleanup'])assert.equal((await fetch(f.origin+route)).status,401);
    for(const route of ['/api/account/delete','/api/admin/users/'+randomUUID()+'/reset-password'])assert.equal((await fetch(f.origin+route,{method:'POST',headers:{'Content-Type':'application/json'},body:'{}'})).status,401);
    const a=await owner(f),b=await user(f),b2=await login(f,'user@example.test');await history(f,b.state.user.id);const started=new Promise(r=>entered=r),blocked=new Promise(r=>release=r),get=f.snapshots.get.bind(f.snapshots);f.snapshots.get=async ref=>{entered();await blocked;return get(ref);};
    const pending=b.get('/api/account/export');await started;await ok(b2.post('/api/account/sessions/revoke-others',{}));release();const result=await pending;assert.equal(result.status,401);assert.equal(result.res.headers.get('content-type'),'application/json');assert.equal((await a.get('/api/settings')).status,200);
  }finally{release?.();await f.close();}
});

test('failed rollback file restoration is visible and recoverable; unavailable user data is denied until ADMIN retry',async()=>{
  let failRestore=true;const f=await fixture({accountFiles:{renameSync(from,to){if(failRestore&&from.includes('.account-deletions'))throw Error('isolated restore failure');return disk.renameSync(from,to);}}});try{const a=await owner(f),b=await user(f),saved=await history(f,b.state.user.id);f.store.db.exec("CREATE TRIGGER fail_delete_restore BEFORE DELETE ON users BEGIN SELECT RAISE(ABORT,'isolated SQL failure'); END");const result=await b.post('/api/account/delete',deletion);assert.equal(result.status,507);assert(result.data.error.includes('recovery is pending'));assert.equal((await b.get('/api/observations')).status,503);assert.equal((await a.get('/api/settings')).status,200);assert.equal((await ok(a.get('/api/admin/cleanup'))).pendingDeletionCount,1);failRestore=false;assert.equal((await ok(a.post('/api/admin/cleanup',{}))).pendingDeletionCount,0);assert.equal((await b.get('/api/observations')).status,200);assert.equal(digest(await readFile(path.join(f.snapshots.directory,saved.ref))),saved.hash);
  }finally{await f.close();}
});
