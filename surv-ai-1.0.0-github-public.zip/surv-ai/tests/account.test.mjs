import {test} from 'node:test';
import assert from 'node:assert/strict';
import {randomUUID,createHash} from 'node:crypto';
import {mkdtemp,rm,readFile} from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import http from 'node:http';
import {LocalStorage} from '../src/storage.mjs';
import {SnapshotStore} from '../src/snapshot-store.mjs';
import {createServer} from '../server.mjs';
import {verifyPassword} from '../src/auth.mjs';

// All account mutations use the real authentication endpoints and isolated data.
const password='account fixture private passphrase 2026';
const newPassword='  new account fixture 世界 passphrase 2026  ';
const image='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+j1ioAAAAASUVORK5CYII=';
const digest=value=>createHash('sha256').update(value).digest('hex');
const signup=(email='owner@example.test')=>({displayName:'Fixture Owner',email,password,confirmPassword:password});
async function fixture(extra={}){
  const dir=await mkdtemp(path.join(os.tmpdir(),'surv-account-'));
  const f={dir,origin:null,store:null,server:null,snapshots:new SnapshotStore(path.join(dir,'snapshots')),calls:0};
  f.start=async()=>{
    f.store=new LocalStorage(path.join(dir,'db.sqlite'));
    f.server=createServer({storage:f.store,snapshots:f.snapshots,apiKey:'fixture-only',fetchImpl(){f.calls++;throw Error('Unexpected AI request');},detector:{async start(){},async inspect(){return {frameValid:true,personPresent:false};},close(){}},...extra});
    await new Promise(r=>f.server.listen(0,'127.0.0.1',r));f.origin=`http://127.0.0.1:${f.server.address().port}`;
    assert.notEqual(new URL(f.origin).port,'4173');
  };
  f.restart=async()=>{await new Promise(r=>f.server.close(r));await f.start();};
  f.close=async()=>{if(f.server.listening)await new Promise(r=>f.server.close(r));await rm(dir,{recursive:true,force:true});};
  await f.start();return f;
}
async function client(f){
  const state={cookie:'',csrf:'',user:null};
  const request=async(route,{body,method=body?'POST':'GET',headers={},...options}={})=>{
    const res=await fetch(f.origin+route,{...options,method,headers:{...(body?{'Content-Type':'application/json'}:{}),...(state.cookie?{Cookie:state.cookie}:{}),...(state.csrf?{'X-Surv-CSRF':state.csrf}:{}),...headers},...(body?{body:JSON.stringify(body)}:{})});
    if(res.headers.get('set-cookie'))state.cookie=res.headers.get('set-cookie').split(';')[0];
    const data=res.headers.get('content-type')?.includes('json')?await res.json():Buffer.from(await res.arrayBuffer());
    if(data.csrfToken)state.csrf=data.csrfToken;if(data.user)state.user=data.user;
    return {res,status:res.status,data};
  };
  const c={state,request,get:route=>request(route),post:(route,body)=>request(route,{body})};await c.get('/api/auth/me');return c;
}
const ok=async request=>{const result=await request;assert.equal(result.status,200,JSON.stringify(result.data));return result.data;};
async function owner(f){const c=await client(f);await ok(c.post('/api/auth/owner',signup()));return c;}
async function login(f,email='owner@example.test',pass=password){const c=await client(f);await ok(c.post('/api/auth/login',{email,password:pass}));return c;}
const currentHash=c=>digest(c.state.cookie.slice(c.state.cookie.indexOf('=')+1));
const privateRows=store=>Object.fromEntries(['observations','monitoring_sessions','cameras','app_settings'].map(table=>[table,JSON.stringify(store.db.prepare(`SELECT * FROM ${table} ORDER BY id`).all())]));
async function history(f,userId){
  const owned=f.store.forUser(userId),ref=await f.snapshots.put(image);
  const record=owned.saveObservation({id:randomUUID(),timestamp:'2026-10-04T14:00:00.000Z',activity:'ACCOUNT_PRIVATE_HISTORY',description:'A book is visible.',location:'Office',confidence:.9,objects:['book'],source:'manual_ai',snapshotRef:ref});
  owned.setInterval(30000);owned.setSaveSnapshots(false);return {record,ref,rows:privateRows(f.store),hash:digest(await readFile(path.join(f.snapshots.directory,ref)))};
}
function noSecrets(data,...values){
  const walk=value=>{if(!value||typeof value!=='object')return;for(const [key,item]of Object.entries(value)){assert(!['password','currentPassword','newPassword','confirmPassword','password_hash','passwordHash','token_hash','tokenHash','csrf_token','sessionHash','cookie'].includes(key),`Leaked ${key}`);walk(item);}};walk(data);
  const serialized=JSON.stringify(data);assert(!serialized.includes('$argon2id$'));for(const value of values.filter(Boolean))assert(!serialized.includes(value),'A credential or raw session token was disclosed');
}

test('display name is validated, immediately updated and persists through logout, login and server restart without changing owned data',async()=>{
  const f=await fixture();try{const a=await owner(f),id=a.state.user.id,saved=await history(f,id),cookie=a.state.cookie,csrf=a.state.csrf;
    const changed=await ok(a.post('/api/account/profile',{displayName:'  New Fixture Name  '}));assert.equal(changed.user.displayName,'New Fixture Name');assert.equal(changed.user.id,id);assert.equal(a.state.cookie,cookie);assert.equal(a.state.csrf,csrf);
    for(const name of ['', '   ', 'x'.repeat(81), 'bad\u0000name', null])assert.equal((await a.post('/api/account/profile',{displayName:name})).status,400);
    assert.equal((await a.get('/api/auth/me')).data.user.displayName,'New Fixture Name');assert.deepEqual(privateRows(f.store),saved.rows);assert.equal(digest(await readFile(path.join(f.snapshots.directory,saved.ref))),saved.hash);
    await ok(a.post('/api/auth/logout',{}));assert.equal((await a.get('/api/account/sessions')).status,401);const signed=await login(f);assert.equal(signed.state.user.displayName,'New Fixture Name');await f.restart();assert.equal((await signed.get('/api/auth/me')).data.user.displayName,'New Fixture Name');assert.deepEqual(privateRows(f.store),saved.rows);assert.equal(f.calls,0);
  }finally{await f.close();}
});

test('account endpoints reject unauthenticated, CSRF, cross-origin and injected ownership fields for USER and ADMIN',async()=>{
  const f=await fixture();try{const a=await owner(f),b=await client(f);await ok(b.post('/api/auth/register',signup('user@example.test')));const anonymous=await client(f);
    const cases=[['/api/account/profile',{displayName:'Valid Name'}],['/api/account/email',{email:'next@example.test',currentPassword:password}],['/api/account/password',{currentPassword:password,newPassword,confirmPassword:newPassword}],['/api/account/sessions/revoke-others',{}]];
    for(const [route,body]of cases){assert.equal((await anonymous.post(route,body)).status,401);assert.equal((await a.request(route,{body,headers:{'X-Surv-CSRF':'invalid'}})).status,403);assert.equal((await a.request(route,{body,headers:{Origin:'http://attacker.test'}})).status,403);
      for(const actor of [a,b]){assert.equal((await actor.post(route,{...body,userId:actor===a?b.state.user.id:a.state.user.id})).status,400);assert.equal((await actor.post(route,{...body,account:{user_id:b.state.user.id}})).status,400);}
    }
    assert.equal((await anonymous.get('/api/account/sessions')).status,401);assert.equal((await a.get('/api/account/sessions?userId='+b.state.user.id)).status,400);assert.equal((await a.post('/api/account/profile',{displayName:'Valid Name',id:b.state.user.id})).status,400);
    assert.equal(f.store.db.prepare('SELECT display_name FROM users WHERE id=?').get(b.state.user.id).display_name,'Fixture Owner');assert.equal((await b.get('/api/admin/users')).status,403);
  }finally{await f.close();}
});

test('email change requires the current password, rejects duplicates and invalid addresses without modifying sessions or identity',async()=>{
  const f=await fixture();try{const a=await owner(f),b=await client(f);await ok(b.post('/api/auth/register',signup('other@example.test')));const before=f.store.db.prepare('SELECT * FROM users WHERE id=?').get(a.state.user.id),cookie=a.state.cookie;
    for(const body of [{email:'next@example.test'},{email:'next@example.test',currentPassword:'incorrect fixture password'},{email:'bad-address',currentPassword:password},{email:'  OTHER@EXAMPLE.TEST ',currentPassword:password}]){const r=await a.post('/api/account/email',body);assert([400,409].includes(r.status),JSON.stringify(r.data));noSecrets(r.data,password);}
    assert.deepEqual(f.store.db.prepare('SELECT * FROM users WHERE id=?').get(a.state.user.id),before);assert.equal(a.state.cookie,cookie);assert.equal(f.store.db.prepare('SELECT revoked_at FROM auth_sessions WHERE token_hash=?').get(currentHash(a)).revoked_at,null);assert.equal((await b.get('/api/settings')).status,200);
  }finally{await f.close();}
});

test('normalized email changes clear verification, update password identity, preserve history, rotate current session and revoke only this user’s other sessions',async()=>{
  const f=await fixture();try{const a=await owner(f),id=a.state.user.id,saved=await history(f,id),other=await login(f),b=await client(f);await ok(b.post('/api/auth/register',signup('other@example.test')));f.store.db.prepare('UPDATE users SET email_verified=1 WHERE id=?').run(id);
    saved.rows=privateRows(f.store);const oldCookie=a.state.cookie,oldCsrf=a.state.csrf,oldHash=currentHash(a),result=await ok(a.post('/api/account/email',{email:'  CHANGED@Example.TEST  ',currentPassword:password}));assert.equal(result.user.id,id);assert.equal(result.user.email,'CHANGED@Example.TEST');assert.equal(result.user.emailVerified,false);assert.notEqual(a.state.cookie,oldCookie);assert.notEqual(a.state.csrf,oldCsrf);assert.match(result.csrfToken,/^[A-Za-z0-9_-]{43}$/);
    assert.notEqual(f.store.db.prepare('SELECT revoked_at FROM auth_sessions WHERE token_hash=?').get(oldHash).revoked_at,null);assert.equal((await other.get('/api/observations')).status,401);assert.equal((await fetch(f.origin+'/api/settings',{headers:{Cookie:oldCookie}})).status,401);assert.equal((await b.get('/api/settings')).status,200);
    const identity=f.store.db.prepare("SELECT * FROM auth_identities WHERE user_id=? AND provider='password'").get(id);assert.equal(identity.provider_subject,'changed@example.test');assert.equal(identity.provider_email,'CHANGED@Example.TEST');assert.equal(f.store.db.prepare('SELECT email_normalized FROM users WHERE id=?').get(id).email_normalized,'changed@example.test');assert.deepEqual(privateRows(f.store),saved.rows);assert.equal(digest(await readFile(path.join(f.snapshots.directory,saved.ref))),saved.hash);assert.equal((await a.get('/api/snapshots/'+saved.ref)).status,200);assert.equal((await b.get('/api/snapshots/'+saved.ref)).status,404);
    const rejected=await client(f);assert.equal((await rejected.post('/api/auth/login',{email:'owner@example.test',password})).status,401);const relogin=await login(f,'changed@EXAMPLE.test');assert.equal(relogin.state.user.id,id);noSecrets(result,password,oldCookie.split('=')[1],oldCsrf,identity.password_hash);assert.equal(f.calls,0);
  }finally{await f.close();}
});

test('password change requires current password and registration-strength rules with exact confirmation',async()=>{
  const f=await fixture();try{const a=await owner(f),before=f.store.db.prepare('SELECT password_hash FROM users WHERE id=?').get(a.state.user.id).password_hash,cookie=a.state.cookie;
    const invalid=[{newPassword,confirmPassword:newPassword},{currentPassword:'incorrect fixture password',newPassword,confirmPassword:newPassword},{currentPassword:password,newPassword:'short',confirmPassword:'short'},{currentPassword:password,newPassword:'x'.repeat(257),confirmPassword:'x'.repeat(257)},{currentPassword:password,newPassword,confirmPassword:newPassword.trim()}];
    for(const body of invalid){const r=await a.post('/api/account/password',body);assert.equal(r.status,400,JSON.stringify(r.data));noSecrets(r.data,password,newPassword);}assert.equal(f.store.db.prepare('SELECT password_hash FROM users WHERE id=?').get(a.state.user.id).password_hash,before);assert.equal(a.state.cookie,cookie);assert.equal((await a.get('/api/settings')).status,200);
  }finally{await f.close();}
});

test('password change stores Argon2id, replaces current cookie and CSRF, revokes all other sessions, and immediately rejects the old password',async()=>{
  const f=await fixture();try{const a=await owner(f),id=a.state.user.id,saved=await history(f,id),other=await login(f),oldCookie=a.state.cookie,oldCsrf=a.state.csrf,oldHash=f.store.db.prepare('SELECT password_hash FROM users WHERE id=?').get(id).password_hash;
    const r=await ok(a.post('/api/account/password',{currentPassword:password,newPassword,confirmPassword:newPassword}));assert.equal(r.user.id,id);assert.notEqual(a.state.cookie,oldCookie);assert.notEqual(a.state.csrf,oldCsrf);assert.match(r.csrfToken,/^[A-Za-z0-9_-]{43}$/);const hash=f.store.db.prepare('SELECT password_hash FROM users WHERE id=?').get(id).password_hash;assert.match(hash,/^\$argon2id\$v=19\$m=65536,t=3,p=1\$/);assert.notEqual(hash,oldHash);assert(await verifyPassword(newPassword,hash));assert.equal(await verifyPassword(password,hash),false);assert.equal(await verifyPassword(newPassword.trim(),hash),false);
    assert.equal((await other.get('/api/settings')).status,401);assert.equal((await fetch(f.origin+'/api/settings',{headers:{Cookie:oldCookie}})).status,401);assert.equal((await a.request('/api/account/profile',{body:{displayName:'Name'},headers:{'X-Surv-CSRF':oldCsrf}})).status,403);assert.equal((await a.get('/api/settings')).status,200);
    const rejected=await client(f);assert.equal((await rejected.post('/api/auth/login',{email:'owner@example.test',password})).status,401);const relogin=await login(f,'owner@example.test',newPassword);assert.equal(relogin.state.user.id,id);assert.deepEqual(privateRows(f.store),saved.rows);noSecrets(r,password,newPassword,hash,oldCookie.split('=')[1],oldCsrf);assert.equal(f.calls,0);
  }finally{await f.close();}
});

test('reusing the current password is rejected without replacing credentials or revoking sessions',async()=>{
  const f=await fixture();try{const a=await owner(f),other=await login(f),id=a.state.user.id,cookie=a.state.cookie,csrf=a.state.csrf,hash=f.store.db.prepare('SELECT password_hash FROM users WHERE id=?').get(id).password_hash;
    const result=await a.post('/api/account/password',{currentPassword:password,newPassword:password,confirmPassword:password});assert.equal(result.status,400);noSecrets(result.data,password,hash);assert.equal(a.state.cookie,cookie);assert.equal(a.state.csrf,csrf);assert.equal(f.store.db.prepare('SELECT password_hash FROM users WHERE id=?').get(id).password_hash,hash);assert.equal((await other.get('/api/settings')).status,200);assert.equal((await a.get('/api/settings')).status,200);assert.equal(f.calls,0);
  }finally{await f.close();}
});

test('session information reports recorded timestamps and sign-out-others preserves current and unrelated users, while ordinary logout still revokes current',async()=>{
  let now=Date.parse('2026-10-05T12:00:00Z');const f=await fixture({authNow:()=>now});try{const a=await owner(f),other=await login(f),third=await login(f),b=await client(f);await ok(b.post('/api/auth/register',signup('other@example.test')));
    now+=20000;const info=await ok(a.get('/api/account/sessions'));assert.deepEqual(Object.keys(info).sort(),['currentSession','otherSessionCount']);assert.equal(info.otherSessionCount,2);const row=f.store.db.prepare('SELECT * FROM auth_sessions WHERE token_hash=?').get(currentHash(a));assert.deepEqual(info.currentSession,{createdAt:new Date(row.created_at).toISOString(),lastActivityAt:new Date(row.last_seen_at).toISOString(),expiresAt:new Date(row.expires_at).toISOString()});noSecrets(info,a.state.cookie.split('=')[1],row.token_hash,row.csrf_token);assert(!JSON.stringify(info).match(/device|browser|location/i));
    const cookie=a.state.cookie,csrf=a.state.csrf,r=await ok(a.post('/api/account/sessions/revoke-others',{}));assert.equal(r.security.otherSessionCount,0);assert.equal(r.revokedSessions,2);assert.equal(a.state.cookie,cookie);assert.equal(a.state.csrf,csrf);assert.equal((await a.get('/api/observations')).status,200);assert.equal((await other.get('/api/observations')).status,401);assert.equal((await third.get('/api/settings')).status,401);assert.equal((await b.get('/api/settings')).status,200);
    assert.equal((await ok(a.post('/api/account/sessions/revoke-others',{}))).revokedSessions,0);await ok(a.post('/api/auth/logout',{}));assert.equal((await fetch(f.origin+'/api/settings',{headers:{Cookie:cookie}})).status,401);
  }finally{await f.close();}
});

test('future provider-only accounts may edit name and manage sessions but receive clear rejection for password-protected email/password changes',async()=>{
  const f=await fixture();try{const a=await owner(f),id=a.state.user.id;f.store.db.prepare('UPDATE users SET password_hash=NULL WHERE id=?').run(id);f.store.db.prepare('DELETE FROM auth_identities WHERE user_id=?').run(id);f.store.db.prepare('INSERT INTO auth_identities VALUES(?,?,?,?,?,?)').run(randomUUID(),id,'google','fixture-provider-subject','owner@example.test',new Date().toISOString());
    const name=await ok(a.post('/api/account/profile',{displayName:'Provider Fixture'}));assert.deepEqual(name.user.providers,['google']);assert.equal((await a.post('/api/account/email',{email:'next@example.test',currentPassword:password})).status,403);assert.equal((await a.post('/api/account/password',{currentPassword:password,newPassword,confirmPassword:newPassword})).status,403);assert.equal(f.store.db.prepare('SELECT password_hash FROM users WHERE id=?').get(id).password_hash,null);assert.equal((await a.get('/api/account/sessions')).status,200);await ok(a.post('/api/account/sessions/revoke-others',{}));assert.equal((await a.get('/api/auth/me')).data.google,undefined);
  }finally{await f.close();}
});

test('credential rotation retains one authoritative current monitoring session; revoked other-session runtime finalizes exactly once',async()=>{
  const f=await fixture();try{const a=await owner(f),other=await login(f),camera=(await ok(a.post('/api/cameras',{name:'Other browser camera',deviceId:'fixture-second-device'}))).camera;
    f.store.db.exec("CREATE TABLE account_finals(id TEXT); CREATE TRIGGER account_final_count AFTER UPDATE OF status ON monitoring_sessions WHEN OLD.status='active' AND NEW.status='completed' BEGIN INSERT INTO account_finals VALUES(NEW.id); END");
    const current=await ok(a.post('/api/monitoring/start',{cameraActive:true})),foreign=await ok(other.post('/api/monitoring/start',{cameraId:camera.id,cameraActive:true}));const check=actor=>actor.post('/api/monitoring/check',{sessionId:current.sessionId,cameraActive:true,image,timestamp:new Date().toISOString()});await ok(check(a));const count=f.store.session(current.sessionId).no_person_skipped;
    await ok(a.post('/api/account/profile',{displayName:'Monitoring Fixture'}));await ok(a.post('/api/account/email',{email:'monitor@example.test',currentPassword:password}));assert.equal(f.store.session(current.sessionId).status,'active');assert.equal(f.store.session(foreign.sessionId).status,'completed');assert.equal(f.store.db.prepare('SELECT COUNT(*) n FROM account_finals WHERE id=?').get(foreign.sessionId).n,1);assert.equal((await other.get('/api/monitoring/status')).status,401);
    await ok(a.post('/api/account/password',{currentPassword:password,newPassword,confirmPassword:newPassword}));await ok(check(a));await ok(a.post('/api/account/sessions/revoke-others',{}));const status=await ok(a.get('/api/monitoring/status'));assert.equal(status.sessionId,current.sessionId);assert.equal(status.cameras.length,1);assert.equal(f.store.session(current.sessionId).no_person_skipped,count+1);assert.equal(f.store.db.prepare('SELECT COUNT(*) n FROM account_finals WHERE id=?').get(current.sessionId).n,0);assert.equal(f.store.db.prepare('SELECT COUNT(*) n FROM monitoring_sessions').get().n,2);
    await ok(a.post('/api/monitoring/stop',{sessionId:current.sessionId}));await ok(a.post('/api/monitoring/stop',{sessionId:current.sessionId}));assert.equal(f.store.db.prepare('SELECT COUNT(*) n FROM account_finals WHERE id=?').get(current.sessionId).n,1);assert.equal(f.store.db.prepare('SELECT COUNT(*) n FROM account_finals WHERE id=?').get(foreign.sessionId).n,1);assert.equal(f.calls,0);
  }finally{await f.close();}
});

test('failed credential transaction leaves identity, password, current/other sessions and monitoring intact',async()=>{
  for(const type of ['email','password']){const f=await fixture();try{const a=await owner(f),other=await login(f),run=await ok(a.post('/api/monitoring/start',{cameraActive:true})),id=a.state.user.id;
    const users=JSON.stringify(f.store.db.prepare('SELECT * FROM users ORDER BY id').all()),identities=JSON.stringify(f.store.db.prepare('SELECT * FROM auth_identities ORDER BY id').all()),sessions=JSON.stringify(f.store.db.prepare('SELECT * FROM auth_sessions ORDER BY token_hash').all()),cookie=a.state.cookie,csrf=a.state.csrf;
    f.store.db.exec("CREATE TRIGGER account_fail_rotation BEFORE INSERT ON auth_sessions BEGIN SELECT RAISE(ABORT,'fixture credential transaction failure'); END");const body=type==='email'?{email:'failed@example.test',currentPassword:password}:{currentPassword:password,newPassword,confirmPassword:newPassword};const r=await a.post('/api/account/'+type,body);assert.notEqual(r.status,200);assert.equal(a.state.cookie,cookie);assert.equal(a.state.csrf,csrf);assert.equal(JSON.stringify(f.store.db.prepare('SELECT * FROM users ORDER BY id').all()),users);assert.equal(JSON.stringify(f.store.db.prepare('SELECT * FROM auth_identities ORDER BY id').all()),identities);assert.equal(JSON.stringify(f.store.db.prepare('SELECT * FROM auth_sessions ORDER BY token_hash').all()),sessions);assert.equal(f.store.session(run.sessionId).status,'active');assert.equal((await other.get('/api/settings')).status,200);assert.equal((await a.get('/api/settings')).status,200);
  }finally{await f.close();}}
});

test('current credential rotation preserves an already-authorized OpenCV request whose JSON body is still arriving',async()=>{
  const f=await fixture();let req;try{const a=await owner(f),run=await ok(a.post('/api/monitoring/start',{cameraActive:true})),body=JSON.stringify({sessionId:run.sessionId,cameraActive:true,image,timestamp:new Date().toISOString()}),split=Math.floor(body.length/2);
    let received;const started=new Promise(r=>received=r),listener=request=>{if(request.url==='/api/monitoring/check'){f.server.off('request',listener);received();}};f.server.on('request',listener);
    const result=new Promise((resolve,reject)=>{req=http.request(f.origin+'/api/monitoring/check',{method:'POST',headers:{Cookie:a.state.cookie,'X-Surv-CSRF':a.state.csrf,'Content-Type':'application/json','Content-Length':Buffer.byteLength(body)}},res=>{const chunks=[];res.on('data',chunk=>chunks.push(chunk));res.on('end',()=>resolve({status:res.statusCode,data:JSON.parse(Buffer.concat(chunks))}));res.on('error',reject);});req.on('error',reject);req.write(body.slice(0,split));});
    await started;await ok(a.post('/api/account/email',{email:'slow-body@example.test',currentPassword:password}));req.end(body.slice(split));const checked=await result;assert.equal(checked.status,200,JSON.stringify(checked.data));assert.equal(checked.data.decision,'No person');assert.equal(f.store.session(run.sessionId).status,'active');assert.equal(f.store.session(run.sessionId).no_person_skipped,1);assert.equal((await ok(a.get('/api/monitoring/status'))).sessionId,run.sessionId);assert.equal(f.calls,0);
  }finally{req?.destroy();await f.close();}
});

test('current password rotation preserves a single already-authorized mocked analysis and its active monitoring session',async()=>{
  let submitted,release,calls=0;const started=new Promise(r=>submitted=r),waiting=new Promise(r=>release=r);
  const f=await fixture({detector:{async start(){},async inspect(){return {frameValid:true,personPresent:true};},close(){}},fetchImpl:async()=>{calls++;submitted();await waiting;return new Response(JSON.stringify({status:'completed',output:[{type:'message',content:[{type:'output_text',text:JSON.stringify({activity:'Fixture reading',description:'A book is visible.',location:'Office',confidence:.9,objects:['book']})}]}]}));}});
  try{const a=await owner(f),id=a.state.user.id,run=await ok(a.post('/api/monitoring/start',{cameraActive:true})),gate=await ok(a.post('/api/monitoring/check',{sessionId:run.sessionId,cameraActive:true,image,timestamp:new Date().toISOString()}));const pending=a.post('/api/automatic-analyze',{sessionId:run.sessionId,ticket:gate.ticket});await started;
    await ok(a.post('/api/account/password',{currentPassword:password,newPassword,confirmPassword:newPassword}));assert.equal(f.store.session(run.sessionId).status,'active');release();const result=await ok(pending);assert.equal(result.observation.monitoringSessionId,run.sessionId);assert.equal(f.store.forUser(id).observations().length,1);assert.equal(f.store.session(run.sessionId).status,'active');assert.equal(f.store.session(run.sessionId).api_requests,1);assert.equal(f.store.session(run.sessionId).successful_analyses,1);assert.equal((await ok(a.get('/api/monitoring/status'))).sessionId,run.sessionId);assert.equal(calls,1);
  }finally{release();await f.close();}
});

test('simultaneous sensitive changes cannot reuse a revoked current session or overwrite a newer credential',async()=>{
  const f=await fixture();try{const a=await owner(f),id=a.state.user.id;const oldCookie=a.state.cookie,oldCsrf=a.state.csrf;
    const requests=['first@example.test','second@example.test'].map(email=>fetch(f.origin+'/api/account/email',{method:'POST',headers:{Cookie:oldCookie,'X-Surv-CSRF':oldCsrf,'Content-Type':'application/json'},body:JSON.stringify({email,currentPassword:password})}));const results=await Promise.all(requests),data=await Promise.all(results.map(r=>r.json()));assert.equal(results.filter(r=>r.status===200).length,1);assert(results.every(r=>[200,400,401,409].includes(r.status)));const winner=data[results.findIndex(r=>r.status===200)];assert.equal(f.store.db.prepare('SELECT email FROM users WHERE id=?').get(id).email,winner.user.email);assert.equal(f.store.db.prepare('SELECT COUNT(*) n FROM auth_sessions WHERE user_id=? AND revoked_at IS NULL').get(id).n,1);noSecrets(data,password,oldCookie.split('=')[1]);
  }finally{await f.close();}
});

test('Admin exposes updated metadata only and retains suspension/restoration without credential or ownership bypass',async()=>{
  const f=await fixture();try{const a=await owner(f),b=await client(f);await ok(b.post('/api/auth/register',signup('user@example.test')));const id=b.state.user.id;await ok(b.post('/api/account/profile',{displayName:'Updated User'}));await ok(b.post('/api/account/email',{email:'updated-user@example.test',currentPassword:password}));
    const users=(await ok(a.get('/api/admin/users'))).users,target=users.find(u=>u.id===id);assert.equal(users.length,2);assert.equal(target.displayName,'Updated User');assert.equal(target.email,'updated-user@example.test');assert.equal(target.emailVerified,false);assert.equal(target.status,'ACTIVE');assert.equal(target.role,'USER');assert.deepEqual(target.providers,['password']);assert(target.lastLoginAt);noSecrets(users,password);
    assert.equal((await a.post('/api/admin/users/'+id,{email:'intruder@example.test',currentPassword:password})).status,400);assert.equal((await a.post('/api/admin/users/'+id,{password:newPassword})).status,400);assert.equal((await a.post('/api/account/email',{email:'intruder@example.test',currentPassword:password,userId:id})).status,400);assert.equal((await b.get('/api/admin/users')).status,403);
    await ok(a.post('/api/admin/users/'+id,{status:'SUSPENDED'}));assert.equal((await b.get('/api/account/sessions')).status,401);const rejected=await client(f),unknown=await client(f),suspended=await rejected.post('/api/auth/login',{email:'updated-user@example.test',password}),absent=await unknown.post('/api/auth/login',{email:'unknown@example.test',password});assert.equal(suspended.status,401);assert.deepEqual(suspended.data,absent.data);await ok(a.post('/api/admin/users/'+id,{status:'ACTIVE'}));assert.equal((await b.get('/api/settings')).status,401);assert.equal((await login(f,'updated-user@example.test')).state.user.id,id);
  }finally{await f.close();}
});
