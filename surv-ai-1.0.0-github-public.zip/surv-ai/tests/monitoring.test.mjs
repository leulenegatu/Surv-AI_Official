import {test} from 'node:test';
import assert from 'node:assert/strict';
import {mkdtemp,readFile,rm} from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import {MonitoringPolicy} from '../src/monitoring.mjs';
import {SnapshotStore} from '../src/snapshot-store.mjs';
import {createTestServer as createServer,testFetch as fetch} from './auth-fixture.mjs';
const image='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+j1ioAAAAASUVORK5CYII=';
const result={activity:'Reading',location:'Office',confidence:.9,description:'Person appears to be reading.',objects:['person','book']};
test('scheduler gates invalid/no-person/OFF/in-flight and enforces 15s with no catch-up',()=>{
  let now=100000;const policy=new MonitoringPolicy({now:()=>now}),s=policy.start(),input={image,timestamp:new Date(now).toISOString()};
  for(const frame of [{frameValid:false,personPresent:true},{frameValid:true,personPresent:false}])assert.equal(policy.checked(s,frame,input,false).ticket,null);
  assert.equal(policy.checked(s,{frameValid:true,personPresent:true},input,true).ticket,null);
  const first=policy.checked(s,{frameValid:true,personPresent:true},input,false);assert(first.ticket);policy.consume(s.id,first.ticket,false);
  assert.throws(()=>policy.consume(s.id,first.ticket,false),/fresh/);
  now+=14999;assert.equal(policy.checked(s,{frameValid:true,personPresent:true},input,false).ticket,null);
  now+=1;assert(policy.checked(s,{frameValid:true,personPresent:true},input,false).ticket);
  now+=600000;const returning=policy.checked(s,{frameValid:true,personPresent:true},input,false);policy.consume(s.id,returning.ticket,false);assert.equal(policy.checked(s,{frameValid:true,personPresent:true},input,false).ticket,null);
  policy.stop(s.id);assert.throws(()=>policy.consume(s.id,'any',false),/OFF/);
  const restarted=policy.start();assert.equal(policy.checked(restarted,{frameValid:true,personPresent:true},input,false).ticket,null,'restart cannot bypass cooldown');
  now+=15000;const expires=policy.checked(restarted,{frameValid:true,personPresent:true},input,false);now+=3001;assert.throws(()=>policy.consume(restarted.id,expires.ticket,false),/fresh/);
});
test('snapshot adapter round-trips original bytes and rejects path traversal',async()=>{
  const directory=await mkdtemp(path.join(os.tmpdir(),'surv-snapshot-'));const store=new SnapshotStore(directory);
  try{const ref=await store.put(image);assert.deepEqual((await store.get(ref)).data,Buffer.from(image.split(',')[1],'base64'));assert.throws(()=>store.validate('../.env'));await store.remove(ref);await assert.rejects(store.get(ref));}finally{await rm(directory,{recursive:true,force:true});}
});
test('backend requires real local gate ticket, current person and interval; saves automatic snapshot',async()=>{
  let now=Date.now(),person=false,valid=true,calls=0,release;
  const directory=await mkdtemp(path.join(os.tmpdir(),'surv-auto-'));
  const detector={async start(){},async inspect(){return {frameValid:valid,personPresent:person}},close(){}};
  const server=createServer({databasePath:':memory:',apiKey:'test-only',now:()=>now,detector,snapshots:new SnapshotStore(directory),fetchImpl:async()=>{calls++;if(release)await release.promise;return new Response(JSON.stringify({status:'completed',output:[{type:'message',content:[{type:'output_text',text:JSON.stringify(result)}]}]}));}});
  await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));const origin=`http://127.0.0.1:${server.address().port}`;
  const post=async(route,body)=>{const response=await fetch(origin+route,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});return {status:response.status,data:await response.json()};};
  try{
    assert.equal((await post('/api/automatic-analyze',{sessionId:'missing',ticket:'missing'})).status,404);assert.equal(calls,0);
    assert.equal((await post('/api/monitoring/start',{cameraActive:false})).status,409);
    const {sessionId}= (await post('/api/monitoring/start',{cameraActive:true})).data;
    const check=()=>post('/api/monitoring/check',{sessionId,cameraActive:true,image,timestamp:new Date(now).toISOString()});
    assert.equal((await check()).data.ticket,null);assert.equal(calls,0);
    valid=false;person=true;assert.equal((await check()).data.ticket,null);assert.equal(calls,0);
    valid=true;const gate=(await check()).data;assert(gate.ticket);
    const automatic=await post('/api/automatic-analyze',{sessionId,ticket:gate.ticket});assert.equal(automatic.status,200);assert.equal(calls,1);assert.equal(automatic.data.observation.source,'automatic_ai');
    assert.equal((await fetch(origin+'/api/snapshots/'+automatic.data.observation.snapshotRef)).status,200);
    assert.equal((await post('/api/automatic-analyze',{sessionId,ticket:gate.ticket})).status,409);assert.equal(calls,1);
    now+=1000;assert.equal((await check()).data.ticket,null);
    person=false;now+=600000;assert.equal((await check()).data.ticket,null);
    person=true;const returned=(await check()).data;let done;release={promise:new Promise(r=>done=r)};
    const inFlight=post('/api/automatic-analyze',{sessionId,ticket:returned.ticket});
    await new Promise(r=>setTimeout(r,20));assert.equal(calls,2);
    now+=15000;assert.equal((await check()).data.ticket,null,'no overlapping AI requests');
    await post('/api/monitoring/stop',{sessionId});done();await inFlight;release=null;
    assert.equal((await check()).status,409);assert.equal(calls,2);
    assert.equal((await post('/api/automatic-analyze',{sessionId,ticket:'anything'})).status,409);assert.equal(calls,2);
  }finally{await new Promise(resolve=>server.close(resolve));await rm(directory,{recursive:true,force:true});}
});
test('detector failure disables monitoring before any OpenAI request',async()=>{
  let calls=0;const detector={async start(){throw Error('Detector unavailable');},close(){}};const server=createServer({databasePath:':memory:',detector,fetchImpl:async()=>{calls++;}});
  await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
  try{const response=await fetch(`http://127.0.0.1:${server.address().port}/api/monitoring/start`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({cameraActive:true})});assert.equal(response.status,503);assert.equal(calls,0);}finally{await new Promise(resolve=>server.close(resolve));}
});
