import test from 'node:test';
import assert from 'node:assert/strict';
import {readdir} from 'node:fs/promises';
import {DatabaseSync} from 'node:sqlite';
import {inflateRawSync} from 'node:zlib';
import path from 'node:path';
import {desktopFixture,client,ok,image,password} from './desktop-fixture.mjs';
import {MonitoringPolicy} from '../src/monitoring.mjs';

async function setup(){
  const scores=new Map(),frames=new Map(),valid=new Map();
  const f=await desktopFixture({detector:{async start(){},async inspect(input){const id=frames.get(input);return {frameValid:valid.get(id)!==false,personConfidence:scores.get(id)??.05,personPresent:false};},close(){}}}),a=await client(f,{owner:true}),s=f.store.forUser(a.state.user.id);
  const cameras=[s.camera(),(await ok(a.post('/api/cameras',{name:'Center',deviceId:'center'}))).camera,(await ok(a.post('/api/cameras',{name:'Right',deviceId:'right'}))).camera],area=(await ok(a.post('/api/camera-areas',{name:'Office'}))).areas[0];
  await ok(a.post('/api/cameras/order',{cameraIds:cameras.map(c=>c.id)}));await ok(a.post('/api/settings',{intervalMs:30000}));const runs=[];
  for(const c of cameras){await ok(a.post('/api/cameras/'+c.id,{areaId:area.id}));const frame='data:image/png;base64,'+Buffer.concat([Buffer.from(image.split(',')[1],'base64'),Buffer.from(c.id)]).toString('base64');frames.set(frame,c.id);runs.push({...await ok(a.post('/api/monitoring/start',{cameraId:c.id,cameraActive:true})),image:frame});}
  const detect=async(ms=0)=>{f.now+=ms;return Promise.all(runs.filter(r=>f.server.desktop.policy.sessions.get(r.sessionId)?.enabled).map(r=>ok(a.post('/api/monitoring/check',{sessionId:r.sessionId,cameraActive:true,image:r.image,timestamp:new Date(f.now).toISOString(),detectOnly:true}))));};
  const ticket=()=>ok(a.post('/api/monitoring/area-ticket',{sessionId:runs.find(r=>f.server.desktop.policy.sessions.get(r.sessionId)?.enabled).sessionId}));
  const submit=async()=>{const g=await ticket();assert(g.ticket);const result=await ok(a.post('/api/automatic-analyze',{sessionId:g.sessionId,ticket:g.ticket}));assert.equal(result.observation.cameraId,g.cameraId);assert.equal(result.observation.monitoringSessionId,g.sessionId);assert.equal((await ticket()).ticket,null);return g;};
  const people=indices=>{for(const [i,c]of cameras.entries())scores.set(c.id,indices.includes(i)?.65:.05);};
  return {f,a,s,cameras,area,runs,scores,valid,detect,ticket,submit,people};
}
function exportData(bytes){const start=30+bytes.readUInt16LE(26)+bytes.readUInt16LE(28);return JSON.parse(inflateRawSync(bytes.subarray(start,start+bytes.readUInt32LE(18))));}

test('default OFF is passive and strict; explicit owned save is backed up, persistent, exported and retained while Smart Surv is OFF',async()=>{
  const x=await setup();try{
    const b=await client(x.f,{email:'rotation-other@example.test'}),schema=x.s.db.prepare("SELECT sql FROM sqlite_master WHERE name='app_settings'").get().sql,rows=x.s.db.prepare('SELECT * FROM app_settings').all();
    assert.equal((await ok(x.a.get('/api/settings'))).detectionOnlyRotation,false);assert.equal((await ok(b.get('/api/settings'))).detectionOnlyRotation,false);
    for(const value of [1,0,'true','false',null,{},[]])assert.equal((await x.a.post('/api/settings',{detectionOnlyRotation:value})).status,400);
    assert.equal(x.s.db.prepare("SELECT sql FROM sqlite_master WHERE name='app_settings'").get().sql,schema);assert.deepEqual(x.s.db.prepare('SELECT * FROM app_settings').all(),rows);
    await ok(x.a.post('/api/settings',{detectionOnlyRotation:true}));assert.equal((await ok(b.get('/api/settings'))).detectionOnlyRotation,false);assert.equal(x.s.settings().detectionOnlyRotation,true);const later=await client(x.f,{email:'rotation-new-after-save@example.test'});assert.equal((await ok(later.get('/api/settings'))).detectionOnlyRotation,false);
    const files=(await readdir(path.join(x.f.dir,'backups'))).filter(n=>n.startsWith('pre-detection-only-rotation-'));assert.equal(files.length,1);const backup=new DatabaseSync(path.join(x.f.dir,'backups',files[0]),{readOnly:true});try{assert.equal(backup.prepare('PRAGMA integrity_check').get().integrity_check,'ok');assert.deepEqual(backup.prepare('SELECT * FROM app_settings').all(),rows);}finally{backup.close();}
    await ok(x.a.post('/api/settings',{smartSurv:false,saveSnapshots:false}));assert.equal(x.s.settings().detectionOnlyRotation,true);await ok(x.a.post('/api/settings',{smartSurv:true,intervalMs:60000}));assert.equal(x.s.settings().detectionOnlyRotation,true);
    assert.equal(exportData(await ok(x.a.get('/api/account/export'))).settings.detectionOnlyRotation,true);assert.equal(exportData(await ok(b.get('/api/account/export'))).settings.detectionOnlyRotation,false);await ok(b.post('/api/settings',{detectionOnlyRotation:true}));await ok(b.post('/api/account/delete',{currentPassword:password,confirmation:'DELETE MY ACCOUNT'}));assert.equal(x.s.db.prepare('SELECT user_id FROM app_settings WHERE user_id=?').get(b.state.user.id),undefined);assert.equal(x.s.settings().detectionOnlyRotation,true);
    await x.f.restart();assert.equal((await ok(x.a.get('/api/settings'))).detectionOnlyRotation,true);assert.equal((await ok(later.get('/api/settings'))).detectionOnlyRotation,false);assert.equal(x.f.store.db.prepare('PRAGMA user_version').get().user_version,5);assert.deepEqual(x.f.store.db.prepare('PRAGMA foreign_key_check').all(),[]);assert.equal(x.f.calls,0);
  }finally{await x.f.close();}
});
test('verified backup and schema/update failures roll back combined saves and preserve pending eligibility',async()=>{
  const x=await setup();try{
    const before=x.s.settings(),prepare=x.s.db.prepare.bind(x.s.db),exec=x.s.db.exec.bind(x.s.db);
    x.s.db.prepare=sql=>{if(sql==='VACUUM INTO ?')throw Error('Synthetic backup failure');return prepare(sql);};assert.equal((await x.a.post('/api/settings',{detectionOnlyRotation:true})).status,507);x.s.db.prepare=prepare;assert.deepEqual(x.s.settings(),before);
    x.people([1]);await x.detect();const ticket=await x.ticket();assert(ticket.ticket);
    x.s.db.exec=sql=>{if(sql.includes('ADD COLUMN detection_only_rotation'))throw Error('Synthetic schema failure');return exec(sql);};assert.equal((await x.a.post('/api/settings',{detectionOnlyRotation:true,intervalMs:60000,saveSnapshots:false})).status,507);x.s.db.exec=exec;assert.deepEqual(x.s.settings(),before);assert(!prepare('PRAGMA table_info(app_settings)').all().some(c=>c.name==='detection_only_rotation'));
    x.s.db.prepare=sql=>{if(sql.startsWith('UPDATE app_settings SET detection_only_rotation'))throw Error('Synthetic update failure');return prepare(sql);};assert.equal((await x.a.post('/api/settings',{detectionOnlyRotation:true,smartSurv:false})).status,507);x.s.db.prepare=prepare;assert.deepEqual(x.s.settings(),before);assert(!prepare('PRAGMA table_info(app_settings)').all().some(c=>c.name==='detection_only_rotation'));await ok(x.a.post('/api/automatic-analyze',{sessionId:ticket.sessionId,ticket:ticket.ticket}));assert.equal(x.f.calls,1);
  }finally{await x.f.close();}
});
for(const detectionOnlyRotation of [false,true])test('Smart Surv OFF ignores Detection-Only '+detectionOnlyRotation+' and preserves one shared slot',async()=>{
  const x=await setup();try{
    await ok(x.a.post('/api/settings',{smartSurv:false,detectionOnlyRotation}));x.people([]);for(let i=0;i<6;i++){const gates=await x.detect(i?30000:0);assert(gates.every(g=>g.personPresent===false));if(i===0){const claim=await x.ticket();await ok(x.a.post('/api/settings',{detectionOnlyRotation:!detectionOnlyRotation}));assert.equal((await x.ticket()).ticket,claim.ticket,'ignored preference save keeps an OFF ticket valid');await ok(x.a.post('/api/settings',{detectionOnlyRotation}));assert.equal((await x.ticket()).ticket,claim.ticket);}assert.equal((await x.submit()).cameraId,x.cameras[i%3].id);}
    assert.equal(x.f.calls,6);assert.equal(x.s.db.prepare("SELECT COUNT(*) n FROM analysis_usage WHERE kind='request'").get().n,6);
  }finally{await x.f.close();}
});
for(const positives of [[1],[0,1],[0,1,2]])test('Detection-Only ON rotates fresh positive cameras '+positives.join(',')+' in saved order at 30-second spacing',async()=>{
  const x=await setup();try{
    await ok(x.a.post('/api/settings',{detectionOnlyRotation:true}));x.people(positives);for(let i=0;i<6;i++){await x.detect(i?30000:0);const g=await x.submit();assert.equal(g.cameraId,x.cameras[positives[i%positives.length]].id);assert.equal(g.personPresent,true);}
    const dates=x.s.observations().map(o=>Date.parse(o.timestamp)).sort();assert(dates.slice(1).every((t,i)=>t-dates[i]===30000));assert.equal(x.f.calls,6);assert.equal(x.s.sessions().reduce((n,s)=>n+s.api_requests,0),6);
  }finally{await x.f.close();}
});
test('eligibility and mode changes preserve the cursor, cooldown, sessions and single-use tickets',async()=>{
  const x=await setup();try{
    await ok(x.a.post('/api/settings',{detectionOnlyRotation:true}));x.people([0,1]);const expected=[0,1,2,0,2,0,1,2];for(let i=0;i<expected.length;i++){if(i===2)x.people([0,1,2]);if(i===4)x.people([0,2]);if(i===5)x.people([0,1,2]);await x.detect(i?30000:0);assert.equal((await x.submit()).cameraId,x.cameras[expected[i]].id);}
    const clock=x.f.server.desktop.policy.area(x.f.server.desktop.policy.sessions.get(x.runs[0].sessionId)),state={...clock};await ok(x.a.post('/api/settings',{detectionOnlyRotation:false}));assert.deepEqual(clock,state);await x.detect(1000);assert.equal((await x.ticket()).ticket,null);assert.equal(x.s.sessions().length,3);
    x.people([1]);await x.detect(29000);const g=await x.ticket();assert.equal(g.cameraId,x.cameras[0].id);assert.equal(g.personPresent,false);await ok(x.a.post('/api/settings',{detectionOnlyRotation:true}));assert.equal((await x.a.post('/api/automatic-analyze',{sessionId:g.sessionId,ticket:g.ticket})).status,409);assert.equal((await x.submit()).cameraId,x.cameras[1].id);assert.equal(x.f.calls,9);assert.equal((await x.ticket()).ticket,null);
  }finally{await x.f.close();}
});
test('no positives skips slots without catch-up; losing a positive before consumption prevents a paid request',async()=>{
  const x=await setup();try{
    await ok(x.a.post('/api/settings',{detectionOnlyRotation:true}));x.people([]);await x.detect();assert.equal((await x.ticket()).ticket,null);x.people([1]);await x.detect(1000);assert.equal((await x.ticket()).ticket,null);await x.detect(29000);const g=await x.ticket();x.people([]);await x.detect();assert.equal((await x.a.post('/api/automatic-analyze',{sessionId:g.sessionId,ticket:g.ticket})).status,409);assert.equal(x.f.calls,0);
    await x.detect(300000);assert.equal((await x.ticket()).ticket,null);x.people([1]);await x.detect(30000);await x.submit();assert.equal(x.f.calls,1);assert.equal((await x.ticket()).ticket,null);
  }finally{await x.f.close();}
});
test('detection-only filtering excludes stale/invalid/unavailable/OFF cameras and isolates Areas/accounts and independent cameras',()=>{
  let now=1000;const p=new MonitoringPolicy({now:()=>now});const add=(id,userId,areaId,order,person)=>{const s=p.start({cameraId:id,userId,intervalMs:30000});p.configure(s,{area_id:areaId,sort_order:order,rotation:0,device_id:id});p.checked(s,{frameValid:true,personPresent:person},{image:id},false,true,true,true);return s;};
  const left=add('left','owner','office',0,false),center=add('center','owner','office',1,true),right=add('right','owner','office',2,true),other=add('other','owner','bedroom',0,false),foreign=add('foreign','other','bedroom',0,true),solo=add('solo','owner',null,0,false);
  assert.equal(p.areaTicket(left,false,true,true).cameraId,'center');p.checked(center,{frameValid:false,personPresent:true},{image:'bad'},false,true,true,true);assert.equal(p.areaTicket(left,false,true,true).cameraId,'right');p.checked(right,{frameValid:true,personPresent:true,detectionStatus:'unavailable'},null,false,true,true,true);assert.equal(p.areaTicket(left,false,true,true).ticket,null);assert.equal(p.areaTicket(other,false,true,true).ticket,null);assert.equal(p.areaTicket(foreign,false,true,true).cameraId,'foreign');assert.equal(p.areaTicket(solo,false,true,true).ticket,null);
  now+=30000;for(const s of [left,center,right])p.get(s.id);p.checked(center,{frameValid:true,personPresent:true},{image:'new'},false,true,true,true);p.stop(center.id);assert.equal(p.areaTicket(left,false,true,true).ticket,null);now+=30000;p.get(right.id);p.checked(right,{frameValid:true,personPresent:true},{image:'new'},false,true,true,true);now+=5001;p.get(left.id);p.checked(left,{frameValid:true,personPresent:false},{image:'left'},false,true,true,true);assert.equal(p.areaTicket(left,false,true,true).ticket,null);
});
test('a held provider request and mode switch preserve the shared lock; failed positive capture cannot cause duplicates',async()=>{
  const x=await setup();let reject;try{
    await ok(x.a.post('/api/settings',{detectionOnlyRotation:true}));x.people([1]);await x.detect();const g=await x.ticket();x.f.providerHold=new Promise((_,r)=>reject=r);const pending=x.a.post('/api/automatic-analyze',{sessionId:g.sessionId,ticket:g.ticket});while(!x.f.calls)await new Promise(r=>setImmediate(r));await ok(x.a.post('/api/settings',{detectionOnlyRotation:false}));await x.detect(90000);assert.equal((await x.ticket()).ticket,null);assert.equal((await x.a.post('/api/automatic-analyze',{sessionId:g.sessionId,ticket:g.ticket})).status,409);assert.equal(x.f.calls,1);reject(Error('Synthetic provider failure'));x.f.providerHold=null;assert.equal((await pending).status,502);await x.detect();assert.equal((await x.ticket()).ticket,null);assert.equal(x.f.calls,1);assert.equal(x.s.sessions().reduce((n,s)=>n+s.failed_analyses,0),1);
  }finally{reject?.(Error('Fixture cleanup'));await x.f.close();}
});
