import test from 'node:test';
import assert from 'node:assert/strict';
import {desktopFixture,client,ok,image} from './desktop-fixture.mjs';
import {MonitoringPolicy} from '../src/monitoring.mjs';

async function setup(){
  const scores=new Map(),frames=new Map(),valid=new Map(),thresholds=[];
  const f=await desktopFixture({detector:{async start(){},async inspect(input,{threshold}){thresholds.push(threshold);const id=frames.get(input);return {frameValid:valid.get(id)!==false,personPresent:false,personConfidence:scores.get(id)??.05};},close(){}}}),a=await client(f,{owner:true}),s=f.store.forUser(a.state.user.id);
  const cameras=[s.camera(),(await ok(a.post('/api/cameras',{name:'Center',deviceId:'center'}))).camera,(await ok(a.post('/api/cameras',{name:'Right',deviceId:'right'}))).camera],area=(await ok(a.post('/api/camera-areas',{name:'Office'}))).areas[0];
  await ok(a.post('/api/cameras/order',{cameraIds:cameras.map(c=>c.id)}));await ok(a.post('/api/settings',{intervalMs:30000}));const runs=[];
  for(const camera of cameras){await ok(a.post('/api/cameras/'+camera.id,{areaId:area.id}));const frame='data:image/png;base64,'+Buffer.concat([Buffer.from(image.split(',')[1],'base64'),Buffer.from(camera.id)]).toString('base64');frames.set(frame,camera.id);runs.push({...await ok(a.post('/api/monitoring/start',{cameraId:camera.id,cameraActive:true})),image:frame});}
  const detectOne=r=>ok(a.post('/api/monitoring/check',{sessionId:r.sessionId,cameraActive:true,image:r.image,timestamp:new Date(f.now).toISOString(),rotation:s.camera(r.cameraId).rotation,detectOnly:true}));
  const detect=async(ms=0)=>{f.now+=ms;return Promise.all(runs.filter(r=>f.server.desktop.policy.sessions.get(r.sessionId)?.enabled).map(detectOne));};
  const ticket=()=>ok(a.post('/api/monitoring/area-ticket',{sessionId:runs.find(r=>f.server.desktop.policy.sessions.get(r.sessionId)?.enabled).sessionId}));
  const submit=async()=>{const gate=await ticket();assert(gate.ticket);const response=await ok(a.post('/api/automatic-analyze',{sessionId:gate.sessionId,ticket:gate.ticket}));assert.equal(response.observation.cameraId,gate.cameraId);assert.equal(response.observation.monitoringSessionId,gate.sessionId);return gate;};
  const people=indices=>{for(const [i,c] of cameras.entries())scores.set(c.id,indices.includes(i)?.65:.05);};
  return {f,a,s,cameras,area,runs,scores,frames,valid,thresholds,detect,detectOne,ticket,submit,people};
}
for(const positive of [[1],[0],[2],[0,2],[0,1,2]])test('Area-wide ON rotates all three perspectives with positive cameras '+positive.join(','),async()=>{
  const x=await setup();try{
    x.people(positive);for(let i=0;i<6;i++){const gates=await x.detect(i?30000:0);assert.deepEqual(gates.map(g=>g.personPresent),x.cameras.map((_,index)=>positive.includes(index)));const chosen=await x.submit();assert.equal(chosen.cameraId,x.cameras[i%3].id);assert.equal(chosen.personPresent,positive.includes(i%3));assert.equal(chosen.areaPersonDetected,true);assert.equal((await x.ticket()).ticket,null);}
    assert.equal(x.f.calls,6);assert.equal(x.s.observations().length,6);assert.equal(x.s.db.prepare("SELECT COUNT(*) n FROM analysis_usage WHERE kind='request'").get().n,6);assert.equal(x.s.sessions().reduce((n,r)=>n+r.api_requests,0),6);assert(x.thresholds.every(v=>v===.25));
  }finally{await x.f.close();}
});
test('switching positive perspectives preserves the cursor; empty slots wait for the next interval without catch-up',async()=>{
  const x=await setup();try{
    for(let i=0;i<3;i++){x.people([(i+1)%3]);await x.detect(i?30000:0);assert.equal((await x.submit()).cameraId,x.cameras[i].id);}
    x.people([]);await x.detect(30000);assert.equal((await x.ticket()).ticket,null);const before=x.f.calls;x.people([1]);await x.detect(1000);assert.equal((await x.ticket()).ticket,null);assert.equal(x.f.calls,before);await x.detect(29000);assert.equal((await x.submit()).cameraId,x.cameras[0].id);assert.equal((await x.ticket()).ticket,null);
    x.people([]);await x.detect(300000);assert.equal((await x.ticket()).ticket,null);await ok(x.a.post('/api/settings',{smartSurv:false}));for(const id of x.cameras.map(c=>c.id)){await x.detect(30000);assert.equal((await x.submit()).cameraId,id===x.cameras[0].id?x.cameras[1].id:id===x.cameras[1].id?x.cameras[2].id:x.cameras[0].id);}assert.equal(x.f.calls,7);
  }finally{await x.f.close();}
});
test('positive results must remain fresh and valid at ticket consumption; negative selected-camera refresh keeps its ticket',async()=>{
  const x=await setup();try{
    x.people([1]);await x.detect();let t=await x.ticket();assert.equal(t.cameraId,x.cameras[0].id);await x.detectOne(x.runs[0]);assert.equal((await x.ticket()).ticket,t.ticket);x.people([]);await x.detectOne(x.runs[1]);assert.equal((await x.a.post('/api/automatic-analyze',{sessionId:t.sessionId,ticket:t.ticket})).status,409);assert.equal(x.f.calls,0);
    x.people([1]);await x.detect(1000);assert.equal((await x.ticket()).ticket,null,'losing occupancy before consumption skips the current interval');await x.detect(29000);t=await x.ticket();x.f.now+=5001;await x.detectOne(x.runs[0]);await x.detectOne(x.runs[2]);assert.equal((await x.ticket()).ticket,null,'stale Center cannot activate fresh negative Left/Right');assert.equal(x.f.calls,0);
    x.valid.set(x.cameras[1].id,false);await x.detect(30000);assert.equal((await x.ticket()).ticket,null,'invalid positive is not occupancy');x.valid.set(x.cameras[1].id,true);await x.detect(30000);t=await x.ticket();assert(t.ticket);await ok(x.a.post('/api/cameras/'+x.cameras[0].id,{areaId:null}));assert.equal((await x.a.post('/api/automatic-analyze',{sessionId:t.sessionId,ticket:t.ticket})).status,409);assert.equal(x.f.calls,0);
  }finally{await x.f.close();}
});
test('Auto OFF and disconnected positive cameras cannot activate their peers; valid remaining cameras retain configuration/history',async()=>{
  const x=await setup();try{
    x.people([1]);await x.detect();await ok(x.a.post('/api/monitoring/stop',{sessionId:x.runs[1].sessionId}));assert.equal((await x.ticket()).ticket,null);x.people([2]);await x.detect(30000);assert.equal((await x.submit()).cameraId,x.cameras[0].id);assert.equal((await x.a.post('/api/monitoring/check',{sessionId:x.runs[2].sessionId,cameraActive:false})).status,409);assert.equal(x.f.server.desktop.policy.sessions.get(x.runs[2].sessionId).enabled,false);await x.detect(30000);assert.equal((await x.ticket()).ticket,null);assert.equal(x.f.calls,1);assert.equal(x.s.cameras().length,3);assert.equal(x.s.observations().length,1);assert.equal(x.s.camera(x.cameras[2].id).area_id,x.area.id);
    x.people([0]);await x.detect(30000);assert.equal((await x.submit()).cameraId,x.cameras[0].id);assert.equal(x.f.calls,2);
  }finally{await x.f.close();}
});
test('Areas and accounts are independent; an unassigned camera still requires its own person result',()=>{
  let now=1000;const p=new MonitoringPolicy({now:()=>now});
  const add=(id,userId,areaId,order,person)=>{const s=p.start({cameraId:id,userId,intervalMs:30000});p.configure(s,{area_id:areaId,sort_order:order,rotation:0,device_id:id});p.checked(s,{frameValid:true,personPresent:person},{image:id},false,true,true);return s;};
  const left=add('left','owner','office',0,false),center=add('center','owner','office',1,true),bed=add('bed','owner','bedroom',0,false),foreign=add('foreign','other','bedroom',0,true),solo=add('solo','owner',null,0,false);
  assert.equal(p.areaTicket(left,false).cameraId,'left');assert.equal(p.areaTicket(bed,false).ticket,null);assert.equal(p.areaTicket(solo,false).ticket,null);assert.equal(p.areaTicket(foreign,false).cameraId,'foreign');
  p.stop(center.id);assert.equal(p.areaTicket(left,false).ticket,null);assert.equal(p.areaPersonDetected(left),false);now+=30000;p.get(solo.id);p.checked(solo,{frameValid:true,personPresent:false},{image:'solo'},false,false);assert(p.areaTicket(solo,false,false).ticket);
});
test('configured confidence is preserved and a below-threshold result cannot activate an Area',async()=>{
  const x=await setup();try{
    await ok(x.a.post('/api/settings/detection',{confidenceThreshold:.50}));x.people([]);x.scores.set(x.cameras[1].id,.31);await x.detect();assert.equal((await x.ticket()).ticket,null);assert.equal((await ok(x.a.get('/api/settings/detection'))).confidenceThreshold,.50);assert(x.thresholds.every(v=>v===.50));assert.equal(x.f.calls,0);
    x.scores.set(x.cameras[1].id,.55);await x.detect(30000);assert.equal((await x.submit()).cameraId,x.cameras[0].id);assert.equal((await ok(x.a.get('/api/settings/detection'))).confidenceThreshold,.50);assert.equal(x.f.calls,1);
  }finally{await x.f.close();}
});
