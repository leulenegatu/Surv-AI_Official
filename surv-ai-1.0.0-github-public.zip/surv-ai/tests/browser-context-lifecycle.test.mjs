import test from 'node:test';
import assert from 'node:assert/strict';
import {inflateRawSync} from 'node:zlib';
import {createHash} from 'node:crypto';
import {writeFile} from 'node:fs/promises';
import {desktopFixture,client,enable,start,automatic,ok,password} from './desktop-fixture.mjs';
import {browserPeer} from './browser-peer.mjs';
import {EXTENSION_ORIGIN,credentialOwner} from '../src/browser-companion-store.mjs';
import {insertSpan,confirmSpan,desktopSpans} from '../src/desktop-store.mjs';
import {desktopExplorer} from '../src/desktop-explorer.mjs';
import {buildReport,buildReportForPeriod} from '../src/report.mjs';
import {renderReportPDF} from '../src/report-pdf.mjs';
const pair=async(f,c)=>{await ok(c.post('/api/settings/browser',{enabled:true,browser:'chrome'}));const challenge=await ok(c.post('/api/settings/browser/pair',{}));return fetch(f.origin+'/browser-companion/pair',{method:'POST',headers:{Origin:EXTENSION_ORIGIN,'Content-Type':'application/json'},body:JSON.stringify({code:challenge.code})}).then(r=>r.json());};
function dataJSON(buffer){let offset=0;while(buffer.readUInt32LE(offset)===0x04034b50){const len=buffer.readUInt32LE(offset+18),n=buffer.readUInt16LE(offset+26),extra=buffer.readUInt16LE(offset+28),name=buffer.subarray(offset+30,offset+30+n).toString(),pos=offset+30+n+extra;if(name==='data.json')return JSON.parse(inflateRawSync(buffer.subarray(pos,pos+len)));offset=pos+len;}throw Error('Export data missing');}
test('date clipping, exact hosts, repeated normalized titles, raw appearances and bounded pages reconcile',async()=>{
  const f=await desktopFixture();try{
    const a=await client(f,{owner:true});await enable(a,'local-webcam',true);await pair(f,a);f.now=Date.parse('2026-10-06T03:59:50Z');const id=await start(f,a),s=f.store.forUser(a.state.user.id),session=f.server.desktop.entries.get(id).session;
    const insert=(at,title,ms=2000,host='sub.example.co.uk')=>{const r=insertSpan(s,session,{sampledAt:at,executable:'chrome.exe',application:'Google Chrome',title:'Unchanging Windows caption',state:'active',browser:'chrome',hostname:host,tabTitle:title,provenance:'verified_browser_companion'});confirmSpan(s,r,new Date(Date.parse(at)+ms).toISOString());};
    insert('2026-10-06T03:59:50Z','Alpha 雪',20000);insert('2026-10-06T04:05:00Z','Beta');insert('2026-10-06T04:06:00Z',' Alpha  雪 ');insert('2026-10-06T04:07:00Z','ALPHA 雪');f.now=Date.parse('2026-10-06T06:00:00Z');
    const base={from:'2026-10-06',to:'2026-10-06',timeZone:'America/New_York',application:'chrome.exe'},apps=desktopExplorer(s,{...base,level:'applications'},f.now),domains=desktopExplorer(s,{...base,level:'domains'},f.now),titles=desktopExplorer(s,{...base,level:'titles',hostname:'sub.example.co.uk'},f.now);
    assert.equal(apps.items[0].ms,16000);assert.equal(domains.items[0].key,'sub.example.co.uk');assert.equal(domains.items.reduce((n,v)=>n+v.ms,0),apps.items[0].ms);assert.equal(titles.items.reduce((n,v)=>n+v.ms,0),apps.items[0].ms);
    const alpha=titles.items.find(v=>v.label==='Alpha 雪');assert.equal(alpha.ms,14000);assert.equal(alpha.appearances,3);const appearances=desktopExplorer(s,{...base,level:'spans',hostname:'sub.example.co.uk',titleKey:alpha.key},f.now);assert.equal(appearances.items.length,3);assert(appearances.items.some(v=>v.tab_title===' Alpha  雪 '));assert.equal(appearances.items.find(v=>v.ms===10000).start,'2026-10-06T04:00:00.000Z');
    for(let i=0;i<30;i++)insert(new Date(Date.parse('2026-10-06T04:10:00Z')+i*4000).toISOString(),'Distinct title '+i);
    const first=desktopExplorer(s,{...base,level:'titles',hostname:'sub.example.co.uk'},f.now),second=desktopExplorer(s,{...base,level:'titles',hostname:'sub.example.co.uk',page:'1'},f.now);assert.equal(first.items.length,25);assert.equal(second.items.length,7);assert.equal(first.total,32);assert.equal(new Set([...first.items,...second.items].map(v=>v.key)).size,32);
    assert.equal((await a.get('/api/desktop/explorer?from=2026-10-06&to=2026-10-06&timeZone=UTC&userId=foreign')).status,400);assert.equal(f.calls,0);await ok(a.post('/api/monitoring/stop',{sessionId:id}));
  }finally{await f.close();}
});
test('owned browser evidence exports without credentials, compact PDFs include hosts, and deletion rolls back then cascades',async()=>{
  const f=await desktopFixture();try{
    const a=await client(f,{owner:true}),b=await client(f,{email:'browser-data@example.test'}),camera=(await ok(b.post('/api/cameras',{name:'Private camera',deviceId:'synthetic'}))).camera;
    await enable(b,camera.id,true);const paired=await pair(f,b),peer=await browserPeer(f,paired.token);f.collector.raw={executable:'chrome.exe',title:'Synthetic tab - Google Chrome',state:'active',idleMs:0};const id=await start(f,b,camera.id),s=f.store.forUser(b.state.user.id);await f.tick(b,id);const record=(await automatic(f,b,id)).observation;for(let i=0;i<4;i++)await f.tick(b,id);
    const exported=dataJSON((await b.get('/api/account/export')).data);assert.equal(exported.observations[0].desktopContext.hostname,'youtube.com');assert.equal(exported.desktopContext.spans.find(r=>r.hostname).tab_title,'Synthetic tab');assert(!JSON.stringify(exported).includes(paired.token));assert(!JSON.stringify(exported).includes('token_hash'));assert.equal((await a.get('/api/desktop/explorer?from=2026-10-06&to=2026-10-06&timeZone=UTC')).data.totalMs,0);assert.equal(f.store.forUser(a.state.user.id).getObservation(record.id),null);
    const report=buildReport(s,{startDate:'2026-10-01',length:7,timeZone:'UTC',now:f.now+86400000});assert.equal(report.desktop.browserHosts[0].hostname,'youtube.com');assert.equal(report.desktopEvidence[0].desktopContext.provenance,'verified_browser_companion');const pdf=await renderReportPDF(report,{snapshots:f.snapshots});assert(pdf.subarray(0,4).toString()==='%PDF');await writeFile('.test-output/browser-report.pdf',pdf);
    const month=buildReportForPeriod(s,{kind:'month',startDate:'2026-10-01',endDate:'2026-10-31',length:31,timeZone:'UTC',bounds:{from:'2026-10-01T00:00:00Z',to:'2026-11-01T00:00:00Z'}},{now:Date.parse('2026-11-02T00:00:00Z')});assert.equal(month.desktop.browserHosts[0].hostname,'youtube.com');
    f.now=Date.parse('2026-11-02T00:00:00Z');const archive=await f.server.monthlyReports.generate(s.userId,'2026-10',{timeZone:'UTC'}),saved=f.server.monthlyReports.get(s.userId,archive.id).pdf,hash=createHash('sha256').update(saved).digest('hex');
    await enable(b,camera.id,false);assert.equal((await b.get('/api/reports/monthly/'+archive.id+'/pdf')).status,403);assert.equal(createHash('sha256').update(f.server.monthlyReports.read(f.server.monthlyReports.row(s.userId,archive.id))).digest('hex'),hash);assert(!JSON.stringify(dataJSON((await b.get('/api/account/export')).data)).includes('Synthetic tab'));
    await enable(b,camera.id,true);assert.equal((await b.get('/api/reports/monthly/'+archive.id+'/pdf')).status,200);await browserPeer(f,paired.token);
    f.store.db.exec("CREATE TRIGGER browser_fixture_failure BEFORE DELETE ON users BEGIN SELECT RAISE(ABORT,'synthetic'); END");assert.equal((await b.post('/api/account/delete',{currentPassword:password,confirmation:'DELETE MY ACCOUNT'})).status,507);assert.equal(credentialOwner(f.store,paired.token),s.userId);assert.equal(f.server.browser.clients.size,1);f.store.db.exec('DROP TRIGGER browser_fixture_failure');
    await ok(b.post('/api/account/delete',{currentPassword:password,confirmation:'DELETE MY ACCOUNT'}));assert.equal(credentialOwner(f.store,paired.token),null);assert.equal(f.server.browser.clients.size,0);assert.equal(desktopSpans(s).length,0);assert.equal(f.store.db.prepare('PRAGMA foreign_key_check').all().length,0);peer.close();assert.equal(f.calls,1);
  }finally{await f.close();}
});
test('history reset and finite retention cascade browser spans while preserving active evidence and pairing',async()=>{
  const f=await desktopFixture();try{
    const a=await client(f,{owner:true});await enable(a);const paired=await pair(f,a);await browserPeer(f,paired.token);f.collector.raw={executable:'chrome.exe',state:'active',idleMs:0};const old=await start(f,a);await f.tick(a,old);await automatic(f,a,old);await ok(a.post('/api/monitoring/stop',{sessionId:old}));const active=await start(f,a);await f.tick(a,active,15000);await automatic(f,a,active);const s=f.store.forUser(a.state.user.id);
    await ok(a.post('/api/account/history/delete',{currentPassword:password,confirmation:'DELETE MY HISTORY',deleteReports:false}));assert.equal(s.session(old),null);assert.equal(s.session(active).status,'active');assert(desktopSpans(s).some(r=>r.session_id===active&&r.hostname==='youtube.com'));assert.equal(credentialOwner(f.store,paired.token),s.userId);
    await ok(a.post('/api/monitoring/stop',{sessionId:active}));f.now=Date.parse('2027-01-10T16:00:00Z');await ok(a.post('/api/privacy/settings',{historyRetention:'30-days',monthlyReports:false}));await ok(a.post('/api/privacy/maintenance',{}));assert.equal(desktopSpans(s).length,0);assert.equal(f.store.db.prepare('SELECT COUNT(*) n FROM observation_desktop').get().n,0);assert.equal(credentialOwner(f.store,paired.token),s.userId);assert.equal(f.calls,2);
  }finally{await f.close();}
});
