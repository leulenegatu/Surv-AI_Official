// Child process used only by crash recovery QA; all AI/network work is mocked.
import {createServer} from '../server.mjs';
import {SnapshotStore} from '../src/snapshot-store.mjs';
import path from 'node:path';
const server=createServer({databasePath:process.argv[2],snapshots:new SnapshotStore(process.argv[3]),apiKey:'test-only',detector:{async start(){},async inspect(){return {frameValid:true,personPresent:true};},close(){}},fetchImpl:()=>new Promise(()=>{})});
server.listen(0,'127.0.0.1',()=>process.send({port:server.address().port}));
