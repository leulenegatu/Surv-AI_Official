import {test} from 'node:test';
import assert from 'node:assert/strict';
import {randomUUID,createHash} from 'node:crypto';
import {mkdtemp,rm,readFile,readdir,writeFile} from 'node:fs/promises';
import {DatabaseSync} from 'node:sqlite';
import os from 'node:os';
import path from 'node:path';
import {LocalStorage} from '../src/storage.mjs';
import {createServer} from '../server.mjs';
import {SnapshotStore} from '../src/snapshot-store.mjs';
import {AuthService,hashPassword,verifyPassword} from '../src/auth.mjs';
import {buildReport} from '../src/report.mjs';
import {stripTestOwnership} from './auth-fixture.mjs';

const image='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+j1ioAAAAASUVORK5CYII=';
const password='a private fixture passphrase 2026';
const signup=(email='owner@example.test')=>({displayName:email.split('@')[0],email,password,confirmPassword:password});
const record=(label='Owner private evidence',extra={})=>({id:randomUUID(),timestamp:'2026-10-02T14:00:00.000Z',activity:label,description:label+' is visible.',location:'Office',confidence:.9,objects:['book'],source:'manual_ai',...extra});
const digest=value=>createHash('sha256').update(value).digest('hex');
async function fixture(extra={}){
  const dir=await mkdtemp(path.join(os.tmpdir(),'surv-auth-')),store=new LocalStorage(path.join(dir,'db.sqlite')),snapshots=new SnapshotStore(path.join(dir,'snapshots'));
  const server=createServer({storage:store,snapshots,now:()=>Date.parse('2026-10-04T18:00:00Z'),apiKey:'fixture-only',fetchImpl:()=>{throw Error('Unexpected AI request');},detector:{async start(){},async inspect(){return {frameValid:true,personPresent:false};},close(){}},...extra});
  await new Promise(r=>server.listen(0,'127.0.0.1',r));const origin=`http://127.0.0.1:${server.address().port}`;
  return {dir,store,snapshots,server,origin,async close(){if(server.listening)await new Promise(r=>server.close(r));await rm(dir,{recursive:true,force:true});}};
}
async function client(origin){
  const state={cookie:'',csrf:'',user:null};
  const request=async(route,{body,method=body?'POST':'GET',headers={},...other}={})=>{
    const res=await fetch(origin+route,{...other,method,headers:{...(body?{'Content-Type':'application/json'}:{}),...(state.cookie?{Cookie:state.cookie}:{}),...(state.csrf?{'X-Surv-CSRF':state.csrf}:{}),...headers},...(body?{body:JSON.stringify(body)}:{})});
    if(res.headers.get('set-cookie'))state.cookie=res.headers.get('set-cookie').split(';')[0];
    const type=res.headers.get('content-type')||'',data=method==='HEAD'?{}:type.includes('json')?await res.json():Buffer.from(await res.arrayBuffer());
    if(data.csrfToken)state.csrf=data.csrfToken;if(data.user&&route.startsWith('/api/auth/'))state.user=data.user;return {res,status:res.status,data};
  };
  const c={state,request,get:route=>request(route),post:(route,body)=>request(route,{body})};await c.get('/api/auth/me');return c;
}
async function owner(f){const c=await client(f.origin);assert.equal((await c.post('/api/auth/owner',signup())).status,200);return c;}
const ok=async p=>{const r=await p;assert.equal(r.status,200,JSON.stringify(r.data));return r.data;};

test('Argon2id uses independent salts and verifies exact Unicode/space-preserving passwords',async()=>{
  const a=await hashPassword('  welcome private 世界 passphrase  '),b=await hashPassword('  welcome private 世界 passphrase  ');
  assert.match(a,/^\$argon2id\$v=19\$m=65536,t=3,p=1\$/);assert.notEqual(a,b);assert(await verifyPassword('  welcome private 世界 passphrase  ',a));assert.equal(await verifyPassword('welcome private 世界 passphrase',a),false);assert.equal(await verifyPassword(password,'broken'),false);assert(!a.includes('welcome'));
});

test('v4 migration verifies a backup and preserves rows, references, bytes and owner settings; claim is atomic',async()=>{
  const dir=await mkdtemp(path.join(os.tmpdir(),'surv-auth-migration-')),filename=path.join(dir,'db.sqlite');let store;
  try{
    store=new LocalStorage(filename);const snaps=new SnapshotStore(path.join(dir,'snapshots')),ref=await snaps.put(image),run={id:randomUUID(),intervalMs:30000,cameraId:'local-webcam',cameraName:'Office',telemetry:{requests:2,successes:1,failures:1,noPerson:3,invalid:4,lastRequest:'2026-10-02T14:00:00Z'}};
    store.createSession(run,'2026-10-02T14:00:00Z');store.saveSession(run,'2026-10-02T14:00:00Z');store.finishSession(run.id,'2026-10-02T14:01:00Z');store.saveObservation(record(undefined,{snapshotRef:ref}));store.setInterval(30000);store.setSaveSnapshots(false);
    stripTestOwnership(store);const tables=['observations','monitoring_sessions','cameras','app_settings'],before=Object.fromEntries(tables.map(t=>[t,JSON.stringify(store.db.prepare(`SELECT * FROM ${t} ORDER BY id`).all())])),fileHash=digest(await readFile(path.join(snaps.directory,ref)));store.close();
    store=new LocalStorage(filename);assert.equal(store.db.prepare('PRAGMA user_version').get().user_version,5);assert(store.ownershipBackup);const backup=new DatabaseSync(store.ownershipBackup,{readOnly:true});assert.equal(backup.prepare('PRAGMA integrity_check').get().integrity_check,'ok');assert.equal(backup.prepare('PRAGMA user_version').get().user_version,4);for(const t of tables)assert.equal(JSON.stringify(backup.prepare(`SELECT * FROM ${t} ORDER BY id`).all()),before[t]);backup.close();
    assert.equal(JSON.parse(await readFile(store.ownershipBackup+'.verified.json','utf8')).integrity,'ok');const auth=new AuthService(store);
    store.db.exec("CREATE TRIGGER fail_claim BEFORE UPDATE OF user_id ON observations BEGIN SELECT RAISE(ABORT,'fixture claim failure'); END");await assert.rejects(auth.signup(signup(),{owner:true}),/Unable to create/);assert.equal(auth.ownerId(),null);assert.equal(store.db.prepare('SELECT COUNT(*) n FROM users').get().n,0);for(const t of tables)assert.equal(store.db.prepare(`SELECT COUNT(*) n FROM ${t} WHERE user_id IS NOT NULL`).get().n,0);
    store.db.exec('DROP TRIGGER fail_claim');const user=await auth.signup(signup(),{owner:true});assert.equal(user.role,'ADMIN');assert.equal(user.email_verified,0);assert.equal(auth.ownerId(),user.id);
    for(const t of tables){const rows=store.db.prepare(`SELECT * FROM ${t} ORDER BY id`).all();assert(rows.every(r=>r.user_id===user.id));assert.equal(JSON.stringify(rows.map(({user_id,...row})=>row)),before[t]);}
    assert.deepEqual(store.forUser(user.id).settings(),{intervalMs:30000,saveSnapshots:false,smartSurv:true,detectionOnlyRotation:false});assert.equal(digest(await readFile(path.join(snaps.directory,ref))),fileHash);assert.deepEqual(store.db.prepare('PRAGMA foreign_key_check').all(),[]);
  }finally{store?.close();await rm(dir,{recursive:true,force:true});}
});

test('schema migration rolls back DDL and keeps a verified v4 backup if migration fails',async()=>{
  const dir=await mkdtemp(path.join(os.tmpdir(),'surv-auth-rollback-')),filename=path.join(dir,'db.sqlite');
  try{let store=new LocalStorage(filename);const r=store.saveObservation(record());stripTestOwnership(store);store.db.exec('CREATE INDEX observations_user_date ON observations(timestamp)');store.close();assert.throws(()=>new LocalStorage(filename),/existing history was preserved/);
    const db=new DatabaseSync(filename,{readOnly:true});assert.equal(db.prepare('PRAGMA user_version').get().user_version,4);assert.equal(db.prepare("SELECT COUNT(*) n FROM sqlite_master WHERE name='users'").get().n,0);assert.equal(db.prepare('SELECT id FROM observations').get().id,r.id);assert.equal(db.prepare('PRAGMA integrity_check').get().integrity_check,'ok');db.close();assert((await readdir(path.join(dir,'backups'))).some(f=>f.endsWith('.verified.json')));
  }finally{await rm(dir,{recursive:true,force:true});}
});

test('owner creation races yield exactly one ADMIN and no partially claimed or duplicate accounts',async()=>{
  const store=new LocalStorage(':memory:');try{const auth=new AuthService(store),results=await Promise.allSettled([auth.signup(signup('a@example.test'),{owner:true}),auth.signup(signup('b@example.test'),{owner:true})]);assert.equal(results.filter(r=>r.status==='fulfilled').length,1);assert.equal(store.db.prepare('SELECT COUNT(*) n FROM users').get().n,1);assert.equal(store.db.prepare("SELECT COUNT(*) n FROM users WHERE role='ADMIN'").get().n,1);assert(store.db.prepare('SELECT user_id FROM cameras').all().every(r=>r.user_id===auth.ownerId()));}finally{store.close();}
});

test('registration, rotation, generic login errors, duplicate email, roles, verification and logout revocation',async()=>{
  const f=await fixture();try{const a=await client(f.origin),anonymous=a.state.cookie;
    assert.equal((await a.post('/api/auth/register',signup())).status,409);assert.equal((await a.post('/api/auth/owner',{...signup(),role:'ADMIN'})).status,400);await ok(a.post('/api/auth/owner',signup()));assert.notEqual(a.state.cookie,anonymous);assert.equal(a.state.user.role,'ADMIN');assert.equal(a.state.user.emailVerified,false);
    const raw=f.store.db.prepare('SELECT * FROM users').get();assert.match(raw.password_hash,/^\$argon2id/);assert(!JSON.stringify(f.store.db.prepare('SELECT * FROM auth_sessions').all()).includes(a.state.cookie.split('=')[1]));
    const b=await client(f.origin);assert.equal((await b.post('/api/auth/register',{...signup('new@example.test'),user_id:a.state.user.id})).status,400);await ok(b.post('/api/auth/register',signup('new@example.test')));assert.equal(b.state.user.role,'USER');assert.equal((await b.get('/api/admin/users')).status,403);
    const unknown=await client(f.origin),badPassword=await unknown.post('/api/auth/login',{email:'new@example.test',password:'wrong password'}),badEmail=await unknown.post('/api/auth/login',{email:'unknown@example.test',password});assert.equal(badPassword.status,401);assert.deepEqual(badPassword.data,badEmail.data);assert.equal((await unknown.post('/api/auth/register',signup('NEW@example.test'))).status,409);
    const before=unknown.state.cookie;await ok(unknown.post('/api/auth/login',{email:' NEW@EXAMPLE.TEST ',password}));assert.notEqual(unknown.state.cookie,before);assert.equal(unknown.state.user.id,b.state.user.id);
    const token=unknown.state.cookie;await ok(unknown.post('/api/auth/logout',{}));assert.equal((await unknown.get('/api/observations')).status,401);assert.equal((await fetch(f.origin+'/api/observations',{headers:{Cookie:token}})).status,401);assert.equal((await fetch(f.origin+'/api/observations',{headers:{Cookie:anonymous}})).status,401);
    const metadata=await ok(a.get('/api/admin/users'));assert.equal(metadata.users.length,2);assert(!JSON.stringify(metadata).includes('password_hash'));assert(!JSON.stringify(metadata).includes('csrf_token'));assert.equal((await a.post('/api/auth/owner',signup('third@example.test'))).status,409);
  }finally{await f.close();}
});

test('all private endpoints require authentication; CSRF rejects absent, malformed and cross-origin requests',async()=>{
  const f=await fixture();try{
    const routes=['/api/cameras','/api/settings','/api/observations','/api/observations/'+randomUUID(),'/api/monitoring/status','/api/monitoring/sessions','/api/history/week?date=2026-10-02','/api/analytics?from=2026-10-02&to=2026-10-02','/api/insights?date=2026-10-02','/api/reports/availability','/api/reports/preview?startDate=2026-09-28&length=7','/api/snapshots/'+randomUUID()+'.png','/api/admin/users'];for(const route of routes)assert.equal((await fetch(f.origin+route)).status,401,route);
    for(const route of ['/api/ask-local','/api/reports/pdf','/api/analyze','/api/monitoring/start','/api/auth/logout'])assert.equal((await fetch(f.origin+route,{method:'POST',headers:{'Content-Type':'application/json'},body:'{}'})).status,401,route);
    const a=await owner(f),change={intervalMs:30000};for(const token of ['', 'é'.repeat(43),'wrong'])assert.equal((await a.request('/api/settings',{body:change,headers:{'X-Surv-CSRF':token}})).status,403);
    assert.equal((await a.request('/api/settings',{body:change,headers:{Origin:'https://attacker.test'}})).status,403);assert.equal((await a.request('/api/settings',{body:change,headers:{'Sec-Fetch-Site':'cross-site'}})).status,403);assert.equal((await a.get('/api/settings')).data.intervalMs,15000);
    const cookie=(await client(f.origin)).state.cookie;assert.match(cookie,/^surv_session=/);const response=await fetch(f.origin+'/api/auth/me');assert.match(response.headers.get('set-cookie'),/HttpOnly; SameSite=Lax; Path=\//);assert.equal(response.headers.get('cache-control'),'no-store');assert.match(response.headers.get('content-security-policy'),/frame-ancestors 'none'/);
    const run=await ok(a.post('/api/monitoring/start',{cameraActive:true}));assert.equal((await a.request('/api/monitoring/stop',{body:{sessionId:run.sessionId,csrfToken:a.state.csrf},headers:{'X-Surv-CSRF':''}})).status,403);
    const beacon=await fetch(f.origin+'/api/monitoring/stop',{method:'POST',headers:{Cookie:a.state.cookie,'Content-Type':'application/json'},body:JSON.stringify({sessionId:run.sessionId,csrfToken:a.state.csrf})});assert.equal(beacon.status,200);
    assert.equal((await fetch(f.origin+'/.local-data/snapshots/anything.png')).status,404);assert.equal((await fetch(f.origin+'/snapshot-store.mjs')).status,404);
  }finally{await f.close();}
});

test('cross-user isolation covers history, summaries, Ask, settings, cameras, sessions, snapshots and reports, including ADMIN',async()=>{
  const f=await fixture();try{
    const ref=await f.snapshots.put(image),legacy=f.store.saveObservation(record('OWNER_SECRET_ALPHA',{snapshotRef:ref}));f.store.setInterval(30000);f.store.setSaveSnapshots(false);const a=await owner(f),aId=a.state.user.id;
    const aRun=await ok(a.post('/api/monitoring/start',{cameraActive:true})),b=await client(f.origin);await ok(b.post('/api/auth/register',signup('user-b@example.test')));const bId=b.state.user.id;
    assert.deepEqual((await ok(b.get('/api/observations'))).observations,[]);assert.deepEqual((await ok(b.get('/api/monitoring/sessions'))).sessions,[]);assert.deepEqual((await ok(b.get('/api/cameras'))).cameras,[]);assert.deepEqual(await ok(b.get('/api/settings')),{intervalMs:15000,saveSnapshots:true,smartSurv:true,detectionOnlyRotation:false});assert.equal((await ok(b.get('/api/monitoring/status'))).monitoring,'off');
    const weekly=await ok(b.get('/api/history/week?date=2026-10-02&timeZone=UTC'));assert(weekly.days.every(d=>d.count===0));assert.equal((await ok(b.get('/api/analytics?from=2026-10-01&to=2026-10-04&timeZone=UTC'))).totals.observations,0);assert.equal((await ok(b.get('/api/insights?date=2026-10-02&timeZone=UTC'))).empty,true);
    const query=()=>({question:'What did I do this week?',date:'2026-10-02',timeZone:'UTC',scope:'week'});assert.equal((await ok(b.post('/api/ask-local',query()))).count,0);assert.equal((await b.get('/api/reports/preview?startDate=2026-09-28&length=7&timeZone=UTC')).status,400);assert.equal((await b.post('/api/reports/pdf',{startDate:'2026-09-28',length:7,timeZone:'UTC'})).status,400);
    const bc=(await ok(b.post('/api/cameras',{name:'B_PRIVATE_CAMERA',deviceId:'same-local-device'}))).camera;await ok(a.post('/api/cameras/local-webcam',{deviceId:'same-local-device'}));const br=(await ok(b.post('/api/observations',{observation:record('USER_B_SECRET_BRAVO',{snapshotRef:ref}),image}))).observation;assert.notEqual(br.snapshotRef,ref,'client snapshot refs cannot attach foreign evidence');const bRun=await ok(b.post('/api/monitoring/start',{cameraId:bc.id,cameraActive:true}));
    assert.deepEqual((await ok(a.get('/api/observations'))).observations.map(r=>r.id),[legacy.id]);assert.deepEqual((await ok(b.get('/api/observations'))).observations.map(r=>r.id),[br.id]);assert.equal((await ok(a.get('/api/cameras'))).cameras.length,1);assert.equal((await ok(b.get('/api/cameras'))).cameras.length,1);assert.equal((await ok(a.get('/api/monitoring/sessions'))).sessions[0].id,aRun.sessionId);assert.equal((await ok(b.get('/api/monitoring/sessions'))).sessions[0].id,bRun.sessionId);
    for(const [actor,foreignObservation,foreignCamera,foreignRun,foreignRef,foreignUser] of [[b,legacy.id,'local-webcam',aRun.sessionId,ref,aId],[a,br.id,bc.id,bRun.sessionId,br.snapshotRef,bId]]){
      for(const route of ['/api/observations/'+foreignObservation,'/api/cameras/'+foreignCamera,'/api/monitoring/sessions/'+foreignRun,'/api/snapshots/'+foreignRef])assert.equal((await actor.get(route)).status,404,route);
      assert.equal((await actor.request('/api/snapshots/'+foreignRef,{method:'HEAD'})).status,404);assert.equal((await actor.request('/api/snapshots/'+foreignRef,{method:'DELETE'})).status,404);assert.equal((await actor.post('/api/cameras/'+foreignCamera,{name:'ATTACK'})).status,404);
      for(const route of ['/api/monitoring/stop','/api/monitoring/check','/api/monitoring/telemetry','/api/automatic-analyze'])assert.equal((await actor.post(route,{sessionId:foreignRun,cameraActive:true,image,timestamp:'2026-10-04T18:00:00Z',ticket:'attack'})).status,404,route);
      for(const route of ['/api/settings','/api/observations','/api/cameras','/api/reports/availability'])assert.equal((await actor.get(route+'?user_id='+foreignUser)).status,400,route);
      for(const route of ['/api/ask-local','/api/reports/pdf','/api/settings','/api/observations'])assert.equal((await actor.post(route,{...query(),userId:foreignUser})).status,400,route);
      assert.equal((await actor.post('/api/ask-local',{...query(),observationId:foreignObservation})).status,400);assert.equal((await actor.post('/api/reports/pdf',{startDate:'2026-09-28',length:7,timeZone:'UTC',sourceId:foreignObservation})).status,400);
    }
    assert.equal((await b.get('/api/admin/users')).status,403);assert.equal((await b.post('/api/admin/users/'+aId,{status:'SUSPENDED'})).status,403);assert.equal((await b.post('/api/observations/import',{observations:[legacy]})).status,403);
    await ok(b.post('/api/settings',{intervalMs:60000,saveSnapshots:true}));assert.deepEqual(await ok(a.get('/api/settings')),{intervalMs:30000,saveSnapshots:false,smartSurv:true,detectionOnlyRotation:false});assert.equal((await ok(a.get('/api/monitoring/status'))).intervalMs,30000);assert.equal((await ok(b.get('/api/monitoring/status'))).intervalMs,60000);
    for(const [actor,label,foreignLabel] of [[a,'OWNER_SECRET_ALPHA','USER_B_SECRET_BRAVO'],[b,'USER_B_SECRET_BRAVO','OWNER_SECRET_ALPHA']]){
      const ask=await ok(actor.post('/api/ask-local',query()));assert.equal(ask.count,1);assert(JSON.stringify(ask).includes(label));assert(!JSON.stringify(ask).includes(foreignLabel));
      const report=buildReport(f.store.forUser(actor.state.user.id),{startDate:'2026-09-28',length:7,now:Date.parse('2026-10-04T18:00:00Z')});assert.equal(report.summary.total,1);assert(JSON.stringify(report).includes(label));assert(!JSON.stringify(report).includes(foreignLabel));
      const pdf=await actor.post('/api/reports/pdf',{startDate:'2026-09-28',length:7,timeZone:'UTC'});assert.equal(pdf.status,200);assert(pdf.data.subarray(0,5).equals(Buffer.from('%PDF-')));await writeFile(`.test-output/v09-user-${actor===a?'a':'b'}.pdf`,pdf.data);
    }
    assert.equal((await a.get('/api/snapshots/'+ref)).status,200);assert.equal((await b.get('/api/snapshots/'+br.snapshotRef)).status,200);assert.equal((await b.get('/api/snapshots/..%2Fdb.sqlite')).status,404);await ok(b.post('/api/monitoring/stop-all',{}));assert.equal((await ok(a.get('/api/monitoring/status'))).sessionId,aRun.sessionId);await ok(a.post('/api/monitoring/stop-all',{}));
  }finally{await f.close();}
});

test('Admin suspension revokes sessions and finalizes only the targeted user; restoration needs a fresh login',async()=>{
  const f=await fixture();try{const a=await owner(f),b=await client(f.origin);await ok(b.post('/api/auth/register',signup('suspend@example.test')));const camera=(await ok(b.post('/api/cameras',{name:'B',deviceId:'test-device'}))).camera,run=await ok(b.post('/api/monitoring/start',{cameraId:camera.id,cameraActive:true})),aRun=await ok(a.post('/api/monitoring/start',{cameraActive:true})),old=b.state.cookie;
    await ok(a.post('/api/admin/users/'+b.state.user.id,{status:'SUSPENDED'}));assert.equal((await b.get('/api/observations')).status,401);assert.equal(f.store.session(run.sessionId).end_reason,'account_suspended');assert.equal(f.store.session(aRun.sessionId).status,'active');const suspended=await client(f.origin);assert.equal((await suspended.post('/api/auth/login',{email:'suspend@example.test',password})).status,401);
    await ok(a.post('/api/admin/users/'+b.state.user.id,{status:'ACTIVE'}));assert.equal((await fetch(f.origin+'/api/observations',{headers:{Cookie:old}})).status,401);await ok(suspended.post('/api/auth/login',{email:'suspend@example.test',password}));assert.equal((await ok(suspended.get('/api/monitoring/status'))).monitoring,'off');assert.equal((await a.post('/api/admin/users/'+a.state.user.id,{status:'SUSPENDED'})).status,400);assert.equal((await a.post('/api/admin/users/'+b.state.user.id,{role:'ADMIN'})).status,400);
  }finally{await f.close();}
});

test('logout during a pending analysis finalizes once, invalidates auth, discards the result and leaves no extra snapshots',async()=>{
  let release,submitted;const started=new Promise(r=>submitted=r),waiting=new Promise(r=>release=r);let calls=0;
  const f=await fixture({detector:{async start(){},async inspect(){return {frameValid:true,personPresent:true};},close(){}},fetchImpl:async()=>{calls++;submitted();await waiting;return new Response(JSON.stringify({status:'completed',output:[{type:'message',content:[{type:'output_text',text:JSON.stringify(record('DISCARDED_RESULT'))}]}]}));}});
  try{const a=await owner(f);let finalizations=0;f.store.db.exec('CREATE TABLE finalizations(n INTEGER); CREATE TRIGGER count_final AFTER UPDATE OF status ON monitoring_sessions WHEN OLD.status=\'active\' AND NEW.status=\'completed\' BEGIN INSERT INTO finalizations VALUES(1); END');
    const run=await ok(a.post('/api/monitoring/start',{cameraActive:true})),gate=await ok(a.post('/api/monitoring/check',{sessionId:run.sessionId,cameraActive:true,image,timestamp:'2026-10-04T18:00:00Z'}));const pending=a.post('/api/automatic-analyze',{sessionId:run.sessionId,ticket:gate.ticket});await started;await ok(a.post('/api/auth/logout',{}));const ended=f.store.session(run.sessionId).ended_at;release();assert.equal((await pending).status,401);assert.equal((await a.post('/api/monitoring/stop',{sessionId:run.sessionId})).status,401);assert.equal(f.store.db.prepare('SELECT COUNT(*) n FROM finalizations').get().n,1);assert.equal(f.store.session(run.sessionId).ended_at,ended);assert.equal(f.store.session(run.sessionId).end_reason,'logout');assert.equal(f.store.observations().length,0);assert.deepEqual(await readdir(f.snapshots.directory).catch(()=>[]),[]);assert.equal(calls,1);
  }finally{release();await f.close();}
});

test('absolute and idle session expiry deny stale cookies; HTTPS configuration uses Secure host cookies',async()=>{
  let now=Date.now();const f=await fixture({authNow:()=>now});try{const a=await owner(f),old=a.state.cookie;now+=31*60000;assert.equal((await a.get('/api/settings')).status,401);const c=await client(f.origin);await ok(c.post('/api/auth/login',{email:signup().email,password}));now+=12*3600*1000+1;assert.equal((await c.get('/api/settings')).status,401);assert.equal((await fetch(f.origin+'/api/settings',{headers:{Cookie:old}})).status,401);
    const auth=new AuthService(f.store,{publicOrigin:'https://surv.example.test'}),headers={},req={headers:{host:'surv.example.test'},socket:{remoteAddress:'127.0.0.1'}},res={setHeader(key,value){headers[key]=value;}};auth.issue(req,res);assert.match(headers['Set-Cookie'],/^__Host-surv_session=.*; HttpOnly; SameSite=Lax; Path=\/; Max-Age=1200; Secure$/);assert.throws(()=>auth.requestOrigin({...req,headers:{host:'attacker.test'}}),/configured Surv-AI origin/);
  }finally{await f.close();}
});

test('persistent login rate limiting blocks password guessing without disclosing account existence',async()=>{
  const f=await fixture();try{await owner(f);const c=await client(f.origin);for(let i=0;i<5;i++)assert.equal((await c.post('/api/auth/login',{email:'unknown@example.test',password})).status,401);assert.equal((await c.post('/api/auth/login',{email:'unknown@example.test',password})).status,429);const other=await client(f.origin);assert.equal((await other.post('/api/auth/login',{email:'unknown@example.test',password})).status,429);assert(f.store.db.prepare('SELECT COUNT(*) n FROM auth_throttle').get().n>0);assert(!JSON.stringify(f.store.db.prepare('SELECT * FROM auth_throttle').all()).includes('unknown@example.test'));
  }finally{await f.close();}
});
