import fixture from './auth-fixture.cjs';
export const {createTestServer,testFetch,authenticateTestContext,ownedFixtureStore,stripTestOwnership,registerTestOrigin}=fixture;
