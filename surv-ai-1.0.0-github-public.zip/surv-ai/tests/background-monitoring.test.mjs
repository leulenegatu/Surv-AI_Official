import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import vm from 'node:vm';
import {MonitoringPolicy} from '../src/monitoring.mjs';

const source=readFileSync(new URL('../dist/live-camera.js',import.meta.url),'utf8');
function fixture(intervalMs=15000){
  let now=Date.now(),serial=0,calls=0,stops=0,starts=0,opens=0,person=true,valid=true,release,startRelease,maxPending=0;
  const timers=new Map(),events=new Map(),policy=new MonitoringPolicy({now:()=>now});
  const track={readyState:'live',stop(){this.readyState='ended';}},video={readyState:4,videoWidth:640,videoHeight:480,srcObject:{}};
  const stream={getVideoTracks:()=>[track],getTracks:()=>[track]};
  const document={hidden:false,addEventListener:(name,fn)=>events.set(name,fn),getElementById:()=>video,querySelectorAll:()=>[]};
  class Clock extends Date{constructor(...args){super(...(args.length?args:[now]));}static now(){return now;}}
  const context=vm.createContext({document,window:{addEventListener:(name,fn)=>events.set(name,fn)},navigator:{sendBeacon(){stops++;policy.stop();},mediaDevices:{async getUserMedia(){opens++;return stream;}}},crypto:{randomUUID:()=> 'fixture-context'},Date:Clock,Blob,AbortSignal,console,location:{hash:'#live'},authState:{csrfToken:'fixture'},localData:{config:{intervalMs},cameras:[{id:'local-webcam',enabled:true,name:'Fixture'}]},overviewState:{},setTimeout:(fn,delay,...args)=>{const id=++serial;timers.set(id,{fn,args,at:now+delay});maxPending=Math.max(maxPending,timers.size);return id;},clearTimeout:id=>timers.delete(id),setInterval:()=>1,clearInterval(){},updateGlobalMonitoring(){},refreshAppData(){},render(){},makeObservationRecord:x=>x,rememberObservation(){},invalidateLocalSummaries(){},userClockTime:x=>x});
  vm.runInContext(source,context);
  vm.runInContext(readFileSync(new URL('../dist/camera-recovery.js',import.meta.url),'utf8'),context);
  const state=vm.runInContext('cameraRuntime()',context);Object.assign(state,{stream,video,cameraActive:true});
  context.cameraReady=()=>state.cameraActive&&track.readyState==='live';context.refreshCameraViews=()=>{};
  context.captureLiveFrame=()=>valid?{image:'fixture-image',timestamp:new Clock().toISOString()}:null;
  context.cameraApi=async(route,input)=>{
    if(route.endsWith('/start')){starts++;if(startRelease)await new Promise(r=>startRelease=r);const s=policy.start({intervalMs});return {sessionId:s.id,intervalMs,telemetry:s.telemetry,nextEligibleMs:0};}
    if(route.endsWith('/stop')){stops++;policy.stop(input.sessionId);return {};}
    if(route.endsWith('/telemetry'))return {};
    if(route==='/api/detection/check')return {frameValid:true,personPresent:person};
    if(route.endsWith('/check'))return policy.checked(policy.get(input.sessionId),{frameValid:true,personPresent:person},input,state.analysisInFlight);
    if(route==='/api/automatic-analyze'){const {session}=policy.consume(input.sessionId,input.ticket,false);calls++;session.telemetry.requests++;session.telemetry.lastRequest=new Clock().toISOString();if(release)await new Promise(r=>release=r);session.telemetry.successes++;return {observation:{id:'record-'+calls,source:'automatic_ai'},telemetry:session.telemetry,lastRequestAt:new Clock().toISOString()};}
    throw Error(route);
  };
  const flush=async()=>{for(let i=0;i<12;i++)await Promise.resolve();};
  return {context,state,track,events,policy,get calls(){return calls;},get stops(){return stops;},get starts(){return starts;},get opens(){return opens;},get maxPending(){return maxPending;},get pending(){return timers.size;},set person(v){person=v;},set valid(v){valid=v;},hold(){release=true;},resume(){const fn=release;release=null;if(typeof fn==='function')fn();},holdStart(){startRelease=true;},resumeStart(){const fn=startRelease;startRelease=null;fn();},async hidden(value){document.hidden=value;events.get('visibilitychange')?.();await flush();},async start(){await context.startAutoMonitoring();await flush();},async tick(ms=1000){now+=ms;const due=[...timers].filter(([,t])=>t.at<=now);for(const [id,t]of due){timers.delete(id);await t.fn(...t.args);}await flush();},flush};
}
for(const interval of [15000,30000,60000])test(`hidden monitoring preserves ${interval/1000}s minimum, one scheduler/session and no backlog`,async()=>{
  const f=fixture(interval);await f.start();const id=f.state.sessionId;await f.tick(0);assert.equal(f.calls,1);
  await f.hidden(true);assert.equal(f.state.autoMonitoring,true);
  for(let i=0;i<4;i++){await f.tick(interval);assert.equal(f.calls,i+2);assert.equal(f.state.sessionId,id);}
  await f.hidden(false);await f.tick(0);assert.equal(f.calls,5);
  for(let i=0;i<3;i++){await f.hidden(true);await f.hidden(false);await f.tick(1000);}
  await f.tick(300000);assert.equal(f.calls,6,'a delayed check submits only the current frame');await f.tick(1000);assert.equal(f.calls,6);
  f.person=false;await f.tick(interval);assert.equal(f.calls,6);f.person=true;f.valid=false;await f.tick(interval);assert.equal(f.calls,6);
  f.valid=true;await f.tick(1000);assert.equal(f.calls,7);
  assert.equal(f.starts,1);assert.equal(f.maxPending,1);assert.equal(f.opens,0);await f.hidden(true);await f.context.stopAutoMonitoring();await f.context.stopAutoMonitoring();await f.tick(300000);await f.hidden(false);
  assert.equal(f.calls,7);assert.equal(f.stops,1);assert.equal(f.pending,1,'local preview detection continues with Auto OFF');assert.equal(f.state.autoMonitoring,false);await f.tick(300000);assert.equal(f.calls,7);
});
test('an explicitly requested start completing while hidden retains its single session',async()=>{
  const f=fixture();f.holdStart();const start=f.context.startAutoMonitoring();await f.flush();await f.hidden(true);f.resumeStart();await start;await f.tick(0);assert.equal(f.calls,1);assert.equal(f.starts,1);assert.equal(f.stops,0);assert.equal(f.pending,1);await f.context.stopAutoMonitoring();
});
test('hidden checks retain shared request locking and explicit camera disable finalizes once',async()=>{
  const f=fixture();f.hold();await f.start();await f.tick(0);assert.equal(f.calls,1);await f.hidden(true);for(let i=0;i<3;i++)await f.tick(60000);assert.equal(f.calls,1);assert.equal(f.state.analysisInFlight,true);
  await f.context.disableLiveCamera();assert.equal(f.track.readyState,'ended');assert.equal(f.stops,1);f.resume();await f.flush();await f.hidden(false);await f.tick(300000);assert.equal(f.calls,1);assert.equal(f.state.autoMonitoring,false);assert.equal(f.pending,0);
});
test('actual pagehide releases hidden capture and finalizes once without resurrection',async()=>{
  const f=fixture();await f.start();await f.tick(0);await f.hidden(true);f.events.get('pagehide')();f.events.get('pagehide')();await f.hidden(false);await f.tick(60000);assert.equal(f.calls,1);assert.equal(f.stops,1);assert.equal(f.track.readyState,'ended');assert.equal(f.state.autoMonitoring,false);assert.equal(f.pending,0);
});
