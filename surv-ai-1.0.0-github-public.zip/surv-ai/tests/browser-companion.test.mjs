import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import net from 'node:net';
import {desktopFixture,client,enable,start,automatic,ok,password} from './desktop-fixture.mjs';
import {browserPeer} from './browser-peer.mjs';
import {EXTENSION_ID,EXTENSION_ORIGIN,normalizeHostname,validateBrowserSample,credentialOwner} from '../src/browser-companion-store.mjs';
import {desktopSpans,desktopAggregate} from '../src/desktop-store.mjs';
import {desktopExplorer} from '../src/desktop-explorer.mjs';
import {tabMetadata} from '../browser-companion/metadata.js';
import {buildReport} from '../src/report.mjs';
const pair=async(f,c)=>{await ok(c.post('/api/settings/browser',{enabled:true,browser:'chrome'}));const challenge=await ok(c.post('/api/settings/browser/pair',{}));const res=await fetch(f.origin+'/browser-companion/pair',{method:'POST',headers:{Origin:EXTENSION_ORIGIN,'Content-Type':'application/json'},body:JSON.stringify({code:challenge.code})});assert.equal(res.status,200);return {...await res.json(),code:challenge.code};};
const explorer=(s,extra={})=>desktopExplorer(s,{from:'2026-10-06',to:'2026-10-06',timeZone:'UTC',...extra});

test('private MV3 structure, stable ID, minimal permissions, no incognito or remote hosts',async()=>{
  const m=JSON.parse(await readFile(new URL('../browser-companion/manifest.json',import.meta.url),'utf8'));
  assert.equal(m.manifest_version,3);assert.equal(m.incognito,'not_allowed');assert.deepEqual(m.permissions,['tabs','storage','alarms']);assert.deepEqual(m.host_permissions,['http://127.0.0.1/*']);assert.equal(m.content_scripts,undefined);assert.equal(m.externally_connectable,undefined);
  const id=[...createHash('sha256').update(Buffer.from(m.key,'base64')).digest().subarray(0,16)].map(x=>String.fromCharCode(97+(x>>4),97+(x&15))).join('');assert.equal(id,EXTENSION_ID);
  for(const file of [m.background.service_worker,m.action.default_popup,'metadata.js','popup.js','popup.css'])assert((await readFile(new URL('../browser-companion/'+file,import.meta.url))).length>0);
});
test('reduce only HTTP(S) active-tab URLs to normalized hosts; preserve hostile raw Unicode titles safely',()=>{
  const title='雪 🎧 <img src=x onerror=alert(1)> \u202e';
  assert.deepEqual(tabMetadata({active:true,url:'https://WWW.Example.CO.UK/private/path?secret=1#fragment',title},true),{hostname:'www.example.co.uk',title});
  assert.equal(tabMetadata({active:true,url:'https://youtube.com/watch?v=secret',title},false).title,null);
  for(const url of ['file:///private','chrome://settings','chrome-extension://abc/popup.html','javascript:alert(1)','data:text/html,secret','https://user:password@example.com/private'])assert.deepEqual(tabMetadata({active:true,url,title},true),{hostname:null,title:null});
  assert.equal(tabMetadata({active:true,incognito:true,url:'https://youtube.com',title},true).hostname,null);
  assert.equal(tabMetadata({active:false,url:'https://youtube.com',title},true).hostname,null);
  const longTitle='Exact raw 雪 '.repeat(50);assert.equal(tabMetadata({active:true,url:'https://youtube.com',title:longTitle},true).title,longTitle);
  assert.equal(tabMetadata({active:true,url:'https://youtube.com',title:'x'.repeat(1025)},true).title,null);
  assert.equal(tabMetadata({active:true,url:'https://youtube.com',title:'control\u0000title'},true).title,null);
  for(const value of ['https://example.com/a','example.com/path','example.com?x=1','user@example.com','example.com:443','a..com','x'.repeat(254)])assert.equal(normalizeHostname(value),null);
  const v={type:'sample',requestId:'abc',sequence:1,timestamp:1000,focused:true,hostname:'youtube.com',title:null};
  assert.deepEqual(validateBrowserSample(v,{includeTitle:false,now:1000}),{hostname:'youtube.com',tabTitle:null});
  for(const change of [{title:'secret'},{hostname:'https://youtube.com'},{fullUrl:'https://youtube.com/private'},{timestamp:-31000},{sequence:0},{focused:false}])assert.throws(()=>validateBrowserSample({...v,...change},{includeTitle:false,now:1000}));
  assert.equal(validateBrowserSample({...v,title:longTitle},{includeTitle:true,now:1000}).tabTitle,longTitle);
  assert.throws(()=>validateBrowserSample({...v,title:'x'.repeat(1025)},{includeTitle:true,now:1000}));
});
test('pairing is explicit, owner scoped, single-use, expiring; origin, CSRF and credentials remain distinct',async()=>{
  const f=await desktopFixture();try{
    const a=await client(f,{owner:true}),b=await client(f,{email:'other-browser@example.test'});
    assert.equal((await a.get('/api/settings/browser')).data.enabled,false);assert.equal(f.store.db.prepare("SELECT name FROM sqlite_master WHERE name='browser_pairings'").get(),undefined);
    assert.equal((await a.post('/api/settings/browser',{enabled:true,browser:'chrome'})).status,400);
    await enable(a);const pairing=await pair(f,a);assert.equal(credentialOwner(f.store,pairing.token),a.state.user.id);const mine=(await a.get('/api/settings/browser')).data,other=(await b.get('/api/settings/browser')).data;assert.equal(other.paired,false);
    assert.equal(pairing.installation,mine.installation);assert.match(mine.installation,/^Surv-AI local · installation [a-f0-9]{8} · account [a-f0-9]{8}$/);assert.notEqual(mine.installation,other.installation);assert(!mine.installation.includes(a.state.user.id));assert(!mine.installation.includes(pairing.token));
    for(const origin of [undefined,'http://evil.test','http://127.0.0.1:4173','chrome-extension://aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa']){const res=await fetch(f.origin+'/browser-companion/pair',{method:'POST',headers:{'Content-Type':'application/json',...(origin?{Origin:origin}:{})},body:JSON.stringify({code:pairing.code})});assert.equal(res.status,403);}
    assert.equal((await fetch(f.origin+'/browser-companion/pair',{method:'POST',headers:{Origin:EXTENSION_ORIGIN,'Content-Type':'application/json'},body:JSON.stringify({code:pairing.code})})).status,403);
    const challenge=await ok(a.post('/api/settings/browser/pair',{}));f.now+=120001;
    assert.equal((await fetch(f.origin+'/browser-companion/pair',{method:'POST',headers:{Origin:EXTENSION_ORIGIN,'Content-Type':'application/json'},body:JSON.stringify({code:challenge.code})})).status,403);
    assert.equal((await b.post('/api/settings/browser/revoke',{userId:a.state.user.id})).status,400);
    const noCsrf=await fetch(f.origin+'/api/settings/browser/pair',{method:'POST',headers:{Cookie:a.state.cookie,'Content-Type':'application/json'},body:'{}'});assert.equal(noCsrf.status,403);
    await ok(a.post('/api/settings/browser/revoke',{}));assert.equal(credentialOwner(f.store,pairing.token),null);
  }finally{await f.close();}
});
test('Chrome → VS Code → Chrome: fresh browser evidence only, background audio excluded, same session and requests',async()=>{
  const f=await desktopFixture();try{
    const a=await client(f,{owner:true});await enable(a,'local-webcam',true);const pairing=await pair(f,a),peer=await browserPeer(f,pairing.token);
    f.collector.raw={executable:'chrome.exe',title:'Synthetic tab - Google Chrome',state:'active',idleMs:100};const id=await start(f,a),s=f.store.forUser(a.state.user.id);
    await f.tick(a,id);await f.tick(a,id);assert.equal(f.server.desktop.context(f.server.desktop.entries.get(id).session,new Date(f.now).toISOString()).hostname,'youtube.com');
    const observation=(await automatic(f,a,id)).observation;assert.equal(observation.desktopContext.hostname,'youtube.com');assert.match(f.requests[0].input[0].content[0].text,/youtube.com/);assert.equal(f.calls,1);
    // Domain change even with identical Windows caption creates a boundary.
    peer.hostname='grammarly.com';await f.tick(a,id);peer.title='Journal';f.collector.raw.title='Journal - Google Chrome';await f.tick(a,id);
    f.collector.raw={executable:'Code.exe',title:'server.mjs — Surv-AI',state:'active',idleMs:100};const requests=peer.received.filter(v=>v.type==='sample').length;await f.tick(a,id);await f.tick(a,id);assert.equal(peer.received.filter(v=>v.type==='sample').length,requests);
    f.collector.raw={executable:'chrome.exe',title:'Journal - Google Chrome',state:'idle',idleMs:300001};peer.focused=false;await f.tick(a,id);await f.tick(a,id);peer.focused=true;await f.tick(a,id);await f.tick(a,id);
    await ok(a.post('/api/monitoring/stop',{sessionId:id}));const rows=desktopSpans(s),total=desktopAggregate(s,null).totalMs;
    assert(rows.some(r=>r.executable==='Code.exe'&&!r.hostname));assert(rows.some(r=>r.executable==='chrome.exe'&&!r.hostname));assert.equal(total,20000);
    const apps=explorer(s),chrome=apps.items.find(v=>v.key==='chrome.exe');assert.equal(chrome.ms,16000);const domains=explorer(s,{level:'domains',application:'chrome.exe'});assert.equal(domains.items.reduce((n,v)=>n+v.ms,0),chrome.ms);assert.equal(domains.unattributedMs,4000);assert.equal(f.calls,1);assert.equal(f.server.desktop.timer,null);peer.close();
  }finally{await f.close();}
});
test('stale/replayed/unsolicited samples close the channel; missed samples use Windows fallback; reconnect replaces once',async()=>{
  const f=await desktopFixture();try{
    const a=await client(f,{owner:true});await enable(a);const pairing=await pair(f,a);await assert.rejects(browserPeer(f,pairing.token,{origin:'http://evil.test'}));
    let peer=await browserPeer(f,pairing.token,{auto:false});f.collector.raw={executable:'chrome.exe',title:'Caption',state:'active',idleMs:0};const id=await start(f,a);assert(!f.server.desktop.entries.get(id).last.hostname);
    const request=peer.received.find(v=>v.type==='sample');peer.respond(request,{timestamp:f.now-31000});await new Promise(r=>setTimeout(r,20));assert.equal(f.server.browser.clients.size,0);
    peer=await browserPeer(f,pairing.token);await f.tick(a,id);assert.equal(f.server.desktop.entries.get(id).last.hostname,'youtube.com');
    const replacement=await browserPeer(f,pairing.token);await new Promise(r=>setTimeout(r,20));assert.equal(peer.closed,true);assert.equal(f.server.browser.clients.size,1);replacement.send({type:'sample',requestId:'unsolicited',sequence:1,timestamp:f.now,focused:true,hostname:'youtube.com',title:null});await new Promise(r=>setTimeout(r,20));assert.equal(f.server.browser.clients.size,0);await f.tick(a,id);assert(!f.server.desktop.entries.get(id).last.hostname);
    f.now+=10000;await f.tick(a,id,10000);assert.equal(f.calls,0);
  }finally{await f.close();}
});
test('title opt-out hides saved titles from history/explorer/export/report; browser and desktop OFF stop enrichment',async()=>{
  const f=await desktopFixture();try{
    const a=await client(f,{owner:true});await enable(a,'local-webcam',true);const pairing=await pair(f,a),peer=await browserPeer(f,pairing.token);peer.title='private 雪 <img src=x>';f.collector.raw={executable:'chrome.exe',title:peer.title+' - Google Chrome',state:'active',idleMs:0};const id=await start(f,a),s=f.store.forUser(a.state.user.id);await f.tick(a,id);const record=(await automatic(f,a,id)).observation;assert.equal(record.desktopContext.tabTitle,peer.title);
    await enable(a,'local-webcam',false);assert.equal(s.getObservation(record.id).desktopContext.title,null);assert.equal(s.getObservation(record.id).desktopContext.tabTitle,null);assert(!JSON.stringify(explorer(s,{level:'titles',application:'chrome.exe',hostname:'youtube.com'})).includes('private'));
    assert(!JSON.stringify(desktopSpans(s)).includes('private'));const report=buildReport(s,{startDate:'2026-10-01',length:7,timeZone:'UTC',now:f.now+86400000});assert(!JSON.stringify(report).includes('private'));
    const next=await browserPeer(f,pairing.token);await f.tick(a,id);assert.equal(f.server.desktop.entries.get(id).last.tabTitle,null);
    await ok(a.post('/api/settings/browser',{enabled:false,browser:'chrome'}));await f.tick(a,id);assert(!f.server.desktop.entries.get(id).last.hostname);assert.equal((await ok(a.get('/api/monitoring/status'))).desktop[0].sessionId,id);assert.equal(f.server.desktop.entries.size,1);
    await enable(a,'local-webcam',false);await ok(a.post('/api/settings/browser',{enabled:true,browser:'chrome'}));await browserPeer(f,pairing.token);await ok(a.post('/api/settings/desktop',{enabled:false,includeTitle:false,cameraId:'local-webcam'}));assert.equal(f.server.desktop.entries.size,0);assert.equal(f.calls,1);next.close();
  }finally{await f.close();}
});
test('credentials survive host restart, metadata does not; camera never restarts silently',async()=>{
  const f=await desktopFixture();try{
    let a=await client(f,{owner:true});await enable(a);const pairing=await pair(f,a);await browserPeer(f,pairing.token);await start(f,a);await f.restart();assert.equal(f.server.desktop.entries.size,0);assert.equal(f.server.desktop.timer,null);assert.equal(f.server.browser.clients.size,0);
    a=await client(f,{register:false});assert.equal((await a.get('/api/settings/browser')).data.paired,true);await browserPeer(f,pairing.token);assert.equal(f.server.browser.clients.size,1);assert.equal(f.server.desktop.entries.size,0);assert.equal(f.calls,0);
  }finally{await f.close();}
});
test('title consent changed during one eligible AI request prevents returning or persisting newly unauthorized titles',async()=>{
  const f=await desktopFixture();try{
    const a=await client(f,{owner:true});await enable(a,'local-webcam',true);const pairing=await pair(f,a);await browserPeer(f,pairing.token);f.collector.raw={executable:'chrome.exe',title:'Synthetic tab - Google Chrome',state:'active',idleMs:0};const id=await start(f,a);let release;f.providerHold=new Promise(r=>release=r);
    const pending=automatic(f,a,id);while(!f.calls)await new Promise(r=>setImmediate(r));await enable(a,'local-webcam',false);release();const result=(await pending).observation;
    assert.equal(result.desktopContext.title,null);assert.equal(result.desktopContext.tabTitle,null);const saved=f.store.db.prepare('SELECT context_json FROM observation_desktop WHERE observation_id=?').get(result.id);assert(!saved.context_json.includes('Synthetic tab'));assert.equal(f.calls,1);
  }finally{await f.close();}
});
test('browser speculative TCP preconnections do not stall host shutdown or same-port restart',async()=>{
  const f=await desktopFixture();const sockets=[];
  try{const a=await client(f,{owner:true});await enable(a);await start(f,a);f.port=Number(new URL(f.origin).port);
    for(let i=0;i<2;i++){const socket=net.createConnection({host:'127.0.0.1',port:f.port});socket.on('error',()=>{});await new Promise(r=>socket.once('connect',r));sockets.push(socket);}
    await Promise.race([f.restart(),new Promise((_,reject)=>{const timer=setTimeout(()=>reject(Error('Shutdown stalled on unused TCP sockets')),2000);timer.unref();})]);assert.equal(f.server.desktop.entries.size,0);assert.equal(f.server.browser.clients.size,0);assert.equal(f.calls,0);
  }finally{for(const socket of sockets)socket.destroy();await f.close();}
});
