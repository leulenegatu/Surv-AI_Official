// Existing regressions now authenticate through the real public endpoints.
// This helper refuses production databases and never changes server auth policy.
const path=require('node:path'),os=require('node:os'),assert=require('node:assert/strict');
const nativeFetch=globalThis.fetch.bind(globalThis),origins=new Map();
const credentials={displayName:'Regression Fixture',email:'regression@example.test',password:'fixture only passphrase 2026',confirmPassword:'fixture only passphrase 2026'};
function temporary(filename){if(filename===':memory:'||filename==='')return true;const relative=path.relative(os.tmpdir(),path.resolve(filename));return relative!==''&&!relative.startsWith('..')&&!path.isAbsolute(relative);}
function registerTestOrigin(origin){assert.match(origin,/^http:\/\/127\.0\.0\.1:\d+$/);assert.notEqual(new URL(origin).port,'4173','Never claim the real local installation');origins.set(origin,{cookie:'',csrf:'',ready:null});}
function createTestServer(options){
  const filename=options.storage?.db.prepare('PRAGMA database_list').get().file??options.databasePath;
  assert(filename!==undefined&&temporary(filename),'Regression servers must use isolated temporary or in-memory databases');
  const server=require('../server.mjs').createServer(options);
  server.on('listening',()=>registerTestOrigin(`http://127.0.0.1:${server.address().port}`));return server;
}
async function ensure(origin){
  const entry=origins.get(origin);assert(entry,'Unregistered fixture origin');if(entry.ready)return entry.ready;
  entry.ready=(async()=>{let response=await nativeFetch(origin+'/api/auth/me');let data=await response.json();assert.equal(response.status,200,JSON.stringify(data));entry.cookie=response.headers.get('set-cookie').split(';')[0];entry.csrf=data.csrfToken;
    response=await nativeFetch(origin+(data.ownerSetup?'/api/auth/owner':'/api/auth/login'),{method:'POST',headers:{'Content-Type':'application/json',Cookie:entry.cookie,'X-Surv-CSRF':entry.csrf},body:JSON.stringify(data.ownerSetup?credentials:{email:credentials.email,password:credentials.password})});data=await response.json();assert.equal(response.status,200,JSON.stringify(data));entry.cookie=response.headers.get('set-cookie').split(';')[0];entry.csrf=data.csrfToken;entry.user=data.user;
    // Existing feature regressions start from a configured test installation.
    // Complete the real new flow with AI deferred, leaving fixture settings intact.
    if(data.onboarding?.pending){for(const [route,body] of [4,5,6].map(step=>['/api/onboarding/progress',{step}]).concat([['/api/onboarding/complete',{}]])){const setup=await nativeFetch(origin+route,{method:'POST',headers:{'Content-Type':'application/json',Cookie:entry.cookie,'X-Surv-CSRF':entry.csrf},body:JSON.stringify(body)});assert.equal(setup.status,200);}}
    return entry;
  })();return entry.ready;
}
async function testFetch(input,init={}){
  const url=new URL(typeof input==='string'?input:input.url);if(!origins.has(url.origin))return nativeFetch(input,init);
  const entry=await ensure(url.origin),headers=new Headers(init.headers);headers.set('Cookie',entry.cookie);if(!['GET','HEAD'].includes((init.method||'GET').toUpperCase()))headers.set('X-Surv-CSRF',entry.csrf);return nativeFetch(input,{...init,headers});
}
async function authenticateTestContext(context,origin){const entry=await ensure(origin);await context.addCookies([{name:'surv_session',value:entry.cookie.slice(entry.cookie.indexOf('=')+1),url:origin,httpOnly:true,sameSite:'Lax'}]);return entry.user;}
async function completeTestOnboarding(page){assert.notEqual(new URL(page.url()).port,'4173','Never complete setup on the actual installation');await page.waitForFunction(()=>authState.ready);await page.evaluate(async()=>{if(!authState.onboarding?.pending)return;for(const step of [4,5,6])await historyApi('/api/onboarding/progress',{step});await historyApi('/api/onboarding/complete',{});location.hash='overview';});await page.reload();await page.waitForFunction(()=>authState.ready);}
function ownedFixtureStore(store){const id=store.db.prepare('SELECT owner_user_id FROM installation').get().owner_user_id;assert(id,'Authenticate the fixture before seeding owned data');return store.forUser(id);}
function stripTestOwnership(store){
  assert.equal(store.db.prepare('SELECT COUNT(*) n FROM users').get().n,0);
  // Produce a genuine pre-account schema for old migration regression fixtures.
  store.db.exec('DROP TABLE installation; DROP TABLE auth_sessions; DROP TABLE auth_identities; DROP TABLE auth_throttle;');
  const indexes=store.db.prepare("SELECT name FROM sqlite_master WHERE type='index' AND sql LIKE '%user_id%'").all();for(const row of indexes)store.db.exec(`DROP INDEX "${row.name}"`);
  for(const table of ['observations','monitoring_sessions','cameras','app_settings'])store.db.exec(`ALTER TABLE ${table} DROP COLUMN user_id`);
  store.db.exec('DROP TABLE users; CREATE UNIQUE INDEX cameras_device ON cameras(device_id) WHERE device_id IS NOT NULL AND deleted_at IS NULL; PRAGMA user_version=4;');
}
module.exports={createTestServer,testFetch,authenticateTestContext,ownedFixtureStore,stripTestOwnership,registerTestOrigin,completeTestOnboarding};
