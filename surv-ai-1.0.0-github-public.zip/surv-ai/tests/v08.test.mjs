import {test} from 'node:test';
import assert from 'node:assert/strict';
import {randomUUID} from 'node:crypto';
import {readFile,mkdir,writeFile,mkdtemp,rm} from 'node:fs/promises';
import vm from 'node:vm';
import os from 'node:os';
import path from 'node:path';
import {LocalStorage} from '../src/storage.mjs';
import {executeSQLQuery} from '../src/local-query.mjs';
import {queryScope} from '../src/query-scope.mjs';
import {calendar,dayBounds,mondayOf,addDays} from '../src/local-calendar.mjs';
import {buildReport} from '../src/report.mjs';
import {renderReportPDF} from '../src/report-pdf.mjs';
import {SnapshotStore} from '../src/snapshot-store.mjs';
import {createTestServer as createServer,testFetch as fetch} from './auth-fixture.mjs';
const record=(timestamp='2026-10-02T18:00:00.000Z',extra={})=>({id:randomUUID(),timestamp,source:'manual_ai',activity:'Using computer',description:'A person is using a computer. A water bottle and food container are visible.',location:'Office',confidence:.9,objects:['water bottle','food container','keyboard'],...extra});
const opts={date:'2026-10-02',scope:'week',timeZone:'America/New_York'};
test('weekly Ask includes all seven local dates, day scope, composable filters and evidence pagination',()=>{
  const store=new LocalStorage(':memory:');try{
    const dates=Array.from({length:7},(_,i)=>addDays('2026-09-28',i));dates.forEach(date=>store.saveObservation(record(date+'T18:00:00.000Z',{cameraId:'local-webcam',cameraName:'Office'})));store.saveObservation(record('2026-10-05T04:00:00.000Z'));store.saveObservation(record('2026-09-28T03:59:59.999Z'));
    const before=JSON.stringify(store.observations()),ask=q=>executeSQLQuery(store,q,opts);
    for(const q of ['What did I do this week?','What activities were observed this week?','What objects were seen this week?','How many observations were recorded this week?','What was observed in the Office this week?'])assert.equal(ask(q).count,7,q);
    const days=ask('Which days had computer activity?');assert.equal(days.kind,'days');assert.equal(days.byDay.length,7);assert(days.byDay.every(d=>d.count===1));assert.equal(days.evidence.length,6);assert.equal(executeSQLQuery(store,days.question,opts,{offset:6}).evidence.length,1);
    assert.equal(executeSQLQuery(store,'What did I do?',{...opts,scope:'day'}).count,1);assert.equal(ask('What happened Friday?').count,1);assert.equal(ask('What did I do on October 2?').date,'2026-10-02');assert.equal(ask('What did I do on 2026-10-04?').count,1);
    assert.equal(ask('What happened Friday this week?').count,1);assert.equal(ask('What happened on 2026-10-02 and 2026-10-04?').understood,false);
    assert.equal(ask('When was I first observed each day?').kind,'daily-first');assert(ask('When was I last observed each day?').byDay.every(d=>d.observation));assert.equal(ask('Which day had the most observations?').kind,'busiest-day');
    assert.equal(ask('How many observations with a water bottle while at my desk in Office after 1 PM this week?').count,7);
    assert.equal(ask('Which days had drinking evidence?').count,0);assert.equal(ask('Which days had eating evidence?').count,0);assert(ask('Which days had drinking evidence?').byDay.every(d=>d.count===0));assert.equal(JSON.stringify(store.observations()),before);
  }finally{store.close();}
});
test('weekly Ask explicit actions do not come from objects, user context, negative or noun phrases',()=>{
  const store=new LocalStorage(':memory:');try{
    store.saveObservation(record(undefined,{context:'I drank and ate',description:'A bottle of drinking water is visible. The person is not drinking or eating.'}));
    store.saveObservation(record('2026-10-01T18:00:00Z',{activity:'Drinking',description:'A person is sipping from a mug.'}));
    store.saveObservation(record('2026-10-03T18:00:00Z',{activity:'Eating',description:'A person is taking a bite of food.'}));
    const drink=executeSQLQuery(store,'Which days had drinking evidence?',opts),eat=executeSQLQuery(store,'Which days had eating evidence?',opts);
    assert.equal(drink.count,1);assert.equal(drink.byDay.find(d=>d.count).date,'2026-10-01');assert.equal(eat.count,1);assert.equal(eat.byDay.find(d=>d.count).date,'2026-10-03');
    for(const q of ['Why was I sad this week?','Was I depressed this week?','How long was I working this week?','What did I do last week?','Which days had unicorn activity?','What happened on October 8?'])assert.equal(executeSQLQuery(store,q,opts).understood,false,q);
  }finally{store.close();}
});
test('Ask week/day boundaries handle month/year, DST and positive/negative timezone offsets',()=>{
  for(const [date,timeZone] of [['2027-01-01','UTC'],['2026-03-08','America/New_York'],['2026-11-01','America/New_York'],['2026-10-04','Asia/Kathmandu'],['2026-10-04','Pacific/Honolulu']]){
    const store=new LocalStorage(':memory:');try{
      const from=mondayOf(date),to=addDays(from,6),start=dayBounds(from,timeZone).from,end=dayBounds(to,timeZone).to;
      [new Date(Date.parse(start)-1).toISOString(),start,new Date(Date.parse(end)-1).toISOString(),end].forEach(t=>store.saveObservation(record(t)));
      const r=executeSQLQuery(store,'How many observations this week?',{date,timeZone,scope:'week'});assert.equal(r.count,2);assert.equal(r.from,from);assert.equal(r.to,to);assert.equal(r.byDay.length,7);
      if(date==='2027-01-01'){const named=executeSQLQuery(store,'What did I do on January 3?',{date:'2026-12-30',scope:'week',timeZone});assert.equal(named.date,'2027-01-03');assert(named.understood);}
    }finally{store.close();}
  }
  assert.throws(()=>queryScope('What did I do?',{date:'2026-10-02',scope:'year',timeZone:'UTC'}));
});
test('per-day first/last and most-observed results preserve exact source IDs and honest zero days',()=>{
  const store=new LocalStorage(':memory:');try{
    const first=record('2026-10-02T04:00:00.000Z'),last=record('2026-10-03T03:59:59.125Z');[first,last,record('2026-10-01T20:00:00Z')].forEach(r=>store.saveObservation(r));
    const earliest=executeSQLQuery(store,'When was I first observed each day?',opts),latest=executeSQLQuery(store,'When was I last observed each day?',opts);
    assert.equal(earliest.byDay.find(d=>d.date==='2026-10-02').observation.id,first.id);assert.equal(latest.byDay.find(d=>d.date==='2026-10-02').observation.id,last.id);assert.equal(earliest.byDay[0].observation,null);
    const most=executeSQLQuery(store,'Which day had the most observations?',opts);assert.equal(most.byDay.find(d=>d.date==='2026-10-02').count,2);
  }finally{store.close();}
});
test('noteworthy evidence preserves raw records, ignores object/context/negation, and never fills a quota',()=>{
  const store=new LocalStorage(':memory:'),now=Date.parse('2026-10-10T12:00:00Z');try{
    const normal=record(undefined,{objects:['crying face picture'],context:'I am distressed',description:'The person is not crying or visibly distressed.'});store.saveObservation(normal);
    assert.equal(buildReport(store,{startDate:'2026-09-28',length:7,now}).noteworthy.length,0);
    store.saveObservation(record(undefined,{activity:'Crying face portrait',description:'The person is viewing a painting of a tearful face.'}));
    store.saveObservation(record(undefined,{activity:'Possibly tired',description:'The person might be tired.'}));
    assert.equal(buildReport(store,{startDate:'2026-09-28',length:7,now}).noteworthy.length,0);
    const upset=record('2026-10-02T22:42:06.125Z',{activity:'Using computer with visible signs of emotional distress',description:'The person appears visibly distressed at the computer.'});store.saveObservation(upset);
    const before=JSON.stringify(store.observations()),report=buildReport(store,{startDate:'2026-09-28',length:7,timeZone:'America/New_York',now});
    assert.equal(report.noteworthy.length,1);const e=report.noteworthy[0];assert.equal(e.id,upset.id);assert.equal(e.activity,upset.activity);assert.equal(e.description,upset.description);assert.equal(e.timestamp,upset.timestamp);assert.match(e.time,/6:42:06\.125 PM EDT/);assert.match(e.reason,/explicitly recorded/);assert.match(e.reason,/not.*diagnosis/);assert(!/indicates|depressed|anxiety|insomnia/.test(e.reason));assert.equal(JSON.stringify(store.observations()),before);
  }finally{store.close();}
});
test('long noteworthy source metadata remains exportable with labelled excerpts and exact wording',async()=>{
  const store=new LocalStorage(':memory:');try{
    const r=record(undefined,{activity:'Tired',description:'A person is sitting. '.repeat(45)+'The person is unusually tired, crying and visibly distressed.',location:'Recorded location '.repeat(6).trim(),cameraId:'local-webcam',cameraName:'Recorded camera '.repeat(4).trim(),objects:Array.from({length:8},(_,i)=>`Object ${i} `+'retained context '.repeat(4))});store.saveObservation(r);
    const report=buildReport(store,{startDate:'2026-09-28',length:7,now:Date.parse('2026-10-10T00:00:00Z')});assert.equal(report.noteworthy[0].description,r.description);assert(report.noteworthy[0].evidenceQuote);assert(report.noteworthy[0].signals.includes('affect:explicit tiredness'));
    const pdf=await renderReportPDF(report);assert(pdf.subarray(0,5).equals(Buffer.from('%PDF-')));await mkdir('.test-output',{recursive:true});await writeFile('.test-output/v08-long-noteworthy.pdf',pdf);
  }finally{store.close();}
});
test('rare activity/time/context must differ from a supported dominant pattern and selection stays bounded',()=>{
  const store=new LocalStorage(':memory:'),now=Date.parse('2026-11-10T12:00:00Z');try{
    for(let i=0;i<25;i++)store.saveObservation(record(`2026-10-${String(1+i%5).padStart(2,'0')}T18:00:00Z`));
    const rare=record('2026-10-03T02:30:00Z',{activity:'Reading',description:'A person is reading a book.'});store.saveObservation(rare);
    let report=buildReport(store,{startDate:'2026-10-01',length:7,now});assert(report.noteworthy.some(r=>r.id===rare.id&&r.reason.includes('dominant')));assert(report.noteworthy.some(r=>r.id===rare.id&&r.signals.some(s=>s.startsWith('time:'))));
    for(let i=0;i<20;i++)store.saveObservation(record(`2026-10-0${1+i%6}T19:00:00Z`,{activity:['Crying','Visibly upset','Agitated','Visibly tired'][i%4],description:'The person is '+['crying','visibly distressed','agitated','visibly tired'][i%4]+'.'}));
    report=buildReport(store,{startDate:'2026-10-01',length:7,now});assert(report.noteworthy.length<=5);const long=buildReport(store,{startDate:'2026-10-01',length:30,now});assert(long.noteworthy.length<=8);assert.equal(new Set(long.noteworthy.map(r=>r.id)).size,long.noteworthy.length);
  }finally{store.close();}
});
test('AM/PM formatting handles midnight/noon/evening, locale preference, timezone and exact source timestamps',async()=>{
  const context={Date,Intl};vm.createContext(context);vm.runInContext(await readFile(new URL('../dist/time-format.js',import.meta.url),'utf8'),context);
  const run=code=>vm.runInContext(code,context);
  for(const [value,expected] of [['00:19','12:19 AM'],['12:19','12:19 PM'],['14:00','2:00 PM'],['23:59','11:59 PM']]){assert.equal(run(`clockInputDisplay('${value}')`),expected);assert.equal(run(`clockInputValue('${expected}')`),value);}
  assert.equal(run("clockInputValue('13:00 PM')"),'');assert.equal(run("clockInputValue('12:30 AM')"),'00:30');
  assert.match(run("userClockTime('2026-10-02T18:00:00Z',{timeZone:'America/New_York',zone:true})"),/2:00 PM EDT/);
  assert.match(calendar('America/New_York').timeExact('2026-11-01T06:19:00Z'),/1:19:00 AM EST/);
  const store=new LocalStorage(':memory:');try{const r=record('2026-10-02T18:00:00.123Z');store.saveObservation(r);const before=JSON.stringify(store.observations());const report=buildReport(store,{startDate:'2026-09-28',length:7,now:Date.parse('2026-10-10T00:00:00Z')});assert.deepEqual(report.timeOfDay.map(t=>t.window),['12:00 AM – 5:59 AM','6:00 AM – 11:59 AM','12:00 PM – 5:59 PM','6:00 PM – 11:59 PM']);assert.equal(JSON.stringify(store.observations()),before);}finally{store.close();}
});
test('PDF reads bounded associated snapshots only and tolerates missing/corrupt or snapshotless evidence',async()=>{
  const store=new LocalStorage(':memory:'),now=Date.parse('2026-10-10T00:00:00Z');const png=Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+j1ioAAAAASUVORK5CYII=','base64');
  try{
    for(let i=0;i<6;i++)store.saveObservation(record(`2026-10-0${i+1}T22:42:00Z`,{activity:['Crying','Visibly upset','Agitated'][i%3],description:'A person is crying, agitated and visibly distressed.',snapshotRef:i<3?randomUUID()+'.png':null}));
    const report=buildReport(store,{startDate:'2026-09-28',length:7,now}),before=JSON.stringify(store.observations());let gets=0;
    const snapshots={async get(ref){gets++;if(ref===report.noteworthy[1]?.snapshotRef)throw Error('Image missing');return {data:png,type:'image/png'};}};
    const pdf=await renderReportPDF(report,{snapshots});assert(pdf.length>10000);assert(gets<=5);assert.equal(JSON.stringify(store.observations()),before);
    await mkdir('.test-output',{recursive:true});await writeFile('.test-output/v08-noteworthy.pdf',pdf);await writeFile('.test-output/v08-noteworthy.json',JSON.stringify(report));
    const corrupt=await renderReportPDF(report,{snapshots:{async get(){return {data:Buffer.from('corrupt'),type:'image/png'};}}});assert(corrupt.subarray(0,5).equals(Buffer.from('%PDF-')));
    const sparse=await renderReportPDF({...report,noteworthy:report.noteworthy.map(r=>({...r,snapshotRef:null}))},{snapshots:{get(){throw Error('Snapshotless evidence must not read images');}}});assert(sparse.length>10000);
  }finally{store.close();}
});
test('HTTP weekly Ask and noteworthy PDF remain local/read-only including Save snapshots OFF',async()=>{
  const dir=await mkdtemp(path.join(os.tmpdir(),'surv-v08-http-')),store=new LocalStorage(path.join(dir,'db.sqlite'));store.saveObservation(record(undefined,{activity:'Crying',description:'A person is crying.'}));store.setSaveSnapshots(false);let calls=0;
  const server=createServer({storage:store,snapshots:new SnapshotStore(path.join(dir,'snapshots')),apiKey:'test-only',fetchImpl(){calls++;throw Error('No AI request allowed');},detector:{close(){}}});await new Promise(r=>server.listen(0,'127.0.0.1',r));const origin=`http://127.0.0.1:${server.address().port}`;
  try{const before=JSON.stringify(store.observations()),post=(route,body)=>fetch(origin+route,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
    const answer=await post('/api/ask-local',{question:'What did I do this week?',...opts});assert.equal(answer.status,200);assert.equal((await answer.json()).count,1);
    const pdf=await post('/api/reports/pdf',{startDate:'2026-09-28',length:7,timeZone:'UTC'});assert.equal(pdf.status,200);assert(Buffer.from(await pdf.arrayBuffer()).subarray(0,5).equals(Buffer.from('%PDF-')));assert.equal(calls,0);assert.equal(JSON.stringify(store.observations()),before);assert.equal(store.settings().saveSnapshots,false);
  }finally{await new Promise(r=>server.close(r));await rm(dir,{recursive:true,force:true});}
});
