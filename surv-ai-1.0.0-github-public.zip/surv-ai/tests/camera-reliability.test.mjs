import test from 'node:test';
import assert from 'node:assert/strict';
import {readdir} from 'node:fs/promises';
import {DatabaseSync} from 'node:sqlite';
import path from 'node:path';
import {desktopFixture,client,ok,image} from './desktop-fixture.mjs';
import {detectionResult} from '../src/person-detection.mjs';
async function fixture(){
  const scores=new Map(),calls=[],f=await desktopFixture({detector:{async start(){},async inspect(input,{threshold}){calls.push({input,threshold});if(f.detectionHold)await f.detectionHold;return {frameValid:true,personPresent:false,personConfidence:scores.get(input)??.30};},close(){}}}),a=await client(f,{owner:true});
  const check=(id='local-webcam',extra={})=>a.post('/api/detection/check',{cameraId:id,cameraActive:true,image,timestamp:new Date(f.now).toISOString(),...extra});return {f,a,scores,calls,check};
}
test('owned preview detection runs without monitoring sessions, AI, usage, observations or context and reports confidence/time',async()=>{
  const {f,a,calls,check}=await fixture();try{
    const gate=await ok(check());assert.equal(gate.personPresent,true);assert.equal(gate.personConfidence,.30);assert.equal(gate.detectionStatus,'person');assert.equal(gate.detectionAt,new Date(f.now).toISOString());assert.equal(gate.confidenceThreshold,.25);assert.equal(calls.length,1);
    assert.equal(f.store.sessions().length,0);assert.equal(f.store.observations().length,0);assert.equal(f.server.desktop.entries.size,0);assert.equal(f.calls,0);assert.equal(f.collector.samples,0);
    assert.equal((await a.post('/api/automatic-analyze',{sessionId:'preview',ticket:'preview'})).status,404);assert.equal(f.calls,0);
  }finally{await f.close();}
});
test('thresholds are bounded, backed up, persistent, owned and do not rewrite core settings/history',async()=>{
  const {f,a,check}=await fixture();try{
    const b=await client(f,{email:'other-threshold@example.test'}),s=f.store.forUser(a.state.user.id),cameras=s.cameras(),settings=s.settings(),schema=s.db.prepare('PRAGMA user_version').get().user_version;
    for(const confidenceThreshold of [.10,.19,.76,1,'0.25',null,true])assert.equal((await a.post('/api/settings/detection',{confidenceThreshold})).status,400);
    assert.equal(s.db.prepare("SELECT name FROM sqlite_master WHERE name='person_detection_settings'").get(),undefined);
    await ok(a.post('/api/settings/detection',{confidenceThreshold:.50}));assert.equal((await ok(check())).detectionStatus,'none');assert.equal((await ok(b.get('/api/settings/detection'))).confidenceThreshold,.25);
    const backups=(await readdir(path.join(f.dir,'backups'))).filter(n=>n.startsWith('pre-person-detection-'));assert.equal(backups.length,1);const copy=new DatabaseSync(path.join(f.dir,'backups',backups[0]),{readOnly:true});try{assert.equal(copy.prepare('PRAGMA integrity_check').get().integrity_check,'ok');assert.equal(copy.prepare("SELECT name FROM sqlite_master WHERE name='person_detection_settings'").get(),undefined);}finally{copy.close();}
    for(const confidenceThreshold of [.20,.25,.75])assert.equal((await ok(a.post('/api/settings/detection',{confidenceThreshold}))).confidenceThreshold,confidenceThreshold);
    assert.deepEqual(s.cameras(),cameras);assert.deepEqual(s.settings(),settings);assert.equal(s.db.prepare('PRAGMA user_version').get().user_version,schema);
    await f.restart();assert.equal((await ok(a.get('/api/settings/detection'))).confidenceThreshold,.75);assert.equal((await ok(b.get('/api/settings/detection'))).confidenceThreshold,.25);assert.equal(f.calls,0);assert.deepEqual(f.store.db.prepare('PRAGMA foreign_key_check').all(),[]);
  }finally{await f.close();}
});
test('backup/update failures leave detector defaults and existing data intact',async()=>{
  const {f,a}=await fixture();try{
    const prepare=f.store.db.prepare.bind(f.store.db);f.store.db.prepare=sql=>{if(sql==='VACUUM INTO ?')throw Error('Synthetic disk failure');return prepare(sql);};assert.equal((await a.post('/api/settings/detection',{confidenceThreshold:.4})).status,507);f.store.db.prepare=prepare;assert.equal((await ok(a.get('/api/settings/detection'))).confidenceThreshold,.25);assert.equal(prepare("SELECT name FROM sqlite_master WHERE name='person_detection_settings'").get(),undefined);
    const exec=f.store.db.exec.bind(f.store.db);f.store.db.exec=sql=>{if(sql.includes('CREATE TABLE IF NOT EXISTS person_detection_settings'))throw Error('Synthetic schema failure');return exec(sql);};assert.equal((await a.post('/api/settings/detection',{confidenceThreshold:.4})).status,507);f.store.db.exec=exec;assert.equal(prepare("SELECT name FROM sqlite_master WHERE name='person_detection_settings'").get(),undefined);assert.equal(f.calls,0);
  }finally{await f.close();}
});
test('three cameras have independent scores, one check per camera, strict ownership and rotation validation',async()=>{
  const {f,a,scores,check}=await fixture();try{
    const cams=[f.store.forUser(a.state.user.id).camera(),(await ok(a.post('/api/cameras',{name:'Same model center',deviceId:'center'}))).camera,(await ok(a.post('/api/cameras',{name:'Same model right',deviceId:'right'}))).camera],b=await client(f,{email:'foreign-camera@example.test'});
    const frames=cams.map((c,i)=>'data:image/png;base64,'+Buffer.concat([Buffer.from(image.split(',')[1],'base64'),Buffer.from(c.id)]).toString('base64'));frames.forEach((img,i)=>scores.set(img,[.65,.28,.12][i]));
    const gates=await Promise.all(cams.map((c,i)=>ok(check(c.id,{image:frames[i]}))));assert.deepEqual(gates.map(g=>g.personConfidence),[.65,.28,.12]);assert.deepEqual(gates.map(g=>g.personPresent),[true,true,false]);assert.deepEqual(gates.map(g=>g.cameraId),cams.map(c=>c.id));
    assert.equal((await b.post('/api/detection/check',{cameraId:cams[0].id,cameraActive:true,image,timestamp:new Date(f.now).toISOString()})).status,404);
    await ok(a.post('/api/cameras/'+cams[1].id,{rotation:90}));assert.equal((await check(cams[1].id)).status,409);assert.equal((await ok(check(cams[1].id,{rotation:90}))).personConfidence,.30);
    await ok(a.post('/api/cameras/'+cams[2].id,{enabled:false}));assert.equal((await check(cams[2].id)).status,409);assert.equal(f.calls,0);
  }finally{await f.close();}
});
test('duplicate preview checks reject; configuration changes reject old worker results; stale results cannot issue paid tickets in either mode',async()=>{
  const {f,a,calls,check}=await fixture();let release;try{
    f.detectionHold=new Promise(r=>release=r);const pending=check();while(!calls.length)await new Promise(r=>setImmediate(r));assert.equal((await check()).status,409);await ok(a.post('/api/cameras/local-webcam',{rotation:180}));release();assert.equal((await pending).status,409);f.detectionHold=null;
    await ok(a.post('/api/cameras/local-webcam',{rotation:0}));const preview=await ok(check('local-webcam',{timestamp:new Date(f.now-6000).toISOString()}));assert.equal(preview.detectionStatus,'stale');
    const run=await ok(a.post('/api/monitoring/start',{cameraActive:true}));for(const smartSurv of [true,false]){await ok(a.post('/api/settings',{smartSurv}));const gate=await ok(a.post('/api/monitoring/check',{sessionId:run.sessionId,cameraActive:true,image,timestamp:new Date(f.now-6000).toISOString()}));assert.equal(gate.detectionStatus,'stale');assert.equal(gate.ticket,null);assert.equal(gate.telemetry.noPerson,0);}
    assert.equal(f.calls,0);
  }finally{release?.();await f.close();}
});
test('changing threshold invalidates pending Area tickets while retaining session/order/interval and OFF behavior',async()=>{
  const {f,a}=await fixture();try{
    const area=(await ok(a.post('/api/camera-areas',{name:'Office'}))).areas[0];await ok(a.post('/api/cameras/local-webcam',{areaId:area.id}));const run=await ok(a.post('/api/monitoring/start',{cameraActive:true}));
    const check=()=>ok(a.post('/api/monitoring/check',{sessionId:run.sessionId,cameraActive:true,image,timestamp:new Date(f.now).toISOString(),detectOnly:true}));await check();const ticket=await ok(a.post('/api/monitoring/area-ticket',{sessionId:run.sessionId}));assert(ticket.ticket);
    await ok(a.post('/api/settings/detection',{confidenceThreshold:.50}));assert.equal((await a.post('/api/automatic-analyze',{sessionId:run.sessionId,ticket:ticket.ticket})).status,409);assert.equal((await check()).personPresent,false);assert.equal((await ok(a.post('/api/monitoring/area-ticket',{sessionId:run.sessionId}))).ticket,null);
    await ok(a.post('/api/settings',{smartSurv:false}));f.now+=15000;await check();const off=await ok(a.post('/api/monitoring/area-ticket',{sessionId:run.sessionId}));assert(off.ticket);await ok(a.post('/api/automatic-analyze',{sessionId:run.sessionId,ticket:off.ticket}));assert.equal(f.calls,1);assert.equal(f.store.sessions().length,1);assert.equal(f.store.forUser(a.state.user.id).camera().area_id,area.id);assert.equal(f.store.settings().intervalMs,15000);
  }finally{await f.close();}
});
test('normalization never invents confidence or treats invalid/unavailable metadata as a person',()=>{
  const now=Date.now(),timestamp=new Date(now).toISOString();assert.equal(detectionResult({frameValid:true,personPresent:true},.25,now,timestamp).personConfidence,null);assert.equal(detectionResult({frameValid:false,personConfidence:.99},.25,now,timestamp).detectionStatus,'invalid');assert.equal(detectionResult({frameValid:true,personConfidence:.24},.25,now,timestamp).personPresent,false);
});
