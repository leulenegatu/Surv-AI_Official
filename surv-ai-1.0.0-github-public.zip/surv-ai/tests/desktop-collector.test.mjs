import {test} from 'node:test';
import assert from 'node:assert/strict';
import {EventEmitter} from 'node:events';
import {WindowsDesktopCollector,cleanDesktopSample} from '../src/desktop-collector.mjs';
import {desktopFixture,client,enable,start,ok} from './desktop-fixture.mjs';

function worker(){const child=new EventEmitter();child.kills=0;child.stdin=new EventEmitter();child.stdout=new EventEmitter();child.stdout.setEncoding=()=>{};child.stderr={resume(){}};child.stdin.end=()=>{};child.kill=()=>child.kills++;return child;}
test('native abstraction has one process and one pending request, no shell interpolation or credential inheritance',async()=>{
  const child=worker(),writes=[];child.stdin.write=v=>writes.push(JSON.parse(v));let launches=0;
  const collector=new WindowsDesktopCollector({platform:'win32',spawnImpl(_exe,args,options){launches++;assert.equal(options.windowsHide,true);assert.equal(options.shell,undefined);assert.equal(options.env.OPENAI_API_KEY,undefined);assert(args.includes('-NoProfile'));return child;}});
  const one=collector.sample({includeTitle:true}),two=collector.sample({includeTitle:true});assert.equal(one,two);assert.equal(launches,1);assert.equal(writes.length,1);child.stdout.emit('data',JSON.stringify({id:writes[0].id,sample:{executable:'fixture.exe',title:'<untrusted>',state:'active',idleMs:5}})+'\n');assert.equal((await one).title,'<untrusted>');assert.equal((await two).executable,'fixture.exe');const next=collector.sample({includeTitle:false});assert.equal(launches,1);assert.equal(writes.length,2);assert.equal(writes[1].includeTitle,false);collector.close();assert.equal((await next).state,'unavailable');collector.close();assert.equal(child.kills,1);assert.equal(collector.pending,null);
});
test('native failure/oversized protocol clears pending data and backs off instead of spawning repeatedly',async()=>{
  const child=worker();child.stdin.write=()=>{};let launches=0;const collector=new WindowsDesktopCollector({platform:'win32',spawnImpl(){launches++;return child;}});
  const pending=collector.sample();child.stdout.emit('data','x'.repeat(8193));assert.equal((await pending).state,'unavailable');assert.equal(collector.child,null);assert.equal(collector.buffer,'');for(let i=0;i<50;i++)assert.equal((await collector.sample()).state,'unavailable');assert.equal(launches,1);collector.close();
});
test('locked/unavailable clear app/title/input facts, unknown remains explicit and title OFF drops metadata',()=>{
  for(const state of ['locked','unavailable']){const c=cleanDesktopSample({state,executable:'private.exe',title:'PRIVATE',idleMs:6},{includeTitle:true});assert.equal(c.executable,null);assert.equal(c.title,null);assert.equal(c.idleMs,null);}
  const c=cleanDesktopSample({state:'unknown',executable:'fixture.exe',title:'Private window',idleMs:null});assert.equal(c.state,'unknown');assert.equal(c.title,null);assert.equal(c.idleMs,null);
});
test('shared hosts have one collecting owner; opt-out/reconnect/in-flight cleanup never duplicates or leaks context',async()=>{
  const f=await desktopFixture({desktopAutoSchedule:true});try{
    const a=await client(f,{owner:true}),b=await client(f,{email:'shared-desktop@example.test'}),camera=(await ok(b.post('/api/cameras',{name:'Second desktop fixture',deviceId:'second'}))).camera;
    await enable(a,'local-webcam',true);const one=await start(f,a);await enable(b,camera.id,false);const two=await start(f,b,camera.id);const timer=f.server.desktop.timer;assert(timer);assert.equal(f.collector.starts,1);assert.equal(f.server.desktop.entries.size,2);assert.equal(f.server.desktop.status(a.state.user.id)[0].context.title,'Synthetic project — Visual Studio Code');assert.equal(f.server.desktop.status(b.state.user.id)[0].context,null);assert.equal(f.server.desktop.status(b.state.user.id)[0].status,'collector_in_use');assert.equal(f.store.db.prepare('SELECT COUNT(*) n FROM desktop_spans WHERE user_id=?').get(b.state.user.id).n,0);
    for(let i=0;i<5;i++){await start(f,a);await start(f,b,camera.id);}assert.equal(f.server.desktop.timer,timer);assert.equal(f.collector.starts,1);
    let release;f.collector.hold=new Promise(r=>release=r);const pending=f.server.desktop.poll();await ok(a.post('/api/settings/desktop',{enabled:false,includeTitle:false,cameraId:'local-webcam'}));await ok(b.post('/api/monitoring/stop',{sessionId:two}));assert.equal(f.server.desktop.entries.size,0);assert.equal(f.server.desktop.timer,null);release();await pending;assert.equal(f.server.desktop.entries.size,0);assert.equal(f.collector.live,false);assert.equal(f.store.forUser(a.state.user.id).session(one).status,'active');assert.deepEqual(f.server.desktop.status(a.state.user.id),[]);
  }finally{await f.close();}
});
