import {test} from 'node:test';
import fs from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
const storage=new Map();let failStorage=false;
const database=new Map();
function setup(){
  const elements=new Map();const element=id=>elements.get(id)||elements.set(id,{innerHTML:'',textContent:'',style:{},dataset:{},addEventListener(){},scrollIntoView(){},showModal(){},close(){}}).get(id);
  const context={document:{addEventListener(){},getElementById:element,querySelector:element,querySelectorAll:()=>[],body:{classList:{remove(){}}}},window:{addEventListener(){},scrollTo(){}},location:{hash:''},localStorage:{getItem(key){return storage.get(key)??null},setItem(key,value){storage.set(key,value)}},navigator:{},setTimeout(){},clearTimeout(){},setInterval(){},clearInterval(){},Blob,URL,URLSearchParams,AbortSignal,crypto:crypto.webcrypto,fetch:async(route,options)=>{
    if(failStorage)throw Error('Persistent storage unavailable');
    if(route==='/api/cameras')return new Response(JSON.stringify({cameras:[{id:'local-webcam',name:'Office'}]}));
    if(route==='/api/settings')return new Response(JSON.stringify({intervalMs:15000}));
    if(route==='/api/monitoring/sessions')return new Response(JSON.stringify({sessions:[]}));
    if(route==='/api/monitoring/status')return new Response(JSON.stringify({monitoring:'off',personPresent:null}));
    const body=options?.body?JSON.parse(options.body):null;
    if(route==='/api/observations/import'){for(const record of body.observations)if(!database.has(record.id))database.set(record.id,record);return new Response(JSON.stringify({imported:body.observations.length}));}
    if(body){const record={...body.observation,snapshotRef:'12345678-1234-1234-1234-123456789abc.png'};database.set(record.id,record);return new Response(JSON.stringify({observation:record}));}
    return new Response(JSON.stringify({observations:[...database.values()]}));
  },console};
  context.authState={user:{role:'ADMIN',installationOwner:true}};context.authenticatedUI=()=>true;context.updateAccountChrome=()=>{};context.accountPage=()=>'';context.adminPage=()=>'';context.bootstrapAuth=()=>vm.runInContext('historyState.ready=initializeHistory()',context);vm.createContext(context);for(const file of ['time-format.js','observation.js','snapshot-storage.js','test-lab.js','live-camera.js','overview.js','local-intelligence.js','cameras.js','ask-scope.js','ask-results.js','reports.js','history-navigation.js','usage-model.js','usage-dashboard.js','analytics-explorer.js','app.js'])vm.runInContext(fs.readFileSync('dist/'+file,'utf8'),context);
  return {context,element,run:code=>vm.runInContext(code,context)};
}
test('routes, review, commit, no duration and durable shared history',async()=>{
  let {context,element,run}=setup();
  await run('historyState.ready');
  for(const page of ['overview','live','timeline','analytics','insights','ask','cameras','test-lab','settings']){context.location.hash='#'+page;run('render()');assert(element('app').innerHTML.length>200,page);assert(!element('app').innerHTML.includes('undefined'),page);}
  assert(!element('app').innerHTML.includes('Pause demo'));
  assert(!element('app').innerHTML.includes('DEMO DATA'));
  context.location.hash='#timeline';run('render()');assert(!element('app').innerHTML.includes('aria-label="History data"'));
  context.fixture={activity:'Reading',location:'Office',description:'A person appears to be reading.',objects:['book'],confidence:.87,timestamp:'2026-10-01T14:12:00.000Z'};
  run("lab.result=fixture;lab.image='data:image/png;base64,test'");assert.equal(run('manualRecords.length'),0);
  run('discardLabResult()');assert.equal(run('manualRecords.length'),0);
  await run('lab.result=fixture;lab.editing=true;commitLabObservation()');assert.equal(run('manualRecords.length'),0);
  run('lab.editing=false');failStorage=true;await run('commitLabObservation()');assert.equal(run('manualRecords.length'),0);failStorage=false;
  await run('commitLabObservation()');assert.equal(run('manualRecords.length'),1);assert.equal(run('manualRecords[0].duration'),null);assert(run('manualRecords[0].snapshotRef').endsWith('.png'));
  assert.equal(run("sessions('2026-10-01').length"),1);assert.equal(run("sessions('2026-10-01')[0].duration"),null);
  run('showSession(manualRecords[0].id)');assert(element('detail').innerHTML.includes('Reading'));assert(element('detail').innerHTML.includes('book'));assert(element('detail').innerHTML.includes('REAL OBSERVATION'));assert(element('detail').innerHTML.includes('No duration measured.'));
  context.location.hash='#timeline';run('render()');assert(element('app').innerHTML.includes('Reading'));assert(element('app').innerHTML.includes('AI Observation'));
  context.location.hash='#overview';run('render()');assert(element('app').innerHTML.includes('Reading'));
  const restored=setup();await restored.run('historyState.ready');assert.equal(restored.run('manualRecords.length'),1);restored.run('selectedDate=manualRecords[0].date;showSession(manualRecords[0].id)');assert(restored.element('detail').innerHTML.includes('No duration measured'));
  await run('commitLabObservation()');assert.equal(run('manualRecords.length'),1);
  run("selectedDate='2026-11-01';filter='all';renderSessions()");assert(element('sessions').innerHTML.includes('No activities'));
  assert.equal(storage.get('surv-history'),undefined,'new observations do not use browser history as persistence');
  const legacy={...context.fixture,id:crypto.randomUUID(),source:'automatic_ai',recordType:'observation',timestamp:'2026-09-30T14:00:00.000Z',activity:'Legacy reading'};
  storage.set('surv-history',JSON.stringify([legacy]));const original=storage.get('surv-history');
  const imported=setup();await imported.run('historyState.ready');assert.equal(imported.run('manualRecords.length'),2);assert.equal(storage.get('surv-history'),original);
  imported.context.location.hash='#timeline';imported.run("selectedDate='2026-09-30';render()");assert(imported.element('app').innerHTML.includes('Legacy reading'));assert(!imported.element('app').innerHTML.includes('1h 26m'));assert(!imported.element('app').innerHTML.includes('class="track"'));assert(!imported.element('app').innerHTML.includes('aria-label="History data"'));
  imported.run('render()');assert(imported.element('app').innerHTML.includes('Legacy reading'),'rerender keeps real persisted history visible');
  imported.context.location.hash='#overview';imported.run('render()');const recent=imported.element('app').innerHTML.split('<h2>Recent activity</h2>')[1].split('</section>')[0];assert(recent.includes('Reading'));assert(!recent.includes('Working at desk'));assert(!recent.includes('54m'));
  imported.context.location.hash='#analytics';imported.run('render()');assert(!imported.element('app').innerHTML.includes('AI observations ·'));assert(!imported.element('app').innerHTML.includes('demo sessions'));assert(imported.element('app').innerHTML.includes('Loading real observation summaries'));
  const again=setup();await again.run('historyState.ready');assert.equal(again.run('manualRecords.length'),2,'legacy import is idempotent');
});
