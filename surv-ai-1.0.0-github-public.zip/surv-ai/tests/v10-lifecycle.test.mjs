import {test} from 'node:test';
import assert from 'node:assert/strict';
import {mkdtemp,rm,mkdir,writeFile,readFile,readdir,copyFile,cp} from 'node:fs/promises';
import {existsSync} from 'node:fs';
import {spawn} from 'node:child_process';
import {once} from 'node:events';
import {createServer as createTCPServer} from 'node:net';
import {DatabaseSync} from 'node:sqlite';
import {createHash,randomUUID} from 'node:crypto';
import {fileURLToPath} from 'node:url';
import os from 'node:os';
import path from 'node:path';
import {createServer} from '../server.mjs';
import {LocalStorage} from '../src/storage.mjs';
import {LocalDetector} from '../src/local-detector.mjs';
import {SnapshotStore} from '../src/snapshot-store.mjs';
import {initializePrivacySchema} from '../src/privacy-lifecycle.mjs';
import {createTestServer,testFetch} from './auth-fixture.mjs';

const source=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const digest=bytes=>createHash('sha256').update(bytes).digest('hex');
const delay=ms=>new Promise(resolve=>setTimeout(resolve,ms));
async function deadline(work){let timer;try{return await Promise.race([work,new Promise((_,reject)=>timer=setTimeout(()=>reject(Error('Fixture operation did not finish promptly.')),3000))]);}finally{clearTimeout(timer);}}
async function temporary(action){const directory=await mkdtemp(path.join(os.tmpdir(),'surv-v10-lifecycle-'));try{return await action(directory);}finally{await rm(directory,{recursive:true,force:true});}}
async function copyApplication(directory){
  for(const entry of await readdir(source))if(entry.endsWith('.mjs'))await copyFile(path.join(source,entry),path.join(directory,entry));
  await cp(path.join(source,'dist'),path.join(directory,'dist'),{recursive:true});
  await cp(path.join(source,'src'),path.join(directory,'src'),{recursive:true});
  await copyFile(path.join(source,'package.json'),path.join(directory,'package.json'));
  assert(!existsSync(path.join(directory,'.env')));assert(!existsSync(path.join(directory,'.local-data')));
}
async function run(command,args,{cwd,env={}}={}){
  const child=spawn(command,args,{cwd,env:{...process.env,OPENAI_API_KEY:'',OPENAI_MODEL:'gpt-4.1-mini',SURV_PUBLIC_ORIGIN:'',...env},windowsHide:true,stdio:['ignore','pipe','pipe']});
  let stdout='',stderr='';child.stdout.on('data',data=>stdout+=data);child.stderr.on('data',data=>stderr+=data);
  const timer=setTimeout(()=>child.kill(),15000);
  try{const [code,signal]=await once(child,'close');assert.equal(signal,null,`Fixture child exceeded its deadline: ${stderr}`);return {code,stdout,stderr};}finally{clearTimeout(timer);}
}
async function port(){const server=createTCPServer();server.listen(0,'127.0.0.1');await once(server,'listening');const value=server.address().port;await new Promise(resolve=>server.close(resolve));assert.notEqual(value,4173);return value;}
const close=server=>new Promise((resolve,reject)=>server.close(error=>error?reject(error):resolve()));

test('V1 startup failures reach the error handler, close constructed resources once, and never announce readiness',async()=>temporary(async directory=>{
  let detectorCloses=0,ready=0;
  const server=createServer({databasePath:directory,apiKey:'',detector:{close(){detectorCloses++;}}});
  server.on('ready',()=>ready++);
  const failed=once(server,'error'),closed=new Promise(resolve=>server.once('close',resolve));server.listen(0,'127.0.0.1');
  const [error]=await failed;await closed;await close(server).catch(error=>assert.equal(error.code,'ERR_SERVER_NOT_RUNNING'));
  assert.match(error.message,/could not open or initialize local storage/);assert(!error.message.includes(directory));assert.equal(ready,0);assert.equal(detectorCloses,1);

  const store=new LocalStorage(':memory:');let storageCloses=0;const originalClose=store.close.bind(store);store.close=()=>{storageCloses++;originalClose();};
  const config=path.join(directory,'invalid-provider.json');await writeFile(config,'{"apiKey":"fixture-private-secret-marker"}');
  const configured=createServer({storage:store,apiKey:'',providerConfigPath:config,detector:{close(){}}});
  const configFailed=once(configured,'error'),configClosed=new Promise(resolve=>configured.once('close',resolve));configured.listen(0,'127.0.0.1');
  const [configError]=await configFailed;await configClosed;await close(configured).catch(error=>assert.equal(error.code,'ERR_SERVER_NOT_RUNNING'));
  assert.match(configError.message,/Stored AI configuration could not be loaded safely/);assert(!configError.message.includes('fixture-private-secret-marker'));assert.equal(storageCloses,1);
}));

test('V1 copied CLI validates configuration before opening a database and sanitizes SQLite startup errors',async()=>temporary(async directory=>{
  await copyApplication(directory);
  for(const value of ['not-a-port','0','65536','4173.5','']){
    const result=await run(process.execPath,['server.mjs'],{cwd:directory,env:{PORT:value}});
    assert.equal(result.code,1);assert.match(result.stderr,/Configure PORT as a whole number from 1 to 65535/);assert(!result.stdout.includes('Surv-AI:'));assert(!existsSync(path.join(directory,'.local-data')));
  }
  for(const value of ['not-an-origin','http://surv.example','https://surv.example/private','https://name:secret@surv.example','https://surv.example?token=secret']){
    const result=await run(process.execPath,['server.mjs'],{cwd:directory,env:{PORT:String(await port()),SURV_PUBLIC_ORIGIN:value}});
    assert.equal(result.code,1);assert.match(result.stderr,/Configure SURV_PUBLIC_ORIGIN as an HTTPS origin/);assert(!result.stderr.includes('name:secret'));assert(!result.stdout.includes('Surv-AI:'));assert(!existsSync(path.join(directory,'.local-data')));
  }
  await mkdir(path.join(directory,'.env'));
  const unreadableEnv=await run(process.execPath,['server.mjs'],{cwd:directory,env:{PORT:String(await port())}});
  assert.equal(unreadableEnv.code,1);assert.match(unreadableEnv.stderr,/could not read the server \.env file/);assert(!unreadableEnv.stdout.includes('Surv-AI:'));assert(!existsSync(path.join(directory,'.local-data')));
  await rm(path.join(directory,'.env'),{recursive:true});
  await mkdir(path.join(directory,'.local-data','surv-ai.sqlite'),{recursive:true});
  const result=await run(process.execPath,['server.mjs'],{cwd:directory,env:{PORT:String(await port())}});
  assert.equal(result.code,1);assert.match(result.stderr,/could not open or initialize local storage/);assert(!result.stdout.includes('Surv-AI:'));assert(!result.stderr.includes(directory));assert(!/at .*server\.mjs/.test(result.stderr));
}));

test('V1 occupied-port launch never opens, recovers, or changes the fixture database',async()=>temporary(async directory=>{
  await copyApplication(directory);
  const database=path.join(directory,'.local-data','surv-ai.sqlite'),store=new LocalStorage(database),sessionId=randomUUID(),timestamp='2026-10-01T12:00:00.000Z';
  store.createSession({id:sessionId,intervalMs:15000,telemetry:{requests:0,successes:0,failures:0,noPerson:0,invalid:0,lastRequest:null}},timestamp);store.close();
  const before=digest(await readFile(database)),filesBefore=await readdir(path.dirname(database));
  const occupied=createTCPServer();occupied.listen(0,'127.0.0.1');await once(occupied,'listening');assert.notEqual(occupied.address().port,4173);
  try{const result=await run(process.execPath,['server.mjs'],{cwd:directory,env:{PORT:String(occupied.address().port)}});assert.equal(result.code,1);assert.match(result.stderr,/is in use/);assert(!result.stdout.includes('Surv-AI:'));}finally{await new Promise(resolve=>occupied.close(resolve));}
  assert.equal(digest(await readFile(database)),before);assert.deepEqual(await readdir(path.dirname(database)),filesBefore);
  const inspected=new DatabaseSync(database,{readOnly:true});try{assert.equal(inspected.prepare('SELECT status FROM monitoring_sessions WHERE id=?').get(sessionId).status,'active');assert.equal(inspected.prepare('PRAGMA user_version').get().user_version,5);}finally{inspected.close();}
}));

test('V1 normal shutdown finalizes each active monitoring session and closes its runtime exactly once',async()=>temporary(async directory=>{
  const store=new LocalStorage(':memory:');let storageCloses=0,detectorCloses=0,finishes=0,providerCalls=0;
  const originalClose=store.close.bind(store),originalFinish=store.finishSession;
  store.close=()=>{storageCloses++;originalClose();};store.finishSession=function(...args){finishes++;return originalFinish.apply(this,args);};
  const snapshots=new SnapshotStore(path.join(directory,'snapshots')),server=createTestServer({storage:store,snapshots,apiKey:'',detector:{async start(){},close(){detectorCloses++;}},fetchImpl:async()=>{providerCalls++;throw Error('Provider must not be called.');}});
  server.listen(0,'127.0.0.1');await once(server,'listening');const origin=`http://127.0.0.1:${server.address().port}`;
  const response=await testFetch(origin+'/api/monitoring/start',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({cameraActive:true})});assert.equal(response.status,200);const {sessionId}=await response.json();assert.equal(store.session(sessionId).status,'active');
  let persisted;store.close=()=>{persisted=store.session(sessionId);storageCloses++;originalClose();};
  await close(server);assert.equal(persisted.status,'completed');assert.equal(persisted.end_reason,'server_shutdown');assert.equal(finishes,1);assert.equal(detectorCloses,1);assert.equal(storageCloses,1);assert.equal(providerCalls,0);
  await close(server).catch(error=>assert.equal(error.code,'ERR_SERVER_NOT_RUNNING'));assert.equal(finishes,1);assert.equal(detectorCloses,1);assert.equal(storageCloses,1);
}));

test('V1 shutdown finishes one pending durable monthly archive, stops further catch-up and retains all history before closing SQLite',async()=>temporary(async directory=>{
  const store=new LocalStorage(':memory:');initializePrivacySchema(store);
  const owner=randomUUID(),observed=randomUUID();
  store.db.prepare("INSERT INTO users(id,display_name,email,email_normalized,password_hash,role,status,email_verified,created_at,updated_at) VALUES(?,?,?,?,?,'ADMIN','ACTIVE',0,?,?)").run(owner,'Shutdown fixture','shutdown@example.test','shutdown@example.test','fixture only hash','2026-01-01T00:00:00.000Z','2026-01-01T00:00:00.000Z');
  store.db.prepare('UPDATE installation SET owner_user_id=? WHERE id=1').run(owner);
  store.db.prepare('UPDATE app_settings SET user_id=? WHERE id=1').run(owner);
  store.forUser(owner).saveObservation({id:observed,timestamp:'2026-08-01T12:00:00.000Z',activity:'Working',location:'Office',description:'Fixture observation.',confidence:0.9,objects:['desk'],source:'manual_ai'});
  store.forUser(owner).saveObservation({id:randomUUID(),timestamp:'2026-07-01T12:00:00.000Z',activity:'Reading',location:'Office',description:'Earlier fixture observation.',confidence:0.9,objects:['book'],source:'manual_ai'});
  store.db.prepare("INSERT INTO privacy_settings(user_id,history_retention,monthly_reports) VALUES(?,'30-days',1)").run(owner);
  let release,renderStarted,storageCloses=0,renderCalls=0,persisted;
  const started=new Promise(resolve=>renderStarted=resolve),rendering=new Promise(resolve=>release=resolve),originalClose=store.close.bind(store);
  store.close=()=>{storageCloses++;persisted={observations:store.observations().length,reports:store.db.prepare('SELECT * FROM monthly_reports').all()};originalClose();};
  const server=createServer({storage:store,snapshots:new SnapshotStore(path.join(directory,'snapshots')),apiKey:'',privacyNow:()=>Date.parse('2026-10-05T12:00:00.000Z'),detector:{close(){}},reportRender:async()=>{renderCalls++;renderStarted();await rendering;return Buffer.from('%PDF-fixture-preserved-on-shutdown');}});
  try{
    server.listen(0,'127.0.0.1');await once(server,'listening');await deadline(started);
    let closed=false;const closing=close(server).then(()=>closed=true);await delay(30);assert.equal(closed,false);assert.equal(storageCloses,0);assert.equal(server.privacy.closed,true);
    release();await deadline(closing);assert.equal(storageCloses,1);assert.equal(renderCalls,1);assert.equal(persisted.observations,2);assert.equal(persisted.reports.length,1);assert.equal(persisted.reports[0].month,'2026-08');assert(existsSync(server.monthlyReports.validate(persisted.reports[0].file_ref)));
  }finally{release();if(!storageCloses)await close(server);}
}));

test('V1 detector close immediately rejects startup, pending checks and queued jobs without spawning another worker',async()=>temporary(async directory=>{
  const previous=process.env.SURV_PYTHON;process.env.SURV_PYTHON=process.execPath;
  try{
    const marker=path.join(directory,'starts.txt');
    await mkdir(path.join(directory,'src'));
    await writeFile(path.join(directory,'src','local_detector.py'),`require('node:fs').appendFileSync(${JSON.stringify(marker)},'start\\n');setInterval(()=>{},1000);`);
    const starting=new LocalDetector(directory),startup=starting.start(),startupRejection=assert.rejects(startup,/Local detector stopped/),firstChild=starting.child;
    starting.close();await startupRejection;assert.equal(starting.starting,null);assert.equal(starting.child,null);assert.equal(firstChild.killed,true);
    if(firstChild.exitCode===null)await once(firstChild,'close');

    await writeFile(path.join(directory,'src','local_detector.py'),`require('node:fs').appendFileSync(${JSON.stringify(marker)},'start\\n');process.stdout.write('{"ready":true}\\n');process.stdin.on('data',()=>{});setInterval(()=>{},1000);`);
    const detector=new LocalDetector(directory);await detector.start();const worker=detector.child;
    const first=detector.inspect('fixture'),second=detector.inspect('fixture'),rejected=Promise.all([assert.rejects(first,/Local detector stopped/),assert.rejects(second,/Local detector stopped/)]);
    await new Promise(resolve=>setImmediate(resolve));assert(detector.pending);const countBefore=(await readFile(marker,'utf8')).split('\n').filter(Boolean).length;
    detector.close();await rejected;assert.equal(detector.pending,null);assert.equal(detector.child,null);assert.equal(detector.ready,false);assert.equal(worker.killed,true);await once(worker,'close');
    assert.equal((await readFile(marker,'utf8')).split('\n').filter(Boolean).length,countBefore);
    detector.close();assert.equal(detector.pending,null);
    await detector.start();assert.notEqual(detector.child,worker);const restarted=detector.child;detector.close();await once(restarted,'close');
  }finally{if(previous===undefined)delete process.env.SURV_PYTHON;else process.env.SURV_PYTHON=previous;}
}));

test('V1 PowerShell launcher preserves native failure status and runs test files serially',{skip:process.platform!=='win32'},async()=>temporary(async directory=>{
  await copyFile(path.join(source,'start.ps1'),path.join(directory,'start.ps1'));await mkdir(path.join(directory,'tests'));await writeFile(path.join(directory,'tests','fixture.test.mjs'),'// fixture only');
  await writeFile(path.join(directory,'node.cmd'),'@echo off\r\nif "%~1"=="--version" (\r\n echo v24.19.0\r\n exit /b 0\r\n)\r\necho %* > "%SURV_LAUNCH_ARGS%"\r\nexit /b 37\r\n');
  const shell=path.join(process.env.SystemRoot,'System32','WindowsPowerShell','v1.0','powershell.exe'),argsFile=path.join(directory,'arguments.txt');
  // Process-scoped policy permits only this trusted copied script; host policy is unchanged.
  for(const flag of [[],['-Test']]){
    const result=await run(shell,['-NoProfile','-ExecutionPolicy','Bypass','-File',path.join(directory,'start.ps1'),...flag],{cwd:directory,env:{PATH:directory+path.delimiter+process.env.PATH,SURV_LAUNCH_ARGS:argsFile}});
    assert.equal(result.code,37,result.stderr);const args=await readFile(argsFile,'utf8');if(flag.length){assert.match(args,/--test --test-concurrency=1/);assert.match(args,/fixture\.test\.mjs/);}else assert.match(args,/server\.mjs/);
  }
}));
