import {test} from 'node:test';
import assert from 'node:assert/strict';
import {randomUUID,createHash} from 'node:crypto';
import * as fs from 'node:fs';
import {mkdtemp,rm,readFile,writeFile} from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import {LocalStorage} from '../src/storage.mjs';
import {SnapshotStore} from '../src/snapshot-store.mjs';
import {MonthlyReports,calendarMonthPeriod,buildMonthlyReport} from '../src/monthly-report.mjs';
import {reportPeriod} from '../src/report.mjs';
import {renderReportPDF} from '../src/report-pdf.mjs';

const now=()=>Date.parse('2026-11-04T17:00:00.000Z');
const sample=(extra={})=>({id:randomUUID(),source:'manual_ai',timestamp:'2026-10-01T12:00:00.000Z',activity:'Using computer',description:'A person uses a computer; a water bottle is visible.',location:'Office',confidence:.9,objects:['water bottle','keyboard'],...extra});
const pdf=Buffer.from('%PDF-1.7\nlocal fixture archive');
const digest=bytes=>createHash('sha256').update(bytes).digest('hex');
async function fixture({files={},renderPDF=async()=>pdf}={}){
  const dir=await mkdtemp(path.join(os.tmpdir(),'surv-monthly-')),storage=new LocalStorage(path.join(dir,'test.sqlite'));
  const users=[randomUUID(),randomUUID()];
  for(const [index,id] of users.entries())storage.db.prepare("INSERT INTO users(id,display_name,email,email_normalized,password_hash,role,status,created_at,updated_at) VALUES (?,?,?,?,?,'USER','ACTIVE',?,?)").run(id,'Monthly Fixture '+index,`month${index}@example.test`,`month${index}@example.test`,'fixture credential unchanged',new Date(now()).toISOString(),new Date(now()).toISOString());
  storage.db.prepare('UPDATE installation SET owner_user_id=? WHERE id=1').run(users[0]);
  storage.db.exec(`CREATE TABLE IF NOT EXISTS monthly_reports(id TEXT PRIMARY KEY,user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,month TEXT NOT NULL,time_zone TEXT NOT NULL,observation_count INTEGER NOT NULL,created_at TEXT NOT NULL,byte_length INTEGER NOT NULL,sha256 TEXT NOT NULL,file_ref TEXT NOT NULL,UNIQUE(user_id,month)) STRICT;`);
  const snapshots=new SnapshotStore(path.join(dir,'snapshots')),reports=new MonthlyReports(storage,snapshots,{directory:path.join(dir,'reports'),files,renderPDF,now});
  return {dir,storage,snapshots,reports,users,close:async()=>{storage.close();await rm(dir,{recursive:true,force:true});}};
}

test('monthly calendars include 28/29/30/31 dates and preserve local DST boundaries; on-demand contract stays 7/30',()=>{
  for(const [month,length,end] of [['2026-02',28,'2026-02-28'],['2028-02',29,'2028-02-29'],['2026-04',30,'2026-04-30'],['2026-10',31,'2026-10-31']]){
    const period=calendarMonthPeriod(month);assert.equal(period.length,length);assert.equal(period.startDate,month+'-01');assert.equal(period.endDate,end);assert.equal(period.kind,'month');
  }
  const march=calendarMonthPeriod('2026-03','America/New_York');assert.equal(Date.parse(march.bounds.to)-Date.parse(march.bounds.from),743*3600000);
  const november=calendarMonthPeriod('2026-11','America/New_York');assert.equal(Date.parse(november.bounds.to)-Date.parse(november.bounds.from),721*3600000);
  for(const month of ['2026-00','2026-13','2026-2','../2026-10',null])assert.throws(()=>calendarMonthPeriod(month));
  assert.throws(()=>calendarMonthPeriod('2026-10','invalid-zone'));assert.throws(()=>reportPeriod('2026-10-01',31),/7-day or 30-day/);
});

test('monthly aggregation uses all calendar dates and saved points only, with honest gaps and no duration',async()=>{
  const f=await fixture();try{
    const owned=f.storage.forUser(f.users[0]);
    for(const timestamp of ['2026-09-30T23:59:59.999Z','2026-10-01T00:00:00.000Z','2026-10-31T23:59:59.999Z','2026-11-01T00:00:00.000Z'])owned.saveObservation(sample({timestamp}));
    f.storage.forUser(f.users[1]).saveObservation(sample({activity:'OTHER USER PRIVATE ACTIVITY'}));
    const before=JSON.stringify(owned.observations()),report=buildMonthlyReport(owned,{month:'2026-10',now:now(),displayName:'Fixture User'});
    assert.equal(report.summary.total,2);assert.equal(report.days.length,31);assert.equal(report.days[0].count,1);assert.equal(report.days[30].count,1);assert.equal(report.days[15].count,0);assert.equal(report.accountDisplayName,'Fixture User');
    assert(report.patterns.some(v=>v.includes('29 of 31')));assert(!JSON.stringify(report).includes('OTHER USER'));assert(!('duration' in report.summary));assert.equal(JSON.stringify(owned.observations()),before);
    assert.throws(()=>buildMonthlyReport(owned,{month:'2026-11',now:now()}),/completed/);
    assert.throws(()=>buildMonthlyReport(owned,{month:'2026-10',now:Date.parse('2026-11-01T03:59:59Z'),timeZone:'America/New_York'}),/completed/);
  }finally{await f.close();}
});

test('archive writes verified PDF before metadata and exposes only own opaque IDs',async()=>{
  let rendered;const f=await fixture({renderPDF:async report=>{rendered=report;return pdf;}}),oldFetch=globalThis.fetch;globalThis.fetch=()=>{throw Error('No reporting network calls');};
  try{
    f.storage.forUser(f.users[0]).saveObservation(sample());f.storage.forUser(f.users[1]).saveObservation(sample({activity:'OTHER_ACCOUNT_SECRET'}));
    const available=f.reports.available(f.users[0]);assert.equal(available.length,1);assert.equal(available[0].month,'2026-10');assert.equal(available[0].observationCount,1);
    const saved=await f.reports.generate(f.users[0],'2026-10');assert.equal(saved.observationCount,1);assert.equal(saved.label,'October 2026');assert.equal(saved.bytes,pdf.length);assert(!('fileRef' in saved));assert(!('userId' in saved));assert(!('sha256' in saved));
    const row=f.storage.db.prepare('SELECT * FROM monthly_reports WHERE id=?').get(saved.id);assert.equal(row.sha256,digest(await readFile(f.reports.validate(row.file_ref))));assert.equal(row.byte_length,pdf.length);
    assert(!JSON.stringify(rendered).includes('OTHER_ACCOUNT_SECRET'));assert.equal(rendered.accountDisplayName,'Monthly Fixture 0');assert.equal(f.reports.available(f.users[0]).length,0);assert.equal(f.reports.list(f.users[1]).length,0);
    assert.deepEqual(f.reports.get(f.users[0],saved.id).pdf,pdf);assert.throws(()=>f.reports.get(f.users[1],saved.id),error=>error.status===404);
    for(const id of ['../secret','%2e%2e%2fsecret',saved.id+'.pdf','',null])assert.throws(()=>f.reports.get(f.users[0],id),error=>error.status===400);
    assert.throws(()=>f.reports.validate('../secret.pdf'));assert.throws(()=>f.reports.validate(saved.id+'/a.pdf'));
  }finally{globalThis.fetch=oldFetch;await f.close();}
});

test('duplicate concurrent archive requests generate one durable report',async()=>{
  let calls=0,release;const pending=new Promise(r=>{release=r;}),f=await fixture({renderPDF:async()=>{calls++;await pending;return pdf;}});
  try{
    f.storage.forUser(f.users[0]).saveObservation(sample());
    const one=f.reports.generate(f.users[0],'2026-10'),two=f.reports.generate(f.users[0],'2026-10');release();
    const [a,b]=await Promise.all([one,two]);assert.equal(a.id,b.id);assert.equal(calls,1);assert.equal(f.reports.list(f.users[0]).length,1);assert.equal(fs.readdirSync(f.reports.directory).length,1);
    const again=await f.reports.generate(f.users[0],'2026-10');assert.equal(again.id,a.id);assert.equal(calls,1);
  }finally{await f.close();}
});

test('renderer failure and staging/flush failures never commit archive metadata or mutate observations',async()=>{
  for(const option of [{renderPDF:async()=>{throw Error('renderer unavailable');}},{files:{renameSync(){throw Error('staging failure');}}},{files:{fsyncSync(){throw Error('flush failure');}}}]){
    const f=await fixture(option);try{
      f.storage.forUser(f.users[0]).saveObservation(sample());const before=JSON.stringify(f.storage.forUser(f.users[0]).observations());
      await assert.rejects(f.reports.generate(f.users[0],'2026-10'),/Saved observations have been retained/);assert.equal(f.reports.list(f.users[0]).length,0);assert.equal(JSON.stringify(f.storage.forUser(f.users[0]).observations()),before);
      if(fs.existsSync(f.reports.directory))assert.equal(fs.readdirSync(f.reports.directory).length,0);
    }finally{await f.close();}
  }
});

test('database failure and pending artifact cleanup recover only safe unreferenced files',async()=>{
  let cleanupFails=true;const f=await fixture({files:{unlinkSync(file){if(cleanupFails&&file.endsWith('.pdf'))throw Error('isolated physical cleanup failure');return fs.unlinkSync(file);}}});
  try{
    f.storage.forUser(f.users[0]).saveObservation(sample());f.storage.db.exec("CREATE TRIGGER reject_monthly BEFORE INSERT ON monthly_reports BEGIN SELECT RAISE(ABORT,'isolated SQL failure'); END;");
    await assert.rejects(f.reports.generate(f.users[0],'2026-10'),/durably archived/);assert.equal(f.reports.list(f.users[0]).length,0);assert.equal(f.storage.forUser(f.users[0]).observations().length,1);assert.equal(fs.readdirSync(f.reports.directory).length,1);
    await writeFile(path.join(f.reports.directory,'manual-backup.pdf'),pdf);assert.equal(f.reports.recover().pendingReportCleanupCount,1);cleanupFails=false;assert.equal(f.reports.recover().pendingReportCleanupCount,0);assert.deepEqual(fs.readdirSync(f.reports.directory),['manual-backup.pdf']);
    f.storage.db.exec('DROP TRIGGER reject_monthly');const saved=await f.reports.generate(f.users[0],'2026-10');assert.equal(f.reports.recover().pendingReportCleanupCount,0);assert.deepEqual(f.reports.get(f.users[0],saved.id).pdf,pdf);assert(fs.existsSync(path.join(f.reports.directory,'manual-backup.pdf')));
  }finally{await f.close();}
});

test('read-back corruption or symbolic report files fail safely without claiming a durable archive',async()=>{
  let corrupt=true;const f=await fixture({files:{readFileSync(file,...args){const data=fs.readFileSync(file,...args);return corrupt&&String(file).endsWith('.pdf')?Buffer.from('%PDF-corrupt'):data;}}});
  try{
    f.storage.forUser(f.users[0]).saveObservation(sample());await assert.rejects(f.reports.generate(f.users[0],'2026-10'),/durably archived/);assert.equal(f.reports.list(f.users[0]).length,0);
    corrupt=false;const saved=await f.reports.generate(f.users[0],'2026-10'),ref=f.storage.db.prepare('SELECT file_ref FROM monthly_reports WHERE id=?').get(saved.id).file_ref;
    await writeFile(f.reports.validate(ref),Buffer.from('%PDF-bad'));assert.throws(()=>f.reports.get(f.users[0],saved.id),/unavailable/);await assert.rejects(f.reports.generate(f.users[0],'2026-10'),/unavailable/);assert.equal(f.reports.list(f.users[0]).length,1);
    const unknown=randomUUID()+'.pdf';await writeFile(f.reports.validate(unknown),pdf);const normal=f.reports.files.lstatSync;f.reports.files.lstatSync=file=>file===f.reports.validate(unknown)?{isFile:()=>true,isSymbolicLink:()=>true}:normal(file);assert.equal(f.reports.recover().pendingReportCleanupCount,1);assert(fs.existsSync(f.reports.validate(unknown)));
  }finally{await f.close();}
});

test('calendar-month PDF retains existing local report design and completes without network requests',async()=>{
  const f=await fixture(),oldFetch=globalThis.fetch;globalThis.fetch=()=>{throw Error('Monthly PDF cannot use network');};
  try{
    f.storage.forUser(f.users[0]).saveObservation(sample({activity:'Reading',description:'A person is reading a book.'}));
    const report=buildMonthlyReport(f.storage.forUser(f.users[0]),{month:'2026-10',now:now(),displayName:'Monthly PDF Fixture'}),result=await renderReportPDF(report);
    assert(result.subarray(0,5).equals(Buffer.from('%PDF-')));assert(result.length>10000);fs.mkdirSync('.test-output',{recursive:true});await writeFile('.test-output/v094-monthly.pdf',result);
  }finally{globalThis.fetch=oldFetch;await f.close();}
});
