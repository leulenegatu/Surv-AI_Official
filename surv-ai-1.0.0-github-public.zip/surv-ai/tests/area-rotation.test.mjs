import test from 'node:test';
import assert from 'node:assert/strict';
import {readdir} from 'node:fs/promises';
import {DatabaseSync} from 'node:sqlite';
import {inflateRawSync} from 'node:zlib';
import path from 'node:path';
import {desktopFixture,client,ok,image} from './desktop-fixture.mjs';
const frames=new Map();
function exportData(bytes){assert.equal(bytes.readUInt32LE(0),0x04034b50);assert.equal(bytes.readUInt16LE(8),8);const start=30+bytes.readUInt16LE(26)+bytes.readUInt16LE(28);return JSON.parse(inflateRawSync(bytes.subarray(start,start+bytes.readUInt32LE(18))));}
async function setup(){
  const people=new Map(),checks=new Map(),f=await desktopFixture({detector:{async start(){},async inspect(image){const id=frames.get(image);checks.set(id,(checks.get(id)||0)+1);return {frameValid:true,personPresent:people.get(id)!==false};},close(){}}}),c=await client(f,{owner:true});
  const cameras=[f.store.forUser(c.state.user.id).camera(),(await ok(c.post('/api/cameras',{name:'Center',deviceId:'center'}))).camera,(await ok(c.post('/api/cameras',{name:'Right',deviceId:'right'}))).camera];
  const area=(await ok(c.post('/api/camera-areas',{name:'Office'}))).areas[0];await ok(c.post('/api/cameras/order',{cameraIds:cameras.map(c=>c.id)}));await ok(c.post('/api/settings',{intervalMs:30000}));
  const runs=[];for(const camera of cameras){await ok(c.post('/api/cameras/'+camera.id,{areaId:area.id}));const frame='data:image/png;base64,'+Buffer.concat([Buffer.from(image.split(',')[1],'base64'),Buffer.from(camera.id)]).toString('base64');frames.set(frame,camera.id);runs.push({...await ok(c.post('/api/monitoring/start',{cameraId:camera.id,cameraActive:true})),image:frame});}
  const detect=async(ms=0)=>{f.now+=ms;for(const r of runs){if(f.server.desktop.policy.sessions.get(r.sessionId)?.enabled){const g=await ok(c.post('/api/monitoring/check',{sessionId:r.sessionId,cameraActive:true,image:r.image,timestamp:new Date(f.now).toISOString(),detectOnly:true,rotation:f.store.forUser(c.state.user.id).camera(r.cameraId).rotation}));assert.equal(g.ticket,null);}}};
  const ticket=()=>ok(c.post('/api/monitoring/area-ticket',{sessionId:runs.find(r=>f.server.desktop.policy.sessions.get(r.sessionId)?.enabled).sessionId}));
  const submit=async()=>{const t=await ticket();assert(t.ticket);const result=await ok(c.post('/api/automatic-analyze',{sessionId:t.sessionId,ticket:t.ticket}));assert.equal(result.observation.cameraId,t.cameraId);assert.equal(result.observation.monitoringSessionId,t.sessionId);return t.cameraId;};
  return {f,c,cameras,area,runs,people,checks,detect,ticket,submit};
}
test('one occupied Area rotates all valid members with three/two/one people, skips empty intervals, and OFF preserves attribution',async()=>{
  const {f,c,cameras,people,checks,detect,ticket,submit}=await setup();try{
    const expected=cameras.map(c=>c.id);for(let i=0;i<6;i++){await detect(i?30000:0);assert.equal(await submit(),expected[i%3]);assert.equal((await ticket()).ticket,null);}
    people.set(expected[1],false);for(const id of [expected[0],expected[1],expected[2],expected[0]]){await detect(30000);assert.equal(await submit(),id);}
    people.set(expected[0],false);for(const id of [expected[1],expected[2]]){await detect(30000);assert.equal(await submit(),id);}
    people.set(expected[2],false);await detect(30000);const before=f.calls;assert.equal((await ticket()).ticket,null);await detect(1000);assert.equal((await ticket()).ticket,null);assert.equal(f.calls,before);
    await ok(c.post('/api/settings',{smartSurv:false}));for(const id of expected){await detect(30000);assert.equal(await submit(),id);}
    assert([...checks.values()].every(n=>n>=15));assert.equal(f.store.db.prepare('SELECT SUM(api_requests) n FROM monitoring_sessions').get().n,f.calls);assert.equal(f.store.db.prepare("SELECT COUNT(*) n FROM analysis_usage WHERE kind='request'").get().n,f.calls);assert.equal(f.store.observations().length,f.calls);assert(f.store.observations().every(o=>expected.includes(o.cameraId)&&o.snapshotRef));
    assert.deepEqual(f.store.db.prepare('PRAGMA foreign_key_check').all(),[]);
  }finally{await f.close();}
});
test('Area clocks are independent; disabled/OFF/stale cameras are excluded; reorder, reassignment and Area deletion preserve cooldown',async()=>{
  const {f,c,cameras,runs,area,detect,ticket,submit}=await setup();try{
    await detect();assert.equal(await submit(),cameras[0].id);await ok(c.post('/api/cameras/order',{cameraIds:[cameras[0].id,cameras[2].id,cameras[1].id]}));await detect(30000);assert.equal(await submit(),cameras[2].id);
    await ok(c.post('/api/monitoring/stop',{sessionId:runs[1].sessionId}));await detect(30000);assert.equal(await submit(),cameras[0].id);await ok(c.post('/api/cameras/'+cameras[0].id,{enabled:false}));await detect(30000);assert.equal(await submit(),cameras[2].id);
    const second=(await ok(c.post('/api/camera-areas',{name:'Kitchen'}))).areas.find(a=>a.id!==area.id);await ok(c.post('/api/cameras/'+cameras[2].id,{areaId:second.id}));await detect(1000);assert.equal((await ticket()).ticket,null,'moving does not bypass per-camera or previous Area spacing');await detect(29000);assert.equal(await submit(),cameras[2].id);
    await ok(c.post('/api/camera-areas/'+second.id,{remove:true}));assert.equal(f.store.forUser(c.state.user.id).camera(cameras[2].id).area_id,null);await detect(1000);assert.equal((await ticket()).ticket,null);f.now+=30000;assert.equal((await ticket()).ticket,null,'stale local frames are never selected');
    assert.equal(f.store.sessions().length,3);assert.equal(f.store.observations().length,f.calls);
  }finally{await f.close();}
});
test('slow/failing requests keep detection running, reject overlapping tickets/submissions, consume one interval, and never catch up',async()=>{
  const {f,c,detect,ticket}=await setup();try{
    await detect();const first=await ticket();let reject;f.providerHold=new Promise((_,r)=>reject=r);const pending=c.post('/api/automatic-analyze',{sessionId:first.sessionId,ticket:first.ticket});while(!f.calls)await new Promise(r=>setImmediate(r));
    await detect(90000);assert.equal((await ticket()).ticket,null);assert.equal((await c.post('/api/automatic-analyze',{sessionId:first.sessionId,ticket:first.ticket})).status,409);f.providerHold=null;reject(Error('Synthetic provider failure'));assert.equal((await pending).status,502);assert.equal(f.calls,1);
    const next=await ticket();assert(next.ticket);await ok(c.post('/api/automatic-analyze',{sessionId:next.sessionId,ticket:next.ticket}));assert.equal(f.calls,2);assert.equal((await ticket()).ticket,null);assert.equal(f.store.db.prepare('SELECT SUM(failed_analyses) n FROM monitoring_sessions').get().n,1);
  }finally{await f.close();}
});
test('changing person eligibility continues from the rotation cursor rather than restarting at the first camera',async()=>{
  const {f,cameras,people,detect,submit}=await setup();try{
    await detect();assert.equal(await submit(),cameras[0].id);await detect(30000);assert.equal(await submit(),cameras[1].id);people.set(cameras[1].id,false);await detect(30000);assert.equal(await submit(),cameras[2].id);people.set(cameras[1].id,true);people.set(cameras[0].id,false);await detect(30000);assert.equal(await submit(),cameras[0].id);
  }finally{await f.close();}
});
test('a camera added after removing a reordered camera appends without duplicate positions or rotation starvation',async()=>{
  const {f,c,cameras,runs,area,detect,submit}=await setup();try{
    await ok(c.post('/api/cameras/order',{cameraIds:[cameras[2].id,cameras[0].id,cameras[1].id]}));await ok(c.post('/api/cameras/'+cameras[0].id,{remove:true}));
    const camera=(await ok(c.post('/api/cameras',{name:'New perspective',deviceId:'new-perspective'}))).camera;await ok(c.post('/api/cameras/'+camera.id,{areaId:area.id}));
    const frame='data:image/png;base64,'+Buffer.concat([Buffer.from(image.split(',')[1],'base64'),Buffer.from(camera.id)]).toString('base64');frames.set(frame,camera.id);runs.push({...await ok(c.post('/api/monitoring/start',{cameraId:camera.id,cameraActive:true})),image:frame});
    const saved=f.store.forUser(c.state.user.id).cameras(),expected=[cameras[2].id,cameras[1].id,camera.id];assert.deepEqual(saved.map(v=>v.id),expected);assert.equal(new Set(saved.map(v=>v.sort_order)).size,3);
    for(let i=0;i<6;i++){await detect(i?30000:0);assert.equal(await submit(),expected[i%3]);}
    assert.equal(f.calls,6);assert.deepEqual(f.store.db.prepare('PRAGMA foreign_key_check').all(),[]);
  }finally{await f.close();}
});
test('two named Areas submit independently while sharing the existing global request lock',async()=>{
  const {f,c,cameras,runs,area,detect,ticket}=await setup();try{
    const other=(await ok(c.post('/api/camera-areas',{name:'Kitchen'}))).areas.find(a=>a.id!==area.id);await ok(c.post('/api/cameras/'+cameras[2].id,{areaId:other.id}));await detect();
    const first=await ticket();assert.equal(first.cameraId,cameras[0].id);await ok(c.post('/api/automatic-analyze',{sessionId:first.sessionId,ticket:first.ticket}));const next=await ok(c.post('/api/monitoring/area-ticket',{sessionId:runs[2].sessionId}));assert.equal(next.cameraId,cameras[2].id);await ok(c.post('/api/automatic-analyze',{sessionId:next.sessionId,ticket:next.ticket}));assert.equal(f.calls,2);assert.equal((await ticket()).ticket,null);assert.equal((await ok(c.post('/api/monitoring/area-ticket',{sessionId:runs[2].sessionId}))).ticket,null);
  }finally{await f.close();}
});
test('simultaneous Area ticket polls share one claim; rotation changes invalidate stale checked images',async()=>{
  const {f,c,cameras,runs,detect,ticket}=await setup();try{
    await detect();const tickets=await Promise.all([ticket(),ticket()]);assert.equal(tickets[0].ticket,tickets[1].ticket);await ok(c.post('/api/cameras/'+cameras[0].id,{rotation:180}));assert.equal((await c.post('/api/automatic-analyze',{sessionId:tickets[0].sessionId,ticket:tickets[0].ticket})).status,409);assert.equal(f.calls,0);
    assert.equal((await c.post('/api/monitoring/check',{sessionId:runs[0].sessionId,cameraActive:true,image:runs[0].image,timestamp:new Date(f.now).toISOString(),rotation:0,detectOnly:true})).status,409);await detect();const next=await ticket();assert.equal(next.cameraId,cameras[0].id);await ok(c.post('/api/automatic-analyze',{sessionId:next.sessionId,ticket:next.ticket}));assert.equal((await c.post('/api/automatic-analyze',{sessionId:next.sessionId,ticket:next.ticket})).status,409);assert.equal(f.calls,1);
  }finally{await f.close();}
});
test('failed layout backup or schema transaction leaves every original camera and preference intact',async()=>{
  const f=await desktopFixture();try{
    const c=await client(f,{owner:true}),s=f.store.forUser(c.state.user.id),before=s.cameras(),prepare=s.db.prepare.bind(s.db),exec=s.db.exec.bind(s.db);
    s.db.prepare=sql=>{if(sql==='VACUUM INTO ?')throw Error('Synthetic disk failure');return prepare(sql);};assert.equal((await c.post('/api/cameras/local-webcam',{rotation:90})).status,507);s.db.prepare=prepare;assert.deepEqual(s.cameras(),before);assert.equal(prepare("SELECT name FROM sqlite_master WHERE name='camera_layout'").get(),undefined);
    s.db.exec=sql=>{if(sql.includes('CREATE TABLE IF NOT EXISTS camera_layout'))throw Error('Synthetic schema failure');return exec(sql);};assert.notEqual((await c.post('/api/camera-areas',{name:'Office'})).status,200);s.db.exec=exec;assert.deepEqual(s.cameras(),before);assert.equal(prepare("SELECT name FROM sqlite_master WHERE name='camera_layout'").get(),undefined);assert.deepEqual(prepare('PRAGMA foreign_key_check').all(),[]);assert.equal(f.calls,0);
  }finally{await f.close();}
});
test('Camera Areas, ordering and orientation are additive, backed up, persistent and account isolated',async()=>{
  const f=await desktopFixture();try{
    const a=await client(f,{owner:true}),b=await client(f,{email:'camera-other@example.test'}),s=f.store.forUser(a.state.user.id),before=s.cameras();assert.equal(s.db.prepare("SELECT name FROM sqlite_master WHERE name='camera_layout'").get(),undefined);
    for(const rotation of [1,-90,360,'90',null])assert.equal((await a.post('/api/cameras/local-webcam',{rotation})).status,400);assert.equal(s.db.prepare("SELECT name FROM sqlite_master WHERE name='camera_layout'").get(),undefined);
    const area=(await ok(a.post('/api/camera-areas',{name:'Office <雪>'}))).areas[0];const backups=await readdir(path.join(f.dir,'backups'));assert.equal(backups.length,1);const copy=new DatabaseSync(path.join(f.dir,'backups',backups[0]),{readOnly:true});assert.equal(copy.prepare('PRAGMA integrity_check').get().integrity_check,'ok');assert.equal(copy.prepare("SELECT name FROM sqlite_master WHERE name='camera_layout'").get(),undefined);copy.close();
    const other=(await ok(b.post('/api/cameras',{name:'Other',deviceId:'other'}))).camera;assert.equal((await b.post('/api/cameras/'+other.id,{areaId:area.id})).status,400);assert.equal((await b.post('/api/cameras/local-webcam',{rotation:90})).status,404);assert.equal((await b.post('/api/camera-areas/'+area.id,{remove:true})).status,404);assert.deepEqual((await ok(b.get('/api/camera-areas'))).areas,[]);
    for(const rotation of [0,90,180,270])assert.equal((await ok(a.post('/api/cameras/local-webcam',{rotation,areaId:area.id}))).camera.rotation,rotation);
    const ownExport=exportData(await ok(a.get('/api/account/export'))),foreignExport=exportData(await ok(b.get('/api/account/export')));assert.deepEqual(ownExport.cameraAreas,[area]);assert.equal(ownExport.cameras[0].rotation,270);assert.equal(ownExport.cameras[0].area_id,area.id);assert.deepEqual(foreignExport.cameraAreas,[]);assert(!JSON.stringify(foreignExport).includes(area.id));assert(!JSON.stringify(ownExport).includes(other.id));
    s.db.exec("CREATE TRIGGER camera_write_failure BEFORE UPDATE ON cameras BEGIN SELECT RAISE(ABORT,'synthetic failure'); END;");assert.notEqual((await a.post('/api/cameras/local-webcam',{rotation:90,name:'Changed'})).status,200);assert.equal(s.camera().rotation,270);assert.equal(s.camera().name,before[0].name);s.db.exec('DROP TRIGGER camera_write_failure');
    await f.restart();assert.equal((await ok(a.get('/api/cameras'))).cameras[0].rotation,270);assert.equal((await ok(a.get('/api/cameras'))).cameras[0].area_id,area.id);assert.equal(f.collector.samples,0);assert.equal(f.calls,0);assert.equal(f.store.db.prepare('PRAGMA user_version').get().user_version,5);assert.deepEqual(f.store.db.prepare('PRAGMA foreign_key_check').all(),[]);
  }finally{await f.close();}
});
