"""Actual Windows hidden launcher acceptance, using copied source and disposable data only."""
import ctypes
import base64
from ctypes import wintypes
import hashlib
import http.cookiejar
import json
import os
from pathlib import Path
import shutil
import socket
import sqlite3
import subprocess
import tempfile
import time
import urllib.request
import uuid

ROOT=Path.cwd()
(ROOT/'.test-output/windows-startup').mkdir(parents=True,exist_ok=True)
SHELL=Path(os.environ['SystemRoot'])/'System32/WindowsPowerShell/v1.0/powershell.exe'
WSCRIPT=Path(os.environ['SystemRoot'])/'System32/wscript.exe'
FILES=('start.ps1','start-hidden.vbs','background.ps1','windows-launcher.cs','windows-launcher-preload.cjs','configure-startup.ps1','setup.ps1','package.json')
TEMP=Path(tempfile.mkdtemp(prefix='surv-hidden-launcher-'))
app=TEMP/'copied app with spaces'
app.mkdir()
for p in ROOT.glob('*.mjs'):shutil.copy2(p,app/p.name)
for name in FILES:shutil.copy2(ROOT/name,app/name)
shutil.copytree(ROOT/'dist',app/'dist')
shutil.copytree(ROOT/'src',app/'src')
# Only the disposable server substitutes hardware/provider adapters, so its
# real monitoring sessions can verify shutdown without starting OpenCV or paid AI.
fixture_server=app/'server.mjs'
fixture_server.write_text(fixture_server.read_text(encoding='utf-8').replace('const server=createServer();',"const server=createServer({apiKey:'mock-only',detector:{async start(){},async inspect(){throw Error('No detector work expected');},close(){}},fetchImpl:async()=>{throw Error('No provider request expected');}});"),encoding='utf-8')
with socket.socket() as s:s.bind(('127.0.0.1',0));port=s.getsockname()[1]
assert port!=4173
(app/'.env').write_text(f'PORT={port}\nOPENAI_API_KEY=\nSURV_PUBLIC_ORIGIN=\n',encoding='utf-8')
env={**os.environ,'PORT':str(port),'OPENAI_API_KEY':'','OPENAI_MODEL':'gpt-4.1-mini','SURV_PUBLIC_ORIGIN':''}
for name in ('NODE_OPTIONS','SURV_LAUNCH_PIPE','SURV_LAUNCH_TOKEN','SURV_LAUNCH_ROOT'):env.pop(name,None)
state_file=app/'.local-launcher/state.json'
logs=[]
task_name='Surv-AI Launcher Acceptance '+uuid.uuid4().hex
task_created=False
def ps_literal(value):return "'"+str(value).replace("'","''")+"'"
def task_ps(script):
    encoded=base64.b64encode(script.encode('utf-16le')).decode()
    return subprocess.run([str(SHELL),'-NoProfile','-ExecutionPolicy','Bypass','-EncodedCommand',encoded],env=env,capture_output=True,text=True,timeout=25,creationflags=subprocess.CREATE_NO_WINDOW)
def command(action,check=True):
    p=subprocess.run([str(SHELL),'-NoProfile','-ExecutionPolicy','Bypass','-File',str(app/'background.ps1'),'-Action',action],cwd=TEMP,env=env,capture_output=True,text=True,timeout=50,creationflags=subprocess.CREATE_NO_WINDOW)
    logs.append({'action':action,'exit':p.returncode,'stdout':p.stdout.strip(),'stderr':p.stderr.strip()})
    if check:assert p.returncode==0,logs[-1]
    return p
def wait(predicate,seconds=12):
    until=time.monotonic()+seconds
    while time.monotonic()<until:
        if predicate():return
        time.sleep(.1)
    raise AssertionError('Fixture timed out')
def state():
    for attempt in range(15):
        try:return json.loads(state_file.read_text(encoding='utf-8-sig'))
        except (PermissionError,FileNotFoundError):
            if attempt==14:raise
            time.sleep(.025)
def public():
    with urllib.request.urlopen(f'http://127.0.0.1:{port}/',timeout=2) as r:assert r.status==200;return r.read()
user32=ctypes.WinDLL('user32',use_last_error=True)
user32.IsWindowVisible.argtypes=[wintypes.HWND];user32.IsWindowVisible.restype=wintypes.BOOL
user32.SendMessageW.argtypes=[wintypes.HWND,wintypes.UINT,wintypes.WPARAM,wintypes.LPARAM];user32.SendMessageW.restype=ctypes.c_ssize_t
def assert_hidden(pids):
    visible=[]
    callback_type=ctypes.WINFUNCTYPE(wintypes.BOOL,wintypes.HWND,wintypes.LPARAM)
    @callback_type
    def collect(hwnd,_):
        pid=wintypes.DWORD();user32.GetWindowThreadProcessId(hwnd,ctypes.byref(pid))
        if pid.value in pids and user32.IsWindowVisible(hwnd):visible.append(pid.value)
        return True
    user32.EnumWindows(collect,0)
    assert not visible,visible
def post(action,body,opener,csrf):
    req=urllib.request.Request(f'http://127.0.0.1:{port}'+action,json.dumps(body).encode(),{'Content-Type':'application/json','X-Surv-CSRF':csrf},method='POST')
    try:
        with opener.open(req,timeout=5) as response:return json.load(response)
    except urllib.error.HTTPError as error:
        raise AssertionError((action,error.code,error.read().decode())) from error
def active_fixture_session():
    opener=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))
    with opener.open(f'http://127.0.0.1:{port}/api/auth/me') as r:me=json.load(r)
    password='Synthetic launcher acceptance passphrase 2026'
    owner=post('/api/auth/owner',{'displayName':'Launcher Fixture','email':'launcher@example.test','password':password,'confirmPassword':password},opener,me['csrfToken'])
    csrf=owner['csrfToken']
    for step in (4,5,6):post('/api/onboarding/progress',{'step':step},opener,csrf)
    post('/api/onboarding/complete',{},opener,csrf)
    return post('/api/monitoring/start',{'cameraActive':True},opener,csrf)['sessionId']
def verify_clean(session_id):
    db=sqlite3.connect(f'file:{(app/".local-data/surv-ai.sqlite").as_posix()}?mode=ro',uri=True)
    row=db.execute('SELECT status,end_reason FROM monitoring_sessions WHERE id=?',(session_id,)).fetchone()
    assert row==('completed','server_shutdown'),row
    assert db.execute('PRAGMA integrity_check').fetchone()[0]=='ok';assert not db.execute('PRAGMA foreign_key_check').fetchall();db.close()
try:
    configured=task_ps(f"& {ps_literal(app/'setup.ps1')}")
    assert configured.returncode==0,(configured.stdout,configured.stderr)
    # Start through the exact GUI entry point used by Scheduler, including process-scoped Bypass.
    entry=subprocess.Popen([str(WSCRIPT),'//B','//NoLogo',str(app/'start-hidden.vbs'),'-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-WindowStyle','Hidden','-File',str(app/'background.ps1'),'-Action','Run'],cwd=TEMP,env=env,creationflags=subprocess.CREATE_NO_WINDOW)
    wait(lambda:state_file.exists() and state().get('Ready'))
    first=state();public();assert_hidden({entry.pid,first['HostPid'],first['WrapperPid'],first['NodePid']})
    assert not user32.IsWindowVisible(first['WindowHandle'])
    with open('\\\\.\\pipe\\'+first['Pipe'],'r+b',buffering=0) as pipe:
        pipe.write(b'{"action":"stop","token":"incorrect"}\n')
        assert json.loads(pipe.readline())=={'ok':False}
    public();assert state()['NodePid']==first['NodePid']
    command('Start');assert state()['NodePid']==first['NodePid']
    duplicate=subprocess.Popen([str(WSCRIPT),'//B','//NoLogo',str(app/'start-hidden.vbs')],cwd=TEMP,env=env,creationflags=subprocess.CREATE_NO_WINDOW)
    assert duplicate.wait(timeout=10)==0;assert state()['NodePid']==first['NodePid']
    # A cancelled Windows session end must preserve the process and public route.
    assert user32.SendMessageW(first['WindowHandle'],0x11,0,0)==1
    user32.SendMessageW(first['WindowHandle'],0x16,0,0);assert state()['NodePid']==first['NodePid'];public()
    session=active_fixture_session();command('Stop');entry.wait(timeout=10);verify_clean(session)
    assert not state_file.exists();assert json.loads(command('Status').stdout)['Running'] is False
    # Restart creates one new managed server, with the same stored fixture history.
    command('Start');before=state()['NodePid'];command('Restart');after=state();assert after['NodePid']!=before;public();verify_clean(session)
    assert_hidden({after['HostPid'],after['WrapperPid'],after['NodePid']})
    second=None
    # Existing owner authenticates to create a second active run before actual shutdown messages.
    opener=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))
    with opener.open(f'http://127.0.0.1:{port}/api/auth/me') as r:me=json.load(r)
    signed=post('/api/auth/login',{'email':'launcher@example.test','password':'Synthetic launcher acceptance passphrase 2026'},opener,me['csrfToken'])
    second=post('/api/monitoring/start',{'cameraActive':True},opener,signed['csrfToken'])['sessionId']
    assert user32.SendMessageW(after['WindowHandle'],0x11,0,0)==1
    user32.SendMessageW(after['WindowHandle'],0x16,1,0)
    wait(lambda:not state_file.exists());verify_clean(second)
    text='\n'.join(p.read_text(encoding='utf-8-sig',errors='replace') for p in (app/'.local-launcher/logs').glob('*.log'))
    assert 'Server ready:' in text and 'windows_session_end' in text and 'Clean server exit: 0' in text
    assert 'Synthetic launcher acceptance passphrase' not in text
    assert text.count('Existing server shutdown handler requested.')==3,text
    assert hashlib.sha256((app/'start.ps1').read_bytes()).digest()==hashlib.sha256((ROOT/'start.ps1').read_bytes()).digest()
    # Exercise the exact program and arguments through the real Scheduler service.
    action_args=f'//B //NoLogo "{app / "start-hidden.vbs"}" -NoProfile -NonInteractive -ExecutionPolicy Bypass -WindowStyle Hidden -File "{app / "background.ps1"}" -Action Run'
    setup=task_ps(f"$ErrorActionPreference='Stop';$u=[Security.Principal.WindowsIdentity]::GetCurrent().Name;$a=New-ScheduledTaskAction -Execute {ps_literal(WSCRIPT)} -Argument {ps_literal(action_args)} -WorkingDirectory {ps_literal(app)};$p=New-ScheduledTaskPrincipal -UserId $u -LogonType Interactive -RunLevel Limited;$s=New-ScheduledTaskSettingsSet -DisallowHardTerminate -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -MultipleInstances IgnoreNew -ExecutionTimeLimit ([TimeSpan]::Zero);Register-ScheduledTask -TaskName {ps_literal(task_name)} -Action $a -Principal $p -Settings $s | Out-Null;Start-ScheduledTask -TaskName {ps_literal(task_name)}")
    assert setup.returncode==0,(setup.stdout,setup.stderr)
    task_created=True
    wait(lambda:state_file.exists() and state().get('Ready'),seconds=20)
    scheduled=state();public();assert_hidden({scheduled['HostPid'],scheduled['WrapperPid'],scheduled['NodePid']})
    # Updating a running task changes its next launch only, preserving this process.
    installed=task_ps(f"& {ps_literal(app/'configure-startup.ps1')} -Action Install -TaskName {ps_literal(task_name)}")
    assert installed.returncode==0,(installed.stdout,installed.stderr)
    assert state()['NodePid']==scheduled['NodePid'];public()
    inspect=task_ps(f"$t=Get-ScheduledTask -TaskName {ps_literal(task_name)};[pscustomobject]@{{State=$t.State.ToString();Arguments=$t.Actions[0].Arguments}} | ConvertTo-Json")
    info=json.loads(inspect.stdout);assert info['State']=='Running';assert '-ExecutionPolicy Bypass' in info['Arguments']
    command('Stop')
    completed=task_ps(f"$end=(Get-Date).AddSeconds(10);while((Get-ScheduledTask -TaskName {ps_literal(task_name)}).State -eq 'Running' -and (Get-Date) -lt $end){{Start-Sleep -Milliseconds 200}};(Get-ScheduledTaskInfo -TaskName {ps_literal(task_name)}).LastTaskResult")
    assert completed.stdout.strip()=='0',completed.stdout
    # Startup failures remain visible in logs and cannot open/change the database.
    database=app/'.local-data/surv-ai.sqlite'
    before_database=hashlib.sha256(database.read_bytes()).digest()
    with socket.socket() as occupied:
        occupied.bind(('127.0.0.1',port));occupied.listen()
        failed=subprocess.run([str(WSCRIPT),'//B','//NoLogo',str(app/'start-hidden.vbs')],cwd=TEMP,env=env,timeout=15,creationflags=subprocess.CREATE_NO_WINDOW)
        assert failed.returncode!=0
    assert hashlib.sha256(database.read_bytes()).digest()==before_database
    errors='\n'.join(p.read_text(encoding='utf-8-sig',errors='replace') for p in (app/'.local-launcher/logs').glob('*stderr.log'))
    assert f'Port {port} is in use.' in errors
    assert first['Token'] not in errors
    results={'passed':True,'port':port,'actualHiddenWscript':True,'duplicateServerPrevented':True,'cancelledShutdownPreserved':True,'manualStopRestart':True,'windowsShutdownMessages':True,'sessionsFinalizedExactlyOnce':True,'logsRetained':True,'realServerUntouched':True,'actualTaskScheduler':True,'liveTaskUpdatePreservesServer':True,'unauthorizedStopRejected':True,'startupFailureLogged':True,'occupiedPortPreservesData':True,'taskResult':0,'executionPolicyBypassPreserved':True,'commands':logs}
    (ROOT/'.test-output/windows-startup/fixture-result.json').write_text(json.dumps(results,indent=2),encoding='utf-8')
    shutil.copytree(app/'.local-launcher/logs',ROOT/'.test-output/windows-startup/fixture-logs',dirs_exist_ok=True)
    print(json.dumps({k:v for k,v in results.items() if k!='commands'}))
finally:
    if task_created:
        task_ps(f"Unregister-ScheduledTask -TaskName {ps_literal(task_name)} -Confirm:$false")
    if (app/'.local-launcher/logs').exists():shutil.copytree(app/'.local-launcher/logs',ROOT/'.test-output/windows-startup/fixture-logs',dirs_exist_ok=True)
    if state_file.exists():command('Stop',check=False)
    if 'entry' in globals() and entry.poll() is None:
        try:entry.wait(timeout=5)
        except subprocess.TimeoutExpired:
            subprocess.run(['taskkill','/PID',str(entry.pid),'/T','/F'],capture_output=True,creationflags=subprocess.CREATE_NO_WINDOW) # Owned disposable tree only.
    assert TEMP.resolve().is_relative_to(Path(tempfile.gettempdir()).resolve()) and TEMP.name.startswith('surv-hidden-launcher-')
    shutil.rmtree(TEMP)
