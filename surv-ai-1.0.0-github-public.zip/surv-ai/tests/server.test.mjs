import {test} from 'node:test';
import assert from 'node:assert/strict';
import {analyze,validateInput} from '../server.mjs';
import {createTestServer as createServer,testFetch as fetch} from './auth-fixture.mjs';
const image='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+j1ioAAAAASUVORK5CYII=';
const input={image,context:'Office camera',timestamp:'2026-10-01T14:12:00.000Z'};
const result={activity:'Working at desk',location:'Office',confidence:0.94,objects:['person','laptop'],description:'Person appears seated at a computer.'};
const output=value=>({status:'completed',output:[{type:'message',content:[{type:'output_text',text:JSON.stringify(value)}]}]});
test('Responses image input, strict schema and user timestamp',async()=>{
  let request;
  const actual=await analyze(input,{apiKey:'test-only',fetchImpl:async(url,options)=>{assert.equal(url,'https://api.openai.com/v1/responses');request=JSON.parse(options.body);return new Response(JSON.stringify(output(result)));}});
  assert.equal(request.text.format.type,'json_schema');assert.equal(request.text.format.strict,true);assert.equal(request.store,false);
  assert.equal(request.input[0].content[1].image_url,image);assert.deepEqual(actual,{...result,timestamp:input.timestamp});
});
test('missing key, invalid image, unsupported type and timestamp',async()=>{
  await assert.rejects(analyze(input,{apiKey:''}),/OPENAI_API_KEY/);
  assert.throws(()=>validateInput({...input,image:'data:image/gif;base64,R0lGODlh'}),/JPG, PNG, or WEBP/);
  assert.throws(()=>validateInput({...input,image:'data:image/png;base64,aGVsbG8='}),/valid image/);
  assert.throws(()=>validateInput({...input,timestamp:'yesterday'}),/date and time/);
  assert.throws(()=>validateInput({...input,context:'x'.repeat(301)}),/300 characters/);
});
test('failures, refusal, incomplete and malformed output cannot become observations',async()=>{
  await assert.rejects(analyze(input,{apiKey:'test',fetchImpl:async()=>new Response('',{status:429})}),/usage limit/);
  await assert.rejects(analyze(input,{apiKey:'test',fetchImpl:async()=>{throw Error('offline');}}),/reach OpenAI/);
  for(const data of [output({...result,confidence:1.5}),output({...result,objects:42}),{status:'incomplete'}, {status:'completed',output:[{type:'message',content:[{type:'refusal'}]}]}, {status:'completed',output:[{type:'message',content:[{type:'output_text',text:'not JSON'}]}]}])await assert.rejects(analyze(input,{apiKey:'test',fetchImpl:async()=>new Response(JSON.stringify(data))}),e=>e.status===502);
});
test('HTTP config errors and private source files',async()=>{
  const server=createServer({databasePath:':memory:',apiKey:''});await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
  const origin=`http://127.0.0.1:${server.address().port}`;
  try{
    assert.equal((await fetch(origin)).status,200);
    for(const asset of ['/.env','/server.mjs','/../.env','/.git/config'])assert.equal((await fetch(origin+asset)).status,404);
    const response=await fetch(origin+'/api/analyze',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(input)});
    assert.equal(response.status,503);assert.match((await response.json()).error,/OPENAI_API_KEY/);
    assert.equal((await fetch(origin+'/api/analyze',{method:'POST',headers:{'Content-Type':'application/json',Origin:'https://other.test'},body:JSON.stringify(input)})).status,403);
  }finally{await new Promise(resolve=>server.close(resolve));}
});
