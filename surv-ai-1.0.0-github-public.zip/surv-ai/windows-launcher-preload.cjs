// Optional process-lifecycle bridge, injected only by the Windows background host.
// It never opens storage or changes server/monitoring logic. Existing SIGTERM owns cleanup.
'use strict';
const net=require('node:net'),path=require('node:path'),fs=require('node:fs'),crypto=require('node:crypto');
const root=process.env.SURV_LAUNCH_ROOT;
if(root&&process.argv[1]&&path.resolve(process.argv[1])===path.join(root,'server.mjs')){
  const pipe=process.env.SURV_LAUNCH_PIPE,token=process.env.SURV_LAUNCH_TOKEN;
  if(!pipe||!/^surv-ai-[a-f0-9]{48}$/.test(pipe)||!token||! /^[a-f0-9]{64}$/.test(token))throw Error('Invalid background launcher control configuration.');
  const secret=Buffer.from(token),same=value=>typeof value==='string'&&Buffer.byteLength(value)===secret.length&&crypto.timingSafeEqual(Buffer.from(value),secret);
  let stopping=false;
  const control=net.createServer(socket=>{
    socket.unref();socket.setTimeout(2000,()=>socket.destroy());let input='';
    socket.on('error',()=>{});socket.on('data',chunk=>{
      input+=chunk.toString('utf8');if(Buffer.byteLength(input)>1024){socket.destroy();return;}if(!input.includes('\n'))return;
      let command;try{command=JSON.parse(input.slice(0,input.indexOf('\n')));}catch{socket.destroy();return;}
      if(!same(command.token)||!['status','stop'].includes(command.action)){socket.end('{"ok":false}\n');return;}
      const available=process.listenerCount('SIGTERM')>0;
      socket.end(JSON.stringify({ok:true,pid:process.pid,root:fs.realpathSync(root),shutdownAvailable:available,stopping})+'\n');
      if(command.action==='stop'&&available&&!stopping){
        stopping=true;process.stderr.write('[Surv-AI launcher] Graceful stop requested.\n');
        setImmediate(()=>{control.close();process.emit('SIGTERM');});
      }
    });
  });
  control.on('error',()=>{process.stderr.write('Surv-AI background control pipe could not be opened.\n');process.exit(1);});
  control.listen('\\\\.\\pipe\\'+pipe,()=>control.unref());
}
