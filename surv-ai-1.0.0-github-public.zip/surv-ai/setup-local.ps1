$ErrorActionPreference = 'Stop'
$taskPythonCommand = Get-Command python -ErrorAction SilentlyContinue
$taskPythonPath = if ($taskPythonCommand) { $taskPythonCommand.Source } else { throw 'Install Python 3.10+ and add python to PATH.' }
if (-not (Test-Path -LiteralPath $taskPythonPath)) { throw 'Install Python 3.10 or newer for local OpenCV gating.' }
Push-Location $PSScriptRoot
try {
  & $taskPythonPath -m pip install --target .local-python --upgrade -r requirements-local.txt
  if ($LASTEXITCODE -ne 0) { throw 'OpenCV installation failed.' }
  New-Item -ItemType Directory -Path .local-models -Force | Out-Null
  $taskModelFiles = @(
    @{ Name='deploy.prototxt'; Hash='2D180F723B3109E21F8287F6B3C691390D07B60EED998327CD3259FFA0E50608' },
    @{ Name='mobilenet_iter_73000.caffemodel'; Hash='52EED8BE80522C152A17FB56740DE705B79881BDE1A167E0E747310523685FC7' }
  )
  foreach ($taskModel in $taskModelFiles) {
    $taskModelPath = Join-Path '.local-models' $taskModel.Name
    if (-not (Test-Path -LiteralPath $taskModelPath)) { Invoke-WebRequest -Uri ('https://raw.githubusercontent.com/chuanqi305/MobileNet-SSD/master/' + $taskModel.Name) -OutFile $taskModelPath }
    if ((Get-FileHash -LiteralPath $taskModelPath -Algorithm SHA256).Hash -ne $taskModel.Hash) { throw ('Detector model checksum mismatch: ' + $taskModel.Name) }
  }
  Write-Output 'Local OpenCV person detector is ready. No API key was used.'
} finally { Pop-Location }
