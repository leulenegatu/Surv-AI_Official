using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.IO.Pipes;
using System.Linq;
using System.Runtime.InteropServices;
using System.Security.AccessControl;
using System.Security.Cryptography;
using System.Security.Principal;
using System.Text;
using System.Threading;
using System.Web.Script.Serialization;
using System.Windows.Forms;

namespace SurvAI {
  public sealed class LauncherState {
    public string Root, Pipe, Token, StartedUtc, NodeStartedUtc, StdoutLog, StderrLog, HostLog;
    public int HostPid, WrapperPid, NodePid;
    public long WindowHandle;
    public bool Ready;
  }
  public static class WindowsLauncher {
    static readonly JavaScriptSerializer Json = new JavaScriptSerializer();
    internal static string Runtime(string root) { return Path.Combine(root,".local-launcher"); }
    internal static string StatePath(string root) { return Path.Combine(Runtime(root),"state.json"); }
    internal static string Encode(object value) { return Json.Serialize(value); }
    static LauncherState Read(string root) {
      var file=StatePath(root); if(!File.Exists(file))return null;
      string content=null;
      for(int attempt=0;attempt<10;attempt++){try{content=File.ReadAllText(file,Encoding.UTF8);break;}catch(IOException){if(attempt==9)throw;Thread.Sleep(20);}catch(UnauthorizedAccessException){if(attempt==9)throw;Thread.Sleep(20);}}
      var s=Json.Deserialize<LauncherState>(content);
      if(s==null || !String.Equals(Path.GetFullPath(s.Root),Path.GetFullPath(root),StringComparison.OrdinalIgnoreCase))throw new Exception("Background state belongs to a different installation.");
      return s;
    }
    internal static Dictionary<string,object> Command(LauncherState s,string action,int timeout) {
      using(var pipe=new NamedPipeClientStream(".",s.Pipe,PipeDirection.InOut,PipeOptions.None)) {
        pipe.Connect(timeout);
        var bytes=Encoding.UTF8.GetBytes(Encode(new {action=action,token=s.Token})+"\n");pipe.Write(bytes,0,bytes.Length);pipe.Flush();
        // A read deadline prevents a corrupt/stale local pipe from hanging manual controls.
        var read=System.Threading.Tasks.Task.Factory.StartNew(()=> {
          using(var reader=new StreamReader(pipe,Encoding.UTF8,false,1024,true))return reader.ReadLine();
        });
        if(!read.Wait(timeout))throw new TimeoutException("Background control did not respond.");
        var result=Json.Deserialize<Dictionary<string,object>>(read.Result??"{}");
        if(!result.ContainsKey("ok") || !Convert.ToBoolean(result["ok"]) || !result.ContainsKey("root") || !String.Equals(Convert.ToString(result["root"]),s.Root,StringComparison.OrdinalIgnoreCase))throw new Exception("Background control identity could not be verified.");
        if(s.NodePid!=0 && Convert.ToInt32(result["pid"])!=s.NodePid)throw new Exception("Background process identity changed; refusing to stop another process.");
        return result;
      }
    }
    public static bool IsRunning(string root) { try { var s=Read(root);return s!=null&&Command(s,"status",500)!=null; } catch{return false;} }
    public static bool IsReady(string root) { try { var s=Read(root);return s!=null&&s.Ready&&Command(s,"status",500)!=null; } catch{return false;} }
    public static object Status(string root) {
      var s=Read(root);bool running=IsRunning(root);
      return new {Running=running,Ready=running&&s.Ready,Supervised=running&&HostAlive(s),HostPid=s==null?0:s.HostPid,ServerPid=s==null?0:s.NodePid,StartedUtc=s==null?null:s.StartedUtc,Logs=Path.Combine(Runtime(root),"logs")};
    }
    public static void Stop(string root,int timeout) {
      var s=Read(root);if(s==null)return;
      Dictionary<string,object> status;
      try {status=Command(s,"status",1500);}catch {
        var pending=DateTime.UtcNow.AddMilliseconds(timeout);while(HostAlive(s)&&DateTime.UtcNow<pending)Thread.Sleep(100);if(HostAlive(s))throw new Exception("Background host exists but its server control is unavailable. Check logs; no process was forcibly terminated.");return;
      }
      if(!Convert.ToBoolean(status["shutdownAvailable"]))throw new Exception("Server is still initializing. Retry Stop after startup finishes.");
      Process node=null;
      try{node=Process.GetProcessById(Convert.ToInt32(status["pid"]));}catch(ArgumentException){}
      var until=DateTime.UtcNow.AddMilliseconds(timeout);
      SignalStop(s);
      if(node!=null){using(node){if(!node.WaitForExit(timeout))throw new Exception("Server shutdown is still pending; no process was force-killed.");}}
      while(DateTime.UtcNow<until){if(!HostAlive(s)){if(File.Exists(StatePath(root))){var current=Read(root);if(current!=null&&current.Token==s.Token)File.Delete(StatePath(root));}return;}Thread.Sleep(100);}
      throw new Exception("Graceful shutdown is still pending. Check logs; the server was not force-killed.");
    }
    internal static void SignalStop(LauncherState s) { Command(s,"stop",1500); }
    static bool HostAlive(LauncherState s) {try {var p=Process.GetProcessById(s.HostPid);return !p.HasExited&&Math.Abs((p.StartTime.ToUniversalTime()-DateTime.Parse(s.StartedUtc).ToUniversalTime()).TotalSeconds)<2;}catch{return false;} }
    static void SecureRuntime(string directory) {
      Directory.CreateDirectory(directory);
      if((File.GetAttributes(directory)&FileAttributes.ReparsePoint)!=0)throw new Exception("Launcher state directory must not be a link.");
      var acl=new DirectorySecurity();var owner=WindowsIdentity.GetCurrent().User;
      acl.SetAccessRuleProtection(true,false);acl.SetOwner(owner);
      foreach(var id in new[]{owner,new SecurityIdentifier(WellKnownSidType.LocalSystemSid,null),new SecurityIdentifier(WellKnownSidType.BuiltinAdministratorsSid,null)})
        acl.AddAccessRule(new FileSystemAccessRule(id,FileSystemRights.FullControl,InheritanceFlags.ContainerInherit|InheritanceFlags.ObjectInherit,PropagationFlags.None,AccessControlType.Allow));
      Directory.SetAccessControl(directory,acl);
    }
    public static int Run(string root,string shell) {
      root=Path.GetFullPath(root).TrimEnd(Path.DirectorySeparatorChar);
      SecureRuntime(Runtime(root));
      FileStream lease;
      try { lease=new FileStream(Path.Combine(Runtime(root),"instance.lock"),FileMode.OpenOrCreate,FileAccess.ReadWrite,FileShare.None); }
      catch(IOException){return 0;} // Cross-session, per-installation lock; no second server is spawned.
      using(lease){
        // Keep an orphan's authenticated state intact; never overwrite its stop token.
        if(IsRunning(root))return 0;
        using(var host=new Host(root,shell)){return host.Execute();}
      }
    }
    internal static void WriteState(LauncherState s) {
      var file=StatePath(s.Root);var temporary=file+".tmp";
      File.WriteAllText(temporary,Encode(s),new UTF8Encoding(false));
      if(File.Exists(file))File.Replace(temporary,file,null);else File.Move(temporary,file);
    }
    internal static string RandomHex(int count) {var b=new byte[count];using(var rng=RandomNumberGenerator.Create())rng.GetBytes(b);return BitConverter.ToString(b).Replace("-","").ToLowerInvariant();}
  }
  internal sealed class Host : NativeWindow,IDisposable {
    const int WM_QUERYENDSESSION=0x11,WM_ENDSESSION=0x16,WM_CLOSE=0x10;
    [DllImport("kernel32.dll")] static extern bool SetProcessShutdownParameters(uint level,uint flags);
    [DllImport("user32.dll",CharSet=CharSet.Unicode)] static extern bool ShutdownBlockReasonCreate(IntPtr window,string reason);
    [DllImport("user32.dll")] static extern bool ShutdownBlockReasonDestroy(IntPtr window);
    readonly string root,shell;
    readonly object logGate=new object();
    LauncherState state;
    Process child;
    System.Windows.Forms.Timer timer;
    StreamWriter stdout,stderr,hostLog;
    volatile bool sawReady,expectedStop;
    bool askedStop,finished;
    DateTime launched,lastState;
    int result=1;
    public Host(string root,string shell){this.root=root;this.shell=shell;}
    StreamWriter Writer(string path){return new StreamWriter(new FileStream(path,FileMode.Append,FileAccess.Write,FileShare.ReadWrite),new UTF8Encoding(false)){AutoFlush=true};}
    void Log(string message){lock(logGate){if(hostLog!=null)hostLog.WriteLine(DateTime.UtcNow.ToString("o")+" "+message);}}
    public int Execute() {
      var folder=Path.Combine(WindowsLauncher.Runtime(root),"logs");Directory.CreateDirectory(folder);
      var name=DateTime.UtcNow.ToString("yyyyMMdd-HHmmss-fff")+"-"+Process.GetCurrentProcess().Id;
      state=new LauncherState {Root=root,HostPid=Process.GetCurrentProcess().Id,StartedUtc=Process.GetCurrentProcess().StartTime.ToUniversalTime().ToString("o"),Pipe="surv-ai-"+WindowsLauncher.RandomHex(24),Token=WindowsLauncher.RandomHex(32),StdoutLog=Path.Combine(folder,name+"-stdout.log"),StderrLog=Path.Combine(folder,name+"-stderr.log"),HostLog=Path.Combine(folder,name+"-host.log")};
      stdout=Writer(state.StdoutLog);stderr=Writer(state.StderrLog);hostLog=Writer(state.HostLog);
      try {
        // Hidden real top-level window, rather than a message-only window: receives shutdown broadcasts.
        CreateHandle(new CreateParams {Caption="Surv-AI background host",Style=0,ExStyle=0x80,Parent=IntPtr.Zero});
        state.WindowHandle=Handle.ToInt64();SetProcessShutdownParameters(0x3ff,1);
        var info=new ProcessStartInfo {FileName=shell,Arguments="-NoProfile -NonInteractive -ExecutionPolicy Bypass -WindowStyle Hidden -File \""+Path.Combine(root,"start.ps1")+"\"",WorkingDirectory=root,UseShellExecute=false,CreateNoWindow=true,RedirectStandardOutput=true,RedirectStandardError=true};
        info.EnvironmentVariables["SURV_LAUNCH_ROOT"]=root;info.EnvironmentVariables["SURV_LAUNCH_PIPE"]=state.Pipe;info.EnvironmentVariables["SURV_LAUNCH_TOKEN"]=state.Token;
        var preload="--require=\""+Path.Combine(root,"windows-launcher-preload.cjs").Replace("\\","\\\\")+"\"";
        info.EnvironmentVariables["NODE_OPTIONS"]=(info.EnvironmentVariables["NODE_OPTIONS"]??"")+" "+preload;
        child=new Process {StartInfo=info};
        child.OutputDataReceived+=(sender,args)=>{if(args.Data==null)return;lock(logGate){stdout.WriteLine(DateTime.UtcNow.ToString("o")+" "+args.Data);}if(args.Data.StartsWith("Surv-AI: http://127.0.0.1:")){sawReady=true;Log("Server ready: "+args.Data);}};
        child.ErrorDataReceived+=(sender,args)=>{if(args.Data==null)return;lock(logGate){stderr.WriteLine(DateTime.UtcNow.ToString("o")+" "+args.Data);}if(args.Data=="[Surv-AI launcher] Graceful stop requested."){expectedStop=true;Log("Existing server shutdown handler requested.");}};
        launched=DateTime.UtcNow;child.Start();state.WrapperPid=child.Id;child.BeginOutputReadLine();child.BeginErrorReadLine();WindowsLauncher.WriteState(state);Log("Hidden startup via unchanged start.ps1; child PID "+child.Id);
        timer=new System.Windows.Forms.Timer {Interval=200};timer.Tick+=(sender,args)=>Poll();timer.Start();Application.Run();
      }catch(Exception error){Log("Launcher error: "+error.Message);RequestStop("host_error");result=1;}
      finally {
        if(timer!=null)timer.Stop();
        if(child!=null&&child.HasExited){child.WaitForExit();Log("Launcher finished with code "+result);}
        if(File.Exists(WindowsLauncher.StatePath(root)) && (child==null||child.HasExited))File.Delete(WindowsLauncher.StatePath(root));
      }
      return result;
    }
    void Poll() {
      if(child.HasExited){child.WaitForExit();result=child.ExitCode;if(sawReady&&!expectedStop&&result==0)result=1;finished=true;Log("Startup wrapper exited: "+child.ExitCode+"; expected stop: "+expectedStop);Application.ExitThread();return;}
      if((DateTime.UtcNow-lastState).TotalMilliseconds>=800){
        try{
          // Query the unguessable authenticated local pipe, never the application's APIs.
          var reply=WindowsLauncher.Command(state,"status",150);
          state.NodePid=Convert.ToInt32(reply["pid"]);state.NodeStartedUtc=Process.GetProcessById(state.NodePid).StartTime.ToUniversalTime().ToString("o");state.Ready=sawReady;WindowsLauncher.WriteState(state);
        }catch(Exception){}
        lastState=DateTime.UtcNow;
      }
    }
    void RequestStop(string reason) {
      if(askedStop||finished)return;askedStop=true;Log("Graceful stop: "+reason);
      try{WindowsLauncher.SignalStop(state);expectedStop=true;if(child.WaitForExit(25000)){child.WaitForExit();result=child.ExitCode;finished=true;Log("Clean server exit: "+result);}else Log("Shutdown still pending; continuing to wait without force-killing.");}catch(Exception error){Log("Shutdown pending: "+error.Message);}
    }
    protected override void WndProc(ref Message message) {
      if(message.Msg==WM_QUERYENDSESSION){Log("Windows session end requested.");ShutdownBlockReasonCreate(Handle,"Surv-AI is closing its local server safely.");message.Result=new IntPtr(1);return;}
      if(message.Msg==WM_ENDSESSION){if(message.WParam!=IntPtr.Zero){RequestStop("windows_session_end");if(finished)Application.ExitThread();}ShutdownBlockReasonDestroy(Handle);message.Result=IntPtr.Zero;return;}
      if(message.Msg==WM_CLOSE){RequestStop("window_close");if(finished)Application.ExitThread();message.Result=IntPtr.Zero;return;}
      base.WndProc(ref message);
    }
    public void Dispose(){if(timer!=null)timer.Dispose();if(Handle!=IntPtr.Zero)DestroyHandle();if(child!=null)child.Dispose();lock(logGate){if(stdout!=null)stdout.Dispose();if(stderr!=null)stderr.Dispose();if(hostLog!=null)hostLog.Dispose();}}
  }
}

