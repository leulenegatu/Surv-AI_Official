# Security reporting

Do not post credentials, browser pairing tokens, session cookies, camera images, private titles or databases in a public issue.

If the new repository enables GitHub private vulnerability reporting, use its Security tab to report a reproducible issue privately. Until the owner supplies a private reporting channel, avoid publishing exploit details or sensitive evidence. This source package does not invent a contact address or configure a remote repository.

Keep this application bound to loopback and protect the Windows installation folder. Review [privacy](docs/PRIVACY.md) and [the release audit](docs/SECURITY-AUDIT.md). No external penetration-test certification is claimed.
