import {randomUUID} from 'node:crypto';

// Only request handlers advance this policy. There are no background AI timers.
export class MonitoringPolicy{
  constructor({now=()=>Date.now()}={}){this.now=now;this.sessions=new Map();this.lastSubmitted=-Infinity;this.cameraRequests=new Map();this.areas=new Map();}
  areaKey(s){return JSON.stringify([s.userId,s.areaId?'area:'+s.areaId:'camera:'+(s.cameraId||'legacy')]);}
  area(s){const key=this.areaKey(s);if(!this.areas.has(key))this.areas.set(key,{lastSubmitted:-Infinity,nextSlotAt:0,lastCameraId:null,lastOrder:-Infinity});return this.areas.get(key);}
  configure(s,camera,cameras=[camera]){
    const previous=s.areaId===undefined?null:this.area(s),changed=s.areaId!==camera.area_id||s.rotation!==camera.rotation||s.deviceId!==camera.device_id;
    s.areaId=camera.area_id;s.order=camera.sort_order;s.rotation=camera.rotation;s.deviceId=camera.device_id;
    if(changed){s.ticket=null;s.lastGate=null;s.lastInput=null;s.layoutRevision=(s.layoutRevision||0)+1;}
    const area=this.area(s),history=cameras.filter(c=>camera.area_id?c.area_id===camera.area_id:c.id===camera.id).map(c=>this.cameraRequests.get(c.id)??-Infinity);
    area.lastSubmitted=Math.max(area.lastSubmitted,previous?.lastSubmitted??-Infinity,...history);
  }
  members(s){return [...this.sessions.values()].filter(v=>v.enabled&&this.areaKey(v)===this.areaKey(s)).sort((a,b)=>(a.order??0)-(b.order??0)||String(a.cameraId).localeCompare(String(b.cameraId)));}
  freshMembers(s){return this.members(s).filter(v=>{const age=this.now()-(v.lastGate?.checkedAt??-Infinity),contact=this.now()-v.lastSeen;return contact>=0&&contact<=10000&&age>=0&&age<=5000&&v.lastInput&&v.lastGate.frameValid;});}
  areaPersonDetected(s){return this.freshMembers(s).some(v=>v.lastGate.personPresent===true);}
  selected(s,smartSurv=true,detectionOnlyRotation=false){
    const area=this.area(s),members=this.members(s),anchor=members.find(v=>v.cameraId===area.lastCameraId)?.order??area.lastOrder,fresh=this.freshMembers(s);
    const occupied=smartSurv===false||detectionOnlyRotation!==true&&s.areaId&&fresh.some(v=>v.lastGate.personPresent===true);
    const eligible=fresh.filter(v=>(occupied||v.lastGate.personPresent===true)&&this.cameraEligibleIn(v)===0);
    return eligible.find(v=>(v.order??0)>anchor)||eligible[0]||null;
  }
  areaTicket(s,analysisInFlight,smartSurv=true,detectionOnlyRotation=false){
    const area=this.area(s),nextEligibleMs=this.eligibleIn(s);
    if(nextEligibleMs>0||analysisInFlight)return {ticket:null,nextEligibleMs:Math.max(nextEligibleMs,analysisInFlight?1000:0),intervalMs:s.intervalMs};
    const chosen=this.selected(s,smartSurv,detectionOnlyRotation);
    if(!chosen){area.nextSlotAt=this.now()+s.intervalMs;return {ticket:null,nextEligibleMs:s.intervalMs,intervalMs:s.intervalMs};}
    if(!chosen.ticket||this.now()-chosen.ticket.createdAt<0||this.now()-chosen.ticket.createdAt>3000)chosen.ticket={id:randomUUID(),createdAt:this.now(),input:chosen.lastInput,personPresent:chosen.lastGate.personPresent};
    return {ticket:chosen.ticket.id,sessionId:chosen.id,cameraId:chosen.cameraId,personPresent:chosen.lastGate.personPresent,areaPersonDetected:s.areaId?this.areaPersonDetected(s):null,nextEligibleMs:0,intervalMs:s.intervalMs,telemetry:{...chosen.telemetry}};
  }
  start({intervalMs=15000,cameraId=null,cameraName=null,userId=null}={}){
    if(![15000,30000,60000].includes(intervalMs))throw Error('The monitoring interval must be 15, 30 or 60 seconds.');
    const existing=[...this.sessions.values()].find(s=>s.enabled&&s.cameraId===cameraId&&s.userId===userId);if(existing){existing.intervalMs=intervalMs;return existing;}
    const session={id:randomUUID(),intervalMs,cameraId,cameraName,userId,enabled:true,checking:false,ticket:null,telemetry:{requests:0,successes:0,failures:0,noPerson:0,invalid:0,lastRequest:null},lastSeen:this.now()};
    this.sessions.set(session.id,session);
    if(this.sessions.size>10)for(const [id,old] of this.sessions){if(id!==session.id&&!old.enabled)this.sessions.delete(id);}
    return session;
  }
  get(id){const session=this.sessions.get(id);if(!session?.enabled)throw Error('Auto Monitoring is OFF.');session.lastSeen=this.now();return session;}
  stop(id){const session=this.sessions.get(id);if(session){session.enabled=false;session.ticket=null;}}
  lastRequest(session){return session.cameraId?this.cameraRequests.get(session.cameraId)??-Infinity:this.lastSubmitted;}
  cameraEligibleIn(session){return Math.max(0,session.intervalMs-(this.now()-this.lastRequest(session)));}
  eligibleIn(session){const area=this.area(session);return Math.max(this.cameraEligibleIn(session),0,session.intervalMs-(this.now()-area.lastSubmitted),area.nextSlotAt-this.now());}
  setInterval(intervalMs,userId){for(const session of this.sessions.values())if(session.enabled&&(userId===undefined||session.userId===userId)){session.intervalMs=intervalMs;session.ticket=null;const area=this.area(session);area.nextSlotAt=Number.isFinite(area.lastSubmitted)?area.lastSubmitted+intervalMs:0;}}
  status(userId){
    const now=this.now(),reportedAt=new Date(now).toISOString();
    const cameras=[...this.sessions.values()].filter(s=>s.enabled&&(userId===undefined||s.userId===userId)).map(session=>{
      const gate=session.lastGate,contactAge=now-session.lastSeen,freshContact=contactAge>=0&&contactAge<=10000,gateAge=gate?now-gate.checkedAt:Infinity;
      return {monitoring:freshContact?'on':'unknown',sessionId:session.id,intervalMs:session.intervalMs,nextEligibleMs:this.eligibleIn(session),lastRequestAt:Number.isFinite(this.lastRequest(session))?new Date(this.lastRequest(session)).toISOString():null,cameraId:session.cameraId,cameraName:session.cameraName,personPresent:freshContact&&gate?.frameValid&&gateAge>=0&&gateAge<=5000?gate.personPresent:null,checkedAt:gate?new Date(gate.checkedAt).toISOString():null,reportedAt};
    });
    const first=cameras[0]||{monitoring:'off',sessionId:null,personPresent:null,checkedAt:null,reportedAt};
    return {...first,monitoring:cameras.some(c=>c.monitoring==='on')?'on':cameras.length?'unknown':'off',personPresent:cameras.some(c=>c.personPresent===true)?true:cameras.length&&cameras.every(c=>c.personPresent===false)?false:null,cameras};
  }
  checked(session,frame,input,analysisInFlight,smartSurv=true,detectOnly=false,detectionOnlyRotation=false){
    if(!session.enabled)throw Error('Auto Monitoring is OFF.');
    // Read-only Overview metadata; this does not grant or consume a ticket.
    const usable=frame.frameValid===true&&!['stale','unavailable'].includes(frame.detectionStatus);
    session.lastGate={frameValid:usable,personPresent:frame.personPresent===true,checkedAt:this.now(),personConfidence:frame.personConfidence??null,detectionAt:frame.detectionAt??null,detectionStatus:frame.detectionStatus,confidenceThreshold:frame.confidenceThreshold};
    session.lastInput=usable?input:null;
    if(!detectOnly||!usable||smartSurv!==false&&(!session.areaId||detectionOnlyRotation===true)&&!frame.personPresent)session.ticket=null;
    const areaPersonDetected=session.areaId?this.areaPersonDetected(session):null,personEligible=session.areaId&&detectionOnlyRotation!==true?areaPersonDetected:frame.personPresent===true;
    const nextEligibleMs=this.eligibleIn(session);
    let decision;
    if(frame.detectionStatus==='stale')decision='Stale detection result';
    else if(frame.detectionStatus==='unavailable')decision='Detection unavailable';
    else if(frame.frameValid!==true){session.telemetry.invalid++;decision='Skipped: invalid camera frame';}
    else if(!personEligible&&smartSurv!==false){session.telemetry.noPerson++;decision=session.areaId&&detectionOnlyRotation!==true?'Area occupancy: No person detected':'No person';}
    else if(detectOnly)decision='Local detection · Area rotation';
    else if(analysisInFlight)decision='Analysis in progress';
    else if(nextEligibleMs>0)decision='Waiting interval';
    else if(session.areaId&&this.selected(session,smartSurv,detectionOnlyRotation)!==session)decision='Waiting Area rotation';
    else {decision=frame.personPresent===true?'Eligible':smartSurv===false?'Eligible · Smart Surv off; no person detected locally':'Eligible · Person detected elsewhere in Area';session.ticket={id:randomUUID(),createdAt:this.now(),input,personPresent:frame.personPresent===true};}
    return {frameValid:frame.frameValid===true,personPresent:usable&&frame.personPresent===true,areaPersonDetected,personConfidence:frame.personConfidence??null,detectionAt:frame.detectionAt??null,detectionStatus:frame.detectionStatus,confidenceThreshold:frame.confidenceThreshold,smartSurv:smartSurv!==false,decision,nextEligibleMs,intervalMs:session.intervalMs,lastRequestAt:Number.isFinite(this.lastRequest(session))?new Date(this.lastRequest(session)).toISOString():null,ticket:detectOnly?null:session.ticket?.id||null,telemetry:{...session.telemetry}};
  }
  consume(id,ticketId,analysisInFlight,smartSurv=true,detectionOnlyRotation=false){
    const session=this.get(id),ticket=session.ticket;session.ticket=null;
    if(analysisInFlight)throw Error('Analysis in progress.');
    if(!ticket||ticket.id!==ticketId||this.now()-ticket.createdAt>3000)throw Error(smartSurv===false?'A fresh valid locally checked frame is required.':'A fresh valid frame with a person is required.');
    if(smartSurv!==false&&(session.areaId&&detectionOnlyRotation!==true?!this.areaPersonDetected(session):ticket.personPresent!==true)){
      if(session.areaId&&detectionOnlyRotation!==true)this.area(session).nextSlotAt=this.now()+session.intervalMs;
      throw Error(session.areaId&&detectionOnlyRotation!==true?'A fresh valid person detection in this Area is required.':'A fresh valid frame with a person is required.');
    }
    if(session.areaId&&this.selected(session,smartSurv,detectionOnlyRotation)!==session)throw Error('Waiting for this camera’s Area rotation.');
    if(this.eligibleIn(session)>0)throw Error(`Waiting for the ${session.intervalMs/1000}-second interval.`);
    const area=this.area(session);area.lastSubmitted=this.now();area.nextSlotAt=this.now()+session.intervalMs;area.lastCameraId=session.cameraId;area.lastOrder=session.order??0;
    if(session.cameraId)this.cameraRequests.set(session.cameraId,this.now());else this.lastSubmitted=this.now();return {session,input:ticket.input};
  }
}
