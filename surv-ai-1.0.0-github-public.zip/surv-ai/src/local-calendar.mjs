// Deterministic summaries/search over date-scoped SQLite results. No AI client.
export const normalize=value=>String(value||'').normalize('NFKC').toLowerCase().replace(/[^\p{L}\p{N}:]+/gu,' ').trim().replace(/\s+/g,' ');
export function validDate(value){
  if(typeof value!=='string'||!/^\d{4}-\d{2}-\d{2}$/.test(value)||!Number.isFinite(Date.parse(value+'T00:00:00Z'))||new Date(value+'T00:00:00Z').toISOString().slice(0,10)!==value)throw Error('Choose a valid calendar date.');
  return value;
}
export function clockHour(hour){return `${hour%12||12}:00 ${hour<12?'AM':'PM'}`;}
export function mondayOf(date){validDate(date);return addDays(date,-((new Date(date+'T00:00:00Z').getUTCDay()+6)%7));}
export function calendar(timeZone){
  if(typeof timeZone!=='string'||timeZone.length>100)throw Error('Choose a valid time zone.');
  let format;try{format=new Intl.DateTimeFormat('en-CA',{timeZone,year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',hourCycle:'h23'});}catch{throw Error('Choose a valid time zone.');}
  const parts=instant=>Object.fromEntries(format.formatToParts(new Date(instant)).filter(p=>p.type!=='literal').map(p=>[p.type,p.value]));
  const time=(instant,exact=false)=>new Intl.DateTimeFormat('en-US',{timeZone,hour:'numeric',minute:'2-digit',hour12:true,timeZoneName:'short',...(exact?{second:'2-digit',...(new Date(instant).getUTCMilliseconds()?{fractionalSecondDigits:3}:{})}:{})}).format(new Date(instant));
  return {date(instant){const p=parts(instant);return `${p.year}-${p.month}-${p.day}`;},hour:instant=>Number(parts(instant).hour),minutes(instant){const p=parts(instant);return Number(p.hour)*60+Number(p.minute);},time,timeExact:instant=>time(instant,true)};
}
export function addDays(date,count){const value=new Date(validDate(date)+'T00:00:00Z');value.setUTCDate(value.getUTCDate()+count);return value.toISOString().slice(0,10);}
export function dayBounds(date,timeZone){
  validDate(date);const clock=calendar(timeZone);
  // Find the first instant of the local date, including midnight offset changes
  // and 23/25-hour days. No assumption that every local day is 24 hours long.
  const boundary=day=>{const center=Date.parse(day+'T00:00:00Z');let lo=center-36*3600000,hi=center+36*3600000;while(lo<hi){const mid=Math.floor((lo+hi)/2);if(clock.date(mid)<day)lo=mid+1;else hi=mid;}return new Date(lo).toISOString();};
  return {from:boundary(date),to:boundary(addDays(date,1))};
}
export function rangeBounds(from,to,timeZone){
  validDate(from);validDate(to);const days=(Date.parse(to)-Date.parse(from))/86400000+1;
  if(days<1||days>31)throw Error('Choose a range of 1–31 calendar days.');
  return {from:dayBounds(from,timeZone).from,to:dayBounds(to,timeZone).to};
}
