import {randomUUID} from 'node:crypto';
import {calendar,rangeBounds,addDays} from './local-calendar.mjs';
import estimation from '../dist/usage-model.js';

const exists=storage=>!!storage.db.prepare("SELECT name FROM sqlite_master WHERE name='analysis_usage'").get();
// Created only by explicit monitoring/analysis, never by a dashboard read/startup.
export function initializeUsage(storage){
  if(exists(storage))return;
  storage.transaction(()=>storage.db.exec(`CREATE TABLE IF NOT EXISTS analysis_usage (
    id TEXT PRIMARY KEY,user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    session_id TEXT REFERENCES monitoring_sessions(id) ON DELETE CASCADE,
    kind TEXT NOT NULL CHECK(kind IN ('session','request')),source TEXT NOT NULL CHECK(source IN ('automatic_ai','manual_ai')),
    started_at TEXT NOT NULL,status TEXT NOT NULL CHECK(status IN ('context','pending','succeeded','failed')),
    interval_ms INTEGER,smart_surv INTEGER,configuration_changed INTEGER NOT NULL DEFAULT 0,
    requested_model TEXT,returned_model TEXT,input_tokens INTEGER,output_tokens INTEGER,total_tokens INTEGER,cached_tokens INTEGER
  ) STRICT; CREATE INDEX IF NOT EXISTS analysis_usage_owner_time ON analysis_usage(user_id,kind,started_at);
  CREATE INDEX IF NOT EXISTS analysis_usage_session ON analysis_usage(session_id);`));
}
export function sessionContext(storage,session,at){
  if(!storage.userId||!storage.session(session.id))throw Error('Owned monitoring session required.');
  initializeUsage(storage);const settings=storage.settings();
  storage.db.prepare("INSERT OR IGNORE INTO analysis_usage(id,user_id,session_id,kind,source,started_at,status,interval_ms,smart_surv) VALUES(?,?,?,'session','automatic_ai',?,'context',?,?)").run(session.id,storage.userId,session.id,at,settings.intervalMs,Number(settings.smartSurv));
}
export function configurationChanged(storage,before,after){
  if(!exists(storage)||before.intervalMs===after.intervalMs&&before.smartSurv===after.smartSurv&&(before.smartSurv!==false&&before.detectionOnlyRotation===true)===(after.smartSurv!==false&&after.detectionOnlyRotation===true))return;
  storage.db.prepare("UPDATE analysis_usage SET configuration_changed=1 WHERE kind='session' AND user_id=? AND session_id IN (SELECT id FROM monitoring_sessions WHERE user_id=? AND status='active')").run(storage.userId,storage.userId);
}
export function beginRequest(storage,{session=null,model,at}){
  if(!storage.userId||session&&!storage.session(session.id))throw Error('Owned analysis context required.');
  initializeUsage(storage);const id=randomUUID(),settings=storage.settings();
  storage.db.prepare("INSERT INTO analysis_usage(id,user_id,session_id,kind,source,started_at,status,interval_ms,smart_surv,requested_model) VALUES(?,?,?,'request',?,?,'pending',?,?,?)").run(id,storage.userId,session?.id??null,session?'automatic_ai':'manual_ai',at,session?.intervalMs??null,session?Number(settings.smartSurv):null,model);
  return id;
}
export function responseUsage(storage,id,data){
  if(!id)return;const t=estimation.tokens(data),model=typeof data?.model==='string'&&data.model.length<=100?data.model:null;
  storage.db.prepare('UPDATE analysis_usage SET returned_model=?,input_tokens=?,output_tokens=?,total_tokens=?,cached_tokens=? WHERE id=? AND user_id=?').run(model,t?.input??null,t?.output??null,t?.total??null,t?.cached??null,id,storage.userId);
}
export function finishRequest(storage,id,succeeded){if(id)storage.db.prepare('UPDATE analysis_usage SET status=? WHERE id=? AND user_id=?').run(succeeded?'succeeded':'failed',id,storage.userId);}

export function usageDashboard(storage,{from,to,timeZone,now=Date.now(),model='gpt-4.1-mini'}){
  if(!storage.userId)throw Error('Authenticated user required.');
  const bounds=rangeBounds(from,to,timeZone),clock=calendar(timeZone),has=exists(storage);
  const rows=has?storage.db.prepare("SELECT * FROM analysis_usage WHERE user_id=? AND kind='request' AND started_at>=? AND started_at<? ORDER BY started_at,id").all(storage.userId,bounds.from,bounds.to):[];
  const started=storage.sessions(bounds),spanning=storage.reportSessions(bounds),observations=storage.observations(bounds).filter(r=>r.source==='automatic_ai');
  const first=has?storage.db.prepare("SELECT MIN(started_at) first FROM analysis_usage WHERE user_id=?").get(storage.userId).first:null;
  const days=[];for(let date=from;date<=to;date=addDays(date,1))days.push({date,requests:0,automatic:0,manual:0,saved:0,cost:0,unpriced:0});
  const byDay=new Map(days.map(d=>[d.date,d]));let estimatedCost=0,priced=0,returnedTokens=0,assumedTokens=0,inputTokens=0,outputTokens=0;
  for(const r of rows){const day=byDay.get(clock.date(r.started_at));day.requests++;day[r.source==='automatic_ai'?'automatic':'manual']++;
    const c=estimation.cost({model:r.returned_model||r.requested_model,input:r.input_tokens,output:r.output_tokens,cached:r.cached_tokens});
    if(r.input_tokens!==null){returnedTokens++;inputTokens+=r.input_tokens;outputTokens+=r.output_tokens;}
    if(c.amount===null){day.unpriced++;continue;}if(c.basis==='assumed-tokens')assumedTokens++;priced++;estimatedCost+=c.amount;day.cost+=c.amount;
  }
  for(const r of observations)byDay.get(clock.date(r.timestamp)).saved++;
  const span=s=>Math.max(0,Math.min(now,Date.parse(bounds.to),Date.parse(s.ended_at||s.updated_at))-Math.max(Date.parse(bounds.from),Date.parse(s.started_at)));
  const spans=spanning.map(span),sum=key=>started.reduce((n,s)=>n+s[key],0),contexts=has?storage.db.prepare("SELECT * FROM analysis_usage WHERE kind='session' AND user_id=?").all(storage.userId):[];
  // A personal observed utilization is not a detector-only pass rate. Require
  // complete, stable ON sessions; exclude active/interrupted/config-changing runs.
  let historyRequests=0,historySlots=0,historyMs=0,historySessions=0;
  for(const s of spanning){const context=contexts.find(c=>c.session_id===s.id);if(!context||context.configuration_changed||context.smart_surv!==1||s.status!=='completed'||s.started_at<bounds.from||s.ended_at>=bounds.to)continue;
    const elapsed=Date.parse(s.ended_at)-Date.parse(s.started_at),requests=rows.filter(r=>r.session_id===s.id);
    if(elapsed<300000||requests.length!==s.api_requests||requests.some(r=>r.interval_ms!==context.interval_ms||r.smart_surv!==1))continue;
    const slots=Math.floor(elapsed/context.interval_ms)+1;if(requests.length>slots)continue;
    historySlots+=slots;historyRequests+=requests.length;historyMs+=elapsed;historySessions++;
  }
  const sufficient=historyMs>=1800000&&historyRequests>=5,history={available:sufficient,rate:sufficient?historyRequests/historySlots:null,requests:historyRequests,theoreticalSlots:historySlots,sessionMs:historyMs,sessions:historySessions,gateRate:null,reason:'Eligible person-gate checks were not recorded. Local skip counters count checks, not requests avoided.'};
  const unit=estimation.cost({model});
  return {from,to,timeZone,reportedAt:new Date(now).toISOString(),trackingStartedAt:first,
    actual:{automaticRequests:rows.filter(r=>r.source==='automatic_ai').length,manualRequests:rows.filter(r=>r.source==='manual_ai').length,successful:rows.filter(r=>r.status==='succeeded').length,failed:rows.filter(r=>r.status==='failed').length,pending:rows.filter(r=>r.status==='pending').length,savedAutomatic:observations.length,sessions:spanning.length,activeSessions:spanning.filter(r=>r.status==='active').length,sessionSpanMs:spans.reduce((a,b)=>a+b,0),longestSpanMs:Math.max(0,...spans),averageSpanMs:spans.length?spans.reduce((a,b)=>a+b,0)/spans.length:0,estimatedCost:priced?estimatedCost:rows.length||observations.length||sum('api_requests')?null:0,pricedRequests:priced,unpricedRequests:rows.length-priced,returnedTokenRequests:returnedTokens,assumedTokenRequests:assumedTokens,inputTokens,outputTokens},
    sessionCounters:{sessions:started.length,requests:sum('api_requests'),successful:sum('successful_analyses'),failed:sum('failed_analyses'),noPerson:sum('no_person_skipped'),invalid:sum('invalid_frame_skipped'),scope:'Whole-run counters for sessions started in the selected period; may include later requests/checks.'},
    config:{...storage.settings(),model,unitCost:unit.amount,unitCostBasis:unit.basis},history,byDay:days,pricing:estimation.pricing,
    labels:{cost:'Estimated, not billed cost',projection:'Hypothetical projection',duration:'Recorded session span; camera-hours, not capture uptime or activity duration.'}};
}
