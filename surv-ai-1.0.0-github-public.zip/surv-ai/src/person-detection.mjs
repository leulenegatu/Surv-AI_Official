import {verifiedDatabaseBackup} from './database-backup.mjs';
export const DEFAULT_PERSON_THRESHOLD=.25,MIN_PERSON_THRESHOLD=.20,MAX_PERSON_THRESHOLD=.75,DETECTION_FRESH_MS=5000;
const hasSettings=s=>!!s.db.prepare("SELECT name FROM sqlite_master WHERE name='person_detection_settings'").get();
export function detectionSettings(s){return {confidenceThreshold:hasSettings(s)?s.db.prepare('SELECT confidence_threshold FROM person_detection_settings WHERE user_id=?').get(s.userId)?.confidence_threshold??DEFAULT_PERSON_THRESHOLD:DEFAULT_PERSON_THRESHOLD};}
export function setDetectionSettings(s,body){
  if(Object.keys(body).some(k=>k!=='confidenceThreshold')||typeof body.confidenceThreshold!=='number'||!Number.isFinite(body.confidenceThreshold)||body.confidenceThreshold<MIN_PERSON_THRESHOLD||body.confidenceThreshold>MAX_PERSON_THRESHOLD)throw Object.assign(Error('Choose a person confidence threshold from 0.20 to 0.75.'),{status:400});
  if(!hasSettings(s))try{verifiedDatabaseBackup(s,'pre-person-detection');}catch(e){throw Object.assign(Error('Could not create a verified detector settings backup.'),{status:507,cause:e});}
  return s.transaction(()=>{s.db.exec('CREATE TABLE IF NOT EXISTS person_detection_settings(user_id TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,confidence_threshold REAL NOT NULL CHECK(confidence_threshold>=0.20 AND confidence_threshold<=0.75)) STRICT;');s.db.prepare('INSERT INTO person_detection_settings VALUES(?,?) ON CONFLICT(user_id) DO UPDATE SET confidence_threshold=excluded.confidence_threshold').run(s.userId,body.confidenceThreshold);return detectionSettings(s);});
}
export function detectionResult(frame,threshold,now,timestamp){
  const confidence=typeof frame.personConfidence==='number'&&Number.isFinite(frame.personConfidence)&&frame.personConfidence>=0&&frame.personConfidence<=1?frame.personConfidence:null;
  const captured=Date.parse(timestamp),stale=!Number.isFinite(captured)||Math.abs(now-captured)>DETECTION_FRESH_MS,valid=frame.frameValid===true;
  const status=!valid?'invalid':stale?'stale':(confidence===null?frame.personPresent===true:confidence>=threshold)?'person':'none';
  return {...frame,frameValid:valid,personPresent:status==='person',personConfidence:confidence,confidenceThreshold:threshold,detectionStatus:status,decision:({person:'Person detected',none:'No person detected',invalid:'Invalid frame',stale:'Stale detection result'})[status],detectionAt:new Date(now).toISOString(),frameCapturedAt:Number.isFinite(captured)?timestamp:null};
}
