import {randomUUID} from 'node:crypto';
import {DatabaseSync} from 'node:sqlite';
import {mkdirSync} from 'node:fs';
import path from 'node:path';
export const hasContext=s=>!!s.db.prepare("SELECT name FROM sqlite_master WHERE name='context_sessions'").get();
// Call before the preference transaction. Existing installations receive a
// consistent, verified backup before the first independent-mode schema write.
export function prepareContextSchema(s){
  if(hasContext(s))return;
  const file=s.db.prepare('PRAGMA database_list').get().file;
  if(file){const folder=path.join(path.dirname(file),'backups');mkdirSync(folder,{recursive:true});const backup=path.join(folder,'pre-independent-'+randomUUID()+'.sqlite');s.db.prepare('VACUUM INTO ?').run(backup);const check=new DatabaseSync(backup,{readOnly:true});try{if(check.prepare('PRAGMA integrity_check').get().integrity_check!=='ok'||check.prepare('PRAGMA foreign_key_check').all().length)throw Error('Context backup verification failed.');}finally{check.close();}}
}
export function ensureContextSchema(s){
  s.db.exec(`CREATE TABLE IF NOT EXISTS context_sessions(
    id TEXT PRIMARY KEY,user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    started_at TEXT NOT NULL,ended_at TEXT,status TEXT NOT NULL CHECK(status IN ('active','paused','completed','interrupted')),
    end_reason TEXT,updated_at TEXT NOT NULL,last_sample_at TEXT,last_success_at TEXT,
    desktop_status TEXT NOT NULL DEFAULT 'awaiting_sample',browser_status TEXT NOT NULL DEFAULT 'not_paired',gap_count INTEGER NOT NULL DEFAULT 0);
    CREATE INDEX IF NOT EXISTS context_sessions_owner_time ON context_sessions(user_id,started_at,updated_at);
    CREATE TABLE IF NOT EXISTS context_spans(
    id TEXT PRIMARY KEY,user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    context_session_id TEXT NOT NULL REFERENCES context_sessions(id) ON DELETE CASCADE,
    camera_session_id TEXT REFERENCES monitoring_sessions(id) ON DELETE SET NULL,
    camera_id TEXT REFERENCES cameras(id) ON DELETE SET NULL,
    camera_assisted INTEGER NOT NULL CHECK(camera_assisted IN (0,1)),
    started_at TEXT NOT NULL,confirmed_through TEXT NOT NULL,executable TEXT,application TEXT,title TEXT,
    state TEXT NOT NULL CHECK(state IN ('active','idle','locked','unavailable','unknown')),
    browser TEXT,hostname TEXT,tab_title TEXT,browser_sampled_at TEXT);
    CREATE INDEX IF NOT EXISTS context_spans_owner_time ON context_spans(user_id,confirmed_through,started_at);`);
  if(!s.db.prepare('PRAGMA table_info(desktop_settings)').all().some(c=>c.name==='independent_enabled'))s.db.exec('ALTER TABLE desktop_settings ADD COLUMN independent_enabled INTEGER NOT NULL DEFAULT 0 CHECK(independent_enabled IN (0,1))');
}
export function contextSession(s,id){return hasContext(s)?s.db.prepare('SELECT * FROM context_sessions WHERE id=? AND user_id=?').get(id,s.userId):null;}
export function contextSessions(s,bounds){return hasContext(s)?s.db.prepare('SELECT * FROM context_sessions WHERE user_id=?'+(bounds?' AND started_at<? AND COALESCE(ended_at,updated_at)>=?':'')+' ORDER BY started_at DESC,id').all(s.userId,...(bounds?[bounds.to,bounds.from]:[])):[];}
export function createContextSession(s,at){const id=randomUUID();s.db.prepare("INSERT INTO context_sessions(id,user_id,started_at,status,updated_at) VALUES(?,?,?,'active',?)").run(id,s.userId,at,at);return contextSession(s,id);}
export function updateContextSession(s,id,{status,reason=null,at,sample=null,browserStatus='not_paired',gap=false}={}){
  s.db.prepare('UPDATE context_sessions SET status=?,end_reason=?,ended_at=?,updated_at=?,last_sample_at=COALESCE(?,last_sample_at),last_success_at=COALESCE(?,last_success_at),desktop_status=COALESCE(?,desktop_status),browser_status=?,gap_count=gap_count+? WHERE id=? AND user_id=?').run(status,reason,['completed','interrupted'].includes(status)?at:null,at,sample?.sampledAt||null,sample&&sample.state!=='unavailable'?sample.sampledAt:null,sample?.state||null,browserStatus,+gap,id,s.userId);
}
export function insertContextSpan(s,session,sample,camera=null){
  if(!contextSession(s,session.id))throw Error('Owned context session is unavailable.');
  if(camera&&s.session(camera.id)?.camera_id!==camera.cameraId)throw Error('Owned camera association is unavailable.');
  const span={id:randomUUID(),user_id:s.userId,context_session_id:session.id,camera_session_id:camera?.id||null,camera_id:camera?.cameraId||null,camera_assisted:camera?1:0,started_at:sample.sampledAt,confirmed_through:sample.sampledAt,executable:sample.executable,application:sample.application,title:sample.title,state:sample.state,browser:sample.browser||null,hostname:sample.hostname||null,tab_title:sample.tabTitle||null,browser_sampled_at:sample.browserSampledAt||null};
  s.db.prepare('INSERT INTO context_spans VALUES('+Object.keys(span).map(()=>'?').join(',')+')').run(...Object.values(span));return span;
}
export function recoverContextSessions(s,at){if(hasContext(s))s.db.prepare("UPDATE context_sessions SET status='interrupted',ended_at=updated_at,end_reason='server_restart' WHERE status IN ('active','paused')").run();}
