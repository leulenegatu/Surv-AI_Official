import {normalize,calendar,addDays,clockHour} from './local-calendar.mjs';
export {normalize,validDate,calendar,addDays,dayBounds,rangeBounds} from './local-calendar.mjs';
function frequency(values){const counts=new Map();for(const value of values){const key=normalize(value);if(key)counts.set(key,(counts.get(key)||0)+1);}return [...counts].map(([label,count])=>({label,count})).sort((a,b)=>b.count-a.count||a.label.localeCompare(b.label));}
export function cameraLabel(record,cameras=[]){return record.cameraId?(cameras.find(c=>c.id===record.cameraId)?.name||record.cameraName||'Unknown camera'):record.source==='manual_ai'?'Manual AI · no camera':'Unassigned camera';}
export function analytics(records,sessions,{from,to,timeZone,cameras=[]}){
  const clock=calendar(timeZone),daily=[];for(let day=from;day<=to;day=addDays(day,1))daily.push({label:day,count:0});
  const hourly=Array.from({length:24},(_,hour)=>({label:String(hour).padStart(2,'0')+':00',count:0})),byCamera=new Map();
  for(const record of records){daily.find(d=>d.label===clock.date(record.timestamp)).count++;hourly[clock.hour(record.timestamp)].count++;const key=record.cameraId||record.source,label=cameraLabel(record,cameras);if(!byCamera.has(key))byCamera.set(key,{id:record.cameraId,label,count:0});byCamera.get(key).count++;}
  const objects=frequency(records.flatMap(record=>[...new Set(record.objects.map(normalize))]));
  const sum=key=>sessions.reduce((n,s)=>n+s[key],0);
  return {from,to,timeZone,totals:{observations:records.length,automatic:records.filter(r=>r.source==='automatic_ai').length,manual:records.filter(r=>r.source==='manual_ai').length,averageConfidence:records.length?records.reduce((n,r)=>n+r.confidence,0)/records.length:null,monitoringSessions:sessions.length,apiRequests:sum('api_requests'),successfulAnalyses:sum('successful_analyses'),failedAnalyses:sum('failed_analyses'),noPersonSkipped:sum('no_person_skipped'),invalidFrameSkipped:sum('invalid_frame_skipped')},byDay:daily,byHour:hourly,byCamera:[...byCamera.values()].sort((a,b)=>b.count-a.count||a.label.localeCompare(b.label)),activities:frequency(records.map(r=>r.activity)),objects};
}
export function insights(records,sessions,{date,timeZone,cameras=[],previousRecords=[]}){
  const data=analytics(records,sessions,{from:date,to:date,timeZone,cameras}),cards=[],n=data.totals.observations;
  const card=(title,text)=>cards.push({title,text});
  if(n){
    const activity=data.activities[0];card('Most recorded activity',`“${activity.label}” appeared in ${activity.count} of ${n} observations. Frequency does not establish time spent.`);
    if(data.objects.length){const object=data.objects[0];card('Most visible object',`“${object.label}” was listed in ${object.count} observations. Visibility does not establish use or an action.`);}
    const max=Math.max(...data.byHour.map(h=>h.count)),hours=data.byHour.filter(h=>h.count===max).map(h=>clockHour(Number(h.label.split(':')[0])));card('Busiest observation hour',`${hours.join(', ')} recorded ${max} observations per hour. This describes sampling frequency, not activity intensity.`);
    const camera=data.byCamera.filter(c=>c.id)[0];if(camera)card('Camera coverage',`${camera.label} produced ${camera.count} observations. Older unassigned observations retain their unknown camera identity.`);
    card('Observation sources',`${data.totals.automatic} automatic and ${data.totals.manual} manual observations were saved. Average AI confidence estimate: ${Math.round(data.totals.averageConfidence*100)}%.`);
    if(previousRecords.length)card('Compared with previous day',`${n} observations on ${date}, compared with ${previousRecords.length} on ${addDays(date,-1)}. Changes in sampling do not establish changes in behavior.`);
  }
  if(sessions.length){const t=data.totals;card('Monitoring results',`Runs started on this date recorded ${t.successfulAnalyses} successes and ${t.failedAnalyses} failures from ${t.apiRequests} API requests. A pending or interrupted request may have no recorded outcome.`);card('Local gate checks',`${t.noPersonSkipped} no-person skips and ${t.invalidFrameSkipped} invalid-frame skips were recorded in those runs. These are checks, not Away periods.`);}
  return {date,timeZone,observations:n,cards,empty:!n&&!sessions.length};
}

export {askLocal} from './local-query.mjs';
