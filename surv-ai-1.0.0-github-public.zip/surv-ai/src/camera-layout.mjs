import {randomUUID} from 'node:crypto';
import {verifiedDatabaseBackup} from './database-backup.mjs';
export const hasCameraLayout=s=>!!s.db.prepare("SELECT name FROM sqlite_master WHERE name='camera_layout'").get();
export function prepareCameraLayout(s){
  if(hasCameraLayout(s))return;
  try{verifiedDatabaseBackup(s,'pre-camera-layout');}catch(e){throw Error('Could not create a verified camera backup before updating configuration.',{cause:e});}
}
export function ensureCameraLayout(s){s.db.exec(`
  CREATE TABLE IF NOT EXISTS camera_areas(id TEXT PRIMARY KEY,user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,name TEXT NOT NULL,created_at TEXT NOT NULL) STRICT;
  CREATE TABLE IF NOT EXISTS camera_layout(camera_id TEXT PRIMARY KEY REFERENCES cameras(id) ON DELETE CASCADE,user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,area_id TEXT REFERENCES camera_areas(id) ON DELETE SET NULL,rotation INTEGER NOT NULL DEFAULT 0 CHECK(rotation IN (0,90,180,270)),order_index INTEGER CHECK(order_index>=0)) STRICT;
`);}
export function cameraAreas(s){return hasCameraLayout(s)?s.db.prepare('SELECT id,name,created_at FROM camera_areas WHERE user_id=? ORDER BY created_at,id').all(s.userId):[];}
export function decorateCameras(s,rows){
  const preferences=hasCameraLayout(s)?new Map(s.db.prepare('SELECT * FROM camera_layout WHERE '+s.owned()).all(...s.ownerArgs()).map(v=>[v.camera_id,v])):new Map();
  let nextOrder=Math.max(-1,...rows.map(c=>preferences.get(c.id)?.order_index??-1))+1;
  return rows.map(c=>({...c,area_id:preferences.get(c.id)?.area_id||null,rotation:preferences.get(c.id)?.rotation||0,sort_order:preferences.get(c.id)?.order_index??nextOrder++})).sort((a,b)=>a.sort_order-b.sort_order||a.created_at.localeCompare(b.created_at)||a.id.localeCompare(b.id));
}
export function validateCameraLayout(s,value){
  if(value.rotation!==undefined&&![0,90,180,270].includes(value.rotation))throw Error('Choose a camera rotation of 0, 90, 180 or 270 degrees.');
  if(value.areaId!==undefined&&value.areaId!==null&&(typeof value.areaId!=='string'||!cameraAreas(s).some(a=>a.id===value.areaId)))throw Error('Choose one of your Camera Areas.');
}
export function saveCameraLayout(s,id,value,update=()=>{}){
  validateCameraLayout(s,value);if(value.rotation===undefined&&value.areaId===undefined){update();return;}
  if(!s.camera(id))throw Error('Camera not found.');prepareCameraLayout(s);
  s.transaction(()=>{ensureCameraLayout(s);s.db.prepare('INSERT INTO camera_layout(camera_id,user_id) VALUES(?,?) ON CONFLICT(camera_id) DO NOTHING').run(id,s.userId);if(value.rotation!==undefined)s.db.prepare('UPDATE camera_layout SET rotation=? WHERE camera_id=? AND user_id=?').run(value.rotation,id,s.userId);if(value.areaId!==undefined)s.db.prepare('UPDATE camera_layout SET area_id=? WHERE camera_id=? AND user_id=?').run(value.areaId,id,s.userId);update();});
}
export function saveCameraOrder(s,ids){
  const cameras=s.cameras();if(!Array.isArray(ids)||ids.length!==cameras.length||new Set(ids).size!==ids.length||ids.some(id=>!cameras.some(c=>c.id===id)))throw Error('Order must contain each of your configured cameras exactly once.');
  prepareCameraLayout(s);s.transaction(()=>{ensureCameraLayout(s);ids.forEach((id,i)=>s.db.prepare('INSERT INTO camera_layout(camera_id,user_id,order_index) VALUES(?,?,?) ON CONFLICT(camera_id) DO UPDATE SET order_index=excluded.order_index WHERE camera_layout.user_id=excluded.user_id').run(id,s.userId,i));});return s.cameras();
}
export function saveCameraArea(s,value,id=null){
  if(Object.keys(value).some(k=>!['name','remove'].includes(k))||value.remove!==undefined&&typeof value.remove!=='boolean')throw Error('Unsupported Camera Area fields.');
  if(id&&!cameraAreas(s).some(a=>a.id===id))throw Object.assign(Error('Camera Area not found.'),{status:404});
  if(value.remove&&!id)throw Error('Choose a Camera Area to delete.');
  if(!value.remove&&(typeof value.name!=='string'||!value.name.trim()||value.name.trim().length>80))throw Error('Use an Area name of 1–80 characters.');
  prepareCameraLayout(s);s.transaction(()=>{ensureCameraLayout(s);if(value.remove)s.db.prepare('DELETE FROM camera_areas WHERE id=? AND user_id=?').run(id,s.userId);else if(id)s.db.prepare('UPDATE camera_areas SET name=? WHERE id=? AND user_id=?').run(value.name.trim(),id,s.userId);else{id=randomUUID();s.db.prepare('INSERT INTO camera_areas VALUES(?,?,?,?)').run(id,s.userId,value.name.trim(),new Date().toISOString());}});return cameraAreas(s);
}
