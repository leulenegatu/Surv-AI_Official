import {createHash} from 'node:crypto';
import {desktopSpanRows} from './desktop-store.mjs';
import {rangeBounds} from './local-calendar.mjs';
const normalized=t=>t===null?'':t.normalize('NFC').trim().replace(/\s+/gu,' ').toLowerCase();
const titleKey=r=>createHash('sha256').update(JSON.stringify([r.hostname||'',r.provenance,normalized(r.hostname?r.tab_title:r.title)])).digest('hex');
export function desktopExplorer(s,params,now=Date.now()){
  const {from,to,timeZone,level='applications',application='',hostname='',titleKey:chosen='',search='',sort='duration',page='0'}=params;
  if(!['applications','domains','titles','spans'].includes(level)||level!=='applications'&&!application||!['duration','alpha','time'].includes(sort)||!/^(0|[1-9]\d{0,5})$/.test(page)||application.length>120||hostname.length>253||search.length>160||chosen&&!/^[a-f0-9]{64}$/.test(chosen))throw Error('Choose valid Desktop Context filters.');
  const bounds=rangeBounds(from,to,timeZone),app=application.toLowerCase(),groups=new Map();let items=[],totalMs=0,unattributedMs=0,appearances=0;
  // Stream the owned date range; application/domain views do not materialize a
  // month's raw transitions. Only the selected title's leaves are inspected.
  for(const raw of desktopSpanRows(s,bounds)){
    const start=Math.max(Date.parse(bounds.from),Date.parse(raw.started_at)),end=Math.min(now,Date.parse(bounds.to),Date.parse(raw.confirmed_through)),ms=Math.max(0,end-start);
    if(!ms||!raw.executable||app&&raw.executable.toLowerCase()!==app||(level==='titles'||level==='spans')&&(raw.hostname||'')!==hostname||level==='spans'&&titleKey(raw)!==chosen)continue;
    const r={...raw,start:new Date(start).toISOString(),end:new Date(end).toISOString(),ms};totalMs+=ms;appearances++;if(!r.hostname)unattributedMs+=ms;
    if(level==='spans'){items.push({key:r.id,label:(r.hostname?r.tab_title:r.title)||'Title unavailable or sharing disabled',...r,activeMs:r.state==='active'?r.ms:0,idleMs:r.state==='idle'?r.ms:0,appearances:1});continue;}
    const key=level==='applications'?r.executable.toLowerCase():level==='domains'?(r.hostname||''):titleKey(r),title=r.hostname?r.tab_title:r.title;
      const label=level==='applications'?(r.application||r.executable):level==='domains'?(r.hostname||'Windows context · domain unavailable'):(title||'Title unavailable or sharing disabled');
      const v=groups.get(key)||{key,label,ms:0,activeMs:0,idleMs:0,appearances:0,domains:new Set(),titles:new Set(),provenance:r.provenance,executable:r.executable,first:r.start,last:r.end};
      v.ms+=r.ms;v.appearances++;if(r.state==='active')v.activeMs+=r.ms;if(r.state==='idle')v.idleMs+=r.ms;if(r.hostname)v.domains.add(r.hostname);if(title)v.titles.add(titleKey(r));v.first=r.start<v.first?r.start:v.first;v.last=r.end>v.last?r.end:v.last;groups.set(key,v);
  }
  if(level!=='spans')items=[...groups.values()].map(v=>({...v,domainCount:v.domains.size,titleCount:v.titles.size,domains:undefined,titles:undefined}));
  items=items.filter(v=>v.label.toLowerCase().includes(search.normalize('NFC').toLowerCase())).sort(sort==='alpha'?(a,b)=>a.label.localeCompare(b.label):sort==='time'?(a,b)=>(b.start||b.last).localeCompare(a.start||a.last):(a,b)=>b.ms-a.ms||a.label.localeCompare(b.label));
  const size=25,index=Number(page),total=items.length;
  return {level,from,to,timeZone,totalMs,unattributedMs,appearances,total,page:index,pageSize:size,items:items.slice(index*size,(index+1)*size),semantics:'Confirmed foreground samples; gaps excluded. Hostnames are exact hosts, not inferred registrable domains.'};
}
