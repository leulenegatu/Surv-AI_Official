import {DatabaseSync} from 'node:sqlite';
import {mkdirSync} from 'node:fs';
import path from 'node:path';
import {randomUUID} from 'node:crypto';
import observation from '../dist/observation.js';
import {migrateOwnership} from './ownership-migration.mjs';
import {observationDesktop} from './desktop-store.mjs';
import {decorateCameras,validateCameraLayout,saveCameraLayout} from './camera-layout.mjs';
import {verifiedDatabaseBackup} from './database-backup.mjs';

const uuid=/^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/i;
export const LOCAL_CAMERA_ID='local-webcam';
export const INTERVALS=[15000,30000,60000];
export function observationRecord(value,{legacy=false,draft=false}={}){
  const clean=observation.validateObservation(value);
  if(!uuid.test(value.id)||!['manual_ai','automatic_ai'].includes(value.source))throw Error('Invalid observation identity or source.');
  if(value.context!==undefined&&(typeof value.context!=='string'||value.context.length>300))throw Error('Context must be at most 300 characters.');
  const snapshotRef=value.snapshotRef??null;
  if(snapshotRef!==null&&!/^[a-f0-9-]{36}\.(jpg|png|webp)$/.test(snapshotRef))throw Error('Invalid snapshot reference.');
  const monitoringSessionId=legacy?null:value.monitoringSessionId??null;
  if(monitoringSessionId!==null&&!uuid.test(monitoringSessionId))throw Error('Invalid monitoring session.');
  if(value.source==='manual_ai'&&monitoringSessionId!==null)throw Error('Manual observations cannot belong to automatic monitoring.');
  if(!legacy&&value.source==='automatic_ai'&&!monitoringSessionId)throw Error('Automatic observations require a monitoring session.');
  const cameraId=legacy?null:value.cameraId??null,cameraName=legacy?null:value.cameraName??null;
  if(cameraId!==null&&(typeof cameraId!=='string'||!cameraId.length||cameraId.length>80))throw Error('Invalid camera identity.');
  if(cameraName!==null&&(typeof cameraName!=='string'||!cameraName.trim()||cameraName.length>80))throw Error('Invalid camera name.');
  if((cameraId===null)!==(cameraName===null))throw Error('Camera identity and name must be supplied together.');
  return {...clean,id:value.id,timestamp:new Date(observation.validateTimestamp(value.timestamp)).toISOString(),source:value.source,snapshotRef,monitoringSessionId,cameraId,cameraName,context:(value.context||'').trim(),legacyImported:legacy};
}

// The app uses observations and monitoring sessions through this adapter only.
export class LocalStorage{
  constructor(filename){
    if(filename!==':memory:')mkdirSync(path.dirname(filename),{recursive:true});
    this.db=new DatabaseSync(filename);
    this.db.exec(`PRAGMA foreign_keys=ON; PRAGMA busy_timeout=5000; PRAGMA journal_mode=WAL; PRAGMA synchronous=FULL;`);
    const version=this.db.prepare('PRAGMA user_version').get().user_version;
    if(version>5){this.db.close();throw Error('This database requires a newer Surv-AI version.');}
    // VACUUM INTO includes committed WAL data. Never migrate an existing file
    // unless its independent, consistent backup has succeeded first.
    if(version>0&&version<4&&filename!==':memory:'){
      const directory=path.join(path.dirname(filename),'backups');
      this.migrationBackup=path.join(directory,`pre-v04-${new Date().toISOString().replace(/[:.]/g,'-')}-${randomUUID()}.sqlite`);
      try{mkdirSync(directory,{recursive:true});this.db.prepare('VACUUM INTO ?').run(this.migrationBackup);}catch(e){this.db.close();throw Error('Could not back up local history before updating settings.',{cause:e});}
    }
    if(version===0)this.db.exec(`
      CREATE TABLE IF NOT EXISTS monitoring_sessions (
        id TEXT PRIMARY KEY, started_at TEXT NOT NULL, ended_at TEXT,
        camera_source TEXT NOT NULL, interval_ms INTEGER NOT NULL CHECK(interval_ms=15000),
        status TEXT NOT NULL CHECK(status IN ('active','completed','interrupted')), end_reason TEXT,
        api_requests INTEGER NOT NULL DEFAULT 0 CHECK(api_requests>=0),
        successful_analyses INTEGER NOT NULL DEFAULT 0 CHECK(successful_analyses>=0),
        failed_analyses INTEGER NOT NULL DEFAULT 0 CHECK(failed_analyses>=0),
        no_person_skipped INTEGER NOT NULL DEFAULT 0 CHECK(no_person_skipped>=0),
        invalid_frame_skipped INTEGER NOT NULL DEFAULT 0 CHECK(invalid_frame_skipped>=0),
        last_request_at TEXT, updated_at TEXT NOT NULL
      ) STRICT;
      CREATE TABLE IF NOT EXISTS observations (
        id TEXT PRIMARY KEY, timestamp TEXT NOT NULL, activity TEXT NOT NULL, location TEXT NOT NULL,
        description TEXT NOT NULL, confidence REAL NOT NULL CHECK(confidence>=0 AND confidence<=1),
        objects_json TEXT NOT NULL, source TEXT NOT NULL CHECK(source IN ('manual_ai','automatic_ai')),
        monitoring_session_id TEXT REFERENCES monitoring_sessions(id), snapshot_ref TEXT,
        user_context TEXT NOT NULL DEFAULT '', legacy_imported INTEGER NOT NULL DEFAULT 0,
        CHECK(source!='manual_ai' OR monitoring_session_id IS NULL)
      ) STRICT;
      CREATE INDEX IF NOT EXISTS observations_timestamp ON observations(timestamp DESC);
      CREATE INDEX IF NOT EXISTS observations_session ON observations(monitoring_session_id);
      PRAGMA user_version=1;
    `);
    if(version<2)this.migrateV2();
    if(version<3)this.migrateV3();
    if(version<4)this.transaction(()=>this.db.exec('ALTER TABLE app_settings ADD COLUMN save_snapshots INTEGER NOT NULL DEFAULT 1 CHECK(save_snapshots IN (0,1)); PRAGMA user_version=4;'));
    try{if(version<5)this.ownershipBackup=migrateOwnership(this.db,filename,{backup:version>0});this.validateOwnership();}catch(e){this.db.close();throw e;}
  }
  validateOwnership(){
    for(const table of ['observations','monitoring_sessions','cameras','app_settings'])if(!this.db.prepare(`PRAGMA table_info(${table})`).all().some(c=>c.name==='user_id'))throw Error('Incomplete account migration; restore the verified backup before retrying.');
    if(this.db.prepare('PRAGMA foreign_key_check').all().length)throw Error('Account ownership integrity check failed. History was not reset.');
    const owner=this.db.prepare('SELECT owner_user_id FROM installation WHERE id=1').get();if(!owner)throw Error('Installation ownership state is missing.');
    if(owner.owner_user_id===null&&this.db.prepare('SELECT COUNT(*) n FROM users').get().n)throw Error('Installation owner state is inconsistent.');
  }
  forUser(userId){if(!uuid.test(userId||''))throw Error('Authenticated user required.');const view=Object.create(this);view.userId=userId;return view;}
  owned(alias=''){return this.userId?`${alias}user_id=?`:'1=1';}
  ownerArgs(){return this.userId?[this.userId]:[];}
  publicRow(row){if(!row)return null;const {user_id,...data}=row;return data;}
  migrateV3(){
    this.transaction(()=>this.db.exec(`
      ALTER TABLE cameras ADD COLUMN enabled INTEGER NOT NULL DEFAULT 1 CHECK(enabled IN (0,1));
      ALTER TABLE cameras ADD COLUMN device_id TEXT;
      ALTER TABLE cameras ADD COLUMN updated_at TEXT;
      ALTER TABLE cameras ADD COLUMN deleted_at TEXT;
      UPDATE cameras SET updated_at=created_at;
      CREATE UNIQUE INDEX cameras_device ON cameras(device_id) WHERE device_id IS NOT NULL AND deleted_at IS NULL;
      CREATE INDEX observations_camera_date ON observations(camera_id,timestamp);
      CREATE INDEX observations_source_date ON observations(source,timestamp);
      PRAGMA user_version=3;
    `));
  }
  migrateV2(){
    // Rebuild only the fixed-interval session table. IDs, counters and foreign-key
    // targets remain identical; old observations receive NULL camera fields.
    this.db.exec('PRAGMA foreign_keys=OFF');let closed=false;
    try{this.transaction(()=>{
      this.db.exec(`
        CREATE TABLE cameras (id TEXT PRIMARY KEY,name TEXT NOT NULL,source TEXT NOT NULL CHECK(source='local-webcam'),configured INTEGER NOT NULL DEFAULT 1 CHECK(configured=1),created_at TEXT NOT NULL) STRICT;
        CREATE TABLE app_settings (id INTEGER PRIMARY KEY CHECK(id=1),interval_ms INTEGER NOT NULL CHECK(interval_ms IN (15000,30000,60000))) STRICT;
        INSERT INTO app_settings VALUES (1,15000);
        CREATE TABLE monitoring_sessions_v2 (
          id TEXT PRIMARY KEY,started_at TEXT NOT NULL,ended_at TEXT,camera_source TEXT NOT NULL,
          interval_ms INTEGER NOT NULL CHECK(interval_ms IN (15000,30000,60000)),
          status TEXT NOT NULL CHECK(status IN ('active','completed','interrupted')),end_reason TEXT,
          api_requests INTEGER NOT NULL DEFAULT 0 CHECK(api_requests>=0),successful_analyses INTEGER NOT NULL DEFAULT 0 CHECK(successful_analyses>=0),
          failed_analyses INTEGER NOT NULL DEFAULT 0 CHECK(failed_analyses>=0),no_person_skipped INTEGER NOT NULL DEFAULT 0 CHECK(no_person_skipped>=0),
          invalid_frame_skipped INTEGER NOT NULL DEFAULT 0 CHECK(invalid_frame_skipped>=0),last_request_at TEXT,updated_at TEXT NOT NULL,
          camera_id TEXT REFERENCES cameras(id),camera_name TEXT
        ) STRICT;
        INSERT INTO monitoring_sessions_v2 SELECT *,NULL,NULL FROM monitoring_sessions;
        DROP TABLE monitoring_sessions;
        ALTER TABLE monitoring_sessions_v2 RENAME TO monitoring_sessions;
        ALTER TABLE observations ADD COLUMN camera_id TEXT REFERENCES cameras(id);
        ALTER TABLE observations ADD COLUMN camera_name TEXT;
        CREATE INDEX observations_camera ON observations(camera_id);
        PRAGMA user_version=2;
      `);
      this.db.prepare('INSERT INTO cameras(id,name,source,created_at) VALUES (?,?,?,?)').run(LOCAL_CAMERA_ID,'Office','local-webcam',new Date().toISOString());
      if(this.db.prepare('PRAGMA foreign_key_check').all().length)throw Error('Camera migration failed its data integrity check.');
    });}catch(e){this.db.close();closed=true;throw e;}finally{if(!closed)this.db.exec('PRAGMA foreign_keys=ON');}
  }
  transaction(action){this.db.exec('BEGIN IMMEDIATE');try{const result=action();this.db.exec('COMMIT');return result;}catch(e){this.db.exec('ROLLBACK');throw e;}}
  decode(row){if(!row)return null;const desktopContext=observationDesktop(this,row.id);return {id:row.id,timestamp:row.timestamp,activity:row.activity,location:row.location,description:row.description,confidence:row.confidence,objects:JSON.parse(row.objects_json),source:row.source,monitoringSessionId:row.monitoring_session_id,snapshotRef:row.snapshot_ref,context:row.user_context,legacyImported:!!row.legacy_imported,cameraId:row.camera_id,cameraName:row.camera_name,recordType:'observation',duration:null,...(desktopContext?{desktopContext}:{}),...(this.privacySchema&&this.db.prepare('SELECT observation_id FROM expired_snapshot_records WHERE observation_id=?').get(row.id)?{snapshotExpired:true}:{})};}
  getObservation(id){return this.decode(this.db.prepare(`SELECT * FROM observations WHERE id=? AND ${this.owned()}`).get(id,...this.ownerArgs()));}
  latestForCamera(id){return this.decode(this.db.prepare(`SELECT * FROM observations WHERE camera_id=? AND ${this.owned()} ORDER BY timestamp DESC,id DESC LIMIT 1`).get(id,...this.ownerArgs()));}
  observations(bounds){return this.db.prepare(`SELECT * FROM observations WHERE ${this.owned()}${bounds?' AND timestamp>=? AND timestamp<?':''} ORDER BY timestamp DESC,id DESC`).all(...this.ownerArgs(),...(bounds?[bounds.from,bounds.to]:[])).map(row=>this.decode(row));}
  saveObservation(value,{legacy=false}={}){
    const r=observationRecord(value,{legacy});
    if(this.userId&&r.cameraId&&!this.db.prepare('SELECT id FROM cameras WHERE id=? AND user_id=?').get(r.cameraId,this.userId))throw Error('Camera not found.');
    if(this.userId&&r.monitoringSessionId&&!this.session(r.monitoringSessionId))throw Error('Monitoring session not found.');
    const existing=this.getObservation(r.id);
    if(existing){
      // An import never overwrites an existing record; a commit retry must match.
      if(!legacy&&['timestamp','activity','location','description','confidence','source','context','cameraId','cameraName'].some(key=>existing[key]!==r[key]))throw Error('This observation ID has already been used.');
      if(!legacy&&JSON.stringify(existing.objects)!==JSON.stringify(r.objects))throw Error('This observation ID has already been used.');
      return existing;
    }
    this.db.prepare(`INSERT INTO observations VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`).run(r.id,r.timestamp,r.activity,r.location,r.description,r.confidence,JSON.stringify(r.objects),r.source,r.monitoringSessionId,r.snapshotRef,r.context,Number(legacy),r.cameraId,r.cameraName,this.userId??null);
    return this.getObservation(r.id);
  }
  snapshotInUse(ref){return !!this.db.prepare(`SELECT id FROM observations WHERE snapshot_ref=? AND ${this.owned()} LIMIT 1`).get(ref,...this.ownerArgs());}
  createSession(session,at,cameraSource='local-webcam'){
    this.db.prepare(`INSERT INTO monitoring_sessions(id,started_at,camera_source,interval_ms,status,updated_at,camera_id,camera_name,user_id) VALUES (?,?,?,?,'active',?,?,?,?)`).run(session.id,at,cameraSource,session.intervalMs||15000,at,session.cameraId||null,session.cameraName||null,this.userId??null);
  }
  saveSession(session,at){
    const t=session.telemetry;
    this.db.prepare(`UPDATE monitoring_sessions SET interval_ms=?,api_requests=?,successful_analyses=?,failed_analyses=?,no_person_skipped=?,invalid_frame_skipped=?,last_request_at=?,updated_at=? WHERE id=? AND ${this.owned()}`).run(session.intervalMs??this.session(session.id)?.interval_ms??15000,t.requests,t.successes,t.failures,t.noPerson,t.invalid+(session.clientInvalid||0),t.lastRequest,at,session.id,...this.ownerArgs());
  }
  finishSession(id,at,reason='auto_off'){
    this.db.prepare(`UPDATE monitoring_sessions SET status='completed',ended_at=?,end_reason=?,updated_at=? WHERE id=? AND status='active' AND ${this.owned()}`).run(at,reason,at,id,...this.ownerArgs());
  }
  recoverUnfinished(){
    // No invented end time or inferred result for a request interrupted by a crash.
    this.db.prepare(`UPDATE monitoring_sessions SET status='interrupted',end_reason='server_restart' WHERE status='active'`).run();
  }
  sessions(bounds){return this.db.prepare(`SELECT * FROM monitoring_sessions WHERE ${this.owned()}${bounds?' AND started_at>=? AND started_at<?':''} ORDER BY started_at DESC,id DESC`).all(...this.ownerArgs(),...(bounds?[bounds.from,bounds.to]:[])).map(row=>this.publicRow(row));}
  reportExtent(now){return this.db.prepare(`SELECT MIN(timestamp) AS first,MAX(timestamp) AS last,COUNT(*) AS count FROM observations WHERE timestamp<=? AND ${this.owned()}`).get(now,...this.ownerArgs());}
  reportSessions(bounds){return this.db.prepare(`SELECT * FROM monitoring_sessions WHERE started_at<? AND COALESCE(ended_at,updated_at)>=? AND ${this.owned()} ORDER BY started_at,id`).all(bounds.to,bounds.from,...this.ownerArgs()).map(row=>this.publicRow(row));}
  cameras({historical=false}={}){return decorateCameras(this,this.db.prepare(`SELECT * FROM cameras WHERE ${this.owned()}${historical?'':' AND deleted_at IS NULL'} ORDER BY created_at,id`).all(...this.ownerArgs()).map(row=>this.publicRow(row)));}
  camera(id=LOCAL_CAMERA_ID){return this.cameras().find(c=>c.id===id)??null;}
  validateCamera({name,deviceId,enabled,source}={}){
    if(name!==undefined&&(typeof name!=='string'||!name.trim()||name.trim().length>80))throw Error('Use a camera name of 1–80 characters.');
    if(deviceId!==undefined&&(typeof deviceId!=='string'||!deviceId.trim()||deviceId.length>500))throw Error('Select an available browser camera.');
    if(enabled!==undefined&&typeof enabled!=='boolean')throw Error('Camera enabled must be true or false.');
    if(source!==undefined&&source!=='local-webcam')throw Error('Only local browser webcams are supported.');
    if(deviceId&&this.db.prepare(`SELECT id FROM cameras WHERE device_id=? AND deleted_at IS NULL AND ${this.owned()}`).get(deviceId,...this.ownerArgs()))throw Error('This physical device is already configured.');
  }
  addCamera(value){
    this.validateCamera(value);if(!value.name||!value.deviceId)throw Error('Choose a camera device and name.');
    const id=randomUUID(),at=new Date().toISOString();
    this.db.prepare('INSERT INTO cameras(id,name,source,created_at,enabled,device_id,updated_at,user_id) VALUES (?,?,?,?,?,?,?,?)').run(id,value.name.trim(),'local-webcam',at,Number(value.enabled!==false),value.deviceId,at,this.userId??null);return this.camera(id);
  }
  updateCamera(id,value){
    const current=this.camera(id);if(!current)throw Error('Camera not found.');
    this.validateCamera({...value,deviceId:value.deviceId===current.device_id?undefined:value.deviceId});
    validateCameraLayout(this,value);
    saveCameraLayout(this,id,value,()=>this.db.prepare(`UPDATE cameras SET name=?,enabled=?,device_id=?,updated_at=? WHERE id=? AND ${this.owned()}`).run(value.name?.trim()??current.name,value.enabled===undefined?current.enabled:Number(value.enabled),value.deviceId??current.device_id,new Date().toISOString(),id,...this.ownerArgs()));return this.camera(id);
  }
  renameCamera(id,name){return this.updateCamera(id,{name});}
  removeCamera(id){if(!this.camera(id))throw Error('Camera not found.');this.db.prepare(`UPDATE cameras SET enabled=0,deleted_at=?,updated_at=? WHERE id=? AND ${this.owned()}`).run(new Date().toISOString(),new Date().toISOString(),id,...this.ownerArgs());}
  settings(){const columns=this.db.prepare('PRAGMA table_info(app_settings)').all(),has=name=>columns.some(c=>c.name===name);const row=this.db.prepare(`SELECT interval_ms,save_snapshots,${has('smart_surv')?'smart_surv':'1 AS smart_surv'},${has('detection_only_rotation')?'detection_only_rotation':'0 AS detection_only_rotation'} FROM app_settings WHERE ${this.userId?'user_id=?':'id=1'}`).get(...this.ownerArgs());if(!row)throw Error('User settings are missing.');return {intervalMs:row.interval_ms,saveSnapshots:!!row.save_snapshots,smartSurv:!!row.smart_surv,detectionOnlyRotation:!!row.detection_only_rotation};}
  prepareDetectionOnlyRotation(){if(!this.db.prepare('PRAGMA table_info(app_settings)').all().some(c=>c.name==='detection_only_rotation'))verifiedDatabaseBackup(this,'pre-detection-only-rotation');}
  setDetectionOnlyRotation(value){
    if(typeof value!=='boolean')throw Error('Detection-Only Rotation must be ON or OFF.');
    if(!this.db.prepare('PRAGMA table_info(app_settings)').all().some(c=>c.name==='detection_only_rotation'))this.db.exec('ALTER TABLE app_settings ADD COLUMN detection_only_rotation INTEGER NOT NULL DEFAULT 0 CHECK(detection_only_rotation IN (0,1));');
    this.db.prepare(`UPDATE app_settings SET detection_only_rotation=? WHERE ${this.userId?'user_id=?':'id=1'}`).run(Number(value),...this.ownerArgs());return this.settings();
  }
  setSmartSurv(value){
    if(typeof value!=='boolean')throw Error('Smart Surv must be ON or OFF.');
    // Old installations default ON without a startup migration or row rewrite.
    // Only an explicit preference save adds this transactional, default-ON column.
    if(!this.db.prepare('PRAGMA table_info(app_settings)').all().some(c=>c.name==='smart_surv'))this.db.exec('ALTER TABLE app_settings ADD COLUMN smart_surv INTEGER NOT NULL DEFAULT 1 CHECK(smart_surv IN (0,1));');
    this.db.prepare(`UPDATE app_settings SET smart_surv=? WHERE ${this.userId?'user_id=?':'id=1'}`).run(Number(value),...this.ownerArgs());return this.settings();
  }
  setSaveSnapshots(value){if(typeof value!=='boolean')throw Error('Save snapshots must be ON or OFF.');this.db.prepare(`UPDATE app_settings SET save_snapshots=? WHERE ${this.userId?'user_id=?':'id=1'}`).run(Number(value),...this.ownerArgs());return this.settings();}
  setInterval(intervalMs){if(!INTERVALS.includes(intervalMs))throw Error('Choose 15, 30 or 60 seconds. The minimum is 15 seconds.');this.db.prepare(`UPDATE app_settings SET interval_ms=? WHERE ${this.userId?'user_id=?':'id=1'}`).run(intervalMs,...this.ownerArgs());return this.settings();}
  lastAutomaticRequest(){return this.db.prepare(`SELECT MAX(last_request_at) AS timestamp FROM monitoring_sessions WHERE ${this.owned()}`).get(...this.ownerArgs()).timestamp;}
  automaticRequestsByCamera(){return this.db.prepare(`SELECT camera_id,MAX(last_request_at) AS timestamp FROM monitoring_sessions WHERE camera_id IS NOT NULL AND ${this.owned()} GROUP BY camera_id`).all(...this.ownerArgs());}
  session(id){return this.publicRow(this.db.prepare(`SELECT * FROM monitoring_sessions WHERE id=? AND ${this.owned()}`).get(id,...this.ownerArgs()));}
  close(){this.db.close();}
}
