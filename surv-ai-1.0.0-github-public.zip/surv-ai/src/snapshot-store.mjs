import {mkdir,writeFile,rename,readFile,unlink} from 'node:fs/promises';
import path from 'node:path';
import {randomUUID} from 'node:crypto';

// Observation records contain only this opaque reference, never a disk path.
// Replace this adapter with object storage later; callers keep put/get/remove.
export class SnapshotStore{
  constructor(directory){this.directory=directory;}
  async put(image){
    const match=image.match(/^data:image\/(jpeg|png|webp);base64,(.+)$/);
    if(!match)throw Error('Invalid snapshot image.');
    const ref=`${randomUUID()}.${match[1]==='jpeg'?'jpg':match[1]}`;
    await mkdir(this.directory,{recursive:true});
    const target=path.join(this.directory,ref),temporary=target+'.tmp';
    try{await writeFile(temporary,Buffer.from(match[2],'base64'),{flag:'wx'});await rename(temporary,target);}catch(e){await unlink(temporary).catch(()=>{});throw e;}
    return ref;
  }
  validate(ref){if(!/^[a-f0-9-]{36}\.(jpg|png|webp)$/.test(ref||''))throw Error('Invalid snapshot reference.');return path.join(this.directory,ref);}
  async get(ref){return {data:await readFile(this.validate(ref)),type:ref.endsWith('.jpg')?'image/jpeg':ref.endsWith('.png')?'image/png':'image/webp'};}
  async remove(ref){try{await unlink(this.validate(ref));}catch(e){if(e.code!=='ENOENT')throw e;}}
}
