import {normalize,calendar,dayBounds,addDays} from './local-calendar.mjs';
import {queryScope} from './query-scope.mjs';
const aliases={computer:['computer','pc','desktop','laptop'],video:['video','videos','watching video','youtube'],phone:['phone','smartphone','cell phone','mobile phone'],bottle:['water bottle','bottle','water'],drink:['drink','drinking','drank','sip'],book:['book','books'],keyboard:['keyboard','keyboards'],monitor:['monitor','monitors','screen','screens'],food:['food','meal','snack'],cup:['cup','mug','coffee mug']};
function words(text,term){const hay=' '+normalize(text)+' ',needle=normalize(term);return !!needle&&hay.includes(' '+needle+' ');}
function terms(term){const clean=normalize(term);const group=Object.values(aliases).find(values=>values.some(v=>words(clean,v)));return group||[clean];}
const matches=(text,search)=>terms(search).some(term=>words(text,term));
const actions=[
  {name:'drinking',question:/\b(drink|drinking|drank|sip|sipping)\b/,behavior:/\b(drinking|drank|sipping|sipped|taking a drink|drinks? from|drink from)\b/,objects:['bottle','cup','mug','glass']},
  {name:'eating',question:/\b(eat|eating|ate)\b/,behavior:/\b(eating|ate|taking a bite|chewing)\b/,objects:['food','bowl','plate','sandwich','meal']},
  {name:'typing',question:/\b(type|typing|typed)\b/,behavior:/\b(typing|typed)\b/,objects:['keyboard']},
  {name:'reading',question:/\b(read|reading)\b/,behavior:/\b(reading|reads? (?:a |the )?book|read (?:a |the )?book)\b/,objects:['book']},
  {name:'phone use',question:/\b(?:use|using|used).*\bphone\b/,behavior:/\b(?:using|used|talking on|scrolling on|interacting with) (?:a |the |their |his |her )?(?:smartphone|phone|mobile phone|cell phone)\b/,objects:['phone']},
  {name:'working',question:/\b(work|working|worked|code|coding|programming)\b/,behavior:/\b(working|worked|coding|programming)\b/,objects:['computer','laptop','keyboard']},
  {name:'watching video',question:/\b(watch|watching|watched)\b/,behavior:/\b(watching|watched) (?:a |the |some )?(?:video|videos|video content|tv|television)\b/,objects:['monitor','screen','television']}
];
export function actionEvidence(record,action){
  // User context and object tags never establish actions. Negated/unknown
  // clauses and object noun phrases are excluded even if they contain a verb.
  return [record.activity,record.description].some((text,index)=>text.split(/[.;!?]/).some(clause=>{
    const normalized=normalize(clause);
    if(/\b(not|no|never|without|unclear|unknown|unconfirmed|isn t|wasn t|doesn t|didn t|can t|cannot)\b/.test(normalized))return false;
    const clean=normalized.replace(/\b(?:bottle|container|cup|glass|jug|mug)(?: of| with| containing| filled with) (?:clean |fresh |safe )?drinking water\b/g,'container')
      .replace(/\bdrinking (?:water )?(?:bottle|container|vessel|cup|glass)\b/g,'container')
      .replace(/\b(?:bottle|container|cup|glass|jug|mug) for drinking\b/g,'container')
      .replace(/\breading (?:lamp|glasses|light)\b/g,'object')
      .replace(/\bworking (?:computer|monitor|phone|keyboard)\b/g,'device')
      .replace(/\beating (?:utensils|tools)\b/g,'objects');
    // The activity label can have an implicit actor. Description evidence must
    // mention a person, rather than a device or container alone doing something.
    return action.behavior.test(clean)&&(index===0||/\b(person|someone|user|individual|man|woman|he|she|they)\b/.test(clean));
  }));
}

const topics=[
  {name:'computer / desk',question:/\b(computer|computers|desktop|laptop|pc|desk|monitors?|screens?)\b/,behavior:/\b(?:(?:using|use|working (?:at|on|with)|interacting with) (?:a |the |their |his |her )?(?:desktop |dual |computer )?(?:computer|laptop|pc|monitors?|screens?)|at (?:a |the |my |their |his |her )?desk|typing)\b/,objects:['computer','keyboard','monitor','desk']},
  {name:'gaming',question:/\b(gaming|games?|playing)\b/,behavior:/\b(gaming|playing (?:a |the )?(?:video |computer )?games?)\b/,objects:['controller']},
  ...actions
];
const objectConcepts=[
  ['water bottle',['water bottle','water bottles','bottle of water','bottles of water']],['coffee mug',['coffee mug','coffee mugs','coffee cup','coffee cups']],['keyboard',['keyboard','keyboards']],['headset',['headset','headsets']],['headphones',['headphones','headphone']],['phone',['phone','phones','smartphone','smartphones','mobile phone','cell phone']],['mug',['mug','mugs','cup','cups']],['bottle',['bottle','bottles']],['monitor',['monitor','monitors','screen','screens']],['computer',['computer','computers','laptop','desktop','pc']],['food',['food','meal','snack']],['book',['book','books']],['bowl',['bowl','bowls']],['chair',['chair','chairs']],['mouse',['mouse']],['plate',['plate','plates']],['desk',['desk']],['controller',['controller']]
];
function objectMatches(objects,search){return objects.some(object=>search.some(term=>words(object,term)));}
export function activityGroup(record){
  const label=normalize(record.activity);
  if(/\b(gaming|playing.*(?:game|games))\b/.test(label))return 'Gaming';
  if(actionEvidence({...record,description:''},actions[0])||actionEvidence({...record,description:''},actions[1]))return 'Eating / drinking';
  if(actionEvidence({...record,description:''},actions.at(-1)))return 'Video viewing';
  if(actionEvidence({...record,description:''},topics[0]))return 'Computer use';
  return 'Other';
}
function parseClock(value){
  const m=value.trim().match(/^(\d{1,2})(?::(\d{2}))?\s*(am|pm)?$/i);if(!m)return null;
  let hour=Number(m[1]),minute=Number(m[2]||0);const ampm=m[3]?.toLowerCase();
  if(minute>59||hour>23||ampm&&(hour<1||hour>12))return null;
  if(!ampm&&hour>=1&&hour<=12)return {error:'Include AM or PM, such as 6:45 PM.'};
  if(ampm)hour=hour%12+(ampm==='pm'?12:0);return {minute:hour*60+minute};
}
const clockPattern='(\\d{1,2}(?::\\d{2})?\\s*(?:am|pm)?)';
export function parseLocalQuery(question,{date,timeZone='UTC',cameras=[],scope='day'}={}){
  if(typeof question!=='string'||!question.trim()||question.length>500)throw Error('Ask a question of 1–500 characters.');
  const resolved=queryScope(question,{date,timeZone,scope});date=resolved.date;const q=normalize(resolved.question);
  const plan={...resolved,question:question.trim(),date,timeZone,type:'observations',order:'asc',activities:[],objectTerms:[],objectLabel:null,cameraIds:[],cameraName:null,location:null,source:null,time:null,supported:true,reason:null};
  // Resolve named camera entities before interpreting time/source/activity words.
  const escapePattern=value=>value.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');
  const commonNames=new Set(['first','earliest','last','latest','morning','afternoon','evening','automatic','manual','desk','gaming','drinking','eating','typing',...objectConcepts.flatMap(([label,values])=>[label,...values])]);
  const named=cameras.filter(c=>words(q,c.name)&&(!commonNames.has(normalize(c.name))||new RegExp('\\b(?:in|from|by|for) (?:the )?'+escapePattern(normalize(c.name))+'\\b|\\b'+escapePattern(normalize(c.name))+' camera\\b').test(q))).sort((a,b)=>b.name.length-a.name.length);
  if(named.length){const name=normalize(named[0].name);plan.cameraIds=[...new Set(named.filter(c=>normalize(c.name)===name).map(c=>c.id))];plan.cameraName=named[0].name;}
  const lexical=plan.cameraName?q.replaceAll(normalize(plan.cameraName),' '):q;
  const unsupported=reason=>({...plan,cameraName:plan.cameraName||cameras.filter(c=>words(q,c.name)).sort((a,b)=>b.name.length-a.name.length)[0]?.name||null,objectLabel:plan.objectLabel||objectConcepts.find(([label,values])=>[label,...values].some(term=>words(q,term)))?.[0]||null,supported:false,type:'unsupported',reason});
  if(resolved.reason)return unsupported(resolved.reason);
  if(/\b(healthy|unhealthy|depressed|dehydrated|anxiety|insomnia|diagnosis|diagnose|sleep|abnormal|compare|versus|every other|second most)\b/.test(q))return unsupported('That interpretation is not supported by point-in-time observations. Try recorded activities, objects, days or counts.');
  if(/\b(not|never|without|except|excluding|unless)\b/.test(lexical))return unsupported('Negative or exclusion filters are not supported yet. Ask for positive recorded activity or object evidence.');
  if(/\b(why|predict|forecast|feel|feelings|tomorrow|recommend|should i)\b/.test(q))return unsupported('That question is outside recorded observation evidence. Try an observation time, activity, object, camera or count.');
  if(/\b(how long|duration|hours|time spent|minutes spent)\b/.test(q))return unsupported('Point-in-time observations do not establish activity duration. Activity during gaps is unknown.');
  if(/\b(yesterday|tomorrow|last week|last month)\b/.test(q))return unsupported('Choose that date with the date selector first. Questions search the selected date.');
  const explicitDate=question.match(/\b(\d{4}-\d{2}-\d{2})\b/);if(explicitDate&&explicitDate[1]!==date)return unsupported('The question names a different date. Change the selected date first.');
  const count=/\b(how many|number of|times observed|times was|times were)\b/.test(lexical),first=/\b(first|earliest)\b/.test(lexical),last=/\b(last|latest)\b/.test(lexical),yesNo=/^(did i|have i|was i|were i)\b/.test(lexical);
  if(count&&/\bmonitoring (?:sessions|runs)\b/.test(lexical))plan.type='runs';
  else if(count)plan.type='count';else if(first||last)plan.type='timestamp';else if(yesNo)plan.type='behavior';
  else if(/\b(?:what|which|most common|most frequent|most frequently) objects?\b/.test(lexical))plan.type='objects';
  else if(/\bwhat cameras?\b/.test(lexical))plan.type='cameras';
  else if(/\b(?:most common|most frequent|most frequently).*activit/.test(lexical))plan.type='activities';
  else if(/\b(?:what did i do|what activities|what happened|what was observed)\b/.test(lexical))plan.type='activities';
  if(last)plan.order='desc';
  if(/\bautomatic\b/.test(lexical)&&/\bmanual\b/.test(lexical))return unsupported('Choose either automatic or manual observations for a source filter.');
  if(/\bautomatic\b/.test(lexical))plan.source='automatic_ai';if(/\bmanual\b/.test(lexical))plan.source='manual_ai';
  let semantic=q;
  if(plan.cameraName)semantic=semantic.replaceAll(normalize(plan.cameraName),' ');
  if(!plan.cameraName){const place=semantic.match(/\b(?:in|from) (?:the )?(.+?)(?: camera)?(?: today| on \d{4} \d{2} \d{2}| before | after | around | between | this morning| this afternoon| this evening|$)/);
    if(place&&!/^(a |my |the )?(computer|desk|morning|afternoon|evening)/.test(place[1])){plan.location=place[1].trim();semantic=semantic.replace(place[0],' ');}}
  const objectWording=plan.type==='objects'||/\b(seen|see|visible|visibility|objects?)\b/.test(semantic)&&!(/\bi (?:first |last )?seen\b/.test(semantic));
  if(objectWording){
    const concept=objectConcepts.find(([label,values])=>[label,...values].some(term=>words(semantic,term)));
    if(concept){plan.objectLabel=concept[0];plan.objectTerms=concept[1];}
    else {const noun=semantic.match(/\b(?:when was|when were|was|were|how many times was|how many times were) (?:a |an |the |my )?(.+?) (?:seen|visible)\b/);
      if(noun&&!/^(i|person|someone|(?:first |last |latest |earliest )?(?:thing|observation|observations))$/.test(noun[1])){plan.objectLabel=noun[1].replace(/^(?:first|earliest|last|latest) /,'');plan.objectTerms=[plan.objectLabel];}}
  }
  // Object visibility requests never turn object nouns into behavioral evidence.
  const activityText=plan.objectTerms.length?semantic.split(/\bwhile\b/)[1]||'':semantic;
  if(plan.type!=='objects')plan.activities=topics.filter(t=>t.question.test(activityText)).map(t=>t.name);
  if(plan.type==='behavior'&&!plan.activities.length)return unsupported('I could not determine the activity to search for. Try drinking, eating, typing, computer use, gaming or watching video.');
  let match=semantic.match(new RegExp('\\bbetween\\s+'+clockPattern+'\\s+and\\s+'+clockPattern+'\\b','i'));
  if(match){const a=parseClock(match[1]),b=parseClock(match[2]);if(!a||!b)return unsupported('Use valid clock times, such as between 9 AM and 2 PM.');if(a.error||b.error)return {...unsupported(a.error||b.error),type:'clarification'};if(a.minute>b.minute)return unsupported('For a range crossing midnight, search each selected date separately.');plan.time={min:a.minute,max:b.minute,mode:'between'};}
  else {match=semantic.match(new RegExp('\\b(before|after|around|at)\\s+'+clockPattern+'\\b','i'));
    if(match){const t=parseClock(match[2]);if(!t)return unsupported('Use a valid time, such as 6:45 PM.');if(t.error)return {...unsupported(t.error),type:'clarification'};const mode=match[1];plan.time={mode,min:mode==='before'?0:mode==='after'?t.minute:Math.max(0,t.minute-15),max:mode==='before'?t.minute:mode==='after'?1439:Math.min(1439,t.minute+15),target:t.minute};}
  }
  if(!plan.time){if(/\bmorning\b/.test(semantic))plan.time={mode:'morning',min:0,max:719};else if(/\bafternoon\b/.test(semantic))plan.time={mode:'afternoon',min:720,max:1079};else if(/\bevening\b/.test(semantic))plan.time={mode:'evening',min:1080,max:1439};}
  if(/\b(before|after|between|around)\b/.test(semantic)&&!plan.time)return unsupported('Use clock times such as before 9 PM, after 6 AM or between 9 AM and 2 PM.');
  if(plan.type==='timestamp'&&!plan.activities.length&&!plan.objectTerms.length&&!plan.cameraIds.length&&!plan.location){
    const remainder=semantic.replace(/\b(?:what|when|was|were|is|are|i|my|me|the|a|an|first|earliest|last|latest|seen|observed|observation|observations|thing|today|on|at|before|after|around|between|and|in|this|morning|afternoon|evening|automatic|manual|am|pm|of)\b|\d+(?::\d+)?/g,' ').trim();
    if(remainder)return unsupported('I could not determine the activity or object for this time search. Try desk/computer, drinking, eating, typing, gaming or a visible object.');
  }
  if(plan.cameraName&&plan.type==='activities')plan.type='camera';
  if(plan.source&&/\b(?:sources|automatic and manual|source breakdown)\b/.test(q))plan.type='sources';
  const generic=/\b(observations?|observed|first seen|earliest|last|latest|what did i do|what activities|what happened|what objects|what cameras|most common|most frequent|source breakdown)\b/.test(q);
  if(!generic&&!plan.activities.length&&!plan.objectTerms.length&&!plan.cameraName&&!plan.location&&!plan.time)return unsupported('I could not determine what to search for. Try a time, activity, object, camera or observation count.');
  if(/\bwhich day had the most observations\b/i.test(question))plan.type='busiest-day';
  else if(/\beach day\b/i.test(question)&&/\b(first|earliest|last|latest)\b/i.test(question))plan.type=/\b(last|latest)\b/i.test(question)?'daily-last':'daily-first';
  else if(/\bwhich days\b/i.test(question)){if(!plan.activities.length&&!plan.objectTerms.length)return unsupported('Name the activity or visible object to group by day, such as computer activity or drinking evidence.');plan.type='days';}
  return plan;
}
function relevantSuggestions(plan){
  const camera=plan.cameraName?' in '+plan.cameraName:'',object=plan.objectLabel||'water bottle',activity=plan.activities.includes('computer / desk')?'at my desk':'drinking';
  return [...new Set([`When was I first ${activity}${camera} today?`,`When was a ${object} seen${camera} today?`,`How many automatic observations${camera} today?`,'What did I do this morning?'])].slice(0,4);
}
function activityMatches(record,names){return names.every(name=>actionEvidence(record,topics.find(t=>t.name===name)));}
function clockSeconds(timestamp,clock){const instant=new Date(timestamp);return clock.minutes(timestamp)*60+instant.getUTCSeconds()+instant.getUTCMilliseconds()/1000;}
function timeLimits(time){return {min:time.min*60,max:time.max*60+(['morning','afternoon','evening','after'].includes(time.mode)?59.999:0)};}
function matchesPlan(record,plan,{context=false}={}){
  if(plan.source&&record.source!==plan.source)return false;
  if(plan.cameraIds.length&&!plan.cameraIds.includes(record.cameraId))return false;
  if(plan.location&&!words(record.location,plan.location)&&!words(record.cameraName,plan.location))return false;
  const value=clockSeconds(record.timestamp,calendar(plan.timeZone)),bounds=plan.time?timeLimits(plan.time):null;
  if(bounds&&(value<bounds.min||value>bounds.max||plan.time.mode==='before'&&value===bounds.max||plan.time.mode==='after'&&value===bounds.min))return false;
  if(context){const terms=plan.activities.flatMap(name=>topics.find(t=>t.name===name)?.objects||[]);return objectMatches(record.objects,terms);}
  return activityMatches(record,plan.activities)&&(!plan.objectTerms.length||objectMatches(record.objects,plan.objectTerms));
}
function sorted(records,plan){return records.sort((a,b)=>plan.time?.target!==undefined?Math.abs(calendar(plan.timeZone).minutes(a.timestamp)-plan.time.target)-Math.abs(calendar(plan.timeZone).minutes(b.timestamp)-plan.time.target)||a.timestamp.localeCompare(b.timestamp):plan.order==='desc'?b.timestamp.localeCompare(a.timestamp)||b.id.localeCompare(a.id):a.timestamp.localeCompare(b.timestamp)||a.id.localeCompare(b.id));}
function freq(values){const m=new Map();for(const v of values){const key=normalize(v);if(key)m.set(key,(m.get(key)||0)+1);}return [...m].map(([label,count])=>({label,count})).sort((a,b)=>b.count-a.count||a.label.localeCompare(b.label));}
function aggregates(records,cameras){
  const groups=new Map();for(const r of records){const label=activityGroup(r);if(!groups.has(label))groups.set(label,{label,count:0,examples:new Map()});const g=groups.get(label);g.count++;g.examples.set(r.activity,(g.examples.get(r.activity)||0)+1);}
  const camerasById=new Map();for(const r of records){const id=r.cameraId||r.source,name=id===r.source?r.source==='manual_ai'?'Manual AI':'Unassigned camera':cameras.find(c=>c.id===id)?.name||r.cameraName;const c=camerasById.get(id)||{id:r.cameraId,label:name,count:0};c.count++;camerasById.set(id,c);}
  return {objects:freq(records.flatMap(r=>[...new Set(r.objects.map(normalize))])),activities:freq(records.map(r=>r.activity)),groups:[...groups.values()].map(g=>({...g,examples:[...g.examples].map(([label,count])=>({label,count})).sort((a,b)=>b.count-a.count)})).sort((a,b)=>b.count-a.count),cameras:[...camerasById.values()].sort((a,b)=>b.count-a.count),sources:freq(records.map(r=>r.source==='automatic_ai'?'Automatic':'Manual'))};
}
function queryDays(plan,lookup){const days=[];for(let date=plan.from;date<=plan.to;date=addDays(date,1))days.push({date,...lookup(date)});return days;}
function result(plan,{count=0,searched=0,evidence=[],aggregates:data={},contextObjects=[],contextCount=0,contextEvidence=[],first=null,latest=null,offset=0}={}){
  const queryType=!plan.supported?plan.type:count===0?'empty':plan.type;
  return {date:plan.date,historyDate:plan.historyDate,scope:plan.scope,requestedScope:plan.requestedScope,from:plan.from,to:plan.to,timeZone:plan.timeZone,question:plan.question,queryType,kind:plan.type,understood:plan.supported,reason:plan.reason,suggestions:!plan.supported?relevantSuggestions(plan):[],filters:{activities:plan.activities,object:plan.objectLabel,camera:plan.cameraName||plan.location,source:plan.source,time:plan.time},searched,count,totalMatches:count,evidence,observations:evidence,offset,hasMore:offset+evidence.length<count,truncated:offset+evidence.length<count,first,latest,...data,context:{objects:contextObjects,count:contextCount,observations:contextEvidence},summary:{count,camera:plan.cameraName||plan.location,activity:plan.activities.join(' and '),object:plan.objectLabel},text:!plan.supported?plan.reason:count?`${count} matching ${count===1?'observation':'observations'}.`:'No matching observations. Activity in observation gaps is unknown.'};
}
export function askLocal(question,records,sessions,options){
  const plan=parseLocalQuery(question,options),scoped=records.filter(r=>r.timestamp>=plan.bounds.from&&r.timestamp<plan.bounds.to),found=sorted(scoped.filter(r=>matchesPlan(r,plan)),plan),context=plan.type==='behavior'?scoped.filter(r=>matchesPlan(r,plan,{context:true})):[];
  if(!plan.supported)return result(plan,{searched:scoped.length});
  if(plan.type==='runs')return {...result(plan,{count:sessions.length,searched:scoped.length}),runCount:sessions.length};
  return result(plan,{count:found.length,searched:scoped.length,evidence:found.slice(0,20).map(r=>plan.type==='behavior'?{...r,evidenceType:'behavior'}:r),aggregates:{...aggregates(found,options.cameras||[]),byDay:queryDays(plan,day=>{const list=found.filter(r=>calendar(plan.timeZone).date(r.timestamp)===day).sort((a,b)=>a.timestamp.localeCompare(b.timestamp));return {count:list.length,first:list[0]?.timestamp||null,last:list.at(-1)?.timestamp||null,...(['daily-first','daily-last'].includes(plan.type)?{observation:plan.type==='daily-first'?list[0]||null:list.at(-1)||null}:{})};})},contextObjects:aggregates(context,[]).objects.filter(o=>plan.activities.some(name=>(topics.find(t=>t.name===name)?.objects||[]).some(term=>words(o.label,term)))),contextCount:context.length,contextEvidence:context.slice(0,6).map(r=>({...r,evidenceType:'object-context'})),first:found.length?[...found].sort((a,b)=>a.timestamp.localeCompare(b.timestamp))[0]:null,latest:found.length?[...found].sort((a,b)=>b.timestamp.localeCompare(a.timestamp))[0]:null});
}
// SQLite applies the date/index filters before deterministic scalar predicates.
// Only one evidence page crosses the API. Summaries aggregate all matches in SQL.
export function executeSQLQuery(store,question,options,{offset=0,limit=6,contextPage=false}={}){
  if(!Number.isSafeInteger(offset)||offset<0||!Number.isSafeInteger(limit)||limit<1||limit>50)throw Error('Use a valid evidence page of up to 50 observations.');
  const cameras=store.cameras({historical:true});
  const oldNames=store.db.prepare(`SELECT DISTINCT camera_id AS id,camera_name AS name FROM observations WHERE camera_id IS NOT NULL AND ${store.owned()}`).all(...store.ownerArgs());
  const plan=parseLocalQuery(question,{...options,cameras:[...cameras,...oldNames]}),bounds=plan.bounds,db=store.db,clock=calendar(plan.timeZone);
  const searched=db.prepare(`SELECT COUNT(*) AS n FROM observations WHERE timestamp>=? AND timestamp<? AND ${store.owned()}`).get(bounds.from,bounds.to,...store.ownerArgs()).n;
  if(!plan.supported)return result(plan,{searched});
  if(plan.type==='runs'){
    const clauses=['started_at>=?','started_at<?',store.owned()],params=[bounds.from,bounds.to,...store.ownerArgs()];if(plan.cameraIds.length){clauses.push(`camera_id IN (${plan.cameraIds.map(()=>'?').join(',')})`);params.push(...plan.cameraIds);}
    const count=db.prepare('SELECT COUNT(*) AS n FROM monitoring_sessions WHERE '+clauses.join(' AND ')).get(...params).n;return {...result(plan,{count,searched}),runCount:count};
  }
  db.function('surv_date',{deterministic:true},timestamp=>clock.date(timestamp));
  db.function('surv_normalize',{deterministic:true},normalize);
  db.function('surv_minutes',{deterministic:true},timestamp=>clockSeconds(timestamp,clock));
  db.function('surv_activity',{deterministic:true},(activity,description)=>Number(activityMatches({activity,description},plan.activities)));
  db.function('surv_object',{deterministic:true},json=>Number(objectMatches(JSON.parse(json),plan.objectTerms)));
  db.function('surv_context',{deterministic:true},json=>Number(objectMatches(JSON.parse(json),plan.activities.flatMap(name=>topics.find(t=>t.name===name)?.objects||[]))));
  db.function('surv_place',{deterministic:true},(location,name)=>Number(words(location,plan.location)||words(name,plan.location)));
  db.function('surv_group',{deterministic:true},activity=>activityGroup({activity,description:''}));
  const clauses=['timestamp>=?','timestamp<?',store.owned()],params=[bounds.from,bounds.to,...store.ownerArgs()];
  if(plan.cameraIds.length){clauses.push(`camera_id IN (${plan.cameraIds.map(()=>'?').join(',')})`);params.push(...plan.cameraIds);}
  if(plan.source){clauses.push('source=?');params.push(plan.source);}
  if(plan.location)clauses.push('surv_place(location,camera_name)=1');
  if(plan.time){clauses.push(`surv_minutes(timestamp)${plan.time.mode==='after'?'>':'>='}? AND surv_minutes(timestamp)${plan.time.mode==='before'?'<':'<='}?`);const limits=timeLimits(plan.time);params.push(limits.min,limits.max);}
  const base=clauses.join(' AND '),contextWhere=base+' AND surv_context(objects_json)=1';
  if(plan.activities.length)clauses.push('surv_activity(activity,description)=1');if(plan.objectTerms.length)clauses.push('surv_object(objects_json)=1');
  const where=contextPage?contextWhere:clauses.join(' AND '),filtered=`WITH matched AS (SELECT * FROM observations WHERE ${where}) `;
  const order=plan.time?.target!==undefined?'ABS(surv_minutes(timestamp)-'+plan.time.target*60+'),timestamp,id':'timestamp '+(plan.order==='desc'?'DESC':'ASC')+',id '+(plan.order==='desc'?'DESC':'ASC');
  const count=db.prepare(filtered+'SELECT COUNT(*) AS n FROM matched').get(...params).n;
  const evidence=db.prepare(filtered+`SELECT * FROM matched ORDER BY ${order} LIMIT ? OFFSET ?`).all(...params,limit,offset).map(r=>({...store.decode(r),...(plan.type==='behavior'?{evidenceType:contextPage?'object-context':'behavior'}:{})}));
  const frequency=column=>db.prepare(filtered+`SELECT ${column} AS label,COUNT(*) AS count FROM matched GROUP BY label ORDER BY count DESC,label`).all(...params);
  const objectsFor=(sql,args)=>db.prepare(`WITH matched AS (SELECT * FROM observations WHERE ${sql}),items AS (SELECT DISTINCT matched.id,surv_normalize(j.value) AS label FROM matched,json_each(matched.objects_json) j WHERE j.type='text') SELECT label,COUNT(*) AS count FROM items WHERE label!='' GROUP BY label ORDER BY count DESC,label`).all(...args);
  const groups=frequency('surv_group(activity)').map(g=>({...g,examples:db.prepare(filtered+'SELECT activity AS label,COUNT(*) AS count FROM matched WHERE surv_group(activity)=? GROUP BY activity ORDER BY count DESC,activity LIMIT 4').all(...params,g.label)}));
  const byCamera=db.prepare(filtered+"SELECT camera_id AS id,MAX(camera_name) AS recordedName,source,COUNT(*) AS count FROM matched GROUP BY camera_id,CASE WHEN camera_id IS NULL THEN source ELSE '' END ORDER BY count DESC").all(...params).map(c=>({id:c.id,label:c.id?cameras.find(x=>x.id===c.id)?.name||c.recordedName:c.source==='manual_ai'?'Manual AI':'Unassigned camera',count:c.count}));
  const first=count?store.decode(db.prepare(filtered+'SELECT * FROM matched ORDER BY timestamp,id LIMIT 1').get(...params)):null,latest=count?store.decode(db.prepare(filtered+'SELECT * FROM matched ORDER BY timestamp DESC,id DESC LIMIT 1').get(...params)):null;
  let contextObjects=[],contextCount=0,contextEvidence=[];
  if(plan.type==='behavior'&&!contextPage){contextObjects=objectsFor(contextWhere,params).filter(o=>plan.activities.some(name=>(topics.find(t=>t.name===name)?.objects||[]).some(term=>words(o.label,term))));contextCount=db.prepare('SELECT COUNT(*) AS n FROM observations WHERE '+contextWhere).get(...params).n;contextEvidence=db.prepare('SELECT * FROM observations WHERE '+contextWhere+' ORDER BY timestamp,id LIMIT 6').all(...params).map(r=>({...store.decode(r),evidenceType:'object-context'}));}
  const dayRows=db.prepare(filtered+'SELECT surv_date(timestamp) AS date,COUNT(*) AS count,MIN(timestamp) AS first,MAX(timestamp) AS last FROM matched GROUP BY date ORDER BY date').all(...params);
  const byDay=queryDays(plan,date=>{const row=dayRows.find(d=>d.date===date)||{count:0,first:null,last:null};const instant=plan.type==='daily-first'?row.first:row.last;return {...row,...(['daily-first','daily-last'].includes(plan.type)?{observation:instant?store.decode(db.prepare(filtered+'SELECT * FROM matched WHERE timestamp=? ORDER BY id LIMIT 1').get(...params,instant)):null}:{})};});
  return result(plan,{count,searched,evidence,offset,first,latest,aggregates:{byDay,objects:objectsFor(where,params),activities:frequency('surv_normalize(activity)'),groups,cameras:byCamera,sources:frequency("CASE source WHEN 'automatic_ai' THEN 'Automatic' ELSE 'Manual' END")},contextObjects,contextCount,contextEvidence});
}
