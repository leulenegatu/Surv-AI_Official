import {createHash,randomBytes} from 'node:crypto';
import {browserSettings,credentialOwner,validateBrowserSample,EXTENSION_ORIGIN,pairingPending,installationLabel} from './browser-companion-store.mjs';
import {desktopSettings} from './desktop-store.mjs';

// A deliberately small RFC6455 text channel. No extensions, fragmentation or binary
// frames; masked client frames only, 4 KiB message / 8 KiB buffer / eight sockets.
export function localCompanionRequest(req){
  const peer=req.socket.remoteAddress;
  if(!['127.0.0.1','::1','::ffff:127.0.0.1'].includes(peer))return false;
  return req.headers.host===`127.0.0.1:${req.socket.localPort}`&&req.headers.origin===EXTENSION_ORIGIN;
}
function frame(value,opcode=1){const data=Buffer.from(value),head=data.length<126?Buffer.from([0x80|opcode,data.length]):Buffer.from([0x80|opcode,126,data.length>>8,data.length&255]);return Buffer.concat([head,data]);}
export class BrowserChannel{
  constructor(storage,{now=Date.now}={}){this.storage=storage;this.now=now;this.clients=new Map();this.sockets=new Set();this.rates=new Map();this.received=new Map();this.closed=false;}
  throttle(key,limit=30){const now=this.now(),v=this.rates.get(key)||{at:now,count:0};if(now-v.at>=60000){v.at=now;v.count=0;}if(++v.count>limit)return false;this.rates.set(key,v);return true;}
  allowed(userId){const s=this.storage.forUser(userId);return browserSettings(s).enabled&&desktopSettings(s).enabled;}
  disconnect(userId,forget=false){this.clients.get(userId)?.close();if(forget){this.received.delete(userId);this.rates.delete('settings-'+userId);}}
  status(s){const cfg=browserSettings(s),client=this.clients.get(s.userId);return {...cfg,state:!cfg.enabled||!desktopSettings(s).enabled?'disabled':pairingPending(s,this.now())?'pairing_pending':!cfg.paired?(cfg.revoked?'revoked':'not_paired'):client?'connected':'temporarily_disconnected',lastReceived:this.received.get(s.userId)||null,installation:installationLabel(this.storage,s.userId)};}
  upgrade(req,socket,head){
    const reject=()=>{socket.end('HTTP/1.1 403 Forbidden\r\nConnection: close\r\n\r\n');};
    const key=req.headers['sec-websocket-key'];
    if(this.closed||req.url!=='/browser-companion/channel'||!localCompanionRequest(req)||this.sockets.size>=8||!this.throttle('upgrade',60)||req.headers.upgrade?.toLowerCase()!=='websocket'||!req.headers.connection?.toLowerCase().split(/\s*,\s*/).includes('upgrade')||req.headers['sec-websocket-version']!=='13'||typeof key!=='string'||!/^[A-Za-z0-9+/]{22}==$/.test(key)||req.headers['sec-websocket-protocol']){reject();return;}
    const accept=createHash('sha1').update(key+'258EAFA5-E914-47DA-95CA-C5AB0DC85B11').digest('base64');
    socket.write('HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: '+accept+'\r\n\r\n');
    socket.setNoDelay(true);this.sockets.add(socket);let buffer=Buffer.alloc(0),userId=null,count=0,windowAt=Date.now();
    const client={socket,sequence:0,pending:null,lastReceived:null,send:v=>{if(!socket.destroyed&&socket.writableLength<8192)socket.write(frame(JSON.stringify(v)));else close();},close:()=>close()};
    const close=()=>{clearTimeout(authTimer);if(client.pending){clearTimeout(client.pending.timer);client.pending.resolve(null);client.pending=null;}if(userId&&this.clients.get(userId)===client)this.clients.delete(userId);this.sockets.delete(socket);socket.destroy();};
    const authTimer=setTimeout(close,3000);authTimer.unref?.();
    socket.on('close',close);socket.on('error',close);
    const message=data=>{
      if(Date.now()-windowAt>1000){windowAt=Date.now();count=0;}if(++count>20){close();return;}
      try{
        const value=JSON.parse(data);
        if(!userId){
          if(!value||Object.keys(value).some(k=>!['type','token'].includes(k))||value.type!=='authenticate')throw Error();
          userId=credentialOwner(this.storage,value.token);if(!userId)throw Error();
          clearTimeout(authTimer);this.disconnect(userId);this.clients.set(userId,client);
          client.send({type:'ready',enabled:this.allowed(userId)});return;
        }
        if(!this.allowed(userId)){client.send({type:'disabled'});close();return;}
        const p=client.pending;if(!p||value.requestId!==p.id||this.now()-p.at>1200||value.sequence<=client.sequence)throw Error();
        const cfg=desktopSettings(this.storage.forUser(userId)),sample=validateBrowserSample(value,{includeTitle:cfg.includeTitle,now:this.now()});
        client.sequence=value.sequence;client.lastReceived=new Date(this.now()).toISOString();this.received.set(userId,client.lastReceived);clearTimeout(p.timer);client.pending=null;
        p.resolve(value.focused&&sample.hostname?{...sample,browserSampledAt:new Date(value.timestamp).toISOString(),verifiedAt:client.lastReceived}:null);
      }catch{close();}
    };
    const receive=chunk=>{
      buffer=Buffer.concat([buffer,chunk]);if(buffer.length>8192){close();return;}
      while(buffer.length>=2){const fin=buffer[0]&128,opcode=buffer[0]&15,masked=buffer[1]&128;let length=buffer[1]&127,offset=2;
        if(!fin||(buffer[0]&112)||!masked||![1,8,9,10].includes(opcode)||length===127){close();return;}
        if(length===126){if(buffer.length<4)return;length=buffer.readUInt16BE(2);offset=4;}
        if(length>4096||(opcode!==1&&length>125)){close();return;}
        if(buffer.length<offset+4+length)return;const mask=buffer.subarray(offset,offset+4),data=Buffer.from(buffer.subarray(offset+4,offset+4+length));buffer=buffer.subarray(offset+4+length);for(let i=0;i<data.length;i++)data[i]^=mask[i%4];
        if(opcode===8){close();return;}if(opcode===9)socket.write(frame(data,10));else if(opcode===1){try{message(new TextDecoder('utf-8',{fatal:true}).decode(data));}catch{close();return;}}
      }
    };
    socket.on('data',receive);if(head.length)receive(head);
  }
  async sample(userId,windows,includeTitle){
    const cfg=browserSettings(this.storage.forUser(userId)),exe=cfg.browser==='edge'?'msedge.exe':'chrome.exe',c=this.clients.get(userId);
    if(!this.allowed(userId)||!c||windows.executable?.toLowerCase()!==exe||!['active','idle'].includes(windows.state)||c.pending)return null;
    const id=randomBytes(16).toString('hex');
    return new Promise(resolve=>{const p={id,at:this.now(),resolve,timer:setTimeout(()=>{if(c.pending===p)c.pending=null;resolve(null);},900)};c.pending=p;c.send({type:'sample',requestId:id,includeTitle,browser:cfg.browser});}).then(value=>{
      if(this.closed||!this.allowed(userId)||this.clients.get(userId)!==c||!value)return null;
      // When both consented captions exist, a conflicting window/title is a
      // conservative fallback (including a different Chrome profile/window).
      if(includeTitle&&windows.title&&value.tabTitle&&windows.title!==value.tabTitle&&!windows.title.startsWith(value.tabTitle+' - ')&&!(windows.title.length===320&&value.tabTitle.startsWith(windows.title)))return null;
      return {...value,browser:cfg.browser,provenance:'verified_browser_companion'};
    });
  }
  close(){this.closed=true;for(const client of [...this.clients.values()])client.close();for(const socket of [...this.sockets])socket.destroy();this.clients.clear();this.received.clear();}
}
