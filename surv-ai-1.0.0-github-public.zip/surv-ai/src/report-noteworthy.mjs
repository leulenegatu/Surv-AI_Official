// Saved evidence for human review. Never a diagnosis, new analysis, or history write.
import {normalize} from './local-calendar.mjs';
import {actionEvidence} from './local-query.mjs';
const affect=[
  ['crying / tearful',/\b(crying|tearful|weeping)\b/],
  ['visibly upset / distressed',/\b(visibly upset|visibly distressed|visible (?:signs of )?(?:emotional )?distress)\b/],
  ['agitated',/\b(agitated|visibly restless)\b/],
  ['explicit tiredness',/\b(tired|fatigued|exhausted)\b/]
];
function explicitAffect(record,behavior){
  if(/\b(may|might|could|possibly|maybe|uncertain|unconfirmed)\b/.test(normalize(record.activity+' '+record.description)))return false;
  const withoutDepictedWording=text=>text.split(/[.;!?]/).filter(clause=>! /\b(picture|portrait|poster|painting|emoji|photograph|depicted|depiction)\b/.test(normalize(clause))).join('. ');
  return actionEvidence({activity:withoutDepictedWording(record.activity),description:withoutDepictedWording(record.description)},{behavior});
}
const frequency=(records,key)=>{const counts=new Map();for(const r of records){const value=key(r);if(value)counts.set(value,(counts.get(value)||0)+1);}return counts;};
function dominant(counts){return [...counts].sort((a,b)=>b[1]-a[1]||a[0].localeCompare(b[0]))[0];}
export function selectNoteworthy(records,{clock,length,categoryFor}){
  const cap=length===30?8:5,n=records.length;
  const categories=frequency(records,r=>categoryFor(r.activity)),main=dominant(categories);
  const cameraCounts=frequency(records,r=>r.cameraId),mainCamera=dominant(cameraCounts);
  const hourCounts=frequency(records,r=>String(clock.hour(r.timestamp))),mainHour=dominant(hourCounts);
  const affected=new Map(affect.map(([name,behavior])=>[name,records.filter(r=>explicitAffect(r,behavior))]));
  const candidates=[];
  for(const r of records){
    const signals=[];
    for(const [name,list] of affected)if(list.some(v=>v.id===r.id)){
      const uncommon=list.length<=2||list.length/n<=.1;
      const behavior=affect.find(v=>v[0]===name)[1];
      const quote=[...r.activity.split(/[.;!?]/),...r.description.split(/[.;!?]/)].find(clause=>behavior.test(normalize(clause))&&explicitAffect({activity:clause,description:''},behavior))||r.activity;
      signals.push({key:'affect:'+name,quote:quote.trim().slice(0,300),score:100+(uncommon?10:0),text:`Observable wording (${name}) was explicitly recorded in ${list.length} ${list.length===1?'observation':'observations'}${uncommon?'; uncommon within this report period':''}. This wording is an AI observation for human review, not a verified state or diagnosis.`});
    }
    const category=categoryFor(r.activity),rare=(categories.get(category)||0)<=Math.min(2,Math.floor(n*.1));
    if(n>=12&&main&&main[1]/n>=.65&&category!==main[0]&&category!=='Other observed activity'&&rare)signals.push({key:'activity:'+category,score:60,text:`The recorded ${category.toLowerCase()} category appeared in ${categories.get(category)} observations, compared with ${main[1]} in the dominant ${main[0].toLowerCase()} category. Different does not mean negative; frequency does not measure duration.`});
    if(n>=12&&r.cameraId&&mainCamera&&mainCamera[1]/n>=.8&&r.cameraId!==mainCamera[0]&&(cameraCounts.get(r.cameraId)||0)<=2)signals.push({key:'camera:'+r.cameraId,score:40,text:'This saved camera context was uncommon within this report period, compared with the dominant recorded camera. Camera placement and availability affect this difference.'});
    const hour=clock.hour(r.timestamp),distance=mainHour?Math.min(Math.abs(hour-Number(mainHour[0])),24-Math.abs(hour-Number(mainHour[0]))):0;
    if(n>=12&&mainHour&&mainHour[1]/n>=.8&&distance>=6&&(hourCounts.get(String(hour))||0)<=2)signals.push({key:'time:'+hour,score:30,text:`The saved local clock time differed by at least six hours from the most frequently recorded hour in this period (${clock.time(records.find(v=>clock.hour(v.timestamp)===Number(mainHour[0])).timestamp)}). This does not establish sleep, wake time, or a health concern.`});
    if(signals.length)candidates.push({record:r,signals,score:Math.max(...signals.map(s=>s.score))});
  }
  candidates.sort((a,b)=>b.score-a.score||a.record.timestamp.localeCompare(b.record.timestamp)||a.record.id.localeCompare(b.record.id));
  const selected=[],used=new Map();
  for(const candidate of candidates){
    const eligible=candidate.signals.filter(s=>(used.get(s.key)||0)<(s.key.startsWith('affect:')?2:1));if(!eligible.length)continue;
    eligible.forEach(s=>used.set(s.key,(used.get(s.key)||0)+1));const r=candidate.record;
    selected.push({id:r.id,timestamp:r.timestamp,date:clock.date(r.timestamp),time:clock.timeExact(r.timestamp),activity:r.activity,description:r.description,evidenceQuote:eligible.find(s=>s.quote)?.quote||null,location:r.location,cameraName:r.cameraName,source:r.source,confidence:r.confidence,objects:r.objects,snapshotRef:r.snapshotRef||null,...(r.desktopContext?{desktopContext:r.desktopContext}:{}),reason:eligible.map(s=>s.text).join(' '),signals:eligible.map(s=>s.key)});
    if(selected.length===cap)break;
  }
  return selected;
}
