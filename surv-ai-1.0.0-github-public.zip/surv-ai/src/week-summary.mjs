// Compact, read-only aggregates. No snapshots, history records, or AI requests.
import {mondayOf,addDays,dayBounds,calendar} from './local-calendar.mjs';
export {mondayOf} from './local-calendar.mjs';
import {actionEvidence,activityGroup} from './local-query.mjs';
const actions={
  drink:{behavior:/\b(drinking|drank|sipping|sipped|taking a drink|drinks? from|drink from)\b/},
  eat:{behavior:/\b(eating|ate|taking a bite|chewing)\b/},
  game:{behavior:/\b(gaming|playing (?:a |the )?(?:video |computer )?games?)\b/}
};
export function dailyHighlight(day){
  const n=day.count;
  if(!n)return 'No observations';
  if(n===1)return 'Only 1 recorded observation';
  if(day.actions.drink)return 'Drinking evidence recorded';
  if(day.actions.eat)return 'Eating evidence recorded';
  if(day.actions.game)return 'Gaming appeared';
  if(n>=3&&day.evening/n>=.6)return 'Evening-heavy observations';
  if(n>=3&&(day.categories.find(c=>c.label==='Computer use')?.count||0)/n>=.6)return 'Computer activity frequently observed';
  if(day.cameraCount>1)return 'Multiple cameras recorded';
  const place=day.locations[0];
  if(n>=3&&place&&place.count/n>=.6&&!/^(unknown|unknown location)$/i.test(place.label))return `Mostly ${place.label.slice(0,60)}${place.label.length>60?'…':''} observations`;
  if(day.lateNight)return 'Late-night observation';
  return `${n} recorded observations`;
}
export function historyWeek(storage,{date,timeZone='UTC'}){
  const from=mondayOf(date),to=addDays(from,6),clock=calendar(timeZone),db=storage.db;
  db.function('surv_week_group',{deterministic:true},activity=>activityGroup({activity,description:''}));
  db.function('surv_week_action',{deterministic:true},(activity,description,kind)=>Number(actionEvidence({activity,description},actions[kind])));
  db.function('surv_week_hour',{deterministic:true},timestamp=>clock.hour(timestamp));
  const where=`timestamp>=? AND timestamp<? AND source IN ('manual_ai','automatic_ai') AND ${storage.owned()}`;
  const totals=db.prepare(`SELECT COUNT(*) count,MIN(timestamp) first,MAX(timestamp) last,COUNT(DISTINCT camera_id) cameraCount,
    COALESCE(SUM(surv_week_action(activity,description,'drink')),0) drink,
    COALESCE(SUM(surv_week_action(activity,description,'eat')),0) eat,
    COALESCE(SUM(surv_week_action(activity,description,'game')),0) game,
    COALESCE(SUM(surv_week_hour(timestamp)>=18),0) evening,
    COALESCE(SUM(surv_week_hour(timestamp)<6),0) lateNight FROM observations WHERE ${where}`);
  const groups=db.prepare(`SELECT surv_week_group(activity) label,COUNT(*) count FROM observations WHERE ${where} GROUP BY label ORDER BY count DESC,label`);
  const places=db.prepare(`SELECT location label,COUNT(*) count FROM observations WHERE ${where} GROUP BY location ORDER BY count DESC,label LIMIT 3`);
  const days=Array.from({length:7},(_,i)=>{
    const date=addDays(from,i),bounds=dayBounds(date,timeZone),args=[bounds.from,bounds.to,...storage.ownerArgs()],row=totals.get(...args);
    const {drink,eat,game,...values}=row;
    const day={date,...values,actions:{drink,eat,game},categories:groups.all(...args),locations:places.all(...args)};
    return {...day,highlight:dailyHighlight(day)};
  });
  return {from,to,timeZone,days};
}
