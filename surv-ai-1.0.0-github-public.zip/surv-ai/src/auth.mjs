import {argon2,randomBytes,randomUUID,createHash,timingSafeEqual} from 'node:crypto';
import {promisify} from 'node:util';
const derive=promisify(argon2),digest=value=>createHash('sha256').update(value).digest('hex');
const parameters={memory:65536,passes:3,parallelism:1,tagLength:32};
const b64=buffer=>buffer.toString('base64').replace(/=+$/,'');
let hashing=0;
export class AuthError extends Error{constructor(status,message){super(message);this.status=status;}}
async function passwordKey(password,salt){
  if(hashing>=4)throw new AuthError(429,'Too many sign-in attempts. Please try again shortly.');
  hashing++;try{return await derive('argon2id',{...parameters,message:Buffer.from(password,'utf8'),nonce:salt});}finally{hashing--;}
}
export async function hashPassword(password){const salt=randomBytes(16),key=await passwordKey(password,salt);return `$argon2id$v=19$m=65536,t=3,p=1$${b64(salt)}$${b64(key)}`;}
export async function verifyPassword(password,encoded){
  const parts=String(encoded||'').match(/^\$argon2id\$v=19\$m=65536,t=3,p=1\$([A-Za-z0-9+/]{22})\$([A-Za-z0-9+/]{43})$/);
  if(!parts)return false;const key=await passwordKey(password,Buffer.from(parts[1],'base64')),expected=Buffer.from(parts[2],'base64');return expected.length===key.length&&timingSafeEqual(key,expected);
}
function fields(body,allowed){
  if(!body||Array.isArray(body)||typeof body!=='object'||Object.keys(body).some(key=>!allowed.includes(key)))throw new AuthError(400,'Invalid account fields. Account identity is server managed.');
}
function displayName(value){
  const name=typeof value==='string'?value.trim():null;
  if(typeof name!=='string'||!name||name.length>80||/\p{C}/u.test(name))throw new AuthError(400,'Use a display name of 1–80 characters.');
  return name;
}
function emailAddress(value){
  const email=typeof value==='string'?value.trim():null;
  if(typeof email!=='string'||email.length>254||!/^[a-zA-Z0-9.!#$%&'*+\/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9.-]*[a-zA-Z0-9])?\.[a-zA-Z]{2,}$/.test(email))throw new AuthError(400,'Enter a valid email address.');
  return {email,normalized:email.toLowerCase()};
}
function newPassword(password,confirmation){
  if(typeof password!=='string'||[...password].length<15||[...password].length>256||Buffer.byteLength(password)>1024)throw new AuthError(400,'Use a password or passphrase of 15–256 characters. Spaces are welcome.');
  if(password!==confirmation)throw new AuthError(400,'The passwords do not match.');
  return password;
}
function registration(body){
  fields(body,['displayName','email','password','confirmPassword']);
  return {name:displayName(body.displayName),...emailAddress(body.email),password:newPassword(body.password,body.confirmPassword)};
}
export class AuthService{
  constructor(storage,{now=()=>Date.now(),publicOrigin=null,onRevoke=()=>{},onRotate=()=>{}}={}){this.storage=storage;this.db=storage.db;this.now=now;this.publicOrigin=publicOrigin;this.onRevoke=onRevoke;this.onRotate=onRotate;this.dummy=null;}
  ownerId(){return this.db.prepare('SELECT owner_user_id FROM installation WHERE id=1').get().owner_user_id;}
  metadata(user){if(!user)return null;return {id:user.id,displayName:user.display_name,email:user.email,role:user.role,status:user.status,emailVerified:!!user.email_verified,createdAt:user.created_at,lastLoginAt:user.last_login_at,providers:this.db.prepare('SELECT provider FROM auth_identities WHERE user_id=? ORDER BY provider').all(user.id).map(r=>r.provider),installationOwner:this.ownerId()===user.id,deletionAllowed:this.ownerId()!==user.id&&(user.role!=='ADMIN'||this.db.prepare("SELECT COUNT(*) n FROM users WHERE role='ADMIN'").get().n>1)};}
  user(id){return this.db.prepare('SELECT * FROM users WHERE id=?').get(id)||null;}
  requestOrigin(req){
    const host=req.headers.host||'';
    if(this.publicOrigin){const expected=new URL(this.publicOrigin);if(expected.protocol!=='https:'||expected.username||expected.password||expected.pathname!=='/'||expected.search||expected.hash)throw new AuthError(503,'Configure SURV_PUBLIC_ORIGIN as an HTTPS origin.');if(host!==expected.host)throw new AuthError(403,'Use the configured Surv-AI origin.');return expected.origin;}
    if(!/^(127\.0\.0\.1|localhost)(:\d+)?$/.test(host))throw new AuthError(403,'Local access only.');return `http://${host}`;
  }
  cookieName(req){return this.requestOrigin(req).startsWith('https:')?'__Host-surv_session':'surv_session';}
  cookie(req,res,token,maxAge){res.setHeader('Set-Cookie',`${this.cookieName(req)}=${token}; HttpOnly; SameSite=Lax; Path=/; Max-Age=${maxAge}${this.requestOrigin(req).startsWith('https:')?'; Secure':''}`);}
  read(req){
    const name=this.cookieName(req),values=(req.headers.cookie||'').split(';').map(v=>v.trim()).filter(v=>v.startsWith(name+'='));if(values.length!==1)return null;
    const token=values[0].slice(name.length+1);if(!/^[A-Za-z0-9_-]{43}$/.test(token))return null;
    const row=this.db.prepare('SELECT * FROM auth_sessions WHERE token_hash=? AND revoked_at IS NULL').get(digest(token));if(!row)return null;
    if(row.expires_at<=this.now()||row.user_id&&row.last_seen_at+30*60000<=this.now()){this.revokeHash(row.token_hash,'auth_expired');return null;}
    const user=row.user_id?this.user(row.user_id):null;if(row.user_id&&user?.status!=='ACTIVE'){this.revokeHash(row.token_hash,'account_suspended');return null;}
    if(this.now()-row.last_seen_at>15000){row.last_seen_at=this.now();this.db.prepare('UPDATE auth_sessions SET last_seen_at=? WHERE token_hash=?').run(row.last_seen_at,row.token_hash);}
    return {...row,user};
  }
  issue(req,res,userId=null,old=null){
    if(old)this.revokeHash(old.token_hash,'session_rotation');
    const {token,row,seconds}=this.newSession(userId);this.insertSession(row);this.cookie(req,res,token,seconds);
    return this.read({...req,headers:{...req.headers,cookie:`${this.cookieName(req)}=${token}`}});
  }
  newSession(userId){
    const token=randomBytes(32).toString('base64url'),now=this.now(),seconds=userId?12*3600:20*60;
    return {token,seconds,row:{token_hash:digest(token),user_id:userId,csrf_token:randomBytes(32).toString('base64url'),created_at:now,last_seen_at:now,expires_at:now+seconds*1000,revoked_at:null}};
  }
  insertSession(row){this.db.prepare('INSERT INTO auth_sessions VALUES(?,?,?,?,?,?,NULL)').run(row.token_hash,row.user_id,row.csrf_token,row.created_at,row.last_seen_at,row.expires_at);}
  assertSession(session){
    const row=session&&this.db.prepare('SELECT revoked_at,expires_at FROM auth_sessions WHERE token_hash=?').get(session.token_hash);
    if(!row||row.revoked_at!==null||row.expires_at<=this.now()||!session.user_id||this.user(session.user_id)?.status!=='ACTIVE')throw new AuthError(401,'Sign in to continue.');
  }
  require(req){const session=this.read(req);this.assertSession(session);return session;}
  csrf(req,session,body=null){
    const origin=this.requestOrigin(req);if(req.headers.origin&&req.headers.origin!==origin||req.headers['sec-fetch-site']==='cross-site')throw new AuthError(403,'Use the same Surv-AI page.');
    const value=req.headers['x-surv-csrf']??body?.csrfToken;if(!session||typeof value!=='string'||!/^[A-Za-z0-9_-]{43}$/.test(value)||!timingSafeEqual(Buffer.from(value),Buffer.from(session.csrf_token)))throw new AuthError(403,'Security token missing or invalid. Refresh this page.');
  }
  bootstrap(req,res){let session=this.read(req);if(!session){this.throttle(req,'bootstrap','bootstrap');session=this.issue(req,res);}const owner=this.ownerId();return {user:this.metadata(session.user),csrfToken:session.csrf_token,ownerSetup:!owner,...(!owner?{legacy:Object.fromEntries(['observations','monitoring_sessions','cameras'].map(table=>[table,this.db.prepare(`SELECT COUNT(*) n FROM ${table} WHERE user_id IS NULL`).get().n]))}:{}),emailDeliveryConfigured:false};}
  throttle(req,email='',kind='login'){
    const now=this.now(),window=15*60000,ip=req.socket.remoteAddress||'local';
    for(const [bucket,limit] of kind==='bootstrap'?[[`${kind}:ip:${digest(ip)}`,30]]:[[`${kind}:ip:${digest(ip)}`,30],[`${kind}:email:${digest(email)}`,5]]){
      const row=this.db.prepare('SELECT * FROM auth_throttle WHERE bucket=?').get(bucket);
      if(row&&row.window_start+window>now&&row.attempts>=limit)throw new AuthError(429,'Too many sign-in attempts. Try again in 15 minutes.');
      this.db.prepare('INSERT INTO auth_throttle VALUES(?,1,?) ON CONFLICT(bucket) DO UPDATE SET attempts=CASE WHEN window_start+?<=? THEN 1 ELSE attempts+1 END,window_start=CASE WHEN window_start+?<=? THEN excluded.window_start ELSE window_start END').run(bucket,now,window,now,window,now);
    }
    this.db.prepare('DELETE FROM auth_throttle WHERE window_start<?').run(now-window);
  }
  async signup(body,{owner=false}={}){
    const input=registration(body),passwordHash=await hashPassword(input.password),id=randomUUID(),at=new Date(this.now()).toISOString();
    try{return this.storage.transaction(()=>{
      const current=this.ownerId();if(owner&&current||!owner&&!current)throw new AuthError(409,owner?'Owner setup is already complete. Sign in.':'Create the installation owner first.');
      this.db.prepare('INSERT INTO users VALUES(?,?,?,?,?,?,\'ACTIVE\',0,?,?,?)').run(id,input.name,input.email,input.normalized,passwordHash,owner?'ADMIN':'USER',at,at,at);
      this.db.prepare('INSERT INTO auth_identities VALUES(?,?,?,?,?,?)').run(randomUUID(),id,'password',input.normalized,input.email,at);
      if(owner){for(const table of ['observations','monitoring_sessions','cameras','app_settings'])this.db.prepare(`UPDATE ${table} SET user_id=? WHERE user_id IS NULL`).run(id);this.db.prepare('UPDATE installation SET owner_user_id=? WHERE id=1 AND owner_user_id IS NULL').run(id);}
      else this.db.prepare('INSERT INTO app_settings(interval_ms,save_snapshots,user_id) VALUES(15000,1,?)').run(id);
      return this.user(id);
    });}catch(e){if(e.status)throw e;throw new AuthError(409,'Unable to create an account with these details. Try signing in or use another email.');}
  }
  async login(body){
    const invalid=new AuthError(401,'Email or password is incorrect.');
    if(!body||Array.isArray(body)||Object.keys(body).some(k=>!['email','password'].includes(k))||typeof body.email!=='string'||typeof body.password!=='string'||body.email.length>254||Buffer.byteLength(body.password)>1024)throw invalid;
    const user=this.db.prepare('SELECT * FROM users WHERE email_normalized=?').get(body.email.trim().toLowerCase());
    if(!this.dummy)this.dummy=hashPassword(randomBytes(32).toString('base64url'));
    const valid=await verifyPassword(body.password,user?.password_hash||await this.dummy);
    // Password verification yields to the event loop. Do not authenticate a
    // password/email/status that changed while Argon2id was running.
    const current=user&&this.user(user.id);
    if(!valid||!current||current.status!=='ACTIVE'||current.password_hash!==user.password_hash||current.email_normalized!==user.email_normalized)throw invalid;
    const at=new Date(this.now()).toISOString();this.db.prepare('UPDATE users SET last_login_at=?,updated_at=? WHERE id=?').run(at,at,user.id);return this.user(user.id);
  }
  revokeHash(hash,reason='logout'){const row=this.db.prepare('SELECT user_id FROM auth_sessions WHERE token_hash=? AND revoked_at IS NULL').get(hash);if(!row)return;this.onRevoke({userId:row.user_id,sessionHash:hash,reason});this.db.prepare('UPDATE auth_sessions SET revoked_at=? WHERE token_hash=?').run(this.now(),hash);}
  logout(req,res,session){if(session)this.revokeHash(session.token_hash,'logout');this.cookie(req,res,'',0);}
  security(session){
    this.assertSession(session);
    const row=this.db.prepare('SELECT created_at,last_seen_at,expires_at FROM auth_sessions WHERE token_hash=?').get(session.token_hash),now=this.now();
    return {currentSession:{createdAt:new Date(row.created_at).toISOString(),lastActivityAt:new Date(row.last_seen_at).toISOString(),expiresAt:new Date(row.expires_at).toISOString()},otherSessionCount:this.db.prepare('SELECT COUNT(*) n FROM auth_sessions WHERE user_id=? AND token_hash<>? AND revoked_at IS NULL AND expires_at>? AND last_seen_at>?').get(session.user_id,session.token_hash,now,now-30*60000).n};
  }
  accountResult(session,revokedSessions){return {user:this.metadata(this.user(session.user_id)),csrfToken:session.csrf_token,security:this.security(session),...(revokedSessions===undefined?{}:{revokedSessions})};}
  updateProfile(session,body){
    fields(body,['displayName']);const name=displayName(body.displayName);
    this.storage.transaction(()=>{this.assertSession(session);this.db.prepare('UPDATE users SET display_name=?,updated_at=? WHERE id=?').run(name,new Date(this.now()).toISOString(),session.user_id);});
    return this.accountResult(session);
  }
  async confirmPassword(session,value){
    this.assertSession(session);const user=this.user(session.user_id);
    if(!user.password_hash||!this.db.prepare("SELECT id FROM auth_identities WHERE user_id=? AND provider='password'").get(user.id))throw new AuthError(403,'Password sign-in is required for this change. Provider account management is not available yet.');
    if(typeof value!=='string'||!value||Buffer.byteLength(value)>1024)throw new AuthError(400,'Enter your current password.');
    const valid=await verifyPassword(value,user.password_hash);this.assertSession(session);
    const current=this.user(user.id);
    if(!valid)throw new AuthError(400,'Current password is incorrect.');
    if(current.password_hash!==user.password_hash||current.email_normalized!==user.email_normalized)throw new AuthError(409,'Your sign-in details changed. Try again with the current details.');
    return user;
  }
  // Credential writes and all token revocations commit together. Runtime
  // callbacks run only after commit; a failed write cannot stop a valid run.
  replaceCurrent(req,res,session,expected,mutate,reason){
    this.requestOrigin(req);const replacement=this.newSession(session.user_id);
    const others=this.storage.transaction(()=>{
      this.assertSession(session);const user=this.user(session.user_id);
      if(user.password_hash!==expected.password_hash||user.email_normalized!==expected.email_normalized)throw new AuthError(409,'Your sign-in details changed. Try again with the current details.');
      mutate(user);
      const rows=this.db.prepare('SELECT token_hash FROM auth_sessions WHERE user_id=? AND token_hash<>? AND revoked_at IS NULL').all(session.user_id,session.token_hash);
      this.db.prepare('UPDATE auth_sessions SET revoked_at=? WHERE user_id=? AND revoked_at IS NULL').run(this.now(),session.user_id);this.insertSession(replacement.row);return rows;
    });
    this.cookie(req,res,replacement.token,replacement.seconds);
    const next={...replacement.row,user:this.user(session.user_id)};
    this.onRotate({userId:session.user_id,previousHash:session.token_hash,session:next});
    for(const row of others)this.onRevoke({userId:session.user_id,sessionHash:row.token_hash,reason});
    return this.accountResult(next,others.length);
  }
  async changeEmail(req,res,session,body){
    fields(body,['email','currentPassword']);const input=emailAddress(body.email),user=await this.confirmPassword(session,body.currentPassword);
    try{return this.replaceCurrent(req,res,session,user,()=>{
      this.db.prepare('UPDATE users SET email=?,email_normalized=?,email_verified=0,updated_at=? WHERE id=?').run(input.email,input.normalized,new Date(this.now()).toISOString(),session.user_id);
      this.db.prepare("UPDATE auth_identities SET provider_subject=?,provider_email=? WHERE user_id=? AND provider='password'").run(input.normalized,input.email,session.user_id);
    },'email_changed');}catch(e){if(e.status)throw e;if(String(e.code).includes('CONSTRAINT')||String(e.message).includes('UNIQUE'))throw new AuthError(409,'Unable to use these email details. Choose a different email.');throw e;}
  }
  async changePassword(req,res,session,body){
    fields(body,['currentPassword','newPassword','confirmPassword']);const password=newPassword(body.newPassword,body.confirmPassword),user=await this.confirmPassword(session,body.currentPassword);
    if(password===body.currentPassword)throw new AuthError(400,'Choose a new password different from your current password.');
    const encoded=await hashPassword(password);
    return this.replaceCurrent(req,res,session,user,()=>this.db.prepare('UPDATE users SET password_hash=?,updated_at=? WHERE id=?').run(encoded,new Date(this.now()).toISOString(),session.user_id),'password_changed');
  }
  revokeOtherSessions(session,body){
    fields(body,[]);
    const others=this.storage.transaction(()=>{this.assertSession(session);const rows=this.db.prepare('SELECT token_hash FROM auth_sessions WHERE user_id=? AND token_hash<>? AND revoked_at IS NULL').all(session.user_id,session.token_hash);this.db.prepare('UPDATE auth_sessions SET revoked_at=? WHERE user_id=? AND token_hash<>? AND revoked_at IS NULL').run(this.now(),session.user_id,session.token_hash);return rows;});
    for(const row of others)this.onRevoke({userId:session.user_id,sessionHash:row.token_hash,reason:'other_sessions_signed_out'});
    return this.accountResult(session,others.length);
  }
  assertUnchanged(session,expected){this.assertSession(session);const user=this.user(session.user_id);if(user.password_hash!==expected.password_hash||user.email_normalized!==expected.email_normalized)throw new AuthError(409,'Your sign-in details changed. Try again with the current details.');return user;}
  async resetUserPassword(session,targetId,body){
    fields(body,['currentPassword','newPassword','confirmPassword','confirmation']);
    if(this.user(session.user_id)?.role!=='ADMIN')throw new AuthError(403,'Administrator access required.');
    if(body.confirmation!=='RESET PASSWORD')throw new AuthError(400,'Type RESET PASSWORD to confirm this recovery action.');
    const replacement=newPassword(body.newPassword,body.confirmPassword),target=this.user(targetId);
    if(!target)throw new AuthError(404,'Account not found.');
    if(target.role!=='USER'||target.id===this.ownerId())throw new AuthError(403,'Local recovery is limited to normal USER accounts. ADMIN and owner credentials are protected.');
    if(!target.password_hash||!this.db.prepare("SELECT id FROM auth_identities WHERE user_id=? AND provider='password'").get(target.id))throw new AuthError(403,'This account does not have password sign-in.');
    const actor=await this.confirmPassword(session,body.currentPassword);
    if(await verifyPassword(replacement,target.password_hash))throw new AuthError(400,'Use a different replacement password.');
    const encoded=await hashPassword(replacement);
    const revoked=this.storage.transaction(()=>{
      if(this.assertUnchanged(session,actor).role!=='ADMIN')throw new AuthError(403,'Administrator access required.');
      const current=this.user(target.id);
      if(!current||current.role!=='USER'||current.id===this.ownerId())throw new AuthError(403,'This account cannot use USER recovery.');
      if(current.password_hash!==target.password_hash||current.email_normalized!==target.email_normalized)throw new AuthError(409,'The account sign-in details changed. Refresh and try again.');
      this.db.prepare('UPDATE users SET password_hash=?,updated_at=? WHERE id=?').run(encoded,new Date(this.now()).toISOString(),target.id);
      const rows=this.db.prepare('SELECT token_hash FROM auth_sessions WHERE user_id=? AND revoked_at IS NULL').all(target.id);
      this.db.prepare('UPDATE auth_sessions SET revoked_at=? WHERE user_id=? AND revoked_at IS NULL').run(this.now(),target.id);return rows;
    });
    for(const row of revoked)this.onRevoke({userId:target.id,sessionHash:row.token_hash,reason:'password_reset'});
    return {user:this.metadata(this.user(target.id)),revokedSessions:revoked.length};
  }
  async authorizeDeletion(session,body){
    fields(body,['currentPassword','confirmation']);
    if(body.confirmation!=='DELETE MY ACCOUNT')throw new AuthError(400,'Type DELETE MY ACCOUNT to confirm permanent deletion.');
    this.assertDeletable(session);return this.confirmPassword(session,body.currentPassword);
  }
  assertDeletable(session,expected){
    const user=expected?this.assertUnchanged(session,expected):(this.assertSession(session),this.user(session.user_id));
    if(user.id===this.ownerId())throw new AuthError(403,'The installation owner cannot be deleted. Safe ownership transfer is not available.');
    if(user.role==='ADMIN'&&this.db.prepare("SELECT COUNT(*) n FROM users WHERE role='ADMIN'").get().n<=1)throw new AuthError(403,'The last ADMIN cannot be deleted.');
    return user;
  }
  users(){return this.db.prepare('SELECT id FROM users ORDER BY created_at,id').all().map(row=>this.metadata(this.user(row.id)));}
  setStatus(actor,target,status){
    if(actor.role!=='ADMIN')throw new AuthError(403,'Administrator access required.');
    if(!['ACTIVE','SUSPENDED'].includes(status)||target===actor.id||target===this.ownerId())throw new AuthError(400,'The installation owner cannot be suspended. Choose an active or suspended user.');
    if(!this.user(target))throw new AuthError(404,'Account not found.');
    this.db.prepare('UPDATE users SET status=?,updated_at=? WHERE id=?').run(status,new Date(this.now()).toISOString(),target);
    if(status==='SUSPENDED')for(const row of this.db.prepare('SELECT token_hash FROM auth_sessions WHERE user_id=? AND revoked_at IS NULL').all(target))this.revokeHash(row.token_hash,'account_suspended');return this.metadata(this.user(target));
  }
}
