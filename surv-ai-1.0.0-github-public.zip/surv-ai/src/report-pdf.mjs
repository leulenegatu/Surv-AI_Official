import {spawn} from 'node:child_process';
import {existsSync} from 'node:fs';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
import os from 'node:os';

export async function renderReportPDF(report,{snapshots}={}){
  const noteworthy=await Promise.all((report.noteworthy||[]).slice(0,report.period.kind==='month'||report.period.length===30?8:5).map(async entry=>{
    if(!entry.snapshotRef)return {...entry,snapshotState:'not-retained'};
    try{if(!snapshots)throw Error('No snapshot reader');const image=await snapshots.get(entry.snapshotRef);if(image.data.length>5*1024*1024||!['image/png','image/jpeg','image/webp'].includes(image.type))throw Error('Unsupported source image');return {...entry,snapshotState:'retained',thumbnail:{type:image.type,data:image.data.toString('base64')}};}
    catch{return {...entry,snapshotState:'unavailable'};}
  }));
  report={...report,noteworthy};
  const python=process.env.SURV_REPORT_PYTHON||(process.platform==='win32'?'python':'python3');
  return new Promise((resolve,reject)=>{
    const env={...process.env,PYTHONIOENCODING:'utf-8'};delete env.OPENAI_API_KEY;
    const child=spawn(python,[fileURLToPath(new URL('./report_pdf.py',import.meta.url))],{env,stdio:['pipe','pipe','pipe'],windowsHide:true});
    const chunks=[];let size=0,settled=false;
    const fail=()=>{if(settled)return;settled=true;clearTimeout(timer);child.kill();reject(Error('The local PDF renderer is unavailable. Install requirements-report.txt for the report Python runtime, then retry.'));};
    const timer=setTimeout(fail,60000);child.on('error',fail);child.stdin.on('error',fail);child.stderr.resume();
    child.stdout.on('data',chunk=>{size+=chunk.length;if(size>20*1024*1024)return fail();chunks.push(chunk);});
    child.on('close',code=>{if(settled)return;if(code!==0)return fail();const pdf=Buffer.concat(chunks);if(!pdf.subarray(0,5).equals(Buffer.from('%PDF-')))return fail();settled=true;clearTimeout(timer);resolve(pdf);});
    child.stdin.end(JSON.stringify(report));
  });
}
