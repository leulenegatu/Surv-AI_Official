import {DatabaseSync} from 'node:sqlite';
import {mkdirSync,writeFileSync} from 'node:fs';
import {randomUUID,createHash} from 'node:crypto';
import path from 'node:path';
const tables=['observations','monitoring_sessions','cameras','app_settings'];
const rowDigest=db=>Object.fromEntries(tables.map(table=>[table,createHash('sha256').update(JSON.stringify(db.prepare(`SELECT * FROM ${table} ORDER BY id`).all())).digest('hex')]));
export function verifiedBackup(db,filename,label='pre-v09'){
  if(filename===':memory:')return null;
  const directory=path.join(path.dirname(filename),'backups');mkdirSync(directory,{recursive:true});
  const target=path.join(directory,`${label}-${new Date().toISOString().replace(/[:.]/g,'-')}-${randomUUID()}.sqlite`),before=rowDigest(db);
  db.prepare('VACUUM INTO ?').run(target);
  const copy=new DatabaseSync(target,{readOnly:true});
  try{if(copy.prepare('PRAGMA integrity_check').get().integrity_check!=='ok'||copy.prepare('PRAGMA foreign_key_check').all().length||JSON.stringify(rowDigest(copy))!==JSON.stringify(before)||copy.prepare('PRAGMA user_version').get().user_version!==db.prepare('PRAGMA user_version').get().user_version)throw Error('The independent SQLite backup failed verification.');}
  finally{copy.close();}
  writeFileSync(target+'.verified.json',JSON.stringify({schema:db.prepare('PRAGMA user_version').get().user_version,rows:before,integrity:'ok'},null,2));return target;
}
export function migrateOwnership(db,filename,{backup:needsBackup=true}={}){
  const backup=needsBackup?verifiedBackup(db,filename):null;
  db.exec('BEGIN IMMEDIATE');
  try{
    db.exec(`
      CREATE TABLE users(id TEXT PRIMARY KEY,display_name TEXT NOT NULL,email TEXT NOT NULL,email_normalized TEXT NOT NULL UNIQUE,password_hash TEXT,role TEXT NOT NULL CHECK(role IN ('ADMIN','USER')),status TEXT NOT NULL CHECK(status IN ('ACTIVE','SUSPENDED')),email_verified INTEGER NOT NULL DEFAULT 0 CHECK(email_verified IN (0,1)),created_at TEXT NOT NULL,updated_at TEXT NOT NULL,last_login_at TEXT) STRICT;
      CREATE TABLE auth_identities(id TEXT PRIMARY KEY,user_id TEXT NOT NULL REFERENCES users(id),provider TEXT NOT NULL CHECK(provider IN ('password','google')),provider_subject TEXT NOT NULL,provider_email TEXT,created_at TEXT NOT NULL,UNIQUE(provider,provider_subject)) STRICT;
      CREATE TABLE auth_sessions(token_hash TEXT PRIMARY KEY,user_id TEXT REFERENCES users(id),csrf_token TEXT NOT NULL,created_at INTEGER NOT NULL,last_seen_at INTEGER NOT NULL,expires_at INTEGER NOT NULL,revoked_at INTEGER) STRICT;
      CREATE INDEX auth_sessions_user ON auth_sessions(user_id);
      CREATE TABLE auth_throttle(bucket TEXT PRIMARY KEY,attempts INTEGER NOT NULL,window_start INTEGER NOT NULL) STRICT;
      CREATE TABLE installation(id INTEGER PRIMARY KEY CHECK(id=1),owner_user_id TEXT REFERENCES users(id)) STRICT;
      INSERT INTO installation VALUES(1,NULL);
      ALTER TABLE observations ADD COLUMN user_id TEXT REFERENCES users(id);
      ALTER TABLE monitoring_sessions ADD COLUMN user_id TEXT REFERENCES users(id);
      ALTER TABLE cameras ADD COLUMN user_id TEXT REFERENCES users(id);
      CREATE TABLE app_settings_v5(id INTEGER PRIMARY KEY,interval_ms INTEGER NOT NULL CHECK(interval_ms IN (15000,30000,60000)),save_snapshots INTEGER NOT NULL CHECK(save_snapshots IN (0,1)),user_id TEXT REFERENCES users(id)) STRICT;
      INSERT INTO app_settings_v5(id,interval_ms,save_snapshots) SELECT id,interval_ms,save_snapshots FROM app_settings;
      DROP TABLE app_settings;
      ALTER TABLE app_settings_v5 RENAME TO app_settings;
      CREATE UNIQUE INDEX settings_user ON app_settings(user_id);
      DROP INDEX cameras_device;
      CREATE UNIQUE INDEX cameras_device ON cameras(user_id,device_id) WHERE device_id IS NOT NULL AND deleted_at IS NULL;
      CREATE INDEX observations_user_date ON observations(user_id,timestamp);
      CREATE INDEX observations_user_snapshot ON observations(user_id,snapshot_ref);
      CREATE INDEX sessions_user_date ON monitoring_sessions(user_id,started_at);
      CREATE INDEX cameras_user ON cameras(user_id);
      PRAGMA user_version=5;
    `);
    if(db.prepare('PRAGMA foreign_key_check').all().length)throw Error('Ownership migration failed its integrity check.');
    db.exec('COMMIT');return backup;
  }catch(e){db.exec('ROLLBACK');throw Error('Account ownership migration failed; existing history was preserved.',{cause:e});}
}
