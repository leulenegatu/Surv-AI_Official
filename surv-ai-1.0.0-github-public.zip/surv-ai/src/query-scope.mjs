// Deterministic date expressions within the user's selected calendar scope.
import {validDate,mondayOf,addDays,rangeBounds} from './local-calendar.mjs';
const weekdays=['monday','tuesday','wednesday','thursday','friday','saturday','sunday'];
const months=['january','february','march','april','may','june','july','august','september','october','november','december'];
export function queryScope(question,{date,timeZone='UTC',scope='day'}){
  validDate(date);if(!['week','day'].includes(scope))throw Error('Choose week or day query scope.');
  let from=scope==='week'?mondayOf(date):date,to=scope==='week'?addDays(from,6):date;
  const original={date,historyDate:date,timeZone,scope,requestedScope:scope,from,to};
  const fail=reason=>({...original,question,reason,bounds:rangeBounds(from,to,timeZone)});
  if((question.match(/\b\d{4}-\d{2}-\d{2}\b/g)||[]).length>1)return fail('Choose one date, or ask about the entire selected week.');
  let text=question,target=null,explicit=false;
  const iso=text.match(/\b\d{4}-\d{2}-\d{2}\b/);
  const named=text.match(new RegExp('\\bon\\s+('+months.join('|')+')\\s+(\\d{1,2})(?:st|nd|rd|th)?(?:,?\\s+(\\d{4}))?\\b','i'));
  const weekday=text.match(new RegExp('\\b(?:on|happened|do|observed)\\s+('+weekdays.join('|')+')\\b','i'));
  if(iso){target=iso[0];text=text.replace(iso[0],'');explicit=true;}
  else if(named){
    const month=String(months.indexOf(named[1].toLowerCase())+1).padStart(2,'0'),day=named[2].padStart(2,'0');
    const candidates=(named[3]?[named[3]]:[...new Set([from.slice(0,4),to.slice(0,4)])]).map(year=>`${year}-${month}-${day}`);
    target=candidates.find(d=>d>=from&&d<=to)||candidates[0];text=text.replace(named[0],'');explicit=true;
  }else if(weekday){target=addDays(mondayOf(date),weekdays.indexOf(weekday[1].toLowerCase()));text=text.replace(weekday[0],weekday[0].toLowerCase().startsWith('on ')?'':weekday[0].split(/\s+/)[0]);explicit=true;}
  else if(/\btoday\b|\bthis (?:morning|afternoon|evening)\b/i.test(text)&&! /\bthis week\b/i.test(text)){target=date;}
  if(target){try{validDate(target);}catch{return fail('Choose a valid calendar date.');}
    if(target<from||target>to)return fail('That date is outside the selected scope. Use Jump to date or select its week first.');
    from=to=target;scope='day';date=target;
  }
  if(original.requestedScope==='day'&&/\bthis week\b/i.test(text))return fail('Select Entire week to ask about this week.');
  if(/\blast week|next week|last month|yesterday|tomorrow\b/i.test(text))return fail('Use the week controls or Jump to date to choose that period first.');
  const daily=/\bwhich days?\b|\beach day\b/i.test(text);
  text=text.replace(/\bthis week\b|\beach day\b/gi,'').replace(/\bwhich days had\b/gi,'Show observations').replace(/\bwhich day had the most observations\b/gi,'How many observations');
  return {...original,date,scope,from,to,question:text.trim(),explicit,daily,bounds:rangeBounds(from,to,timeZone)};
}
