from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parent.parent / '.local-python'))
"""Deterministic, local PDF layout. Reads a structured summary from stdin.
No network, model client, database access, or retained report files.
"""
import io
import base64
import json
import os
import sys
from datetime import date
from html import escape

import reportlab
from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.pagesizes import A4
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Flowable, KeepTogether, Image as PDFImage
from PIL import Image, ImageOps

INK = colors.HexColor('#14252c')
MUTED = colors.HexColor('#56686e')
MINT = colors.HexColor('#159878')
PALE = colors.HexColor('#edf7f3')
LINE = colors.HexColor('#dce5e3')
# Platypus frames add 6pt of padding inside each document margin.
WIDTH = A4[0] - 100
FONTS = os.path.join(os.path.dirname(reportlab.__file__), 'fonts')
pdfmetrics.registerFont(TTFont('Surv', os.path.join(FONTS, 'Vera.ttf')))
pdfmetrics.registerFont(TTFont('SurvBold', os.path.join(FONTS, 'VeraBd.ttf')))
pdfmetrics.registerFontFamily('Surv', normal='Surv', bold='SurvBold', italic='Surv', boldItalic='SurvBold')
styles = {
    'body': ParagraphStyle('body', fontName='Surv', fontSize=9.2, leading=13.5, textColor=INK, spaceAfter=7, splitLongWords=True),
    'small': ParagraphStyle('small', fontName='Surv', fontSize=8, leading=11, textColor=MUTED, splitLongWords=True),
    'sectionNote': ParagraphStyle('sectionNote', fontName='Surv', fontSize=8, leading=11, textColor=MUTED, splitLongWords=True, keepWithNext=True),
    'cell': ParagraphStyle('cell', fontName='Surv', fontSize=7.7, leading=11, textColor=INK, splitLongWords=True),
    'headcell': ParagraphStyle('headcell', fontName='SurvBold', fontSize=7.7, leading=11, textColor=colors.white),
    'section': ParagraphStyle('section', fontName='SurvBold', fontSize=16, leading=21, textColor=INK, spaceBefore=16, spaceAfter=8, keepWithNext=True),
    'eyebrow': ParagraphStyle('eyebrow', fontName='SurvBold', fontSize=8, leading=12, textColor=MINT, spaceAfter=7),
    'hero': ParagraphStyle('hero', fontName='SurvBold', fontSize=26, leading=33, textColor=colors.white, spaceAfter=12),
    'heroSmall': ParagraphStyle('heroSmall', fontName='Surv', fontSize=10, leading=15, textColor=colors.HexColor('#d2ece3')),
    'metric': ParagraphStyle('metric', fontName='SurvBold', fontSize=21, leading=27, textColor=INK),
}

def clean(text):
    return str(text).replace('\u2011', '-').replace('\u2013', '-').replace('\u2014', '-').replace('\x00', '')

def p(text, style='body'):
    return Paragraph(escape(clean(text)), styles[style])

def desktop_text(c):
    tab = c.get('tabTitle') or ''
    excerpt = tab[:320] + (' [excerpt; exact title in personal export]' if len(tab) > 320 else '')
    browser = (' / Verified hostname: ' + c['hostname'] + (' / Tab: ' + excerpt if tab else '') + ' / Source: browser companion + Windows' if c.get('hostname') else ' / Source: Windows only')
    return 'Application: ' + (c.get('application') or c.get('executable') or 'Unavailable') + (' / Window: ' + c['title'] if c.get('title') else '') + browser + ' / Computer state: ' + c['state'] + ' / Nearby sample: ' + c['sampledAt'] + '. Supporting computer evidence; foreground does not prove active use.'

def fmt(day):
    value = date.fromisoformat(day)
    return f'{value.strftime("%B")} {value.day}, {value.year}'

def short(day):
    value = date.fromisoformat(day)
    return f'{value.strftime("%b")} {value.day}'

def table(headers, rows, widths):
    values = [[p(v, 'headcell') for v in headers]] + [[p(v, 'cell') for v in row] for row in rows]
    result = Table(values, colWidths=widths, repeatRows=1, hAlign='LEFT')
    result.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), INK),
        ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.HexColor('#f4f8f7')]),
        ('VALIGN', (0, 0), (-1, -1), 'TOP'),
        ('LEFTPADDING', (0, 0), (-1, -1), 8), ('RIGHTPADDING', (0, 0), (-1, -1), 8),
        ('TOPPADDING', (0, 0), (-1, -1), 6), ('BOTTOMPADDING', (0, 0), (-1, -1), 6),
        ('LINEBELOW', (0, 0), (-1, 0), 0.7, INK),
        ('LINEBELOW', (0, 1), (-1, -1), 0.3, LINE),
    ]))
    return result

def source_thumbnail(entry):
    """Optional retained source only. An unreadable image cannot break a report."""
    try:
        raw = base64.b64decode(entry['thumbnail']['data'], validate=True)
        if len(raw) > 5 * 1024 * 1024:
            return None
        with Image.open(io.BytesIO(raw)) as original:
            if original.width * original.height > 24_000_000:
                return None
            source = ImageOps.exif_transpose(original)
            source.thumbnail((480, 300))
            output = io.BytesIO()
            source.convert('RGB').save(output, format='JPEG', quality=85)
            output.seek(0)
            scale = min(112 / source.width, 88 / source.height)
            return PDFImage(output, width=source.width * scale, height=source.height * scale)
    except Exception:
        return None

class CoverageChart(Flowable):
    def __init__(self, days):
        super().__init__()
        self.days = days
        self.width = WIDTH
        self.height = 116

    def draw(self):
        c = self.canv
        maximum = max(1, max(d['count'] for d in self.days))
        step = WIDTH / len(self.days)
        c.setStrokeColor(LINE)
        c.line(0, 25, WIDTH, 25)
        for i, day in enumerate(self.days):
            x = i * step + 3
            bar = max(1, 65 * day['count'] / maximum)
            c.setFillColor(MINT if day['count'] else LINE)
            c.roundRect(x, 26, max(3, step - 6), bar, 2, stroke=0, fill=1)
            if len(self.days) == 7 or i % 5 == 0 or i == len(self.days) - 1:
                c.setFillColor(MUTED)
                c.setFont('Surv', 7)
                if i == 0:
                    c.drawString(0, 12, short(day['date']))
                elif i == len(self.days) - 1:
                    c.drawRightString(WIDTH, 12, short(day['date']))
                else:
                    c.drawCentredString(x + (step - 6) / 2, 12, short(day['date']))
            if day['count']:
                c.setFillColor(INK)
                c.setFont('Surv', 7)
                c.drawCentredString(x + (step - 6) / 2, 31 + bar, str(day['count']))

class ReportDocument(SimpleDocTemplate):
    def __init__(self, target, report):
        self.report = report
        self.page_total = None
        super().__init__(target, pagesize=A4, rightMargin=44, leftMargin=44, topMargin=54, bottomMargin=44,
                         title='Surv-AI Activity & Wellness Observation Report', author='Surv-AI', pageCompression=1)

    def afterFlowable(self, flowable):
        if isinstance(flowable, Paragraph) and flowable.style.name == 'section':
            self.canv.bookmarkPage(flowable.getPlainText())
            self.canv.addOutlineEntry(flowable.getPlainText(), flowable.getPlainText(), 0, False)

def generate(report):
    output = io.BytesIO()
    doc = ReportDocument(output, report)
    period = report['period']
    period_label = f'{fmt(period["startDate"])} - {fmt(period["endDate"])}'
    story = []
    report_name = f'{period["label"]} MONTHLY REPORT' if period.get('kind') == 'month' else f'{period["length"]}-DAY REPORT'
    story.append(p(f'{report_name}  /  LOCAL OBSERVATION HISTORY', 'eyebrow'))
    hero = Table([[
        [p('SURV-AI', 'hero'), p('Activity & Wellness<br/>Observation Report'.replace('<br/>', '\n'), 'heroSmall')],
        [p(period_label, 'heroSmall'), Spacer(1, 10), p(f'Generated {report["generatedLabel"]}', 'heroSmall'), p(period['timeZone'], 'heroSmall')]
    ]], colWidths=[WIDTH * .53, WIDTH * .47])
    hero.setStyle(TableStyle([('BACKGROUND', (0, 0), (-1, -1), INK), ('VALIGN', (0, 0), (-1, -1), 'TOP'), ('TOPPADDING', (0, 0), (-1, -1), 22), ('BOTTOMPADDING', (0, 0), (-1, -1), 22), ('LEFTPADDING', (0, 0), (-1, -1), 20), ('RIGHTPADDING', (0, 0), (-1, -1), 20)]))
    story.extend([hero, Spacer(1, 16), p('This report summarizes recorded point-in-time Surv-AI observations. It is not a medical diagnosis and gaps in observation should not be interpreted as inactivity, absence, or sleep.')])
    if report.get('accountDisplayName'):
        story.append(p('Saved observation history for ' + report['accountDisplayName'], 'small'))
    for warning in report['warnings']:
        story.append(p(warning, 'small'))

    def section(number, title, note=None):
        story.append(p(f'{number:02d}  {title}', 'section'))
        if note:
            story.append(p(note, 'sectionNote'))

    s = report['summary']
    section(1, 'Period overview')
    metrics = [(s['total'], 'Recorded observations'), (f'{s["observedDays"]} / {period["length"]}', 'Days with observations'), (s['automatic'], 'Automatic observations'), (s['manual'], 'Manual observations'), (s['cameras'], 'Recorded cameras'), (f'{s["confidence"]}%' if s['confidence'] is not None else 'Not available', 'Mean label confidence')]
    rows = []
    for i in (0, 3):
        rows.append([[p(str(value), 'metric'), p(label, 'small')] for value, label in metrics[i:i + 3]])
    cards = Table(rows, colWidths=[WIDTH / 3] * 3)
    cards.setStyle(TableStyle([('BACKGROUND', (0, 0), (-1, -1), PALE), ('VALIGN', (0, 0), (-1, -1), 'TOP'), ('BOX', (0, 0), (-1, -1), .4, LINE), ('INNERGRID', (0, 0), (-1, -1), .4, LINE), ('TOPPADDING', (0, 0), (-1, -1), 12), ('BOTTOMPADDING', (0, 0), (-1, -1), 12), ('LEFTPADDING', (0, 0), (-1, -1), 12)]))
    story.extend([cards, Spacer(1, 10), p('Confidence is an AI label estimate, not a validated accuracy measure. Counts describe saved observations, never continuous activity duration.', 'small')])
    m = report['monitoring']
    story.append(table(['Monitoring runs represented', 'Successful analyses', 'Failed analyses', 'No-person skips'], [[m['sessions'], m['successful'], m['failed'], m['noPerson']]], [WIDTH / 4] * 4))
    story.append(p(f'Analysis and skip counters cover {m["counterSessions"]} runs whose recorded counter window is wholly within this period. {m["excludedSessions"]} boundary-spanning runs are excluded from those counter totals because their lifetime counters cannot be allocated reliably. Manual analyses are not included in these run counters.', 'small'))

    section(2, 'Daily observation coverage', 'Each bar is a saved observation count. A zero means no recorded observations; it does not mean no activity. First and last times mark recorded points, not an uninterrupted window.')
    story.append(CoverageChart(report['days']))
    coverage = []
    for d in report['days']:
        coverage.append([short(d['date']), d['count'], f'{d["first"]}\n{d["last"]}' if d['count'] else 'No recorded observations', ', '.join(a['label'] for a in d['activities']) or '-', ', '.join(c['label'] for c in d['cameras']) or '-'])
    story.append(table(['Day', 'Count', 'First / last recorded', 'Main categories', 'Camera / location'], coverage, [53, 43, 109, 152, WIDTH - 357]))

    section(3, 'Activity patterns', 'Closely related explicit activity labels are grouped conservatively. Every observation contributes to exactly one category. Frequency is not duration; ambiguous activity remains Other observed activity.')
    if report['activities']:
        story.append(table(['Recorded category', 'Observations', 'Share of observations', 'Observed days'], [[a['label'], a['count'], f'{a["percent"]}%', a['days']] for a in report['activities']], [WIDTH * .44, WIDTH * .18, WIDTH * .22, WIDTH * .16]))
        story.append(Spacer(1, 7))
        for e in report['evidence']:
            story.append(p(f'Original label example: "{e["activity"]}" ({short(e["date"])}, {e["time"]}, {e["location"]}); grouped as {e["category"]}.', 'small'))
    else:
        story.append(p('No activity observations were recorded in this period.'))

    desktop = report.get('desktop', {})
    if desktop.get('spanCount'):
        story.append(p('Desktop context / Estimated foreground time', 'section'))
        story.append(p('Two-second sampled computer state, clipped to this report. Gaps are excluded; foreground includes idle context and does not measure human activity, attention or productivity.', 'small'))
        def duration(ms):
            seconds = max(0, int(ms // 1000))
            return f'{seconds // 3600}h {(seconds % 3600) // 60}m {seconds % 60}s'
        story.append(table(['Foreground application', 'Estimated time'], [[a['label'], duration(a['ms'])] for a in desktop.get('applications', [])[:8]] or [['Application unavailable', '-']], [WIDTH * .65, WIDTH * .35]))
        story.append(p('Computer state: ' + ', '.join(v['label'] + ' ' + duration(v['ms']) for v in desktop.get('states', [])) + '.', 'small'))
        if desktop.get('independentMs'):
            story.append(p('Confirmed context coverage: camera-free ' + duration(desktop.get('cameraFreeMs', 0)) + '; camera-assisted ' + duration(desktop.get('cameraAssistedMs', 0)) + '. Browser foreground time is a subset of application time.', 'small'))
        if desktop.get('browserHosts'):
            story.append(p('Verified foreground browser hosts (highest confirmed times; included in application totals):', 'small'))
            story.append(table(['Application / exact hostname', 'Confirmed time'], [[h['application'] + ' / ' + h['hostname'], duration(h['ms'])] for h in desktop['browserHosts'][:6]], [WIDTH * .65, WIDTH * .35]))
    for e in report.get('desktopEvidence', []):
        story.append(p('Desktop context at observation (' + e['date'] + ' / ' + e['time'] + ' / ' + (e.get('cameraName') or 'Unassigned camera') + '): ' + desktop_text(e['desktopContext']), 'small'))

    section(4, 'Object / environment context', 'Objects are counted once per observation after obvious aliases are combined. Object visibility does not establish use. Repeated objects are prioritized; sparse reports include a small number of useful visible objects.')
    if report['objects']:
        story.append(table(['Visible object', 'Observations', 'Observed days'], [[o['label'], o['count'], o['days']] for o in report['objects']], [WIDTH * .6, WIDTH * .22, WIDTH * .18]))
    else:
        story.append(p('Insufficient repeated object evidence to summarize reliably.'))
    if report['cameras']:
        story.extend([Spacer(1, 10), table(['Recorded camera / source context', 'Observations', 'Observed days'], [[c['label'], c['count'], c['days']] for c in report['cameras']], [WIDTH * .6, WIDTH * .22, WIDTH * .18])])
        if s['total'] > 5:
            story.append(p('Camera counts use saved camera associations. Older unassigned observations and manual uploads are shown separately; no historical camera identity is inferred.', 'small'))
    if report.get('locations'):
        if s['total'] <= 5:
            story.append(p('Recorded location evidence: ' + ', '.join(f'{c["label"]} ({c["count"]} observations)' for c in report['locations']) + '.', 'small'))
        else:
            story.extend([Spacer(1, 8), table(['Common recorded location wording', 'Observations', 'Observed days'], [[c['label'], c['count'], c['days']] for c in report['locations']], [WIDTH * .6, WIDTH * .22, WIDTH * .18])])
            story.append(p('Up to six recurring location descriptions are shown as recorded. Differently worded descriptions may refer to the same place.', 'small'))

    section(5, 'Routine / time-of-day patterns', f'Local calendar and clock: {period["timeZone"]}. Distribution reflects when the camera recorded observations. Missing coverage cannot establish sleep, wake times or absence.')
    story.append(table(['Time of day', 'Local clock range', 'Observations', 'Share', 'Observed days'], [[t['label'], t['window'], t['count'], f'{t["percent"]}%', t['days']] for t in report['timeOfDay']], [WIDTH * .22, WIDTH * .27, WIDTH * .19, WIDTH * .14, WIDTH * .18]))

    section(6, 'Patterns worth reviewing', 'Observational context for your own review or a discussion with a professional. These statements describe recorded evidence and coverage, without assessing health or diagnosing conditions.')
    if report['patterns']:
        for text in report['patterns']:
            block = Table([[p(text)]], colWidths=[WIDTH])
            block.setStyle(TableStyle([('BACKGROUND', (0, 0), (-1, -1), PALE), ('LINEBEFORE', (0, 0), (0, 0), 2, MINT), ('TOPPADDING', (0, 0), (-1, -1), 10), ('BOTTOMPADDING', (0, 0), (-1, -1), 6), ('LEFTPADDING', (0, 0), (-1, -1), 12), ('RIGHTPADDING', (0, 0), (-1, -1), 12)]))
            story.extend([block, Spacer(1, 7)])
    else:
        story.append(p('There is insufficient recurring evidence to identify an additional pattern. Refer to the recorded counts and coverage above.'))

    noteworthy_start = len(story)
    section(7, 'Noteworthy observations', 'Individual saved evidence for human review, separate from aggregate patterns. Different or uncommon does not mean negative. Original AI wording may be inaccurate and is not a diagnosis or verified emotional state.')
    entries = report.get('noteworthy', [])[:8 if period.get('kind') == 'month' or period['length'] == 30 else 5]
    if not entries:
        story.append(p("No individual saved observations met the report's noteworthy-evidence criteria during this period."))
    for entry_index, entry in enumerate(entries):
        description = entry['description']
        excerpt = description[:500] + ('...' if len(description) > 500 else '')
        source = 'Automatic AI' if entry['source'] == 'automatic_ai' else 'Manual AI'
        text = [
            p(f'{fmt(entry["date"])}  /  {entry["time"]}', 'eyebrow'),
            p('Recorded observation: "' + entry['activity'] + '"'),
            p(('Recorded description excerpt: ' if len(description) > 500 else 'Recorded description: ') + '"' + excerpt + '"', 'small'),
            p(f'Context: {entry["cameraName"] or "Unassigned camera"} / {entry["location"]} / {source} / {round(entry["confidence"] * 100)}% confidence estimate', 'small'),
            p('Why this was surfaced: ' + entry['reason'], 'small'),
            p('Visible context: ' + (', '.join(entry['objects'][:8]) or 'No objects listed') + (f' (+{len(entry["objects"]) - 8} more recorded objects)' if len(entry['objects']) > 8 else ''), 'small'),
            p('Observation ID: ' + entry['id'], 'small'),
        ]
        if entry.get('desktopContext'):
            text.append(p('Desktop context at observation: ' + desktop_text(entry['desktopContext']), 'small'))
        if entry.get('evidenceQuote') and entry['evidenceQuote'] not in excerpt and entry['evidenceQuote'] not in entry['activity']:
            text.insert(3, p('Explicit saved wording: "' + entry['evidenceQuote'] + '"', 'small'))
        image = source_thumbnail(entry)
        right = [image, Spacer(1, 5), p('Source snapshot for this observation', 'small')] if image else [p('No source snapshot retained.' if not entry.get('snapshotRef') else 'Source snapshot unavailable; recorded evidence remains available.', 'small')]
        block = Table([[text, right]], colWidths=[WIDTH - 136, 136], hAlign='LEFT')
        block.setStyle(TableStyle([('BACKGROUND', (0, 0), (-1, -1), PALE), ('LINEBEFORE', (0, 0), (0, 0), 2, MINT), ('VALIGN', (0, 0), (-1, -1), 'TOP'), ('TOPPADDING', (0, 0), (-1, -1), 12), ('BOTTOMPADDING', (0, 0), (-1, -1), 8), ('LEFTPADDING', (0, 0), (-1, -1), 12), ('RIGHTPADDING', (0, 0), (-1, -1), 12)]))
        if entry_index == 0:
            story[noteworthy_start:] = [KeepTogether(story[noteworthy_start:] + [block]), Spacer(1, 9)]
        else:
            story.extend([KeepTogether([block]), Spacer(1, 9)])

    section(8, 'Day-by-day summary', 'A chronological summary of saved points. The first-to-last span below is a recorded observation window and is not activity duration.')
    skip_until = -1
    for index, d in enumerate(report['days']):
        if index < skip_until:
            continue
        if not d['count']:
            end = index
            while end + 1 < len(report['days']) and not report['days'][end + 1]['count']:
                end += 1
            label = fmt(d['date']) if end == index else f'{short(d["date"])} - {fmt(report["days"][end]["date"])}'
            story.append(p(f'{label}: no recorded observations on {end - index + 1} calendar day(s).', 'small'))
            skip_until = end + 1
            continue
        lines = [p(f'{fmt(d["date"])}  /  {d["count"]} observations', 'eyebrow'), p(f'Recorded points: {d["first"]} to {d["last"]}. Context: {", ".join(c["label"] for c in d["cameras"])}.', 'small'), p('Common recorded categories: ' + ', '.join(f'{a["label"]} ({a["count"]})' for a in d['activities']) + '.', 'small')]
        if d['objects']:
            lines.append(p('Visible objects: ' + ', '.join(f'{o["label"]} ({o["count"]})' for o in d['objects']) + '.', 'small'))
        story.extend([KeepTogether(lines), Spacer(1, 6)])

    methodology_start = len(story)
    section(9, 'Methodology / limitations')
    for text in [
        'Surv-AI records point-in-time observations. Counts do not equal duration. Object visibility does not prove use; ambiguous activity wording remains unclassified.',
        'Missing observations do not establish inactivity, absence or sleep. Camera placement, availability and monitoring settings affect what can be observed.',
        'OpenCV person gating can prevent requests when no person is detected. Detection can miss a person; skip counts do not establish absence. AI-generated labels and confidence estimates may be imperfect.',
        'Activity wording and obvious object aliases are grouped locally; original records are preserved. Calendar days use the report time zone, including daylight-saving changes. Day 1 and the ending date are inclusive.',
        'Monitoring counters describe whole runs. Boundary-spanning run counters are excluded because their events cannot be allocated reliably to dates.',
        'Noteworthy selection uses explicit saved wording or uncommon recorded categories, camera contexts, and clock times within this period. It does not assess health or diagnose conditions. Sparse history cannot establish a routine. Only a small set of representative observations is selected; this is not an exhaustive review.',
        'Source snapshot thumbnails appear only for selected observations whose associated image was retained and readable. Missing images do not establish missing activity. Original labels and images are preserved; description excerpts are labelled.',
        'Generated locally from saved observations and monitoring runs, without demo history or additional AI analysis. This is observational context, not medical advice or a physical or mental health diagnosis.'
    ]:
        story.append(p(text))
    # Keep the final review notes intact instead of leaving a few lines on a new page.
    story[methodology_start:] = [KeepTogether(story[methodology_start:])]

    def decoration(c, document):
        c.saveState()
        c.setFillColor(MINT)
        c.setFont('SurvBold', 10)
        c.drawString(44, A4[1] - 33, 'SURV-AI')
        c.setFillColor(MUTED)
        c.setFont('Surv', 7.5)
        page_label = f'{period["label"]} monthly observation report' if period.get('kind') == 'month' else f'{period["length"]}-day observation report'
        c.drawRightString(A4[0] - 44, A4[1] - 33, page_label)
        c.setStrokeColor(LINE)
        c.line(44, 39, A4[0] - 44, 39)
        c.setFont('Surv', 7)
        c.drawString(44, 26, f'{short(period["startDate"])} - {short(period["endDate"])} {period["endDate"][:4]}  |  {period["timeZone"]}')
        c.drawRightString(A4[0] - 44, 26, f'Page {document.page}')
        c.restoreState()

    doc.build(story, onFirstPage=decoration, onLaterPages=decoration)
    return output.getvalue()

if __name__ == '__main__':
    report = json.load(sys.stdin)
    pdf = generate(report)
    sys.stdout.buffer.write(pdf)
