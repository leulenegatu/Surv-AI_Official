import fs from 'node:fs';
import path from 'node:path';
import {randomUUID} from 'node:crypto';

function failure(status,message){const error=Error(message);error.status=status;return error;}
// Installation progress is independent of browser storage and personal history.
// Only a previously unclaimed installation starts this flow; existing owners
// are recorded as complete without changing their account or configuration.
export class Onboarding{
  constructor(storage,auth,{configPath,apiKey='',model='gpt-4.1-mini',files=fs}={}){
    this.storage=storage;this.db=storage.db;this.auth=auth;this.configPath=configPath;this.baseKey=apiKey;this.model=model;this.files={...fs,...files};files=this.files;this.savedKey='';
    this.db.exec('CREATE TABLE IF NOT EXISTS installation_onboarding(id INTEGER PRIMARY KEY CHECK(id=1),step INTEGER NOT NULL CHECK(step BETWEEN 1 AND 6),completed_at TEXT) STRICT');
    this.db.prepare('INSERT OR IGNORE INTO installation_onboarding VALUES(1,?,?)').run(auth.ownerId()?6:1,auth.ownerId()?new Date().toISOString():null);
    // Registration commits independently. Recover a crash between creating the
    // owner and advancing setup without ever asking for another owner account.
    if(auth.ownerId())this.ownerCreated();
    if(configPath&&files.existsSync(configPath)){
      try{if(files.lstatSync(configPath).isSymbolicLink())throw Error();const data=JSON.parse(files.readFileSync(configPath,'utf8'));if(data.version!==1||data.provider!=='openai'||!this.validKey(data.apiKey))throw Error();this.savedKey=data.apiKey;}
      catch{throw Error('Stored AI configuration could not be loaded safely. Check the installation configuration file.');}
    }
  }
  validKey(value){return typeof value==='string'&&value.length>=20&&value.length<=1024&&/^[\x21-\x7e]+$/.test(value);}
  row(){return this.db.prepare('SELECT step,completed_at FROM installation_onboarding WHERE id=1').get();}
  summary(session){let state=this.row();const owner=this.auth.ownerId();if(owner&&!state.completed_at&&state.step<3){this.ownerCreated();state=this.row();}return {pending:!state.completed_at&&(!owner||session?.user_id===owner),step:state.step};}
  requireOwner(session){this.auth.assertSession(session);if(session.user_id!==this.auth.ownerId())throw failure(403,'Installation owner access required.');}
  requirePending(session){this.requireOwner(session);if(this.row().completed_at)throw failure(409,'Installation setup is already complete. Your existing configuration is retained.');}
  begin(){if(this.auth.ownerId())throw failure(409,'An installation owner already exists. Sign in to continue.');this.db.prepare('UPDATE installation_onboarding SET step=MAX(step,2) WHERE id=1 AND completed_at IS NULL').run();return {pending:true,step:2};}
  ownerCreated(){this.db.prepare('UPDATE installation_onboarding SET step=MAX(step,3) WHERE id=1 AND completed_at IS NULL').run();}
  provider(){return {provider:'OpenAI',configured:!!(this.baseKey?.trim()||this.savedKey),source:this.baseKey?.trim()?'server_environment':this.savedKey?'installation':null,model:this.model};}
  details(session){this.requireOwner(session);return {...this.summary(session),ai:this.provider()};}
  progress(session,step){this.requirePending(session);if(!Number.isInteger(step)||step<3||step>6||step>this.row().step+1)throw failure(400,'Complete the current setup step before continuing.');this.db.prepare('UPDATE installation_onboarding SET step=MAX(step,?) WHERE id=1').run(step);return this.details(session);}
  saveCredential(session,body){
    this.requirePending(session);const candidate=typeof body.apiKey==='string'?body.apiKey.trim():null;if(Object.keys(body).some(key=>key!=='apiKey')||!this.validKey(candidate))throw failure(400,'Enter a valid API credential without spaces (20–1024 characters).');
    if(this.baseKey?.trim())throw failure(409,'AI is already configured through the server environment. Update that credential on the server.');
    const key=candidate;if(!this.configPath){this.savedKey=key;return this.provider();}
    const directory=path.dirname(this.configPath),temporary=path.join(directory,`.ai-configuration-${randomUUID()}.tmp`);let handle;
    try{
      this.files.mkdirSync(directory,{recursive:true});if(this.files.existsSync(this.configPath)&&this.files.lstatSync(this.configPath).isSymbolicLink())throw Error();
      handle=this.files.openSync(temporary,'wx',0o600);this.files.writeFileSync(handle,JSON.stringify({version:1,provider:'openai',apiKey:key}));this.files.fsyncSync(handle);this.files.closeSync(handle);handle=undefined;this.files.renameSync(temporary,this.configPath);this.savedKey=key;
    }catch{if(handle!==undefined)try{this.files.closeSync(handle);}catch{}try{this.files.unlinkSync(temporary);}catch{}throw failure(507,'AI configuration could not be saved. Check server file permissions and try again.');}
    return this.provider();
  }
  check(session){this.requirePending(session);const ai=this.provider();return {...ai,checkedLocally:true,message:ai.configured?'A credential is available to the server. This local check does not verify provider access or billing, contact OpenAI, or spend credits.':'No credential is configured. You can add one now or finish setup and configure the server later.'};}
  complete(session){this.requirePending(session);if(this.row().step!==6)throw failure(400,'Review the Ready step before finishing setup.');this.db.prepare('UPDATE installation_onboarding SET completed_at=? WHERE id=1 AND completed_at IS NULL').run(new Date().toISOString());return this.details(session);}
  analysisOptions(){return {apiKey:this.baseKey?.trim()?this.baseKey:this.savedKey,model:this.model};}
}
