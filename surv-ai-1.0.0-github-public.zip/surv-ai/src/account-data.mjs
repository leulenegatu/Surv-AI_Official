import {cameraAreas} from './camera-layout.mjs';
import {detectionSettings} from './person-detection.mjs';
import {desktopSettings,desktopSpans} from './desktop-store.mjs';
import {browserSettings} from './browser-companion-store.mjs';
import {contextSessions} from './context-store.mjs';
import * as fs from 'node:fs';
import path from 'node:path';
import {randomUUID,createHash} from 'node:crypto';
import {deflateRaw} from 'node:zlib';
import {promisify} from 'node:util';

const uuid=/^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/i;
const reference=/^[a-f0-9-]{36}\.(jpg|png|webp)$/;
const compress=promisify(deflateRaw);
const crcTable=Array.from({length:256},(_,n)=>{for(let i=0;i<8;i++)n=(n&1)?0xedb88320^(n>>>1):n>>>1;return n>>>0;});
const crc32=bytes=>{let crc=0xffffffff;for(const byte of bytes)crc=crcTable[(crc^byte)&255]^(crc>>>8);return (crc^0xffffffff)>>>0;};
// Standard ZIP entries, without a package dependency or external service.
export async function zipEntries(entries){
  const local=[],central=[];let offset=0,total=0;
  if(entries.length>65535)throw Error('Too many files for one personal export.');
  for(const [name,data] of entries){
    if(!/^(data\.json|README\.txt|snapshots\/[a-f0-9-]{36}\.(jpg|png|webp))$/.test(name))throw Error('Invalid export filename.');
    total+=data.length;if(total>256*1024*1024)throw Error('Personal export exceeds the 256 MB download limit.');
    const filename=Buffer.from(name),compressed=await compress(data),crc=crc32(data),header=Buffer.alloc(30),directory=Buffer.alloc(46);
    header.writeUInt32LE(0x04034b50);header.writeUInt16LE(20,4);header.writeUInt16LE(0x800,6);header.writeUInt16LE(8,8);header.writeUInt16LE(33,12);header.writeUInt32LE(crc,14);header.writeUInt32LE(compressed.length,18);header.writeUInt32LE(data.length,22);header.writeUInt16LE(filename.length,26);
    directory.writeUInt32LE(0x02014b50);directory.writeUInt16LE(20,4);directory.writeUInt16LE(20,6);directory.writeUInt16LE(0x800,8);directory.writeUInt16LE(8,10);directory.writeUInt16LE(33,14);directory.writeUInt32LE(crc,16);directory.writeUInt32LE(compressed.length,20);directory.writeUInt32LE(data.length,24);directory.writeUInt16LE(filename.length,28);directory.writeUInt32LE(offset,42);
    local.push(header,filename,compressed);central.push(directory,filename);offset+=header.length+filename.length+compressed.length;
  }
  const index=Buffer.concat(central),end=Buffer.alloc(22);end.writeUInt32LE(0x06054b50);end.writeUInt16LE(entries.length,8);end.writeUInt16LE(entries.length,10);end.writeUInt32LE(index.length,12);end.writeUInt32LE(offset,16);return Buffer.concat([...local,index,end]);
}

export class AccountData{
  constructor(storage,snapshots,{files={},now=()=>Date.now(),reports=null}={}){this.storage=storage;this.db=storage.db;this.snapshots=snapshots;this.reports=reports;this.files={...fs,...files};this.now=now;this.directory=path.resolve(snapshots.directory,'.account-deletions');this.blocked=new Set();this.unknownRecovery=false;}
  jobs(){if(!this.files.existsSync(this.directory))return [];if(this.files.lstatSync(this.directory).isSymbolicLink())throw Error('Invalid account cleanup storage.');return this.files.readdirSync(this.directory);}
  jobPath(id){if(!uuid.test(id))throw Error('Invalid account cleanup job.');return path.join(this.directory,id);}
  manifest(job){
    if(this.files.lstatSync(job).isSymbolicLink())throw Error('Invalid account cleanup directory.');
    if(this.files.lstatSync(path.join(job,'manifest.json')).isSymbolicLink())throw Error('Invalid account cleanup journal.');
    const data=JSON.parse(this.files.readFileSync(path.join(job,'manifest.json'),'utf8'));
    if(![1,2].includes(data.version)||!uuid.test(data.userId)||!Array.isArray(data.refs)||data.refs.some(ref=>!reference.test(ref))||new Set(data.refs).size!==data.refs.length||data.version===2&&(!this.reports||!Array.isArray(data.reportRefs)||data.reportRefs.some(ref=>!/^[a-f0-9-]{36}\.pdf$/.test(ref))||new Set(data.reportRefs).size!==data.reportRefs.length))throw Error('Invalid account cleanup journal.');return data;
  }
  removeJob(job,manifest,restore){
    for(const ref of manifest.refs){const staged=path.join(job,ref);if(!this.files.existsSync(staged))continue;
      if(this.files.lstatSync(staged).isSymbolicLink())throw Error('Invalid staged snapshot.');
      if(restore||this.db.prepare('SELECT id FROM observations WHERE snapshot_ref=? LIMIT 1').get(ref)){const original=this.snapshots.validate(ref);if(this.files.existsSync(original))throw Error('Snapshot recovery requires administrator attention.');this.files.renameSync(staged,original);}
      else this.files.unlinkSync(staged);
    }
    for(const ref of manifest.reportRefs||[]){
      const staged=path.join(job,ref);if(!this.files.existsSync(staged))continue;
      if(this.files.lstatSync(staged).isSymbolicLink())throw Error('Invalid staged report.');
      if(restore||this.db.prepare('SELECT id FROM monthly_reports WHERE file_ref=? LIMIT 1').get(ref)){const original=this.reports.validate(ref);if(this.files.existsSync(original))throw Error('Report recovery requires administrator attention.');this.files.renameSync(staged,original);}
      else this.files.unlinkSync(staged);
    }
    this.files.unlinkSync(path.join(job,'manifest.json'));this.files.rmdirSync(job);
    if(this.files.readdirSync(this.directory).length===0)this.files.rmdirSync(this.directory);
  }
  recover(){
    this.blocked.clear();this.unknownRecovery=false;
    for(const id of this.jobs()){
      let manifest;try{const job=this.jobPath(id);if(this.files.readdirSync(job).length===0){this.files.rmdirSync(job);continue;}manifest=this.manifest(job);const restore=!!this.db.prepare('SELECT id FROM users WHERE id=?').get(manifest.userId);this.removeJob(job,manifest,restore);}
      catch{if(manifest&&this.db.prepare('SELECT id FROM users WHERE id=?').get(manifest.userId))this.blocked.add(manifest.userId);else if(!manifest)this.unknownRecovery=true;}
    }
    return {pendingDeletionCount:this.jobs().length};
  }
  assertAvailable(userId){if(this.unknownRecovery||this.blocked.has(userId)){const error=Error('Account file recovery is pending. Ask the installation administrator to retry cleanup.');error.status=503;throw error;}}
  deleteUser(userId,{authorize,beforeDelete=()=>{},afterDelete=()=>{},extraRefs=[]}={}){
    if(!uuid.test(userId))throw Error('Authenticated account required.');this.recover();this.assertAvailable(userId);
    const job=this.jobPath(randomUUID()),manifest={version:this.reports?2:1,userId,refs:[],...(this.reports?{reportRefs:[]}:{}),createdAt:new Date(this.now()).toISOString()};let prepared=false;
    try{
      this.storage.transaction(()=>{
        authorize();manifest.refs=[...new Set([...this.db.prepare('SELECT snapshot_ref FROM observations WHERE user_id=? AND snapshot_ref IS NOT NULL').all(userId).map(row=>row.snapshot_ref),...extraRefs])].filter(ref=>!this.db.prepare('SELECT id FROM observations WHERE snapshot_ref=? AND user_id IS NOT ? LIMIT 1').get(ref,userId));
        if(this.reports)manifest.reportRefs=[...new Set(this.db.prepare('SELECT file_ref FROM monthly_reports WHERE user_id=?').all(userId).map(r=>r.file_ref))].filter(ref=>!this.db.prepare('SELECT id FROM monthly_reports WHERE file_ref=? AND user_id IS NOT ? LIMIT 1').get(ref,userId));
        for(const ref of manifest.refs)this.snapshots.validate(ref);this.files.mkdirSync(job,{recursive:true});
        const handle=this.files.openSync(path.join(job,'manifest.json'),'wx');try{this.files.writeFileSync(handle,JSON.stringify(manifest));this.files.fsyncSync(handle);}finally{this.files.closeSync(handle);}prepared=true;
        for(const ref of manifest.refs){const source=this.snapshots.validate(ref);if(this.files.existsSync(source)){if(this.files.lstatSync(source).isSymbolicLink())throw Error('Invalid snapshot file.');this.files.renameSync(source,path.join(job,ref));}}
        for(const ref of manifest.reportRefs||[]){const source=this.reports.validate(ref);if(this.files.existsSync(source)){if(this.files.lstatSync(source).isSymbolicLink())throw Error('Invalid report file.');this.files.renameSync(source,path.join(job,ref));}}
        beforeDelete();
        this.db.prepare("UPDATE monitoring_sessions SET status='completed',ended_at=?,end_reason='account_deleted',updated_at=? WHERE user_id=? AND status='active'").run(new Date(this.now()).toISOString(),new Date(this.now()).toISOString(),userId);
        for(const table of ['observations','monitoring_sessions','cameras','app_settings','auth_identities','auth_sessions'])this.db.prepare(`DELETE FROM ${table} WHERE user_id=?`).run(userId);
        const user=this.db.prepare('SELECT email_normalized FROM users WHERE id=?').get(userId);
        const digest=value=>createHash('sha256').update(value).digest('hex');
        for(const bucket of [`account-security:email:${digest(userId)}`,`admin-reset:email:${digest(userId)}`,`login:email:${digest(user.email_normalized)}`,`register:email:${digest(user.email_normalized)}`])this.db.prepare('DELETE FROM auth_throttle WHERE bucket=?').run(bucket);
        this.db.prepare('DELETE FROM users WHERE id=?').run(userId);
      });
    }catch(error){
      if(prepared){try{this.removeJob(job,manifest,true);}catch{this.blocked.add(userId);const failure=Error('Account deletion was rolled back. Snapshot recovery is pending; ask the administrator to retry cleanup.');failure.status=507;throw failure;}}
      else this.recover();
      if(error.status)throw error;const failure=Error('Account deletion failed and was rolled back. Your account and data are retained.');failure.status=507;throw failure;
    }
    afterDelete();let cleanupPending=false;try{this.removeJob(job,manifest,false);}catch{cleanupPending=true;}
    return {deleted:true,cleanupPending,...(cleanupPending?{message:'Account access and database records are removed. Snapshot file cleanup is pending; the installation administrator must retry cleanup.'}:{})};
  }
  async exportUser(storage,account){
    this.assertAvailable(account.id);
    const data=storage.transaction(()=>({formatVersion:1,application:'Surv-AI',exportedAt:new Date(this.now()).toISOString(),account,observations:storage.observations(),monitoringSessions:storage.sessions(),cameras:storage.cameras({historical:true}),cameraAreas:cameraAreas(storage),personDetection:detectionSettings(storage),settings:storage.settings(),desktopContext:{settings:desktopSettings(storage),browser:browserSettings(storage),contextSessions:contextSessions(storage),spans:desktopSpans(storage)},snapshots:{included:[],missing:[]}}));
    const entries=[],refs=[...new Set(data.observations.map(row=>row.snapshotRef).filter(Boolean))];let size=0;
    for(const ref of refs){try{const file=this.files.lstatSync(this.snapshots.validate(ref));if(!file.isFile()||file.isSymbolicLink())throw Error('Invalid saved snapshot file.');const image=await this.snapshots.get(ref);size+=image.data.length;if(size>256*1024*1024)throw Error('Personal export exceeds the 256 MB download limit.');entries.push([`snapshots/${ref}`,image.data]);data.snapshots.included.push(ref);}catch(error){if(error.code==='ENOENT')data.snapshots.missing.push(ref);else throw error;}}
    entries.unshift(['data.json',Buffer.from(JSON.stringify(data,null,2))],['README.txt',Buffer.from('Surv-AI personal data export. data.json contains your local account/profile, observations, monitoring history, cameras and settings. snapshots/ contains referenced saved source images. Missing files are listed in data.json; no replacement images are invented. This archive contains private data: store it safely. Authentication credentials and session secrets are excluded.\n')]);
    return zipEntries(entries);
  }
}
