// Calendar archives contain only already-saved local evidence. No AI client.
import * as fs from 'node:fs';
import path from 'node:path';
import {randomUUID,createHash} from 'node:crypto';
import {calendar,validDate,addDays,rangeBounds} from './local-calendar.mjs';
import {buildReportForPeriod} from './report.mjs';
import {renderReportPDF} from './report-pdf.mjs';
import {desktopSettings} from './desktop-store.mjs';

const uuid=/^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/i;
const reference=/^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}\.pdf$/i;
const temporary=/^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}\.pdf\.tmp$/i;
const hash=bytes=>createHash('sha256').update(bytes).digest('hex');
const failure=(message,status=503)=>Object.assign(Error(message),{status});

export function calendarMonthPeriod(month,timeZone='UTC'){
  if(typeof month!=='string'||!/^\d{4}-(0[1-9]|1[0-2])$/.test(month))throw failure('Choose a valid calendar month.',400);
  const startDate=validDate(month+'-01'),next=new Date(startDate+'T00:00:00Z');next.setUTCMonth(next.getUTCMonth()+1);
  const nextDate=next.toISOString().slice(0,10);validDate(nextDate);
  const endDate=addDays(nextDate,-1),length=(Date.parse(nextDate)-Date.parse(startDate))/86400000;
  const label=new Intl.DateTimeFormat('en-US',{timeZone:'UTC',month:'long',year:'numeric'}).format(new Date(startDate+'T12:00:00Z'));
  return {kind:'month',month,label,startDate,endDate,length,timeZone,bounds:rangeBounds(startDate,endDate,timeZone)};
}

export function buildMonthlyReport(storage,{month,timeZone='UTC',now=Date.now(),displayName}={}){
  const period=calendarMonthPeriod(month,timeZone);
  if(period.endDate>=calendar(timeZone).date(now))throw failure('Only completed calendar months can be archived.',400);
  const report=buildReportForPeriod(storage,period,{now});
  if(!report.summary.total)throw failure('This month has no saved observations to archive.',400);
  if(displayName!==undefined){if(typeof displayName!=='string'||displayName.length>120)throw failure('Invalid account display name.',400);report.accountDisplayName=displayName.trim();}
  return report;
}

// The metadata row is committed only after an atomically renamed PDF has been
// flushed and verified. An interruption before the row leaves a safe orphan;
// startup recovery removes only such server-generated filenames.
export class MonthlyReports{
  constructor(storage,snapshots,{directory,files={},renderPDF=renderReportPDF,now=()=>Date.now()}={}){
    this.storage=storage;this.db=storage.db;this.snapshots=snapshots;
    this.directory=path.resolve(directory||path.join(snapshots.directory,'..','reports'));
    this.files={...fs,...files};this.renderPDF=renderPDF;this.now=now;this.inFlight=new Map();
  }
  assertUser(userId){if(!uuid.test(userId||''))throw failure('Authenticated account required.',401);}
  assertDirectory(create=false){
    if(!this.files.existsSync(this.directory)){if(!create)return false;this.files.mkdirSync(this.directory,{recursive:true});}
    const item=this.files.lstatSync(this.directory);if(item.isSymbolicLink()||!item.isDirectory())throw failure('Local report storage is unavailable.');return true;
  }
  validate(ref){if(!reference.test(ref||''))throw failure('Invalid report reference.',400);return path.join(this.directory,ref);}
  metadata(row){
    const period=calendarMonthPeriod(row.month,row.time_zone);
    return {id:row.id,month:row.month,label:period.label,startDate:period.startDate,endDate:period.endDate,timeZone:row.time_zone,observationCount:row.observation_count,createdAt:row.created_at,bytes:row.byte_length};
  }
  list(userId){this.assertUser(userId);return this.db.prepare('SELECT * FROM monthly_reports WHERE user_id=? ORDER BY month DESC,id').all(userId).map(row=>this.metadata(row));}
  available(userId,{timeZone='UTC'}={}){
    this.assertUser(userId);const clock=calendar(timeZone),currentMonth=clock.date(this.now()).slice(0,7),existing=new Set(this.list(userId).map(row=>row.month)),counts=new Map();
    for(const record of this.storage.forUser(userId).observations()){const month=clock.date(record.timestamp).slice(0,7);if(month<currentMonth&&!existing.has(month))counts.set(month,(counts.get(month)||0)+1);}
    return [...counts].sort((a,b)=>b[0].localeCompare(a[0])).map(([month,observationCount])=>{const period=calendarMonthPeriod(month,timeZone);return {month,label:period.label,startDate:period.startDate,endDate:period.endDate,timeZone,observationCount};});
  }
  row(userId,id){this.assertUser(userId);if(!uuid.test(id||''))throw failure('Invalid report identifier.',400);const row=this.db.prepare('SELECT * FROM monthly_reports WHERE id=? AND user_id=?').get(id,userId);if(!row)throw failure('Monthly report not found.',404);return row;}
  read(row){
    try{
      if(!this.assertDirectory())throw Error('Missing report directory');const target=this.validate(row.file_ref),item=this.files.lstatSync(target);
      if(!item.isFile()||item.isSymbolicLink()||item.size!==row.byte_length||item.size>20*1024*1024)throw Error('Invalid report file');
      const pdf=this.files.readFileSync(target);if(!pdf.subarray(0,5).equals(Buffer.from('%PDF-'))||hash(pdf)!==row.sha256)throw Error('Invalid report bytes');return pdf;
    }catch{throw failure('The archived PDF is unavailable. Its metadata is retained; retry or delete this report.');}
  }
  get(userId,id){const row=this.row(userId,id),owned=this.storage.forUser(userId),settings=this.db.prepare("SELECT name FROM sqlite_master WHERE name='desktop_settings'").get()&&this.db.prepare('SELECT user_id FROM desktop_settings WHERE user_id=?').get(userId);
    if(settings&&!desktopSettings(owned).includeTitle&&row.desktop_titles!==0)throw failure('This preserved report contains or may contain desktop titles captured earlier. Enable title sharing in Settings to open it, or delete the report. Its original file is unchanged.',403);
    return {metadata:this.metadata(row),pdf:this.read(row)};}
  async generate(userId,month,{timeZone='UTC',displayName}={}){
    this.assertUser(userId);calendarMonthPeriod(month,timeZone);
    const key=userId+':'+month;if(this.inFlight.has(key))return this.inFlight.get(key);
    const operation=this.create(userId,month,{timeZone,displayName});this.inFlight.set(key,operation);
    try{return await operation;}finally{if(this.inFlight.get(key)===operation)this.inFlight.delete(key);}
  }
  syncDirectory(){
    let handle;try{handle=this.files.openSync(this.directory,'r');this.files.fsyncSync(handle);}
    // Windows may not permit opening directories for fsync. The PDF itself is
    // still fsynced before its atomic rename and verified before metadata save.
    catch(error){if(process.platform!=='win32'||!['EINVAL','ENOTSUP','EISDIR','EPERM','EACCES'].includes(error.code))throw error;}
    finally{if(handle!==undefined)this.files.closeSync(handle);}
  }
  async create(userId,month,{timeZone,displayName}){
    const existing=this.db.prepare('SELECT * FROM monthly_reports WHERE user_id=? AND month=?').get(userId,month);
    if(existing){this.read(existing);return this.metadata(existing);}
    const account=this.db.prepare('SELECT display_name FROM users WHERE id=?').get(userId);if(!account)throw failure('Authenticated account no longer exists.',401);
    const owned=this.storage.forUser(userId),report=buildMonthlyReport(owned,{month,timeZone,now:this.now(),displayName:displayName??account.display_name});
    let pdf;try{pdf=await this.renderPDF(report,{snapshots:{get:ref=>{if(!owned.snapshotInUse(ref))throw Error('Source image unavailable');return this.snapshots.get(ref);}}});}
    catch{throw failure('Monthly report generation failed. Saved observations have been retained; retry later.');}
    if(!Buffer.isBuffer(pdf)||pdf.length>20*1024*1024||!pdf.subarray(0,5).equals(Buffer.from('%PDF-')))throw failure('Monthly report generation failed. Saved observations have been retained; retry later.');
    const id=randomUUID(),ref=id+'.pdf',target=this.validate(ref),temp=target+'.tmp',digest=hash(pdf),createdAt=new Date(this.now()).toISOString();let renamed=false;
    try{
      this.assertDirectory(true);const handle=this.files.openSync(temp,'wx');try{this.files.writeFileSync(handle,pdf);this.files.fsyncSync(handle);}finally{this.files.closeSync(handle);}
      this.files.renameSync(temp,target);renamed=true;this.syncDirectory();
      const item=this.files.lstatSync(target),saved=this.files.readFileSync(target);
      if(!item.isFile()||item.isSymbolicLink()||saved.length!==pdf.length||hash(saved)!==digest)throw Error('Report durable verification failed');
      const metadata=this.metadata({id,month,time_zone:timeZone,observation_count:report.summary.total,created_at:createdAt,byte_length:pdf.length});
      this.storage.transaction(()=>{
        if(!this.db.prepare('SELECT id FROM users WHERE id=?').get(userId))throw Error('Account no longer exists');
        if(!this.db.prepare('PRAGMA table_info(monthly_reports)').all().some(c=>c.name==='desktop_titles'))this.db.exec('ALTER TABLE monthly_reports ADD COLUMN desktop_titles INTEGER');
        const containsTitles=value=>Array.isArray(value)?value.some(containsTitles):!!value&&typeof value==='object'&&(value.desktopContext&&(value.desktopContext.title!=null||value.desktopContext.tabTitle!=null)||Object.values(value).some(containsTitles));
        this.db.prepare('INSERT INTO monthly_reports(id,user_id,month,time_zone,observation_count,created_at,byte_length,sha256,file_ref,desktop_titles) VALUES (?,?,?,?,?,?,?,?,?,?)').run(id,userId,month,timeZone,report.summary.total,createdAt,pdf.length,digest,ref,Number(containsTitles(report)));
      });
      return metadata;
    }catch{
      for(const file of [temp,...(renamed?[target]:[])])try{if(this.files.existsSync(file)&&!this.files.lstatSync(file).isSymbolicLink())this.files.unlinkSync(file);}catch{/* Safe UUID orphan is retried by recover(). */}
      throw failure('Monthly report could not be durably archived. Saved observations have been retained; retry later.');
    }
  }
  recover(){
    if(!this.assertDirectory())return {pendingReportCleanupCount:0};let pendingReportCleanupCount=0;
    for(const ref of this.files.readdirSync(this.directory)){
      if(!reference.test(ref)&&!temporary.test(ref))continue;
      const target=path.join(this.directory,ref);if(reference.test(ref)&&this.db.prepare('SELECT id FROM monthly_reports WHERE file_ref=? LIMIT 1').get(ref))continue;
      try{const item=this.files.lstatSync(target);if(!item.isFile()||item.isSymbolicLink())throw Error('Unsafe report cleanup entry');this.files.unlinkSync(target);}
      catch{pendingReportCleanupCount++;}
    }
    return {pendingReportCleanupCount};
  }
}
