import {randomBytes} from 'node:crypto';
import {WindowsDesktopCollector,cleanDesktopSample} from './desktop-collector.mjs';
import {desktopSettings,insertSpan,confirmSpan,DESKTOP_SAMPLE_MS,DESKTOP_FRESH_MS,DESKTOP_LEASE_MS} from './desktop-store.mjs';
import {createContextSession,contextSession,contextSessions,insertContextSpan,updateContextSession} from './context-store.mjs';
export const CONTEXT_LEASE_MS=90000;
const failure=(status,message)=>Object.assign(Error(message),{status});
// One clock and OS worker; every physical interval has one persisted span.
export class DesktopRuntime {
  constructor(storage,policy,{collector=new WindowsDesktopCollector(),platform=process.platform,autoSchedule=true,browser=null,validateAuth=()=>true}={}){Object.assign(this,{storage,policy,collector,platform,autoSchedule,browser,validateAuth});this.entries=new Map();this.independent=new Map();this.owner=null;this.timer=null;this.busy=false;this.closed=false;this.ticks=0;}
  at(){return new Date(this.policy.now()).toISOString();}
  cameraFresh(e){return e.session.enabled&&this.policy.now()-e.session.lastSeen>=0&&this.policy.now()-e.session.lastSeen<=DESKTOP_LEASE_MS;}
  fresh(e){return e.independent?e.session.enabled&&this.policy.now()-e.lastSeen>=0&&this.policy.now()-e.lastSeen<=CONTEXT_LEASE_MS&&this.validateAuth(e):this.cameraFresh(e);}
  flush(e){if(e.span&&e.last)try{confirmSpan(e.store,e.span,e.last.sampledAt);}catch{/* Optional evidence cannot stop cameras. */}}
  reset(e){this.flush(e);e.span=null;e.last=null;e.recent=[];e.version=(e.version||0)+1;}
  sync(){
    if(this.closed)return;
    for(const e of [...this.independent.values()]){const setting=desktopSettings(e.store);if(!setting.enabled||!setting.independentEnabled)this.end(e,'preference_off');else if(JSON.stringify(setting)!==JSON.stringify(e.setting)){this.reset(e);e.setting=setting;}}
    const desired=new Map();if(this.platform==='win32')for(const s of this.policy.sessions.values())if(s.enabled){const store=this.storage.forUser(s.userId),setting=desktopSettings(store);if(setting.enabled&&setting.cameraId===s.cameraId)desired.set(s.id,{session:s,store,setting});}
    for(const [id,e] of this.entries)if(!desired.has(id)||JSON.stringify(desired.get(id).setting)!==JSON.stringify(e.setting)){this.reset(e);this.entries.delete(id);}
    for(const [id,e] of desired)if(!this.entries.has(id))this.entries.set(id,{...e,span:null,last:null,recent:[]});
    const active=[...this.independent.values()].find(e=>e.session.enabled),cameras=[...this.entries.values()].filter(e=>this.cameraFresh(e));
    this.owner=active?.session.userId||(cameras.some(e=>e.session.userId===this.owner)?this.owner:cameras[0]?.session.userId)||null;
    for(const e of this.entries.values())if(e.session.userId!==this.owner||this.independent.get(e.session.userId)?.session.enabled)this.reset(e);
    if(this.entries.size||this.independent.size){if(this.autoSchedule&&!this.timer){this.timer=setInterval(()=>void this.poll(),DESKTOP_SAMPLE_MS);this.timer.unref?.();}void this.poll();}
    else{clearInterval(this.timer);this.timer=null;this.collector.close();}
  }
  startIndependent(store,authSession){
    const setting=desktopSettings(store);if(this.closed||this.platform!=='win32')throw failure(400,'Desktop Context is unavailable on this server.');
    if(!setting.enabled||!setting.independentEnabled)throw failure(400,'Enable Independent Context Monitoring before starting.');
    const previous=this.independent.get(store.userId);if(previous){
      if(previous.authSessionHash!==authSession.token_hash)throw failure(409,'Context is controlled by another signed-in browser. Stop that session first.');
      const age=this.policy.now()-previous.lastSeen;
      if(this.validateAuth(previous)&&age>=0&&age<=CONTEXT_LEASE_MS){previous.lastSeen=this.policy.now();return {...this.independentStatus(store.userId),runToken:previous.runToken};}
      this.end(previous,'browser_disconnected');this.sync();
    }
    if([...this.independent.values()].some(e=>e.session.enabled&&e.session.userId!==store.userId)||[...this.entries.values()].some(e=>e.session.userId!==store.userId&&this.cameraFresh(e)&&e.session.userId===this.owner))throw failure(409,'Another account is using this computerâ€™s context collector. Stop that collection first.');
    const row=createContextSession(store,this.at()),session={id:row.id,userId:store.userId,enabled:true};
    const e={independent:true,session,store,setting,span:null,last:null,recent:[],lastSeen:this.policy.now(),authSessionHash:authSession.token_hash,runToken:randomBytes(32).toString('base64url')};this.independent.set(store.userId,e);this.sync();return {...this.independentStatus(store.userId),runToken:e.runToken};
  }
  control(store,authSession,action,body){
    if(!body||Object.keys(body).some(k=>!['sessionId','runToken','csrfToken'].includes(k))||typeof body.sessionId!=='string')throw failure(400,'Choose a valid context session.');
    const row=contextSession(store,body.sessionId);if(!row)throw failure(404,'Context session not found.');const e=this.independent.get(store.userId);
    if(!e||e.session.id!==row.id){if(action==='stop')return this.independentStatus(store.userId);throw failure(409,'This context session has ended. Start a new session explicitly.');}
    if(action==='stop'){this.end(e,'user_stop');this.sync();return this.independentStatus(store.userId);}
    if(e.authSessionHash!==authSession.token_hash||body.runToken!==e.runToken)throw failure(409,'This browser does not control the active context session. Stop it and start explicitly.');
    if(!this.validateAuth(e)||this.policy.now()-e.lastSeen>CONTEXT_LEASE_MS){this.end(e,'browser_disconnected');this.sync();throw failure(409,'The context connection expired. Start a new session explicitly.');}
    e.lastSeen=this.policy.now();
    if(action==='pause'){this.reset(e);e.session.enabled=false;updateContextSession(store,row.id,{status:'paused',at:this.at(),browserStatus:this.browser?.status(store).state});this.sync();}
    if(action==='resume'){if([...this.independent.values()].some(v=>v!==e&&v.session.enabled)||this.owner&&this.owner!==store.userId)throw failure(409,'Another account is using this computerâ€™s context collector.');e.session.enabled=true;updateContextSession(store,row.id,{status:'active',at:this.at(),browserStatus:this.browser?.status(store).state});this.sync();}
    return this.independentStatus(store.userId);
  }
  end(e,reason,status='completed'){this.reset(e);updateContextSession(e.store,e.session.id,{status,reason,at:this.at(),browserStatus:this.browser?.status(e.store).state});e.session.enabled=false;this.independent.delete(e.session.userId);}
  revoke({userId,sessionHash,reason},scoped=false){const e=this.independent.get(userId);if(e&&(!scoped||e.authSessionHash===sessionHash)){this.end(e,reason);this.sync();}}
  rotate(userId,previousHash,nextHash){const e=this.independent.get(userId);if(e?.authSessionHash===previousHash)e.authSessionHash=nextHash;}
  async poll(){
    if(this.closed||this.busy||(!this.entries.size&&!this.independent.size))return;
    this.busy=true;this.ticks++;
    try{
      for(const e of [...this.independent.values()])if(!this.validateAuth(e)||this.policy.now()-e.lastSeen>CONTEXT_LEASE_MS)this.end(e,'browser_disconnected');
      const independent=[...this.independent.values()].filter(e=>this.fresh(e));
      const candidates=[...this.entries.values()].filter(e=>this.cameraFresh(e));this.owner=independent[0]?.session.userId||(candidates.some(e=>e.session.userId===this.owner)?this.owner:candidates[0]?.session.userId)||null;
      const eligible=independent.length?independent:candidates.filter(e=>e.session.userId===this.owner);
      for(const e of this.entries.values())if(!this.cameraFresh(e)||e.session.userId!==this.owner)this.reset(e);
      if(!eligible.length){this.collector.close();return;}
      const versions=new Map(eligible.map(e=>[e,e.version||0])),started=this.policy.now(),raw=await this.collector.sample({includeTitle:eligible.some(e=>e.setting.includeTitle)});if(this.closed)return;
      const now=this.policy.now();if(now-started>DESKTOP_FRESH_MS){for(const e of eligible){e.pendingGap=!!e.last;this.reset(e);}return;}
      for(const e of eligible){if(!this.present(e)||!this.fresh(e)||versions.get(e)!==(e.version||0))continue;
        const sample=cleanDesktopSample(raw,{includeTitle:e.setting.includeTitle,now}),enrichment=await this.browser?.sample(e.session.userId,sample,e.setting.includeTitle);
        if(this.closed||!this.present(e)||!this.fresh(e)||versions.get(e)!==(e.version||0)||this.policy.now()-now>DESKTOP_FRESH_MS)continue;if(enrichment)Object.assign(sample,enrichment);
        if(e.last&&Date.parse(sample.sampledAt)<=Date.parse(e.last.sampledAt))continue;
        const camera=e.independent?candidates.find(v=>v.session.userId===e.session.userId&&this.cameraFresh(v))?.session:e.session;
        const key=s=>JSON.stringify([s.executable,s.title,s.state,s.browser,s.hostname,s.tabTitle,s.cameraSessionId]);sample.cameraSessionId=camera?.id||null;
        const continuous=e.last&&Date.parse(sample.sampledAt)-Date.parse(e.last.sampledAt)<=DESKTOP_FRESH_MS;
        if(!continuous||key(e.last)!==key(sample)){if(continuous)confirmSpan(e.store,e.span,sample.sampledAt);else this.flush(e);e.span=e.independent?insertContextSpan(e.store,e.session,sample,camera):insertSpan(e.store,e.session,sample);}
        else if(Date.parse(sample.sampledAt)-Date.parse(e.span.confirmed_through)>=10000)confirmSpan(e.store,e.span,sample.sampledAt);
        if(e.independent)updateContextSession(e.store,e.session.id,{status:'active',at:this.at(),sample,browserStatus:this.browser?.status(e.store).state,gap:!!e.pendingGap||!!e.last&&!continuous});e.pendingGap=false;
        e.last=sample;e.recent.push(sample);if(e.recent.length>8)e.recent.shift();
      }
    }catch{for(const e of [...this.entries.values(),...this.independent.values()]){e.pendingGap=!!e.last;this.reset(e);}this.collector.close();}
    finally{this.busy=false;if(!this.entries.size&&!this.independent.size){clearInterval(this.timer);this.timer=null;}}
  }
  present(e){return e.independent?this.independent.get(e.session.userId)===e:this.entries.get(e.session.id)===e&&!this.independent.get(e.session.userId)?.session.enabled;}
  context(session,captureAt){const camera=this.entries.get(session.id),shared=this.independent.get(session.userId),e=shared?.session.enabled?shared:camera,time=Date.parse(captureAt);if(!camera||session.userId!==this.owner||!this.cameraFresh(camera)||!e||!this.fresh(e))return null;const sample=e.recent.findLast(s=>Date.parse(s.sampledAt)<=time&&time-Date.parse(s.sampledAt)<=DESKTOP_FRESH_MS);if(!sample)return null;const context={...sample,captureAt,sessionId:session.id,cameraId:session.cameraId,...(e.independent?{contextSessionId:e.session.id}:{})};if(context.hostname&&(!this.browser?.allowed(session.userId)||Date.parse(context.verifiedAt)>time))for(const k of ['browser','hostname','tabTitle','verifiedAt','browserSampledAt','provenance'])delete context[k];return context;}
  status(userId){return [...this.entries.values()].filter(e=>e.session.userId===userId&&e.session.enabled).map(e=>({sessionId:e.session.id,cameraId:e.session.cameraId,cameraName:e.session.cameraName,status:!this.cameraFresh(e)?'awaiting_browser':userId!==this.owner?'collector_in_use':!this.context(e.session,this.at())?'unavailable':'collecting',context:this.context(e.session,this.at())}));}
  independentStatus(userId){const store=this.storage.forUser(userId),e=this.independent.get(userId),row=e?contextSession(store,e.session.id):contextSessions(store)[0]||null;return {supported:this.platform==='win32',enabled:desktopSettings(store).independentEnabled,session:row?{...row,user_id:undefined}:null,status:e?!e.session.enabled?'paused':!this.fresh(e)?'disconnected':!e.last||this.policy.now()-Date.parse(e.last.sampledAt)>DESKTOP_FRESH_MS||e.last.state==='unavailable'?'unavailable':'running':row?.end_reason==='browser_disconnected'?'disconnected':'stopped',desktop:e?.session.enabled?(e.last?.state||'awaiting_sample'):e?'paused':'not_collecting',lastDesktopState:row?.desktop_status||null,browser:this.browser?.status(store).state||'not_paired',leaseMs:CONTEXT_LEASE_MS};}
  close(){if(this.closed)return;this.closed=true;clearInterval(this.timer);this.timer=null;this.collector.close();for(const e of this.entries.values())this.flush(e);for(const e of [...this.independent.values()])this.end(e,'server_shutdown','interrupted');this.entries.clear();}
}
