import {randomBytes,createHash} from 'node:crypto';
import {desktopSettings,ensureDesktopSchema} from './desktop-store.mjs';

export const EXTENSION_ID='bndekblhpdjogjgoemidnaiohccjncfj';
export const EXTENSION_ORIGIN='chrome-extension://'+EXTENSION_ID;
export const digest=value=>createHash('sha256').update(value).digest('hex');
export function installationLabel(base,userId){const owner=base.db.prepare('SELECT owner_user_id FROM installation').get()?.owner_user_id;return `Surv-AI local · installation ${digest(owner||'unclaimed').slice(0,8)} · account ${digest(userId).slice(0,8)}`;}
const exists=s=>!!s.db.prepare("SELECT name FROM sqlite_master WHERE name='browser_pairings'").get();
export function browserSettings(s){
  const row=s.userId&&exists(s)?s.db.prepare('SELECT * FROM browser_pairings WHERE user_id=?').get(s.userId):null;
  return {enabled:!!row?.enabled,browser:row?.browser||'chrome',paired:!!row?.token_hash,revoked:!!row?.revoked,extensionId:EXTENSION_ID};
}
function schema(s){
  ensureDesktopSchema(s);
  s.db.exec(`CREATE TABLE IF NOT EXISTS browser_pairings(user_id TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,enabled INTEGER NOT NULL DEFAULT 0,browser TEXT NOT NULL DEFAULT 'chrome',token_hash TEXT UNIQUE,challenge_hash TEXT UNIQUE,challenge_expires INTEGER,revoked INTEGER NOT NULL DEFAULT 0);
    ALTER TABLE desktop_spans ADD COLUMN browser TEXT;
    ALTER TABLE desktop_spans ADD COLUMN hostname TEXT;
    ALTER TABLE desktop_spans ADD COLUMN tab_title TEXT;`);
}
function ensure(s){if(!exists(s))schema(s);}
export function setBrowserSettings(s,value){
  if(!value||Object.keys(value).some(k=>!['enabled','browser'].includes(k))||typeof value.enabled!=='boolean'||!['chrome','edge'].includes(value.browser))throw Error('Choose valid Browser Context preferences.');
  if(value.enabled&&!desktopSettings(s).enabled)throw Error('Enable Desktop Context for an owned camera first.');
  ensure(s);
  const old=browserSettings(s);
  s.db.prepare('INSERT INTO browser_pairings(user_id,enabled,browser) VALUES(?,?,?) ON CONFLICT(user_id) DO UPDATE SET enabled=excluded.enabled,browser=excluded.browser').run(s.userId,+value.enabled,value.browser);
  if(old.browser!==value.browser)revokeBrowser(s);
  return browserSettings(s);
}
export function createChallenge(s,now){
  if(!browserSettings(s).enabled||!desktopSettings(s).enabled)throw Error('Enable Desktop and Browser Context first.');
  const code=randomBytes(24).toString('base64url'),expiresAt=now+120000;
  s.db.prepare('UPDATE browser_pairings SET challenge_hash=?,challenge_expires=? WHERE user_id=?').run(digest(code),expiresAt,s.userId);
  return {code,expiresAt:new Date(expiresAt).toISOString()};
}
export function redeemChallenge(base,code,now){
  if(typeof code!=='string'||!/^[A-Za-z0-9_-]{32}$/.test(code)||!exists(base))return null;
  return base.transaction(()=>{
    const r=base.db.prepare('SELECT * FROM browser_pairings WHERE challenge_hash=? AND challenge_expires>?').get(digest(code),now);
    if(!r||!r.enabled||!desktopSettings(base.forUser(r.user_id)).enabled)return null;
    const token=randomBytes(32).toString('base64url');
    base.db.prepare('UPDATE browser_pairings SET token_hash=?,challenge_hash=NULL,challenge_expires=NULL,revoked=0 WHERE user_id=?').run(digest(token),r.user_id);
    return {token,userId:r.user_id,browser:r.browser,installation:installationLabel(base,r.user_id)};
  });
}
export function credentialOwner(base,token){
  if(typeof token!=='string'||!/^[A-Za-z0-9_-]{43}$/.test(token)||!exists(base))return null;
  return base.db.prepare('SELECT user_id FROM browser_pairings WHERE token_hash=?').get(digest(token))?.user_id||null;
}
export function revokeBrowser(s){if(exists(s))s.db.prepare('UPDATE browser_pairings SET token_hash=NULL,challenge_hash=NULL,challenge_expires=NULL,revoked=1 WHERE user_id=?').run(s.userId);}
export function pairingPending(s,now){return exists(s)&&!!s.db.prepare('SELECT user_id FROM browser_pairings WHERE user_id=? AND challenge_expires>?').get(s.userId,now);}

// Hostnames, not registrable domains: no guessed public-suffix stripping.
export function normalizeHostname(value){
  if(typeof value!=='string'||!value.length||value.length>253||/[\s/@:#?\\\[\]%]/u.test(value))return null;
  try{const host=new URL('https://'+value).hostname.toLowerCase().replace(/\.$/,'');return host&&host.split('.').every(v=>/^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$/.test(v))?host:null;}catch{return null;}
}
export function validateBrowserSample(value,{includeTitle,now}){
  if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).some(k=>!['type','requestId','sequence','timestamp','focused','hostname','title'].includes(k)))throw Error('Invalid browser fields.');
  if(value.type!=='sample'||typeof value.requestId!=='string'||value.requestId.length>64||!Number.isSafeInteger(value.sequence)||value.sequence<1||typeof value.focused!=='boolean'||!Number.isFinite(value.timestamp)||Math.abs(now-value.timestamp)>30000)throw Error('Invalid or stale browser sample.');
  if(value.hostname!==null&&normalizeHostname(value.hostname)!==value.hostname)throw Error('Invalid normalized hostname.');
  if(value.title!==null&&(typeof value.title!=='string'||value.title.length>1024||/[\u0000-\u001f\u007f]/u.test(value.title)||!includeTitle))throw Error('Title sharing is disabled or invalid.');
  if(!value.focused&&(value.hostname!==null||value.title!==null))throw Error('Background metadata is not accepted.');
  if(!value.hostname&&value.title!==null)throw Error('Unsupported pages cannot share titles.');
  return {hostname:value.hostname,tabTitle:value.title};
}
