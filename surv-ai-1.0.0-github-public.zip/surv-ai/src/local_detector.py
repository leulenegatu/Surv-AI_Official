"""Local-only OpenCV frame gate. JSON lines in/out; no network and no API keys."""
import base64
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / '.local-python'))

def validate_frame(frame):
    if frame is None or frame.size == 0:
        return False
    height, width = frame.shape[:2]
    if min(height, width) < 64 or max(height, width) > 1920:
        return False
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    # Reject obvious initialization garbage, not dark/bright scenes with useful contrast.
    return not (float(gray.mean()) <= 3 or float(gray.mean()) >= 252 or float(gray.std()) < 1)

def inspect(image, network, threshold=0.20):
    if isinstance(threshold, bool) or not isinstance(threshold, (int, float)) or not 0.20 <= threshold <= 0.75:
        raise ValueError('Unsupported confidence threshold')
    try:
        raw = base64.b64decode(image.split(',', 1)[1], validate=True)
        frame = cv2.imdecode(np.frombuffer(raw, dtype=np.uint8), cv2.IMREAD_COLOR)
    except Exception:
        frame = None
    if not validate_frame(frame):
        return {'frameValid': False, 'personPresent': False, 'decision': 'Skipped: invalid camera frame'}
    # Keep the model's trained BGR/300x300 normalization. One inference per frame.
    # A mild gamma lift helps dim, usable scenes; invalid/blank frames stay rejected.
    brightness_adjusted = float(cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY).mean()) < 55
    if brightness_adjusted:
        lut = np.clip((np.arange(256, dtype=np.float32) / 255) ** 0.7 * 255, 0, 255).astype(np.uint8)
        frame = cv2.LUT(frame, lut)
    blob = cv2.dnn.blobFromImage(frame, 0.007843, (300, 300), 127.5, swapRB=False, crop=False)
    network.setInput(blob)
    detections = network.forward()[0, 0]
    scores = [float(row[2]) for row in detections if float(row[1]) == 15 and np.isfinite(row[2]) and 0 <= float(row[2]) <= 1]
    confidence = max(scores, default=0.0)
    present = confidence >= threshold
    return {'frameValid': True, 'personPresent': present, 'personConfidence': confidence, 'decision': 'Person detected' if present else 'No person', 'brightnessAdjusted': brightness_adjusted}

if __name__ == '__main__':
    try:
        import cv2
        import numpy as np
        cv2.setNumThreads(2)
        network = cv2.dnn.readNetFromCaffe(str(ROOT / '.local-models/deploy.prototxt'), str(ROOT / '.local-models/mobilenet_iter_73000.caffemodel'))
        network.setPreferableBackend(cv2.dnn.DNN_BACKEND_OPENCV)
        network.setPreferableTarget(cv2.dnn.DNN_TARGET_CPU)
        print(json.dumps({'ready': True, 'detector': 'OpenCV MobileNet-SSD'}), flush=True)
    except Exception:
        print(json.dumps({'error': 'Local OpenCV detector unavailable. Run setup-local.ps1 before enabling Auto Monitoring.'}), flush=True)
        sys.exit(1)
    for line in sys.stdin:
        try:
            message = json.loads(line)
            print(json.dumps(inspect(message['image'], network, message.get('threshold', 0.25))), flush=True)
        except Exception:
            print(json.dumps({'error': 'Local person detection failed. Auto Monitoring has stopped.'}), flush=True)
