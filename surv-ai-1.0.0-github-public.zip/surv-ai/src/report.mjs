import {desktopAggregate} from './desktop-store.mjs';
// Local evidence aggregation only. This module has no AI or network client.
import {calendar,validDate,addDays,rangeBounds,normalize} from './local-calendar.mjs';
import {selectNoteworthy} from './report-noteworthy.mjs';

export function reportPeriod(startDate,length,timeZone='UTC'){
  validDate(startDate);if(![7,30].includes(length))throw Error('Choose a 7-day or 30-day report.');
  const endDate=addDays(startDate,length-1);
  return {startDate,endDate,length,timeZone,bounds:rangeBounds(startDate,endDate,timeZone)};
}
export function reportAvailability(storage,{timeZone='UTC',now=Date.now()}={}){
  const clock=calendar(timeZone),extent=storage.reportExtent(new Date(now).toISOString());
  return {today:clock.date(now),firstDate:extent.first?clock.date(extent.first):null,lastDate:extent.last?clock.date(extent.last):null,count:extent.count};
}
// One exclusive category per observation. Only explicit activity labels qualify;
// a visible object or the user's context never establishes an action.
export function activityCategory(activity){
  const text=normalize(activity);
  if(/\b(not|no|unknown|unclear|possibly|maybe)\b/.test(text))return 'Other observed activity';
  if(/\b(eating|eat|having (?:a )?(?:meal|lunch|dinner|breakfast|snack)|preparing food|cooking)\b/.test(text))return 'Eating / food';
  if(/\b(drinking|sipping)\b/.test(text))return 'Drinking / beverage';
  if(/\b(gaming|playing (?:a )?(?:video|computer|console) game)\b/.test(text))return 'Gaming';
  if(/\b(watching (?:a |the )?(?:video|videos|movie|tv|television)|video viewing)\b/.test(text))return 'Media / video';
  if(/\b(coding|programming|writing code)\b/.test(text))return 'Coding / programming';
  if(/\b(using|working (?:at|on|with)|interacting with|typing (?:at|on))\b/.test(text)&&/\b(computer|computers|desktop|laptop|monitor|monitors|screens)\b/.test(text))return 'Computer use';
  if(/\b(reading)\b/.test(text))return 'Reading';
  return 'Other observed activity';
}
const aliases=new Map([
  ['coffee mug','mug'],['mugs','mug'],['computer monitor','monitor'],['computer monitors','monitor'],['monitors','monitor'],['dual monitors','monitor'],
  ['water bottles','water bottle'],['keyboards','keyboard'],['computer keyboard','keyboard'],['headsets','headset'],['headphones','headset'],
  ['mobile phone','phone'],['cell phone','phone'],['smartphone','phone'],['phones','phone'],['food containers','food container']
]);
const usefulObjects=new Set(['water bottle','mug','monitor','keyboard','headset','phone','food container','bowl','plate','cup','bottle','laptop']);
export function objectCategory(value){const text=normalize(value);return aliases.get(text)||text;}
const percent=(count,total)=>total?Math.round(count/total*1000)/10:0;
function frequencies(records,clock,extract){
  const counts=new Map();
  for(const record of records)for(const label of new Set(extract(record))){if(!label)continue;const item=counts.get(label)||{label,count:0,days:new Set()};item.count++;item.days.add(clock.date(record.timestamp));counts.set(label,item);}
  return [...counts.values()].map(v=>({...v,days:v.days.size,percent:percent(v.count,records.length)})).sort((a,b)=>b.count-a.count||a.label.localeCompare(b.label));
}
export function buildReport(storage,{startDate,length,timeZone='UTC',now=Date.now()}={}){
  return buildReportForPeriod(storage,reportPeriod(startDate,length,timeZone),{now});
}
// Calendar-month archives reuse the same evidence aggregation as on-demand
// exports. The public on-demand period validator remains restricted to 7/30.
export function buildReportForPeriod(storage,period,{now=Date.now()}={}){
  const {startDate,length,timeZone}=period,clock=calendar(timeZone),available=reportAvailability(storage,{timeZone,now});
  if(period.endDate>available.today)throw Error('The report ends in the future. Choose an earlier starting date.');
  if(!available.count)throw Error('No recorded observations are available for a report yet.');
  if(period.endDate<available.firstDate||period.startDate>available.lastDate)throw Error('This period does not overlap your available observation history.');
  const instant=new Date(now).toISOString();
  const records=storage.observations(period.bounds).filter(r=>['manual_ai','automatic_ai'].includes(r.source)&&r.timestamp<=instant).sort((a,b)=>a.timestamp.localeCompare(b.timestamp)||a.id.localeCompare(b.id));
  const activities=frequencies(records,clock,r=>[activityCategory(r.activity)]);
  const objects=frequencies(records,clock,r=>r.objects.map(objectCategory)).filter(o=>o.count>=2||(records.length<=5&&usefulObjects.has(o.label))).slice(0,12);
  const cameraNames=new Map();for(const r of records)if(r.cameraId)cameraNames.set(r.cameraId,r.cameraName);
  const nameCounts=new Map(),nameOrdinals=new Map();for(const name of cameraNames.values())nameCounts.set(name,(nameCounts.get(name)||0)+1);
  for(const id of [...cameraNames.keys()].sort()){const name=cameraNames.get(id);if(nameCounts.get(name)>1){const ordinal=(nameOrdinals.get(name)||0)+1;nameOrdinals.set(name,ordinal);cameraNames.set(id,`${name} (camera ${ordinal})`);}}
  const cameraBuckets=new Map();for(const r of records){const key=r.cameraId||(r.source==='manual_ai'?'manual':'unassigned'),label=r.cameraId?cameraNames.get(r.cameraId):r.source==='manual_ai'?'Manual upload':'Unassigned camera',item=cameraBuckets.get(key)||{label,count:0,days:new Set()};item.count++;item.days.add(clock.date(r.timestamp));cameraBuckets.set(key,item);}
  const cameras=[...cameraBuckets.values()].map(c=>({...c,days:c.days.size})).sort((a,b)=>b.count-a.count||a.label.localeCompare(b.label));
  const locationCounts=frequencies(records,clock,r=>[r.location]);
  const locations=locationCounts.filter(c=>c.count>=2||records.length<=5).slice(0,6);
  const dayRecords=new Map();for(const r of records){const date=clock.date(r.timestamp);if(!dayRecords.has(date))dayRecords.set(date,[]);dayRecords.get(date).push(r);}
  const days=Array.from({length},(_,i)=>{const date=addDays(startDate,i),list=dayRecords.get(date)||[];return {date,count:list.length,first:list[0]?clock.time(list[0].timestamp):null,last:list.length?clock.time(list.at(-1).timestamp):null,activities:frequencies(list,clock,r=>[activityCategory(r.activity)]).slice(0,3),cameras:frequencies(list,clock,r=>[r.cameraId?cameraNames.get(r.cameraId):r.location]).slice(0,3),objects:frequencies(list,clock,r=>r.objects.map(objectCategory)).filter(o=>o.count>=2||usefulObjects.has(o.label)).slice(0,4)};});
  const timeDefinitions=[['Late night','12:00 AM – 5:59 AM',0,6],['Morning','6:00 AM – 11:59 AM',6,12],['Afternoon','12:00 PM – 5:59 PM',12,18],['Evening','6:00 PM – 11:59 PM',18,24]];
  const timeOfDay=timeDefinitions.map(([label,window,from,to])=>{const list=records.filter(r=>clock.hour(r.timestamp)>=from&&clock.hour(r.timestamp)<to);return {label,window,count:list.length,percent:percent(list.length,records.length),days:new Set(list.map(r=>clock.date(r.timestamp))).size};});
  const runs=storage.reportSessions(period.bounds),contained=r=>r.started_at>=period.bounds.from&&(r.ended_at||r.updated_at)<period.bounds.to;
  const counterRuns=runs.filter(contained),sum=key=>counterRuns.reduce((s,r)=>s+r[key],0);
  const monitoring={sessions:runs.length,counterSessions:counterRuns.length,excludedSessions:runs.length-counterRuns.length,successful:sum('successful_analyses'),failed:sum('failed_analyses'),noPerson:sum('no_person_skipped'),invalid:sum('invalid_frame_skipped')};
  const observedDays=days.filter(d=>d.count).length,total=records.length,patterns=[];
  if(observedDays<length)patterns.push(`${length-observedDays} of ${length} calendar days have no recorded observations. This is missing coverage; it does not establish inactivity, absence or sleep.`);
  if(total<5||observedDays<2)patterns.push('Observation coverage is too limited to characterize a routine reliably. The counts below describe only the recorded evidence.');
  if(total>=5&&observedDays>=2){
    const dominant=timeOfDay.find(t=>t.percent>=60);if(dominant)patterns.push(`${dominant.percent}% of recorded observations occurred in the ${dominant.label.toLowerCase()} (${dominant.window}), across ${dominant.days} observed days. Camera availability and sampling affect this distribution.`);
    const computer=activities.filter(a=>['Computer use','Coding / programming'].includes(a.label));const count=computer.reduce((s,a)=>s+a.count,0),computerDays=new Set(records.filter(r=>['Computer use','Coding / programming'].includes(activityCategory(r.activity))).map(r=>clock.date(r.timestamp))).size;
    if(count>=3)patterns.push(`Computer-related activity appeared in ${count} observations (${percent(count,total)}%), across ${computerDays} of ${observedDays} observed days. This frequency does not measure time at a computer.`);
    for(const label of ['Eating / food','Drinking / beverage']){const a=activities.find(v=>v.label===label);if(a?.count>=2)patterns.push(`${label} activity appeared in ${a.count} observations on ${a.days} observed days. Unrecorded meals or drinks cannot be assessed.`);}
    const repeat=objects.find(o=>o.days>=2);if(repeat)patterns.push(`${repeat.label} evidence appeared in ${repeat.count} observations across ${repeat.days} days. Visibility alone does not establish use.`);
  }
  const warnings=[];
  if(startDate<available.firstDate)warnings.push(`History begins on ${available.firstDate}; earlier days are shown as having no recorded observations.`);
  if(period.endDate>available.lastDate)warnings.push(`The latest recorded day is ${available.lastDate}; later days are shown with their actual recorded counts.`);
  if(period.endDate===available.today)warnings.push('The final day is still in progress; this report includes observations recorded up to its generation time.');
  const evidence=activities.slice(0,4).map(a=>{const r=records.find(v=>activityCategory(v.activity)===a.label);return {category:a.label,date:clock.date(r.timestamp),time:clock.time(r.timestamp),activity:r.activity,description:r.description,location:r.cameraName||r.location,...(r.desktopContext?{desktopContext:r.desktopContext}:{})};});
  const noteworthy=selectNoteworthy(records,{clock,length:period.kind==='month'?30:length,categoryFor:activityCategory});
  return {desktop:desktopAggregate(storage,period.bounds,{now}),desktopEvidence:records.filter(r=>r.desktopContext).slice(0,3).map(r=>({id:r.id,date:clock.date(r.timestamp),time:clock.timeExact(r.timestamp),activity:r.activity,cameraName:r.cameraName,desktopContext:r.desktopContext})),noteworthy,period:{...period,bounds:undefined},available,generatedAt:instant,generatedLabel:new Intl.DateTimeFormat('en-US',{timeZone,dateStyle:'medium',timeStyle:'short'}).format(new Date(now)),summary:{total,observedDays,automatic:records.filter(r=>r.source==='automatic_ai').length,manual:records.filter(r=>r.source==='manual_ai').length,cameras:cameraNames.size,confidence:total?percent(records.reduce((s,r)=>s+r.confidence,0),total):null},monitoring,days,activities,objects,cameras,locations,timeOfDay,patterns,warnings,evidence};
}
