import {DatabaseSync} from 'node:sqlite';
import {randomUUID,createHash} from 'node:crypto';
import {mkdirSync} from 'node:fs';
import path from 'node:path';
const digest=db=>Object.fromEntries(db.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name").all().map(({name})=>[name,createHash('sha256').update(JSON.stringify(db.prepare('SELECT * FROM "'+name.replaceAll('"','""')+'"').all().map(r=>JSON.stringify(r)).sort())).digest('hex')]));
export function verifiedDatabaseBackup(s,prefix){
  if(!/^[a-z-]+$/.test(prefix))throw Error('Invalid backup prefix.');
  const file=s.db.prepare('PRAGMA database_list').get().file;if(!file)return;
  const folder=path.join(path.dirname(file),'backups');mkdirSync(folder,{recursive:true});const backup=path.join(folder,prefix+'-'+randomUUID()+'.sqlite'),before=digest(s.db);
  s.db.prepare('VACUUM INTO ?').run(backup);const copy=new DatabaseSync(backup,{readOnly:true});
  try{if(copy.prepare('PRAGMA integrity_check').get().integrity_check!=='ok'||copy.prepare('PRAGMA foreign_key_check').all().length||copy.prepare('PRAGMA user_version').get().user_version!==s.db.prepare('PRAGMA user_version').get().user_version||JSON.stringify(before)!==JSON.stringify(digest(copy)))throw Error('Database backup verification failed.');}finally{copy.close();}
}
