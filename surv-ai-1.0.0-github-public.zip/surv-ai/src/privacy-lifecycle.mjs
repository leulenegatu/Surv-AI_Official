import * as fs from 'node:fs';
import path from 'node:path';
import {randomUUID} from 'node:crypto';
import {calendar,dayBounds,addDays} from './local-calendar.mjs';
import {contextSessions,hasContext} from './context-store.mjs';

const uuid=/^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/i;
const snapshotRef=/^[a-f0-9-]{36}\.(jpg|png|webp)$/;
const reportRef=/^[a-f0-9-]{36}\.pdf$/;
export const HISTORY_RETENTION=['indefinite','30-days','90-days','6-months','1-year'];
export const SNAPSHOT_RETENTION=['with-history','30-days','90-days','never'];
const failure=(status,message)=>Object.assign(Error(message),{status});

// Additive, transactional auxiliary schema. Core history/account schema stays v5.
// No existing row is rewritten, and no finite policy is installed by default.
export function initializePrivacySchema(storage){
  storage.transaction(()=>storage.db.exec(`
    CREATE TABLE IF NOT EXISTS privacy_settings (
      user_id TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
      history_retention TEXT NOT NULL DEFAULT 'indefinite' CHECK(history_retention IN ('indefinite','30-days','90-days','6-months','1-year')),
      snapshot_retention TEXT NOT NULL DEFAULT 'with-history' CHECK(snapshot_retention IN ('with-history','30-days','90-days','never')),
      monthly_reports INTEGER NOT NULL DEFAULT 0 CHECK(monthly_reports IN (0,1)),
      time_zone TEXT NOT NULL DEFAULT 'UTC',legacy_import_disabled INTEGER NOT NULL DEFAULT 0,
      legacy_import_floor TEXT,last_maintenance TEXT,maintenance_error TEXT NOT NULL DEFAULT '',suppressed_months TEXT NOT NULL DEFAULT '[]'
    ) STRICT;
    CREATE TABLE IF NOT EXISTS monthly_reports (
      id TEXT PRIMARY KEY,user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      month TEXT NOT NULL,time_zone TEXT NOT NULL,observation_count INTEGER NOT NULL,
      created_at TEXT NOT NULL,byte_length INTEGER NOT NULL,sha256 TEXT NOT NULL,file_ref TEXT NOT NULL,
      UNIQUE(user_id,month)
    ) STRICT;
    CREATE TABLE IF NOT EXISTS expired_snapshot_records (
      observation_id TEXT PRIMARY KEY REFERENCES observations(id) ON DELETE CASCADE,
      user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE
    ) STRICT;
    CREATE TABLE IF NOT EXISTS privacy_cleanup_commits (
      job_id TEXT PRIMARY KEY,user_id TEXT NOT NULL,committed_at TEXT NOT NULL
    ) STRICT;
  `));
  if(!storage.db.prepare('PRAGMA table_info(privacy_settings)').all().some(c=>c.name==='suppressed_months'))storage.transaction(()=>storage.db.exec("ALTER TABLE privacy_settings ADD COLUMN suppressed_months TEXT NOT NULL DEFAULT '[]'"));
  storage.privacySchema=true;
}

export function retentionCutoff(policy,now,timeZone='UTC'){
  if(policy==='indefinite'||policy==='with-history'||policy==='never')return null;
  const date=calendar(timeZone).date(now);let cutoff;
  if(policy==='30-days'||policy==='90-days')cutoff=addDays(date,policy==='30-days'?-30:-90);
  else if(policy==='6-months'||policy==='1-year'){
    const [year,month,day]=date.split('-').map(Number),d=new Date(Date.UTC(year,month-1-(policy==='6-months'?6:12),1));
    const last=new Date(Date.UTC(d.getUTCFullYear(),d.getUTCMonth()+1,0)).getUTCDate();
    cutoff=`${d.getUTCFullYear()}-${String(d.getUTCMonth()+1).padStart(2,'0')}-${String(Math.min(day,last)).padStart(2,'0')}`;
  }else throw failure(400,'Choose a supported retention period.');
  return dayBounds(cutoff,timeZone).from;
}

export class PrivacyLifecycle{
  constructor(storage,snapshots,reports,{directory,files={},now=()=>Date.now()}={}){
    this.storage=storage;this.db=storage.db;this.snapshots=snapshots;this.reports=reports;
    this.directory=path.resolve(directory||path.join(path.dirname(snapshots.directory),'privacy-cleanups'));
    this.files={...fs,...files};this.now=now;this.busy=new Set();this.pending=new Map();this.blocked=new Set();this.unknownRecovery=false;this.closed=false;
  }
  row(userId){return this.db.prepare('SELECT * FROM privacy_settings WHERE user_id=?').get(userId);}
  settings(userId){
    const row=this.row(userId),saveSnapshots=this.storage.forUser(userId).settings().saveSnapshots;
    return {historyRetention:row?.history_retention||'indefinite',snapshotRetention:saveSnapshots?(row?.snapshot_retention==='never'?'with-history':row?.snapshot_retention||'with-history'):'never',monthlyReports:!!row?.monthly_reports,timeZone:row?.time_zone||'UTC',saveSnapshots,lastMaintenance:row?.last_maintenance||null,maintenanceError:row?.maintenance_error||''};
  }
  ensureRow(userId){this.db.prepare('INSERT OR IGNORE INTO privacy_settings(user_id) VALUES(?)').run(userId);}
  updateSettings(userId,body){
    const allowed=['historyRetention','snapshotRetention','monthlyReports','timeZone'];
    if(!body||Object.keys(body).some(k=>!allowed.includes(k))||!Object.keys(body).length)throw failure(400,'Choose supported privacy settings.');
    if(body.historyRetention!==undefined&&!HISTORY_RETENTION.includes(body.historyRetention))throw failure(400,'Choose a supported observation retention period.');
    if(body.snapshotRetention!==undefined&&!SNAPSHOT_RETENTION.includes(body.snapshotRetention))throw failure(400,'Choose a supported source image retention period.');
    if(body.monthlyReports!==undefined&&typeof body.monthlyReports!=='boolean')throw failure(400,'Monthly reports must be ON or OFF.');
    if(body.timeZone!==undefined){try{calendar(body.timeZone);}catch{throw failure(400,'Choose a valid time zone.');}}
    this.assertIdle(userId);
    this.storage.transaction(()=>{
      this.ensureRow(userId);const old=this.settings(userId);
      this.db.prepare('UPDATE privacy_settings SET history_retention=?,snapshot_retention=?,monthly_reports=?,time_zone=? WHERE user_id=?').run(body.historyRetention??old.historyRetention,body.snapshotRetention??old.snapshotRetention,Number(body.monthlyReports??old.monthlyReports),body.timeZone??old.timeZone,userId);
      if(body.snapshotRetention!==undefined)this.storage.forUser(userId).setSaveSnapshots(body.snapshotRetention!=='never');
    });return this.settings(userId);
  }
  syncSaveSnapshots(userId,enabled){
    const row=this.row(userId);if(!row)return;
    if(!enabled)this.db.prepare("UPDATE privacy_settings SET snapshot_retention='never' WHERE user_id=?").run(userId);
    else if(row.snapshot_retention==='never')this.db.prepare("UPDATE privacy_settings SET snapshot_retention='with-history' WHERE user_id=?").run(userId);
  }
  importAllowed(userId,record){const row=this.row(userId);return !row?.legacy_import_disabled&&(!row?.legacy_import_floor||record.timestamp>=row.legacy_import_floor);}
  suppressedMonths(userId){return new Set(JSON.parse(this.row(userId)?.suppressed_months||'[]'));}
  assertAvailable(userId){if(this.unknownRecovery||this.blocked.has(userId))throw failure(503,'Private file recovery is pending. Retry cleanup from Admin before changing history.');}
  assertIdle(userId){this.assertAvailable(userId);if(this.busy.has(userId))throw failure(409,'Your history maintenance or report operation is in progress. Wait a moment and retry.');}
  async exclusive(userId,action){
    this.assertIdle(userId);this.busy.add(userId);
    try{if(!this.db.prepare('SELECT id FROM users WHERE id=?').get(userId))throw failure(401,'Sign in again.');return await action();}
    finally{this.busy.delete(userId);}
  }
  jobs(){if(!this.files.existsSync(this.directory))return [];if(this.files.lstatSync(this.directory).isSymbolicLink())throw failure(503,'Private file recovery is pending.');return this.files.readdirSync(this.directory);}
  jobPath(id){if(!uuid.test(id))throw Error('Invalid private cleanup journal.');return path.join(this.directory,id);}
  readManifest(job){
    if(this.files.lstatSync(job).isSymbolicLink()||this.files.lstatSync(path.join(job,'manifest.json')).isSymbolicLink())throw Error('Invalid private cleanup journal.');
    const m=JSON.parse(this.files.readFileSync(path.join(job,'manifest.json'),'utf8'));
    if(m.version!==1||!uuid.test(m.id)||!uuid.test(m.userId)||!Array.isArray(m.entries)||m.entries.some(e=>!['snapshot','report'].includes(e.type)||!(e.type==='snapshot'?snapshotRef:reportRef).test(e.ref))||new Set(m.entries.map(e=>e.type+e.ref)).size!==m.entries.length)throw Error('Invalid private cleanup journal.');return m;
  }
  original(entry){return entry.type==='snapshot'?this.snapshots.validate(entry.ref):this.reports.validate(entry.ref);}
  referenced(entry){return entry.type==='snapshot'?!!this.db.prepare('SELECT id FROM observations WHERE snapshot_ref=? LIMIT 1').get(entry.ref):!!this.db.prepare('SELECT id FROM monthly_reports WHERE file_ref=? LIMIT 1').get(entry.ref);}
  syncDirectory(directory){let handle;try{handle=this.files.openSync(directory,'r');this.files.fsyncSync(handle);}catch(error){if(process.platform!=='win32'||!['EINVAL','ENOTSUP','EISDIR','EPERM','EACCES'].includes(error.code))throw error;}finally{if(handle!==undefined)this.files.closeSync(handle);}}
  finishJob(job,manifest,restore){
    for(const entry of manifest.entries){
      const staged=path.join(job,entry.type+'-'+entry.ref);if(!this.files.existsSync(staged))continue;
      if(this.files.lstatSync(staged).isSymbolicLink())throw Error('Invalid staged file.');
      if(restore||this.referenced(entry)){const source=this.original(entry);if(this.files.existsSync(source))throw Error('Private file recovery is pending.');this.files.renameSync(staged,source);}
      else this.files.unlinkSync(staged);
    }
    this.files.unlinkSync(path.join(job,'manifest.json'));this.files.rmdirSync(job);
    this.db.prepare('DELETE FROM privacy_cleanup_commits WHERE job_id=?').run(manifest.id);
    if(!this.files.readdirSync(this.directory).length)this.files.rmdirSync(this.directory);
  }
  recover(){
    this.blocked.clear();this.unknownRecovery=false;
    for(const id of this.jobs()){
      let manifest,committed=false;try{
        const job=this.jobPath(id);if(this.files.lstatSync(job).isSymbolicLink())throw Error('Invalid cleanup directory.');if(!this.files.readdirSync(job).length){this.files.rmdirSync(job);this.db.prepare('DELETE FROM privacy_cleanup_commits WHERE job_id=?').run(id);continue;}
        manifest=this.readManifest(job);if(manifest.id!==id)throw Error('Invalid cleanup journal.');committed=!!this.db.prepare('SELECT job_id FROM privacy_cleanup_commits WHERE job_id=?').get(manifest.id);
        this.finishJob(job,manifest,!committed);
      }catch{if(manifest&&!committed)this.blocked.add(manifest.userId);else if(!manifest)this.unknownRecovery=true;}
    }
    for(const row of this.db.prepare('SELECT job_id FROM privacy_cleanup_commits').all())if(uuid.test(row.job_id)&&!this.files.existsSync(this.jobPath(row.job_id)))this.db.prepare('DELETE FROM privacy_cleanup_commits WHERE job_id=?').run(row.job_id);
    return {pendingPrivacyCleanupCount:this.jobs().length};
  }
  apply(userId,{observationIds=[],expireIds=[],sessionIds=[],contextSessionIds=[],reportIds=[],reset=false,floor=null,suppressMonths=[]}={}){
    const id=randomUUID(),job=this.jobPath(id),manifest={version:1,id,userId,entries:[]};let prepared=false;
    const deleteIds=new Set(observationIds),expiredIds=new Set(expireIds),removeReports=new Set(reportIds);
    let result;
    try{result=this.storage.transaction(()=>{
      // Recheck authoritative ownership/active state in the same transaction.
      const records=this.db.prepare('SELECT o.* FROM observations o WHERE o.user_id=? AND NOT EXISTS(SELECT 1 FROM monitoring_sessions s WHERE s.id=o.monitoring_session_id AND s.status=\'active\')').all(userId);
      const deleted=records.filter(r=>deleteIds.has(r.id)),expired=records.filter(r=>expiredIds.has(r.id)&&!deleteIds.has(r.id)&&r.snapshot_ref),affected=new Set([...deleted,...expired].map(r=>r.id));
      const reports=this.db.prepare('SELECT * FROM monthly_reports WHERE user_id=?').all(userId).filter(r=>removeReports.has(r.id));
      const refs=[...new Set([...deleted,...expired].map(r=>r.snapshot_ref).filter(Boolean))];
      for(const ref of refs){const users=this.db.prepare('SELECT id FROM observations WHERE snapshot_ref=?').all(ref);if(users.every(r=>affected.has(r.id)))manifest.entries.push({type:'snapshot',ref});}
      for(const ref of new Set(reports.map(r=>r.file_ref)))if(this.db.prepare('SELECT id FROM monthly_reports WHERE file_ref=?').all(ref).every(r=>removeReports.has(r.id)))manifest.entries.push({type:'report',ref});
      if(manifest.entries.length){
        this.files.mkdirSync(job,{recursive:true});const handle=this.files.openSync(path.join(job,'manifest.json'),'wx');
        try{this.files.writeFileSync(handle,JSON.stringify(manifest));this.files.fsyncSync(handle);}finally{this.files.closeSync(handle);}prepared=true;
        this.syncDirectory(job);this.syncDirectory(this.directory);
        for(const entry of manifest.entries){const source=this.original(entry);if(this.files.existsSync(source)){const stat=this.files.lstatSync(source);if(!stat.isFile()||stat.isSymbolicLink())throw Error('Invalid source file.');this.files.renameSync(source,path.join(job,entry.type+'-'+entry.ref));}}
        this.syncDirectory(job);for(const directory of new Set(manifest.entries.map(e=>path.dirname(this.original(e)))))if(this.files.existsSync(directory))this.syncDirectory(directory);
      }
      for(const r of expired){this.db.prepare('UPDATE observations SET snapshot_ref=NULL WHERE id=? AND user_id=?').run(r.id,userId);this.db.prepare('INSERT OR IGNORE INTO expired_snapshot_records VALUES(?,?)').run(r.id,userId);}
      for(const r of deleted)this.db.prepare('DELETE FROM observations WHERE id=? AND user_id=?').run(r.id,userId);
      let sessionsDeleted=0;for(const sid of sessionIds)sessionsDeleted+=Number(this.db.prepare("DELETE FROM monitoring_sessions WHERE id=? AND user_id=? AND status!='active' AND NOT EXISTS(SELECT 1 FROM observations WHERE monitoring_session_id=?)").run(sid,userId,sid).changes);
      let contextSessionsDeleted=0;if(hasContext(this.storage))for(const sid of contextSessionIds)contextSessionsDeleted+=Number(this.db.prepare("DELETE FROM context_sessions WHERE id=? AND user_id=? AND status NOT IN ('active','paused')").run(sid,userId).changes);
      for(const r of reports)this.db.prepare('DELETE FROM monthly_reports WHERE id=? AND user_id=?').run(r.id,userId);
      if(suppressMonths.length){this.ensureRow(userId);this.db.prepare('UPDATE privacy_settings SET suppressed_months=? WHERE user_id=?').run(JSON.stringify([...new Set([...this.suppressedMonths(userId),...suppressMonths])].sort()),userId);}
      if(reset||floor){this.ensureRow(userId);if(reset)this.db.prepare('UPDATE privacy_settings SET legacy_import_disabled=1 WHERE user_id=?').run(userId);if(floor)this.db.prepare('UPDATE privacy_settings SET legacy_import_floor=MAX(COALESCE(legacy_import_floor,?),?) WHERE user_id=?').run(floor,floor,userId);}
      if(prepared)this.db.prepare('INSERT INTO privacy_cleanup_commits VALUES(?,?,?)').run(id,userId,new Date(this.now()).toISOString());
      return {observationsDeleted:deleted.length,sourceImagesExpired:expired.length,sessionsDeleted,contextSessionsDeleted,reportsDeleted:reports.length};
    });}catch(error){
      if(prepared){try{this.finishJob(job,manifest,true);}catch{this.blocked.add(userId);throw failure(507,'History change was rolled back. Private file recovery is pending; retry cleanup from Admin.');}}
      else{try{this.recover();}catch{this.unknownRecovery=true;}}
      throw failure(507,'History change failed and was rolled back. Your data is retained.');
    }
    let cleanupPending=false;if(prepared){try{this.finishJob(job,manifest,false);}catch{cleanupPending=true;}}
    return {...result,cleanupPending};
  }
  async resetHistory(userId,{deleteReports=false,authorize=()=>{}}={}){
    return this.exclusive(userId,()=>{
      authorize();const records=this.storage.forUser(userId).observations(),sessions=this.storage.forUser(userId).sessions();
      const archived=deleteReports?this.reports.list(userId):[];
      const result=this.apply(userId,{observationIds:records.map(r=>r.id),sessionIds:sessions.filter(s=>s.status!=='active').map(s=>s.id),contextSessionIds:contextSessions(this.storage.forUser(userId)).filter(s=>!['active','paused'].includes(s.status)).map(s=>s.id),reportIds:archived.map(r=>r.id),suppressMonths:archived.map(r=>r.month),reset:true});
      return {deleted:true,...result,activeSessionsPreserved:sessions.filter(s=>s.status==='active').length,activeContextSessionsPreserved:contextSessions(this.storage.forUser(userId)).filter(s=>['active','paused'].includes(s.status)).length,message:'Historical observations and completed context sessions were deleted. Active monitoring runs, active/paused context sessions and their evidence remain. '+(deleteReports?'Selected archived reports were deleted.':'Archived monthly reports remain.')+' Existing external or manual backups are not modified.'};
    });
  }
  async deleteReport(userId,id){return this.exclusive(userId,()=>{const row=this.reports.row(userId,id);return {deleted:true,...this.apply(userId,{reportIds:[id],suppressMonths:[row.month]})};});}
  async generateReport(userId,month,{timeZone}={}){if(timeZone!==undefined){try{calendar(timeZone);}catch{throw failure(400,'Choose a valid time zone.');}}return this.exclusive(userId,async()=>{const report=await this.reports.generate(userId,month,{timeZone:timeZone||this.settings(userId).timeZone,displayName:this.db.prepare('SELECT display_name FROM users WHERE id=?').get(userId)?.display_name});const suppressed=this.suppressedMonths(userId);if(suppressed.delete(month))this.db.prepare('UPDATE privacy_settings SET suppressed_months=? WHERE user_id=?').run(JSON.stringify([...suppressed].sort()),userId);return report;});}
  maintain(userId,{force=false}={}){
    if(this.pending.has(userId))return this.pending.get(userId);
    if(this.closed)return Promise.resolve({skipped:true});
    const prefs=this.settings(userId);
    if(!force&&prefs.lastMaintenance&&this.now()-Date.parse(prefs.lastMaintenance)<3600000)return Promise.resolve({skipped:true});
    if(!prefs.monthlyReports&&prefs.historyRetention==='indefinite'&&!['30-days','90-days'].includes(prefs.snapshotRetention))return Promise.resolve({skipped:true});
    const work=this.exclusive(userId,async()=>{
      let error='';
      if(prefs.monthlyReports){
        const suppressed=this.suppressedMonths(userId),due=this.reports.available(userId,{timeZone:prefs.timeZone}).filter(r=>!suppressed.has(r.month)).slice(0,12);
        for(const month of due){if(this.closed)break;try{await this.reports.generate(userId,month.month,{timeZone:prefs.timeZone,displayName:this.db.prepare('SELECT display_name FROM users WHERE id=?').get(userId)?.display_name});}catch{error='A monthly report could not be preserved. History needed for that report is retained; retry maintenance.';break;}}
      }
      if(this.closed)return {skipped:true};
      const rows=this.storage.forUser(userId).observations(),historyCutoff=retentionCutoff(prefs.historyRetention,this.now(),prefs.timeZone),imageCutoff=retentionCutoff(prefs.snapshotRetention,this.now(),prefs.timeZone),clock=calendar(prefs.timeZone),currentMonth=clock.date(this.now()).slice(0,7),protectedMonths=new Set();
      if(prefs.monthlyReports){const suppressed=this.suppressedMonths(userId);for(const month of new Set(rows.filter(r=>clock.date(r.timestamp).slice(0,7)<currentMonth).map(r=>clock.date(r.timestamp).slice(0,7)))){
        if(suppressed.has(month))continue;
        const archived=this.reports.list(userId).find(r=>r.month===month);try{if(!archived)throw Error();this.reports.get(userId,archived.id);}catch{protectedMonths.add(month);error='A required monthly report is not durably available. Eligible history and images are retained; retry maintenance.';}
      }}
      const permitted=r=>!protectedMonths.has(clock.date(r.timestamp).slice(0,7));
      const result=this.apply(userId,{observationIds:rows.filter(r=>historyCutoff&&r.timestamp<historyCutoff&&permitted(r)).map(r=>r.id),expireIds:rows.filter(r=>imageCutoff&&r.timestamp<imageCutoff&&r.snapshotRef&&permitted(r)).map(r=>r.id),sessionIds:protectedMonths.size?[]:this.storage.forUser(userId).sessions().filter(s=>historyCutoff&&s.status!=='active'&&(s.ended_at||s.updated_at)<historyCutoff).map(s=>s.id),contextSessionIds:protectedMonths.size?[]:contextSessions(this.storage.forUser(userId)).filter(s=>historyCutoff&&!['active','paused'].includes(s.status)&&(s.ended_at||s.updated_at)<historyCutoff).map(s=>s.id),floor:historyCutoff});
      this.ensureRow(userId);this.db.prepare('UPDATE privacy_settings SET last_maintenance=?,maintenance_error=? WHERE user_id=?').run(new Date(this.now()).toISOString(),error,userId);
      return {...result,maintenanceError:error};
    }).catch(error=>{
      if(this.closed)return {skipped:true};
      if(error.status===409)return {skipped:true};
      this.ensureRow(userId);this.db.prepare('UPDATE privacy_settings SET maintenance_error=? WHERE user_id=?').run('Private history maintenance could not complete. Data is retained; retry cleanup or maintenance.',userId);
      return {maintenanceError:'Private history maintenance could not complete. Data is retained; retry cleanup or maintenance.'};
    }).finally(()=>this.pending.delete(userId));
    this.pending.set(userId,work);return work;
  }
  async maintainAll(){
    const users=this.db.prepare("SELECT user_id FROM privacy_settings WHERE monthly_reports=1 OR history_retention!='indefinite' OR snapshot_retention IN ('30-days','90-days') LIMIT 100").all();
    for(const {user_id} of users){if(this.closed)break;await this.maintain(user_id,{force:true});}
  }
}
