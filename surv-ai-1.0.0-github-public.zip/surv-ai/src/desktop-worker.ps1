param([switch]$Synthetic)
# One automatically managed host. No screen capture, child/control text,
# input hooks, process enumeration, profile access or process-memory reads.
$ErrorActionPreference = 'Stop'
[Console]::InputEncoding = [Text.UTF8Encoding]::new($false)
[Console]::OutputEncoding = [Text.UTF8Encoding]::new($false)
Add-Type -TypeDefinition @'
using System;
using System.Text;
using System.IO;
using System.Runtime.InteropServices;
public static class SurvDesktop {
  [DllImport("user32.dll")] static extern IntPtr GetForegroundWindow();
  [DllImport("user32.dll")] static extern uint GetWindowThreadProcessId(IntPtr hwnd, out uint pid);
  [DllImport("user32.dll", CharSet=CharSet.Unicode,ExactSpelling=true)] static extern int GetWindowTextW(IntPtr hwnd, StringBuilder text, int length);
  [DllImport("user32.dll")] static extern bool GetLastInputInfo(ref INPUT info);
  [StructLayout(LayoutKind.Sequential)] struct INPUT { public uint size; public uint time; }
  [DllImport("kernel32.dll")] static extern uint GetTickCount();
  [DllImport("kernel32.dll")] static extern uint GetCurrentProcessId();
  [DllImport("kernel32.dll")] static extern bool ProcessIdToSessionId(uint pid,out uint session);
  [DllImport("kernel32.dll")] static extern IntPtr OpenProcess(uint rights,bool inherit,uint pid);
  [DllImport("kernel32.dll",CharSet=CharSet.Unicode,ExactSpelling=true)] static extern bool QueryFullProcessImageNameW(IntPtr process,uint flags,StringBuilder name,ref uint size);
  [DllImport("kernel32.dll")] static extern bool CloseHandle(IntPtr handle);
  [DllImport("user32.dll")] static extern IntPtr OpenInputDesktop(uint flags,bool inherit,uint rights);
  [DllImport("user32.dll")] static extern bool CloseDesktop(IntPtr desktop);
  [DllImport("user32.dll",CharSet=CharSet.Unicode,ExactSpelling=true)] static extern bool GetUserObjectInformationW(IntPtr h,int index,StringBuilder value,uint size,out uint needed);
  [DllImport("wtsapi32.dll",CharSet=CharSet.Unicode,ExactSpelling=true)] static extern bool WTSQuerySessionInformationW(IntPtr server,uint session,int type,out IntPtr buffer,out uint bytes);
  [DllImport("wtsapi32.dll")] static extern void WTSFreeMemory(IntPtr buffer);
  // Define native layout to derive alignment, but read only Level/SessionFlags.
  [StructLayout(LayoutKind.Sequential,CharSet=CharSet.Unicode)] struct LEVEL1 {
    public uint session; public uint state; public int flags;
    [MarshalAs(UnmanagedType.ByValTStr,SizeConst=33)] public string station;
    [MarshalAs(UnmanagedType.ByValTStr,SizeConst=21)] public string user;
    [MarshalAs(UnmanagedType.ByValTStr,SizeConst=18)] public string domain;
    public long logon,connect,disconnect,lastInput,current;
    public uint incoming,outgoing,inFrames,outFrames,inCompressed,outCompressed;
  }
  [StructLayout(LayoutKind.Sequential)] struct INFO { public uint level; public LEVEL1 data; }
  public class Sample { public string executable, title, state, sampledAt; public long? idleMs; }
  static int LockState() {
    uint session,bytes; IntPtr b;
    // Windows 7 reversed these flags; do not guess on those legacy systems.
    if(Environment.OSVersion.Version.Major<6 || (Environment.OSVersion.Version.Major==6 && Environment.OSVersion.Version.Minor<2)) return -1;
    if(!ProcessIdToSessionId(GetCurrentProcessId(),out session)||!WTSQuerySessionInformationW(IntPtr.Zero,session,25,out b,out bytes))return -1;
    try { int offset=(int)Marshal.OffsetOf(typeof(INFO),"data")+(int)Marshal.OffsetOf(typeof(LEVEL1),"flags");
      return bytes>=offset+4 && Marshal.ReadInt32(b)==1?Marshal.ReadInt32(b,offset):-1;
    } finally { WTSFreeMemory(b); }
  }
  public static Sample Read(bool title, long threshold) {
    var result=new Sample { state="unavailable", sampledAt=DateTime.UtcNow.ToString("o") };
    if(LockState()==0){result.state="locked";return result;}
    IntPtr desktop=OpenInputDesktop(0,false,1);
    if(desktop==IntPtr.Zero)return result;
    try { var name=new StringBuilder(128);uint needed;
      if(!GetUserObjectInformationW(desktop,2,name,256,out needed)||!String.Equals(name.ToString(),"Default",StringComparison.OrdinalIgnoreCase))return result;
    } finally { CloseDesktop(desktop); }
    INPUT input=new INPUT {size=(uint)Marshal.SizeOf(typeof(INPUT))};
    if(GetLastInputInfo(ref input)){result.idleMs=(long)unchecked(GetTickCount()-input.time);result.state=result.idleMs>=threshold?"idle":"active";}
    else result.state="unknown";
    IntPtr hwnd=GetForegroundWindow();uint pid;
    if(hwnd==IntPtr.Zero || GetWindowThreadProcessId(hwnd,out pid)==0)return result;
    IntPtr process=OpenProcess(0x1000,false,pid);
    if(process!=IntPtr.Zero)try {var name=new StringBuilder(32768);uint size=32768;
      if(QueryFullProcessImageNameW(process,0,name,ref size))result.executable=Path.GetFileName(name.ToString());
    }finally {CloseHandle(process);}
    if(title){var text=new StringBuilder(321);GetWindowTextW(hwnd,text,text.Capacity);result.title=text.ToString();}
    // A focus change during the reads must not pair one app with another title.
    if(GetForegroundWindow()!=hwnd){result.executable=null;result.title=null;}
    return result;
  }
}
'@
while ($null -ne ($line = [Console]::ReadLine())) {
  try {
    $request = $line | ConvertFrom-Json
    if ($request.op -eq 'stop') { break }
    if ($request.op -ne 'sample') { continue }
    if ($Synthetic) { $process = [Diagnostics.Process]::GetCurrentProcess(); $process.Refresh(); $value = @{ executable='fixture.exe'; title=$(if($request.includeTitle){'Synthetic fixture window'}else{$null}); state='active'; idleMs=100; metrics=@{cpuMs=$process.TotalProcessorTime.TotalMilliseconds; workingSet=$process.WorkingSet64; privateBytes=$process.PrivateMemorySize64; handles=$process.HandleCount; flagsOffset=[Runtime.InteropServices.Marshal]::OffsetOf([SurvDesktop].GetNestedType('INFO',[Reflection.BindingFlags]::NonPublic),'data').ToInt32()+8 } }; $process.Dispose() }
    else { $value = [SurvDesktop]::Read([bool]$request.includeTitle, [long]$request.idleThresholdMs) }
    if ($Synthetic) { $value.sampledAt = [DateTime]::UtcNow.ToString('o') }
    [Console]::WriteLine((@{ id=$request.id; sample=$value } | ConvertTo-Json -Depth 4 -Compress))
  } catch { [Console]::WriteLine('{"error":"Desktop metadata unavailable"}') }
}
