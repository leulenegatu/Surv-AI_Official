import {desktopAggregate} from './desktop-store.mjs';
import {contextHistory} from './context-history.mjs';
import {analytics} from './intelligence.mjs';
import {calendar,rangeBounds,dayBounds} from './local-calendar.mjs';

// Presentation reads only. Existing persisted counters remain authoritative.
function distribution(values,total){
  const counts=new Map();for(const label of values)counts.set(label,(counts.get(label)||0)+1);
  return [...counts].map(([label,count])=>({label,count,percent:total?100*count/total:0})).sort((a,b)=>b.count-a.count||a.label.localeCompare(b.label));
}
function cameraNames(cameras,records,sessions){
  const names=new Map(cameras.map(c=>[c.id,{name:c.name,historical:!!c.deleted_at}]));
  for(const r of records)if(r.cameraId&&!names.has(r.cameraId))names.set(r.cameraId,{name:r.cameraName||'Unknown camera',historical:true});
  for(const s of sessions)if(s.camera_id&&!names.has(s.camera_id))names.set(s.camera_id,{name:s.camera_name||'Unknown camera',historical:true});
  const groups=new Map();for(const [id,value] of names){if(!groups.has(value.name))groups.set(value.name,[]);groups.get(value.name).push(id);}
  return new Map([...names].map(([id,value])=>{const ids=groups.get(value.name).sort();return [id,value.name+(value.historical?' · Historical camera':'')+(ids.length>1?' · Camera '+(ids.indexOf(id)+1):'')];}));
}
export function analyticsExplorer(storage,{from,to,timeZone,now=Date.now()}){
  if(!storage.userId)throw Error('Authenticated user required.');
  const bounds=rangeBounds(from,to,timeZone),clock=calendar(timeZone),records=storage.observations(bounds),started=storage.sessions(bounds),spanning=storage.reportSessions(bounds);
  const data=analytics(records,started,{from,to,timeZone,cameras:storage.cameras()});
  data.desktop=desktopAggregate(storage,bounds,{now});
  data.contextSessions=contextHistory(storage,bounds,{now});
  const names=cameraNames(storage.cameras({historical:true}),records,spanning),cameraLabel=(id,name,source)=>id?(names.get(id)||name||'Unknown camera'):source==='manual_ai'?'Manual AI · no camera':'Unassigned camera';
  // Labels retain their exact saved spelling, punctuation and case. No semantic grouping.
  data.activities=distribution(records.map(r=>r.activity),records.length);
  data.objects=distribution(records.flatMap(r=>[...new Set(r.objects)]),records.length);
  const cameras=new Map();for(const r of records){const key=r.cameraId||r.source;if(!cameras.has(key))cameras.set(key,{id:r.cameraId,label:cameraLabel(r.cameraId,r.cameraName,r.source),count:0});cameras.get(key).count++;}
  data.byCamera=[...cameras.values()].sort((a,b)=>b.count-a.count||a.label.localeCompare(b.label));
  const hasUsage=!!storage.db.prepare("SELECT name FROM sqlite_master WHERE name='analysis_usage'").get();
  const contexts=hasUsage?storage.db.prepare("SELECT session_id,interval_ms,smart_surv,configuration_changed FROM analysis_usage WHERE user_id=? AND kind='session'").all(storage.userId):[];
  const contextMap=new Map(contexts.map(c=>[c.session_id,c]));
  const savedCounts=new Map(storage.db.prepare('SELECT monitoring_session_id id,COUNT(*) count FROM observations WHERE user_id=? AND monitoring_session_id IS NOT NULL GROUP BY monitoring_session_id').all(storage.userId).map(r=>[r.id,r.count]));
  const sessions=spanning.map(s=>{
    const context=contextMap.get(s.id),start=Date.parse(s.started_at),last=Date.parse(s.status==='completed'&&s.ended_at?s.ended_at:s.updated_at),end=Math.max(start,Math.min(now,last));
    return {id:s.id,camera:cameraLabel(s.camera_id,s.camera_name,'automatic_ai'),status:s.status,start:s.started_at,end:s.status==='completed'?s.ended_at:null,lastRecorded:s.updated_at,recordedThrough:new Date(end).toISOString(),spanMs:end-start,
      intervalMs:s.interval_ms??null,initialIntervalMs:context?.interval_ms??null,smartSurv:context&&[0,1].includes(context.smart_surv)?context.smart_surv===1:null,configurationChanged:context?!!context.configuration_changed:null,
      requests:s.api_requests,successes:s.successful_analyses,failures:s.failed_analyses,noPerson:s.no_person_skipped,invalid:s.invalid_frame_skipped,savedObservations:savedCounts.get(s.id)||0};
  }).filter(s=>Date.parse(s.start)<Date.parse(bounds.to)&&(Date.parse(s.recordedThrough)>Date.parse(bounds.from)||Date.parse(s.start)>=Date.parse(bounds.from)));
  const recordsByDay=new Map();for(const r of records){const date=clock.date(r.timestamp);if(!recordsByDay.has(date))recordsByDay.set(date,[]);recordsByDay.get(date).push(r);}
  data.days=data.byDay.map(d=>{
    const b=dayBounds(d.label,timeZone),lo=Date.parse(b.from),hi=Date.parse(b.to),dayRecords=recordsByDay.get(d.label)||[],hourly=Array.from({length:24},(_,hour)=>({label:String(hour).padStart(2,'0')+':00',count:0}));
    for(const r of dayRecords)hourly[clock.hour(r.timestamp)].count++;
    const runs=sessions.filter(s=>Date.parse(s.start)<hi&&(Date.parse(s.recordedThrough)>lo||Date.parse(s.start)>=lo)).map(s=>{const a=Math.max(lo,Date.parse(s.start)),z=Math.max(a,Math.min(hi,Date.parse(s.recordedThrough)));return {...s,desktop:desktopAggregate(storage,b,{sessionId:s.id,now}),clippedStart:new Date(a).toISOString(),clippedEnd:new Date(z).toISOString(),clippedSpanMs:z-a,left:100*(a-lo)/(hi-lo),width:100*(z-a)/(hi-lo),savedOnDay:dayRecords.filter(r=>r.monitoringSessionId===s.id).length};});
    const dayCameras=new Map();for(const r of dayRecords){const key=r.cameraId||r.source;if(!dayCameras.has(key))dayCameras.set(key,{id:r.cameraId,label:cameraLabel(r.cameraId,r.cameraName,r.source),count:0});dayCameras.get(key).count++;}
    return {contextSessions:contextHistory(storage,b,{now}),desktop:desktopAggregate(storage,b,{now}),date:d.label,count:d.count,automatic:dayRecords.filter(r=>r.source==='automatic_ai').length,manual:dayRecords.filter(r=>r.source==='manual_ai').length,averageConfidence:dayRecords.length?dayRecords.reduce((n,r)=>n+r.confidence,0)/dayRecords.length:null,hours:hourly,sessions:runs,activities:distribution(dayRecords.map(r=>r.activity),dayRecords.length),objects:distribution(dayRecords.flatMap(r=>[...new Set(r.objects)]),dayRecords.length),byCamera:[...dayCameras.values()].sort((a,b)=>b.count-a.count||a.label.localeCompare(b.label)),dayHours:(hi-lo)/3600000,ticks:Array.from({length:5},(_,i)=>({percent:i*25,label:i===4?'Midnight':clock.time(new Date(lo+(hi-lo)*i/4))}))};
  });
  data.overlappingSessions=sessions.length;return data;
}
