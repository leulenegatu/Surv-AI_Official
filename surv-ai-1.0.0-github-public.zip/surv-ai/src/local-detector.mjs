import {spawn} from 'node:child_process';
import {createInterface} from 'node:readline';
import {existsSync} from 'node:fs';
import path from 'node:path';
import os from 'node:os';

export class LocalDetector{
  constructor(root){this.root=root;this.child=null;this.pending=null;this.starting=null;this.startControl=null;this.queue=Promise.resolve();this.generation=0;this.unavailableUntil=0;}
  async start(){
    if(this.child&&this.ready)return;
    if(this.starting)return this.starting;
    if(Date.now()<this.unavailableUntil)throw Error('Local OpenCV detector unavailable. Retry shortly or check setup-local.ps1.');
    const operation=new Promise((resolve,reject)=>{
      const python=process.env.SURV_PYTHON||(process.platform==='win32'?'python':'python3');
      const env={...process.env};delete env.OPENAI_API_KEY;
      const child=spawn(python,[path.join(this.root,'src','local_detector.py')],{cwd:this.root,env,stdio:['pipe','pipe','pipe'],windowsHide:true});this.child=child;
      const reader=createInterface({input:child.stdout});
      const timer=setTimeout(()=>fail(),15000);
      const fail=(error=Error('Local OpenCV detector unavailable. Run setup-local.ps1 or check SURV_PYTHON.'))=>{
        this.unavailableUntil=Date.now()+10000;
        clearTimeout(timer);reader.close();
        if(this.child===child){this.ready=false;this.child=null;this.rejectPending(Error('Local detector stopped.'));}
        if(this.startControl?.child===child)this.startControl=null;
        reject(error);child.kill();
      };
      this.startControl={child,fail};
      // Never forward stderr: frames, credentials, and raw subprocess diagnostics stay out of logs.
      child.stderr.resume();child.on('error',()=>fail());
      child.stdin.on('error',()=>{if(this.child===child)fail(Error('Local detector stopped.'));});
      child.on('exit',()=>{if(this.child===child)fail();});
      reader.on('line',line=>{
        if(this.child!==child)return;
        let data;try{data=JSON.parse(line);}catch{fail();return;}
        if(data.ready){clearTimeout(timer);this.ready=true;resolve();return;}
        if(!this.ready){fail();return;}
        const pending=this.pending;this.pending=null;if(!pending)return;
        clearTimeout(pending.timer);if(data.error)pending.reject(Error(data.error));else pending.resolve(data);
      });
    }).finally(()=>{if(this.starting===operation)this.starting=null;});
    this.starting=operation;
    return this.starting;
  }
  async inspect(image,{threshold=.25}={}){
    // Ordered local jobs keep each frame paired with its own camera's result.
    const generation=this.generation;
    const job=this.queue.then(()=>{if(generation!==this.generation)throw Error('Local detector stopped.');return this.inspectOne(image,threshold);});this.queue=job.catch(()=>{});return job;
  }
  async inspectOne(image,threshold=.25){
    await this.start();if(!this.child||!this.ready)throw Error('Local detector stopped.');if(this.pending)throw Error('Local detector is already checking a frame.');
    return new Promise((resolve,reject)=>{
      const timer=setTimeout(()=>{this.pending=null;this.close();this.unavailableUntil=Date.now()+10000;reject(Error('Local detector timed out. Auto Monitoring has stopped.'));},10000);
      this.pending={resolve,reject,timer};this.child.stdin.write(JSON.stringify({image,threshold})+'\n');
    });
  }
  rejectPending(error){if(this.pending){clearTimeout(this.pending.timer);this.pending.reject(error);this.pending=null;}}
  close(){
    this.generation++;this.ready=false;
    this.rejectPending(Error('Local detector stopped.'));
    if(this.startControl)this.startControl.fail(Error('Local detector stopped.'));
    else{this.child?.kill();this.child=null;}
    this.unavailableUntil=0;
  }
}
