import {spawn} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
import {DESKTOP_IDLE_MS} from './desktop-store.mjs';

const friendly={'code.exe':'Visual Studio Code','chrome.exe':'Google Chrome','msedge.exe':'Microsoft Edge','firefox.exe':'Firefox','discord.exe':'Discord','explorer.exe':'Windows Explorer','notepad.exe':'Notepad'};
const text=(value,max)=>typeof value==='string'?value.replace(/[\u0000-\u001f\u007f]/g,' ').slice(0,max):null;
export function cleanDesktopSample(raw,{includeTitle=false,now=Date.now()}={}){
  const sourceTime=raw?.sampledAt===undefined?now:Date.parse(raw.sampledAt);
  if(!Number.isFinite(sourceTime)||sourceTime>now||now-sourceTime>6000)return {sampledAt:new Date(now).toISOString(),executable:null,application:null,title:null,state:'unavailable',idleMs:null};
  const state=['active','idle','locked','unavailable','unknown'].includes(raw?.state)?raw.state:'unavailable',hidden=['locked','unavailable'].includes(state);
  const executable=hidden?null:text(typeof raw?.executable==='string'?raw.executable.split(/[\\/]/).at(-1):null,120);
  return {sampledAt:new Date(sourceTime).toISOString(),executable,application:executable?(friendly[executable.toLowerCase()]||executable):null,title:includeTitle&&!hidden?text(raw?.title,320):null,state,idleMs:hidden?null:Number.isSafeInteger(raw?.idleMs)&&raw.idleMs>=0?raw.idleMs:null};
}
// stdin closes with the parent; the worker exits. One outstanding request only.
export class WindowsDesktopCollector {
  constructor({platform=process.platform,spawnImpl=spawn,synthetic=false}={}){this.platform=platform;this.spawn=spawnImpl;this.synthetic=synthetic;this.child=null;this.pending=null;this.sequence=0;this.buffer='';this.spawns=0;this.cooldown=0;}
  start(){
    if(this.platform!=='win32'||this.child||Date.now()<this.cooldown)return;
    const executable=path.join(process.env.SystemRoot||'C:\\Windows','System32','WindowsPowerShell','v1.0','powershell.exe');
    const env={...process.env};delete env.OPENAI_API_KEY;
    const child=this.spawn(executable,['-NoLogo','-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-File',fileURLToPath(new URL('./desktop-worker.ps1',import.meta.url)),...(this.synthetic?['-Synthetic']:[])],{env,windowsHide:true,stdio:['pipe','pipe','pipe']});this.child=child;this.spawns++;this.buffer='';
    const failed=()=>{if(this.child!==child)return;this.child=null;this.buffer='';this.cooldown=Date.now()+60000;this.finish({state:'unavailable'});child.kill();};
    child.on('error',failed);child.on('exit',failed);child.stdin.on('error',failed);child.stderr.resume();
    child.stdout.setEncoding('utf8');child.stdout.on('data',chunk=>{if(this.child!==child)return;this.buffer+=chunk;if(this.buffer.length>8192){failed();return;}
      let end;while((end=this.buffer.indexOf('\n'))>=0){const line=this.buffer.slice(0,end);this.buffer=this.buffer.slice(end+1);try{const value=JSON.parse(line);if(value.id===this.pending?.id)this.finish(value.sample);else if(value.error)this.finish({state:'unavailable'});}catch{failed();}}
    });
  }
  finish(value){const p=this.pending;if(!p)return;this.pending=null;clearTimeout(p.timer);p.resolve(value);}
  sample({includeTitle=false}={}){
    if(this.pending)return this.pending.promise;
    this.start();if(!this.child)return Promise.resolve({state:'unavailable'});
    let resolve;const promise=new Promise(r=>resolve=r),id=++this.sequence;
    this.pending={id,promise,resolve,timer:setTimeout(()=>{this.close();this.cooldown=Date.now()+60000;},10000)};
    this.child.stdin.write(JSON.stringify({op:'sample',id,includeTitle,idleThresholdMs:DESKTOP_IDLE_MS})+'\n');return promise;
  }
  close(){const child=this.child;this.child=null;this.buffer='';this.finish({state:'unavailable'});if(child){child.stdin.end();child.kill();}}
}
