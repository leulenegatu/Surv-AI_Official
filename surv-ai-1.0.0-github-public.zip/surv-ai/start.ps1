param([switch]$Test)
$taskNodeCommand = Get-Command node -ErrorAction SilentlyContinue
$taskNodeRecord = Join-Path $PSScriptRoot '.local-runtime\node-path.txt'
$taskNodePath = if (Test-Path -LiteralPath $taskNodeRecord) { (Get-Content -LiteralPath $taskNodeRecord -Raw -Encoding UTF8).Trim() } elseif ($taskNodeCommand) { $taskNodeCommand.Source } else { throw 'Install Node.js 24.7 or newer, reopen PowerShell, and run setup.ps1.' }
if (-not (Test-Path -LiteralPath $taskNodePath)) { throw 'The configured Node executable is unavailable. Run setup.ps1 again to select the installed Node runtime.' }
$taskNodeVersion = [version]((& $taskNodePath --version) -replace '^v', '')
if ($taskNodeVersion -lt [version]'24.7.0') { throw 'Surv-AI requires Node.js 24.7 or newer for native SQLite and Argon2id.' }
Push-Location $PSScriptRoot
$taskExitCode = 1
try {
  if ($Test) {
    $taskTestFiles = Get-ChildItem -Path tests -Filter '*.test.mjs' | ForEach-Object { $_.FullName }
    & $taskNodePath --test --test-concurrency=1 $taskTestFiles
  } else {
    & $taskNodePath server.mjs
  }
  $taskExitCode = $LASTEXITCODE
} finally { Pop-Location }
exit $taskExitCode
