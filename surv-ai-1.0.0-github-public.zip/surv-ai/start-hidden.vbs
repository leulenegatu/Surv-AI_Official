' GUI-subsystem entry point: no console is ever shown. Wait so Scheduler tracks the host.
Option Explicit
Dim shell, files, root, command, index, result, message, logFile, runtime
Set shell = CreateObject("WScript.Shell")
Set files = CreateObject("Scripting.FileSystemObject")
root = files.GetParentFolderName(WScript.ScriptFullName)
shell.CurrentDirectory = root
command = Quote(shell.ExpandEnvironmentStrings("%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"))
If WScript.Arguments.Count = 0 Then
  command = command & " -NoProfile -NonInteractive -ExecutionPolicy Bypass -WindowStyle Hidden -File " & Quote(root & "\background.ps1") & " -Action Run"
Else
  For index = 0 To WScript.Arguments.Count - 1
    command = command & " " & Quote(WScript.Arguments(index))
  Next
End If
On Error Resume Next
result = shell.Run(command, 0, True)
If Err.Number <> 0 Then
  message = "Hidden launcher could not start PowerShell: " & Err.Description
  Err.Clear
  runtime = root & "\.local-launcher"
  If Not files.FolderExists(runtime) Then files.CreateFolder(runtime)
  If Not files.FolderExists(runtime & "\logs") Then files.CreateFolder(runtime & "\logs")
  Set logFile = files.OpenTextFile(runtime & "\logs\bootstrap-errors.log", 8, True, -1)
  logFile.WriteLine CStr(Now) & " " & message
  logFile.Close
  WScript.Quit 1
End If
WScript.Quit result
Function Quote(value)
  Quote = Chr(34) & Replace(value, Chr(34), Chr(34) & Chr(34)) & Chr(34)
End Function
